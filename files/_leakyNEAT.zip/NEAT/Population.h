#ifndef __NEAT_POPULATION_H__
#define __NEAT_POPULATION_H__

#include "NEAT.h"
#include "NEAT_Utilities.h"

//Forward declarations
class Innovation;
//struct Generation_viz;

//Description: 

/* ---------------------------------------------  */
/* POPULATION CLASS:
   A Population is a group of Organisms   
   including their species                        */
/* ---------------------------------------------  */
class Population
{
public:
  /* Construct off of a single spawning Genome */
  Population(Genome *g, int size, bool mutateInitialWeights);

  /* Special constructor to create a population of random topologies */
  // uses Genome(int i, int o, int n,int nmax, bool r, double linkprob) 
  //See the Genome constructor above for the argument specifications
  //Population(int size,int i,int o, int nmax, bool r, double linkprob);

  /* Construct off of a file of Genomes */
  //Population(char *filename);

  //It can delete a Population in two ways:
  //-delete by killing off the species
  //-delete by killing off the organisms themselves (if not speciated)
  //It does the latter if it sees the species std::list is empty
  ~Population();

 protected: 

  /* A Population can be spawned off of a single Genome */
  /* There will be size Genomes added to the Population */
  /* The Population does not have to be empty to add Genomes */
  bool spawn(Genome *g, int size, bool mutate);

 public:

  std::list<Organism*> organisms; //The organisms in the Population

  std::list<Species*> species;  /* Species in the Population
				   Note that the species should comprise
				   all the genomes */

  /* Member variables used during reproduction */

  std::list<Innovation*> innovations;  /* For holding the genetic innovations
				     of the newest generation */
  int cur_node_id;  //Current label number available
  double cur_innov_num;

  int last_species;  //The highest species number

  int final_gen;  //The last generation played

  //std::list<Generation_viz*> generation_snapshots; /* Visualization of Speciation History */

  ///* Fitness Statistics */
  //double mean_fitness;
  //double variance;
  //double standard_deviation;

  double GetMinFitness();
  double GetMaxFitness();
  double GetAvgFitness();
  int GetMinComplexity();
  int GetMaxComplexity();
  double GetAvgComplexity();
  const Organism* GetChamp();
  void ResetHighestFitnesses();

  //An integer that when above zero tells when the first winner appeared
  int winnergen;
  
  /*  When do we need to delta code?  */
  double highest_fitness;  //Stagnation detector
  int highest_last_changed; //If too high, leads to delta coding

  bool speciate(); //Separate the Organisms into species

  //Print Population to a file specified by a string 
  //bool print_to_file(char *filename);

  //Print Population to a file in speciated order with comments
  //separating each species
  //bool print_to_file_by_species(char *filename);

  //Run verify on all Genomes in this Population (Debugging)
  //bool verify();

  //Turnover the population to a new generation using fitness 
  //The generation argument is the next generation
  bool epoch(int generation);//, std::fstream& statsFile, bool outputStats);

  //Take a snapshot of the current generation for visualization purpose
  //void snapshot();
};

#endif

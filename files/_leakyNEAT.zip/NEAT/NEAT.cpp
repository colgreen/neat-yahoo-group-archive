#include "NEAT.h"
#include <time.h>

namespace NEAT
{
	//const int num_trait_params=8;

	//double testvar;

	//double trait_param_mut_prob; /* Prob. of mutating a single trait param */
	//double trait_mutation_power; /* Power of mutation on a signle trait param */
	//double linktrait_mut_sig;  /* Amount that mutation_num changes for a trait change inside a link*/
	//double nodetrait_mut_sig; /* Amount a mutation_num changes on a link connecting a node that changed its trait */
	double weight_mut_power;  /* The power of a linkweight mutation */
  
  /* These 3 global coefficients are used to determine the formula for
     computating the compatibility between 2 genomes.  The formula is:
     disjoint_coeff*pdg+excess_coeff*peg+mutdiff_coeff*mdmg.
     See the compatibility method in the Genome class for more info
     They can be thought of as the importance of disjoint Genes,
     excess Genes, and parametric difference between Genes of the
     same function, respectively. */
	double disjoint_coeff;
	double excess_coeff;
	double mutdiff_coeff;
	double biasdiff_coeff;
	double time_constant_diff_coeff;  

	/* This global tells compatibility threshold under which 
		two Genomes are considered the same species */
	double compat_threshold;
	double initial_compat_threshold;
  
	/* Globals involved in the epoch cycle - mating, reproduction, etc.. */
	double age_significance;          /* How much does age matter? */
	double reproducing_fraction;           /* Percent of pop that gets to reproduce */
	double mutate_only_prob;          /* Prob. of a non-mating reproduction */
	//double mutate_random_trait_prob;
	//double mutate_link_trait_prob;
	//double mutate_node_trait_prob;
	//double mutate_link_weights_prob;
	double mutate_toggle_enable_prob;
	double mutate_gene_reenable_prob;
	double mutate_add_node_prob;
	double mutate_add_link_prob;
	double interspecies_mate_rate;    /* Prob. of a mate being outside species */
	double mate_multipoint_prob;     
	double mate_multipoint_avg_prob;
	//double mate_singlepoint_prob;
	double mate_only_prob;            /* Prob. of mating without mutation */
	//double recur_only_prob;  /* Probability of forcing selection of ONLY links that are naturally recurrent */
	int dropoff_age;  /* Age where Species starts to be penalized */
	int newlink_tries;  /* Number of tries mutate_add_link will attempt to
				find an open link */

	int num_runs; /* The number of runs to average over in an experiment */
	int pop_size;  /* Size of population */
	//int print_every; /* Tells to print population to file every n generations */

	//On average, mutate this number of parameters per genome.
	double avg_mutations_per_genome;

	//Each genome has this probability of having all parameters mutated.
	double mutate_all_params_prob;

	//Used to calculate parameter mutation powers; ranges from 0.0 to 1.0
	double param_mut_power;

	double link_weight_clamp;

	//When a new population is created, multiply the initial mutation rate by this amount.
	double initial_mutation_factor;

	double min_time_constant;
	double max_time_constant;
	double time_constant_mut_power;
	//double mutate_time_constants_prob;

	double bias_clamp;
	//double mutate_biases_prob;
	double bias_mut_power;
	unsigned int random_seed;
	bool use_nevt;

	double link_weight_range;
	double bias_range;
	double time_constant_range;

	void InitParams()
	{
		pop_size = 0;
		mutate_add_node_prob = 0.0;
		mutate_add_link_prob = 0.0;
		avg_mutations_per_genome = 0.0;
		mutate_all_params_prob = 0.0;
		param_mut_power = 0.0;
		//mutate_link_weights_prob = 0.0;
		initial_mutation_factor = 1.0;
		weight_mut_power = 0.0;
		link_weight_clamp = 0.0;
		//mutate_time_constants_prob = 0.0;
		time_constant_mut_power = 0.0;
		min_time_constant = 0.0;
		max_time_constant = 0.0;
		//mutate_biases_prob = 0.0;
		bias_mut_power = 0.0;
		bias_clamp = 0.0;
		//trait_param_mut_prob  = 0.0;
		//trait_mutation_power = 0.0;
		//linktrait_mut_sig = 0.0;
		//nodetrait_mut_sig = 0.0;
		disjoint_coeff = 0.0;
		excess_coeff = 0.0;
		mutdiff_coeff = 0.0;
		biasdiff_coeff = 0.0;
		time_constant_diff_coeff = 0.0;
		compat_threshold = 0.0;
		initial_compat_threshold = 0.0;
		age_significance = 0.0;
		reproducing_fraction = 0.0;
		mutate_only_prob = 0.0;
		mate_only_prob = 0.0;
		//recur_only_prob = 0.0;
		//mutate_random_trait_prob = 0.0;
		//mutate_link_trait_prob = 0.0;
		//mutate_node_trait_prob = 0.0;
		mutate_toggle_enable_prob = 0.0;
		mutate_gene_reenable_prob = 0.0;
		interspecies_mate_rate = 0.0;
		mate_multipoint_prob = 0.0;
		mate_multipoint_avg_prob = 0.0;
		//mate_singlepoint_prob = 0.0;
		dropoff_age = 0;
		newlink_tries = 0;
		use_nevt = true;
		random_seed = 0;
		link_weight_range = 0.0;
		bias_range = 0.0;
		time_constant_range = 0.0;
	}

	//Return true on success
	bool LoadParams(const std::string& filename)
	{
		std::cout << "Loading NEAT parameters file: " << filename << std::endl;

		TiXmlDocument NEATParams;
		if (false == NEATParams.LoadFile(filename))
		{
			return false;
		}
		
		//Begin loading data
		TiXmlElement* rootElement = NEATParams.RootElement();

		pop_size = atoi(rootElement->FirstChild("PopSize")->FirstChild()->Value());
		mutate_add_node_prob = atof(rootElement->FirstChild("MutateAddNodeProb")->FirstChild()->Value());
		mutate_add_link_prob = atof(rootElement->FirstChild("MutateAddLinkProb")->FirstChild()->Value());
		avg_mutations_per_genome = atof(rootElement->FirstChild("AvgMutationsPerGenome")->FirstChild()->Value());;
		mutate_all_params_prob = atof(rootElement->FirstChild("MutateAllParamsProb")->FirstChild()->Value());;
		param_mut_power = atof(rootElement->FirstChild("ParamMutationPower")->FirstChild()->Value());
		//mutate_link_weights_prob = atof(rootElement->FirstChild("MutateLinkWeightsProb")->FirstChild()->Value());
		initial_mutation_factor = atof(rootElement->FirstChild("InitialMutationFactor")->FirstChild()->Value());
		//weight_mut_power = atof(rootElement->FirstChild("WeightMutPower")->FirstChild()->Value());
		link_weight_clamp = atof(rootElement->FirstChild("LinkWeightClamp")->FirstChild()->Value());
		//mutate_time_constants_prob = atof(rootElement->FirstChild("MutateTimeConstantsProb")->FirstChild()->Value());
		//time_constant_mut_power = atof(rootElement->FirstChild("TimeConstantMutPower")->FirstChild()->Value());
		min_time_constant = atof(rootElement->FirstChild("MinTimeConstant")->FirstChild()->Value());
		max_time_constant = atof(rootElement->FirstChild("MaxTimeConstant")->FirstChild()->Value());
		//mutate_biases_prob = atof(rootElement->FirstChild("MutateBiasesProb")->FirstChild()->Value());
		//bias_mut_power = atof(rootElement->FirstChild("BiasMutPower")->FirstChild()->Value());
		bias_clamp = atof(rootElement->FirstChild("BiasClamp")->FirstChild()->Value());
		//trait_param_mut_prob  = atof(rootElement->FirstChild("TraitParamMutProb")->FirstChild()->Value());
		//trait_mutation_power = atof(rootElement->FirstChild("TraitMutPower")->FirstChild()->Value());
		//linktrait_mut_sig = atof(rootElement->FirstChild("LinkTraitMutSig")->FirstChild()->Value());
		//nodetrait_mut_sig = atof(rootElement->FirstChild("NodeTraitMutSig")->FirstChild()->Value());
		disjoint_coeff = atof(rootElement->FirstChild("DisjointCoeff")->FirstChild()->Value());
		excess_coeff = atof(rootElement->FirstChild("ExcessCoeff")->FirstChild()->Value());
		mutdiff_coeff = atof(rootElement->FirstChild("MutDiffCoeff")->FirstChild()->Value());
		biasdiff_coeff = atof(rootElement->FirstChild("BiasDiffCoeff")->FirstChild()->Value());
		time_constant_diff_coeff = atof(rootElement->FirstChild("TimeConstantDiffCoeff")->FirstChild()->Value());
		initial_compat_threshold = atof(rootElement->FirstChild("CompatThresh")->FirstChild()->Value());
		compat_threshold = initial_compat_threshold;
		age_significance = atof(rootElement->FirstChild("AgeSignificance")->FirstChild()->Value());
		reproducing_fraction = atof(rootElement->FirstChild("ReproducingFraction")->FirstChild()->Value());
		mutate_only_prob = atof(rootElement->FirstChild("MutateOnlyProb")->FirstChild()->Value());
		mate_only_prob = atof(rootElement->FirstChild("MateOnlyProb")->FirstChild()->Value());
		//recur_only_prob = atof(rootElement->FirstChild("RecurOnlyProb")->FirstChild()->Value());
		//mutate_random_trait_prob = atof(rootElement->FirstChild("MutateRandomTraitProb")->FirstChild()->Value());
		//mutate_link_trait_prob = atof(rootElement->FirstChild("MutateLinkTraitProb")->FirstChild()->Value());
		//mutate_node_trait_prob = atof(rootElement->FirstChild("MutateNodeTraitProb")->FirstChild()->Value());
		mutate_toggle_enable_prob = atof(rootElement->FirstChild("MutateToggleEnableProb")->FirstChild()->Value());
		mutate_gene_reenable_prob = atof(rootElement->FirstChild("MutateGeneReenableProb")->FirstChild()->Value());
		interspecies_mate_rate = atof(rootElement->FirstChild("InterspeciesMateRate")->FirstChild()->Value());
		mate_multipoint_prob = atof(rootElement->FirstChild("MateMultipointProb")->FirstChild()->Value());
		mate_multipoint_avg_prob = atof(rootElement->FirstChild("MateMultipointAvgProb")->FirstChild()->Value());
		//mate_singlepoint_prob = atof(rootElement->FirstChild("MateSinglepointProb")->FirstChild()->Value());
		dropoff_age = atoi(rootElement->FirstChild("DropoffAge")->FirstChild()->Value());
		newlink_tries = atoi(rootElement->FirstChild("NewLinkTries")->FirstChild()->Value());
		use_nevt = (bool)atoi(rootElement->FirstChild("UseNEVT")->FirstChild()->Value());
		int temp_random_seed = atoi(rootElement->FirstChild("RandomSeed")->FirstChild()->Value());

		if (-1 == temp_random_seed)
		{
			random_seed = time(NULL);
		}
		else
		{
			random_seed = temp_random_seed;
		}

		weight_mut_power = param_mut_power * 2.0 * link_weight_clamp;
		bias_mut_power = param_mut_power * 2.0 * bias_clamp;
		time_constant_mut_power = param_mut_power * (max_time_constant - min_time_constant);

		link_weight_range = 2.0*link_weight_clamp;
		bias_range = 2.0*bias_clamp;
		time_constant_range = max_time_constant - min_time_constant;

		return true;
	}

	void ResetCompatThreshold()
	{
		compat_threshold = initial_compat_threshold;
	}
}; //end of NEAT namespace

#include "Genome.h"
#include "Species.h"
#include "Organism.h"
#include "Innovation.h"
#include "Network.h"
#include "Population.h"

/* Construct off of a single spawning Genome */
Population::Population(Genome *g, int size, bool mutateInitialWeights) 
{
	winnergen=0;
	highest_fitness=0.0;
	highest_last_changed=0;
	spawn(g, size, mutateInitialWeights);
}

/* Special constructor to create a population of random topologies */
// uses Genome(int i, int o, int n,int nmax, bool r, double linkprob) 
//See the Genome constructor above for the argument specifications
//Population::Population(int size,int i,int o, int nmax, bool r, double linkprob) 
//{
//	int count;
//	Genome *new_genome; 
//
//	std::cout<<"Making a random pop"<<std::endl;
//
//	winnergen=0;
//	highest_fitness=0.0;
//	highest_last_changed=0;
//
//	for(count=0;count<size;count++) {
//		new_genome=new Genome(count,i,o,randint(0,nmax),nmax,r,linkprob);
//		organisms.push_back(new Organism(0,new_genome,1));
//	}
//
//	cur_node_id=i+o+nmax+1;
//	cur_innov_num=(i+o+nmax)*(i+o+nmax)+1;
//
//	std::cout<<"Calling speciate"<<std::endl;
//	speciate(); 
//
//}

/* Construct off of a file of Genomes */
//Population::Population(char *filename) 
//{
//	char curword[20];  //max word size of 20 characters
//
//	std::ifstream iFile(filename,std::ios::in);
//
//	Genome *new_genome;
//
//	winnergen=0;
//
//	highest_fitness=0.0;
//	highest_last_changed=0;
//
//	cur_node_id=0;
//	cur_innov_num=0.0;
//
//	//Make sure it worked
//	if (!iFile)
//	{
//		std::cerr<<"Can't open "<<filename<<" for input"<<std::endl;
//	}
//	else
//	{
//		//Loop until file is finished, parsing each line
//		while (iFile>>curword)
//		{
//			//Check for next
//			if (strcmp(curword,"genomestart")==0)
//			{
//				int idcheck;
//				iFile>>idcheck;
//				new_genome=new Genome(idcheck,iFile);
//				organisms.push_back(new Organism(0,new_genome,1));
//
//				if (cur_node_id<(new_genome->get_last_node_id()))
//				{
//					cur_node_id=new_genome->get_last_node_id();
//				}
//				
//				if (cur_innov_num<(new_genome->get_last_gene_innovnum()))
//				{
//					cur_innov_num=new_genome->get_last_gene_innovnum();
//				}
//			}
//
//			//Ignore comments surrounded by /* */ - they get printed to screen
//			else if (strcmp(curword,"/*")==0)
//			{
//				iFile>>curword;
//
//				while (strcmp(curword,"*/")!=0)
//				{
//					std::cout<<curword<<" ";
//					iFile>>curword;
//				}
//				std::cout<<std::endl;
//			}
//		}
//	    
//		iFile.close();
//		speciate(); 
//	}
//}

//It can delete a Population in two ways:
//-delete by killing off the species
//-delete by killing off the organisms themselves (if not speciated)
//It does the latter if it sees the species std::list is empty
Population::~Population() 
{
	std::list<Species*>::iterator curspec;
	std::list<Organism*>::iterator curorg;
	//std::list<Generation_viz*>::iterator cursnap;

	if (species.begin()!=species.end())
	{
		for(curspec=species.begin();curspec!=species.end();++curspec)
		{
			delete (*curspec);
		}
	}
	else
	{
		for(curorg=organisms.begin();curorg!=organisms.end();++curorg)
		{
			delete (*curorg);
		}
	}
}

//Debug Population
///Note: This checks each genome by verifying each one
//       Only useful for debugging
//bool Population::verify()
//{
//	std::list<Organism*>::iterator curorg;
//
//	bool verification;
//
//	for(curorg=organisms.begin();curorg!=organisms.end();++curorg)
//	{
//		verification=((*curorg)->gnome)->verify();
//	}
//
//	return verification;
//}

//Create a population of size size off of Genome g
//The new Population will have the same topology as g
//with linkweights slightly perturbed from g's (if mutate is true)
bool Population::spawn(Genome *g, int size, bool mutate)
{
  int count;
  Genome *new_genome;
  Organism *new_organism;

  //Create size copies of the Genome
  //Possibly start with perturbed linkweights
	for(count=1;count<=size;count++)
	{
		//std::cout<<"CREATING ORGANISM "<<count<<std::endl;

		new_genome=g->duplicate(count);
		//new_genome->mutate_link_weights(10.0,1.0,GAUSSIAN);

		if (mutate)
		{
			//Mutate the parameters of the initial population.

			if (NEAT::initial_mutation_factor < 0.0)
			{
				//Make all parameters totally random.
				new_genome->randomize_all_parameters();
			}
			else
			{
				if (randfloat()<NEAT::mutate_all_params_prob)
				{
					//Mutate all parameters in the genome.
					for (int i=0; i<NEAT::initial_mutation_factor; i++)
					{
						new_genome->mutate_all_parameters();
					}
				}
				else
				{
					//Mutate a few parameters in the genome.
					for (int i=0; i<NEAT::initial_mutation_factor; i++)
					{
						new_genome->mutate_some_parameters();
					}
				}
			}
		}


		new_organism=new Organism(0.0,new_genome,1);
		organisms.push_back(new_organism);
	}

  //Keep a record of the innovation and node number we are on
  cur_node_id=new_genome->get_last_node_id();
  cur_innov_num=new_genome->get_last_gene_innovnum();

  //Separate the new Population into species
  speciate();

  return true;
}

//speciate separates the organisms into species by
//checking compatibilities against a threshold
//Any organism that does is not compatible with the first
//organism in any existing species becomes a new species
bool Population::speciate()
{
  std::list<Organism*>::iterator curorg;  //For stepping through Population
  std::list<Species*>::iterator curspecies; //Steps through species
  Organism *comporg=0;  //Organism for comparison 
  Species *newspecies; //For adding a new species

  int counter=0; //Species counter

  //Step through all existing organisms
  for(curorg=organisms.begin();curorg!=organisms.end();++curorg)
  {
    //For each organism, search for a species it is compatible to
    curspecies=species.begin();
    if (curspecies==species.end())
	 {
      //Create the first species
      newspecies=new Species(++counter);
      species.push_back(newspecies);
      newspecies->add_Organism(*curorg);  //Add the current organism
      (*curorg)->species=newspecies;  //Point organism to its species
    } 
    else
	 {
      comporg=(*curspecies)->first();

      while((comporg!=0)&&(curspecies!=species.end()))
		{
			 if ((((*curorg)->gnome)->compatibility(comporg->gnome))<NEAT::compat_threshold)
			 {
				//Found compatible species, so add this organism to it
				(*curspecies)->add_Organism(*curorg);
				(*curorg)->species=(*curspecies);  //Point organism to its species
				comporg=0;  //Note the search is over
			}
			else
			{
				//Keep searching for a matching species
				++curspecies;
				if (curspecies!=species.end())
				{
					comporg=(*curspecies)->first();
				}
			}
		}

      //If we didn't find a match, create a new species
      if (comporg!=0)
		{
			newspecies=new Species(++counter);
			species.push_back(newspecies);
			newspecies->add_Organism(*curorg);  //Add the current organism
			(*curorg)->species=newspecies;  //Point organism to its species
      }
    } //end else 
  } //end for

  last_species=counter;  //Keep track of highest species

  return true;
}

//epoch turns over a Population to the next generation based on fitness
bool Population::epoch(int generation)//, std::fstream& statsFile, bool outputStats) 
{
	std::list<Species*>::iterator curspecies;
	std::list<Species*>::iterator deadspecies;  //For removing empty Species

	std::list<Organism*>::iterator curorg;
	std::list<Organism*>::iterator deadorg;

	std::list<Innovation*>::iterator curinnov;  
	std::list<Innovation*>::iterator deadinnov;  //For removing old Innovs

	double total=0.0; //Used to compute average fitness over all Organisms

	double overall_average;  //The average modified fitness among ALL organisms

	int orgcount;

	//The fractional parts of expected offspring that can be 
	//Used only when they accumulate above 1 for the purposes of counting
	//Offspring
	double skim; 
	int total_expected;  //precision checking
	int total_organisms=organisms.size();
	int max_expected;
	Species *best_species;
	int final_expected;

	//int pause;

	//Rights to make babies can be stolen from inferior species
	//and given to their superiors, in order to concentrate exploration on
	//the best species
	//int NUM_STOLEN=NEAT::babies_stolen; //Number of babies to steal
	//int one_fifth_stolen;
	//int one_tenth_stolen;

	std::list<Species*> sorted_species;  //Species sorted by max fit org in Species
	//int stolen_babies; //Babies taken from the bad species and given to the champs

	int half_pop;

	int best_species_num;  //Used in debugging to see why (if) best species dies
	bool best_ok;

	//Record what generation we are on
	final_gen=generation;

	//Keeping species diverse
	//This forces the system to aim for 
	// num_species species at all times, enforcing diversity
	//This tinkers with the compatibility threshold, which
	// normally would be held constant
	//We can try to keep the number of species constant at this number
	int speciesSize = 25;
	int num_species_target=NEAT::pop_size/speciesSize;
	int num_species = species.size();

	double compat_mod=0.3;  //Modify compat thresh to control speciation

	if (generation>1)
	{
		if (num_species<num_species_target)
		{
			NEAT::compat_threshold-=compat_mod;
		}
		else if (num_species>num_species_target)
		{
			NEAT::compat_threshold+=compat_mod;
		}

		if (NEAT::compat_threshold<0.3)
		{
			NEAT::compat_threshold=0.3;
		}
	}

	//std::cout<<"Number of Species: "<<num_species<<std::endl;
	//std::cout<<"compat_thresh: "<<NEAT::compat_threshold<<std::endl;

	//Use Species' ages to modify the objective fitness of organisms
	// in other words, make it more fair for younger species
	// so they have a chance to take hold
	//Also penalize stagnant species
	//Then adjust the fitness using the species size to "share" fitness
	//within a species.
	//Then, within each Species, mark for death 
	//those below survival_thresh*average
	for(curspecies=species.begin();curspecies!=species.end();++curspecies)
	{
		//(*curspecies)->adjust_fitness();
		(*curspecies)->adjust_fitness_fuss_version();
	}

	//Go through the organisms and add up their fitnesses to compute the
	//overall average
	for(curorg=organisms.begin();curorg!=organisms.end();++curorg)
	{
		total+=(*curorg)->fitness;
	}
	overall_average=total/total_organisms;
	//std::cout<<"Generation "<<generation<<": "<<"overall_average = "<<overall_average<<std::endl;
	std::cout << "Overall average = " << overall_average << std::endl;

	//Now compute expected number of offspring for each individual organism
	for(curorg=organisms.begin();curorg!=organisms.end();++curorg)
	{
		(*curorg)->expected_offspring=(((*curorg)->fitness)/overall_average);
	}

	//Now add those offspring up within each Species to get the number of
	//offspring per Species
	skim=0.0;
	total_expected=0;
	for(curspecies=species.begin();curspecies!=species.end();++curspecies)
	{
		skim=(*curspecies)->count_offspring(skim);
		total_expected+=(*curspecies)->expected_offspring;
	}    

	//Need to make up for lost foating point precision in offspring assignment
	//If we lost precision, give an extra baby to the best Species
	if (total_expected<total_organisms)
	{
		//Find the Species expecting the most
		max_expected=0;
		final_expected=0;
		for(curspecies=species.begin();curspecies!=species.end();++curspecies)
		{
			if ((*curspecies)->expected_offspring>=max_expected)
			{
				max_expected=(*curspecies)->expected_offspring;
				best_species=(*curspecies);
			}
			final_expected+=(*curspecies)->expected_offspring;
		}
		//Give the extra offspring to the best species
		++(best_species->expected_offspring);
		final_expected++;

		//If we still arent at total, there is a problem
		//Note that this can happen if a stagnant Species
		//dominates the population and then gets killed off by its age
		//Then the whole population plummets in fitness
		//If the average fitness is allowed to hit 0, then we no longer have 
		//an average we can use to assign offspring.
		if (final_expected<total_organisms)
		{
			std::cout<<"Population died!"<<std::endl;
			//std::cin>>pause;
			for(curspecies=species.begin();curspecies!=species.end();++curspecies)
			{
				(*curspecies)->expected_offspring=0;
			}
			best_species->expected_offspring=total_organisms;
		}
	}

	//Stick the Species pointers into a new Species std::list for sorting
	for(curspecies=species.begin();curspecies!=species.end();++curspecies) 
	{
		sorted_species.push_back(*curspecies);
	}

	//Sort the Species by max fitness (Use an extra list to do this)
	//These need to use ORIGINAL fitness
	sorted_species.sort(order_species);

	best_species_num=(*(sorted_species.begin()))->id;

	//if (outputStats)
	//{
	//	//statsFile << "Overall average = " << overall_average << std::endl;
	//	statsFile << overall_average << " ";
	//}

	//if (outputStats)
	//{
	//	//Temporary until XML is used
	//	curspecies = sorted_species.begin();
	//	statsFile << (*((*curspecies)->organisms).begin())->orig_fitness << " "
	//		<< (*((*curspecies)->organisms).begin())->net->nodecount() << " "
	//		<< (*((*curspecies)->organisms).begin())->net->linkcount() << std::endl;
	//}

	////Print out for Debugging/viewing what's going on; condensed version
	//curspecies = sorted_species.begin();
	//std::cout << "Best Species" << (*curspecies)->id << " (Size " 
	//<< (*curspecies)->organisms.size() << "): last improved "
	//<< ((*curspecies)->age-(*curspecies)->age_of_last_improvement)
	//<< ", Best individual: fitness = " << (*((*curspecies)->organisms).begin())->orig_fitness 
	//<< ", " << (*((*curspecies)->organisms).begin())->net->nodecount() << " nodes, " 
	//<< (*((*curspecies)->organisms).begin())->net->linkcount() << " links" << std::endl;

	//Full output version
	for(curspecies=sorted_species.begin();curspecies!=sorted_species.end();++curspecies)
	{
		//Print out for Debugging/viewing what's going on
		std::cout << "Species" << (*curspecies)->id << " (Size " 
		<< (*curspecies)->organisms.size() << "): last improved "
		<< ((*curspecies)->age-(*curspecies)->age_of_last_improvement)
		<< ", Best individual: fitness = " << (*((*curspecies)->organisms).begin())->orig_fitness 
		<< ", " << (*((*curspecies)->organisms).begin())->net->nodecount() << " nodes, " 
		<< (*((*curspecies)->organisms).begin())->net->linkcount() << " links" << std::endl;

		//if (outputStats)
		//{
		//	statsFile << "Species" << (*curspecies)->id << " (Size " 
		//	<< (*curspecies)->organisms.size() << "): last improved "
		//	<< ((*curspecies)->age-(*curspecies)->age_of_last_improvement)
		//	<< ", Best individual: fitness = " << (*((*curspecies)->organisms).begin())->orig_fitness 
		//	<< ", " << (*((*curspecies)->organisms).begin())->net->nodecount() << " nodes, " 
		//	<< (*((*curspecies)->organisms).begin())->net->linkcount() << " links" << std::endl;
		//}
	}

	//Check for Population-level stagnation
	curspecies=sorted_species.begin();
	(*(((*curspecies)->organisms).begin()))->pop_champ=true; //DEBUG marker of the best of pop
	if (((*(((*curspecies)->organisms).begin()))->orig_fitness)>highest_fitness)
	{
		highest_fitness=((*(((*curspecies)->organisms).begin()))->orig_fitness);
		highest_last_changed=0;
		std::cout<<"NEW POPULATION RECORD FITNESS: "<<highest_fitness<<std::endl;
	}
	else
	{
		++highest_last_changed;
		std::cout<<highest_last_changed<<" generations since last population fitness record: "<<highest_fitness<<std::endl;
	}


	//Check for stagnation- if there is stagnation, perform delta-coding
	if (highest_last_changed>=NEAT::dropoff_age+5)
	{
		std::cout<<"PERFORMING DELTA CODING"<<std::endl;

		highest_last_changed=0;

		half_pop=NEAT::pop_size/2;

		std::cout<<"half_pop"<<half_pop<<" pop_size-halfpop: "<<NEAT::pop_size-half_pop<<std::endl;

		curspecies=sorted_species.begin();

		(*(((*curspecies)->organisms).begin()))->super_champ_offspring=half_pop;
		(*curspecies)->expected_offspring=half_pop;
		(*curspecies)->age_of_last_improvement=(*curspecies)->age;

		++curspecies;

		if (curspecies!=sorted_species.end())
		{
			(*(((*curspecies)->organisms).begin()))->super_champ_offspring=NEAT::pop_size-half_pop;
			(*curspecies)->expected_offspring=NEAT::pop_size-half_pop;
			(*curspecies)->age_of_last_improvement=(*curspecies)->age;

			++curspecies;

			//Get rid of all species under the first 2
			while(curspecies!=sorted_species.end())
			{
				(*curspecies)->expected_offspring=0;
				++curspecies;
			}
		}
		else
		{
			curspecies=sorted_species.begin();
			(*(((*curspecies)->organisms).begin()))->super_champ_offspring+=NEAT::pop_size-half_pop;
			(*curspecies)->expected_offspring=NEAT::pop_size-half_pop;
		}
	}
  
	//Kill off all Organisms marked for death.  The remainder
	//will be allowed to reproduce.
	curorg=organisms.begin();
	while(curorg!=organisms.end())
	{
		if (((*curorg)->eliminate))
		{
			//Remove the organism from its Species
			((*curorg)->species)->remove_org(*curorg);

			//Delete the organism from memory
			delete (*curorg);

			//Remember where we are
			deadorg=curorg;
			++curorg;

			//Remove the organism from the master std::list
			organisms.erase(deadorg);
		}
		else
		{
			++curorg;
		}
	}

	std::cout<<"Reproducing..."<<std::endl;

	//Perform reproduction.  Reproduction is done on a per-Species
	//basis.  (So this could be paralellized potentially.)
	for(curspecies=species.begin();curspecies!=species.end();++curspecies)
	{
		//(*curspecies)->reproduce(generation,this,sorted_species);
		(*curspecies)->reproduce_fuss_version(generation,this,sorted_species);
	}    

	//std::cout<<"Reproduction Complete"<<std::endl;


	//Destroy and remove the old generation from the organisms and species  
	curorg=organisms.begin();
	while(curorg!=organisms.end())
	{
		//Remove the organism from its Species
		((*curorg)->species)->remove_org(*curorg);

		//Delete the organism from memory
		delete (*curorg);

		//Remember where we are
		deadorg=curorg;
		++curorg;

		//Remove the organism from the master std::list
		organisms.erase(deadorg);
	}

	//Remove all empty Species and age ones that survive
	//As this happens, create master organism std::list for the new generation
	curspecies=species.begin();
	orgcount=0;
	while(curspecies!=species.end())
	{
		if (((*curspecies)->organisms.size())==0)
		{
			delete (*curspecies);

			deadspecies=curspecies;
			++curspecies;

			species.erase(deadspecies);
		}
		//Age surviving Species and 
		//Rebuild master Organism std::list: NUMBER THEM as they are added to the std::list
		else
		{
			//Age any Species that is not newly created in this generation
			if ((*curspecies)->novel)
			{
				(*curspecies)->novel=false;
			}
			else
			{
				++((*curspecies)->age);
			}

			//Go through the organisms of the curspecies and add them to 
			//the master std::list
			for(curorg=((*curspecies)->organisms).begin();curorg!=((*curspecies)->organisms).end();++curorg)
			{
				((*curorg)->gnome)->genome_id=orgcount++;
				organisms.push_back(*curorg);
			}
			++curspecies;
		}
	}      

	//Remove the innovations of the current generation
	curinnov=innovations.begin();
	while(curinnov!=innovations.end())
	{
		delete (*curinnov);

		deadinnov=curinnov;
		++curinnov;

		innovations.erase(deadinnov);
	}

  //DEBUG: Check to see if the best species died somehow
  // We don't want this to happen
  //curspecies=species.begin();
  //best_ok=false;
  //while(curspecies!=species.end()) {
  //  if (((*curspecies)->id)==best_species_num) best_ok=true;
  //  ++curspecies;
  //}
  //if (!best_ok) {
  //  std::cout<<"ERROR: THE BEST SPECIES DIED!"<<std::endl;
  //}
  //else {
  //  std::cout<<"The best species survived: species "<<best_species_num<<std::endl;
  //}

  //DEBUG: Checking the top organism's duplicate in the next gen
  //This prints the champ's child to the screen
  //for(curorg=organisms.begin();curorg!=organisms.end();++curorg) {
  //  if ((*curorg)->pop_champ_child) {
  //    std::cout<<"At end of reproduction cycle, the child of the pop champ is: "<<(*curorg)->gnome<<std::endl;
  //  }
  //}

  //std::cout<<"babies_stolen at end: "<<NEAT::babies_stolen<<std::endl;
  
  //std::cout<<"Epoch complete"<<std::endl; 

  return true;
}

const Organism* Population::GetChamp()
{
	const Organism* champ = (*(organisms.begin()));
	double highestFitness = -1.0;

	std::list<Organism*>::iterator iter;
	for (iter = organisms.begin(); iter != organisms.end(); iter++)
	{
		if ((*iter)->fitness > highestFitness)
		{
			champ = (*iter);
			highestFitness = (*iter)->fitness;
		}
	}

	return champ;
}

double Population::GetMinFitness()
{
	std::list<Organism*>::iterator iter = organisms.begin();
	double minFitness = (*iter)->fitness;

	for (iter = organisms.begin(); iter != organisms.end(); iter++)
	{
		if ((*iter)->fitness < minFitness)
		{
			minFitness = (*iter)->fitness;
		}
	}

	return minFitness;
}

double Population::GetMaxFitness()
{
	std::list<Organism*>::iterator iter = organisms.begin();
	double maxFitness = (*iter)->fitness;

	for (iter = organisms.begin(); iter != organisms.end(); iter++)
	{
		if ((*iter)->fitness > maxFitness)
		{
			maxFitness = (*iter)->fitness;
		}
	}

	return maxFitness;
}

double Population::GetAvgFitness()
{
	double totalFitness = 0.0;

	std::list<Organism*>::iterator iter;
	for (iter = organisms.begin(); iter != organisms.end(); iter++)
	{
		totalFitness += (*iter)->fitness;
	}

	return (totalFitness/organisms.size());
}


int Population::GetMinComplexity()
{
	std::list<Organism*>::iterator iter = organisms.begin();
	int minComplexity = (*iter)->gnome->GetComplexity();

	for (iter = organisms.begin(); iter != organisms.end(); iter++)
	{
		int c = (*iter)->gnome->GetComplexity();
		if (c < minComplexity)
		{
			minComplexity = c;
		}
	}

	return minComplexity;
}

int Population::GetMaxComplexity()
{
	std::list<Organism*>::iterator iter = organisms.begin();
	int maxComplexity = (*iter)->gnome->GetComplexity();

	for (iter = organisms.begin(); iter != organisms.end(); iter++)
	{
		int c = (*iter)->gnome->GetComplexity();
		if (c > maxComplexity)
		{
			maxComplexity = c;
		}
	}

	return maxComplexity;
}

double Population::GetAvgComplexity()
{
	double totalComplexity = 0.0;

	std::list<Organism*>::iterator iter;
	for (iter = organisms.begin(); iter != organisms.end(); iter++)
	{
		totalComplexity += (*iter)->gnome->GetComplexity();
	}

	return (totalComplexity/organisms.size());
}

void Population::ResetHighestFitnesses()
{
	highest_fitness = 0.0;

	std::list<Species*>::iterator iter;
	for (iter = species.begin(); iter != species.end(); iter++)
	{
		(*iter)->max_fitness_ever = 0.0;
		(*iter)->age_of_last_improvement = 0;
	}
}

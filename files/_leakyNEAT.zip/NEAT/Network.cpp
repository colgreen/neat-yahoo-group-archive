#include "NEAT_Utilities.h"
#include "NNode.h"
#include "Link.h"
#include <algorithm> //for find() function
#include "Network.h"

#define MIN_ENABLE_MOD_PROB 0.5
#define MAX_ENABLE_MOD_PROB 0.99
#define MOD_INDEX_NOISE 0.01
#define MOD_LEVEL_NOISE 0.1

/* ************************************************************** */
/* *                      NETWORK METHODS HERE                  * */
/* ************************************************************** */

//Network pointer display
//std::ostream& operator<<(std::ostream &os,Network *thenet) {
//  thenet->show_activation();
//  return os; //is this correct?
//}
 
//This constructor allows the input and output lists to be supplied
Network::Network(std::list<NNode*> in,std::list<NNode*> out,
		std::list<NNode*> allNodes, std::list<Link*> allLinks, int netid)
//: MRLSystem(MRL_NUM_INSTRUCTIONS, MRL_INSTR_PER_TIME_STEP)
{
   inputs=in;
   outputs=out;
   all_nodes=allNodes;
	all_links=allLinks;
   name=0;   //Defaults to no name  ..NOTE: TRYING TO PRINT AN EMPTY NAME CAN CAUSE A CRASH
   numnodes=-1;
   numlinks=-1;
   net_id=netid;

	mIntrospectiveInput = 0.0;

	std::list<NNode*>::iterator nodeIter = all_nodes.end();
	nodeIter--;
	mAnaTypeNode = (*nodeIter);
	mAnaTypeNode->ftype = LINEAR;
	nodeIter--;
	mAnaIndexNode = (*nodeIter);
	mAnaIndexNode->ftype = LINEAR;
	nodeIter--;
	mModTypeNode = (*nodeIter);
	mModTypeNode->ftype = LINEAR;
	nodeIter--;
	mModIndexNode = (*nodeIter);
	mModIndexNode->ftype = LINEAR;
	nodeIter--;
	mModLevelNode = (*nodeIter);
	mModLevelNode->ftype = POS_OR_NEG_SIGMOID;
	nodeIter--;
	mModEnableNode = (*nodeIter); //ftype is just a normal sigmoid

	mCurrentTime = 0.0;
	mInModSequence = false;
	mTotalReinforcement = 0.0;

	//OLD ASSEMBLY INSTRUCTIONS APPROACH...
	//mNodePointer = all_nodes.begin();
	//mLinkPointer = all_links.begin();

	//mNumMRLInputs = inputs.size() + all_links.size() + 2*all_nodes.size();
	//mMRLInputArray = new int[mNumMRLInputs];

	//mInstrArgNums[0] = 3;
	//mInstrArgNums[1] = 3;
	//mInstrArgNums[2] = 3;
	//mInstrArgNums[3] = 0;
	//mInstrArgNums[4] = 0;
	//mInstrArgNums[5] = 1;
	//mInstrArgNums[6] = 3;
	//mInstrArgNums[7] = 3;
	//mInstrArgNums[8] = 3;
	//mInstrArgNums[9] = 3;
	//mInstrArgNums[10] = 3;
	//mInstrArgNums[11] = 3;
	//mInstrArgNums[12] = 3;
	//mInstrArgNums[13] = 1;
	//mInstrArgNums[14] = 1;
	//mInstrArgNums[15] = 2;
	//mInstrArgNums[16] = 2;
	//mInstrArgNums[17] = 0;
	//mInstrArgNums[18] = 0;
	//mInstrArgNums[19] = 0;
	//mInstrArgNums[20] = 0;
	//mInstrArgNums[21] = 0;
	//mInstrArgNums[22] = 0;
	//mInstrArgNums[23] = 1;
	//mInstrArgNums[24] = 1;
	//mInstrArgNums[25] = 1;
	//mInstrArgNums[26] = 1;
	//mInstrArgNums[27] = 1;
}

//This constructs a net with empty input and output lists
//Network::Network(int netid)
//{
//   name=0; //Defaults to no name
//   numnodes=-1;
//   numlinks=-1;
//   net_id=netid;
//}

Network::~Network()
{
	//delete [] mMRLInputArray;
	mSSAStack.clear();

   if (name!=0)
   delete [] name;

   destroy();  //Kill off all the nodes and links
}

//Puts the network back into an initial state
void Network::flush()
{
  std::list<NNode*>::iterator curnode;

  for(curnode=outputs.begin();curnode!=outputs.end();++curnode)
  {
    (*curnode)->flushback();
  }
}

//Debugger: Checks network state
//void Network::flush_check()
//{
//  std::list<NNode*>::iterator curnode;
//  std::list<NNode*>::iterator location;
//  std::list<NNode*> seenlist;  //std::list of nodes not to doublecount
//
//  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {    
//	  location=std::find(seenlist.begin(),seenlist.end(),(*curnode));
//    if (location==seenlist.end()) {
//      seenlist.push_back(*curnode);
//      (*curnode)->flushback_check(seenlist);
//    }
//  }
//}

//If some outputs are not active then return true
bool Network::someoutputsoff()
{
	std::list<NNode*>::iterator curnode;

	for(curnode=outputs.begin();curnode!=outputs.end();++curnode)
	{
		if (((*curnode)->activation_count)==0) return true;
	}

	return false;
}

//Activates the net such that all outputs are active
//Returns true on success;
//bool Network::activate()
//{
//	std::list<NNode*>::iterator curnode;
//	std::list<Link*>::iterator curlink;
//	double add_amount;  //For adding to the activesum
//	bool onetime; //Make sure we at least activate once
//	int abortcount=0;  //Used in case the output is somehow truncated from the network
//
//	//std::cout<<"Activating network: "<<this->genotype<<std::endl;
//
//	//Keep activating until all the outputs have become active 
//	//(This only happens on the first activation, because after that they
//	// are always active)
//
//	onetime=false;
//
//	while(outputsoff()||!onetime) 
//	{
//		++abortcount;
//
//		if (abortcount==20) 
//		{
//			return false;
//			std::cout<<"Inputs disconnected from output!"<<std::endl;
//		}
//		//std::cout<<"Outputs are off"<<std::endl;
//
//		/* For each node, compute the sum of its incoming activation */
//		for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode)
//		{
//			//Ignore SENSORS
//
//			//std::cout<<"On node "<<(*curnode)->node_id<<std::endl;
//
//			if (((*curnode)->type)!=SENSOR)
//			{
//				(*curnode)->activesum=0;
//				(*curnode)->active_flag=false;  //This will tell us if it has any active inputs
//
//				/* For each incoming connection, add the activity from the connection
//				to the activesum */
//				for(curlink=((*curnode)->incoming).begin();curlink!=((*curnode)->incoming).end();++curlink)
//				{
//					////Handle possible time delays
//					//if (!((*curlink)->time_delay))
//					//{
//						add_amount=((*curlink)->weight)*(((*curlink)->in_node)->get_active_out());
//
//						if ((((*curlink)->in_node)->active_flag)||(((*curlink)->in_node)->type==SENSOR))
//						{
//							(*curnode)->active_flag=true;
//						}
//
//						(*curnode)->activesum+=add_amount;
//						//std::cout<<"Node "<<(*curnode)->node_id<<" adding "<<add_amount
//						//<<" from node "<<((*curlink)->in_node)->node_id<<std::endl;
//					//}
//					//else
//					//{
//					//	//Input over a time delayed connection
//					//	add_amount=((*curlink)->weight)*(((*curlink)->in_node)->get_active_out_td());
//					//	(*curnode)->activesum+=add_amount;
//					//}
//				} //End for over incoming links
//			} //End if (((*curnode)->type)!=SENSOR) 
//		} //End for over all nodes
//
//		/* Now activate all the non-sensor nodes off their incoming activation */
//		for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode)
//		{
//			if (((*curnode)->type)!=SENSOR)
//			{
//				//Only activate if some active input came in
//				if ((*curnode)->active_flag)
//				{
//					//std::cout<<"Activating "<<(*curnode)->node_id<<" with "<<(*curnode)->activesum<<": ";
//
//					//Keep a memory of activations for potential time delayed connections
//					(*curnode)->last_activation2=(*curnode)->last_activation;
//					(*curnode)->last_activation=(*curnode)->activation;
//					//Now run the net activation through an activation function
//					if ((*curnode)->ftype==SIGMOID)
//					{
//						//Sigmoidal activation- see comments under fsigmoid
//						(*curnode)->activation=fsigmoid((*curnode)->activesum,4.924273,2.4621365);
//					}
//
//					//std::cout<<(*curnode)->activation<<std::endl;
//
//					//Increment the activation_count
//					//First activation cannot be from nothing!!
//					(*curnode)->activation_count++;
//				}
//			}
//		}
//
//		onetime=true;
//	}
//
//	return true;  
//}

//Activates the net such that all outputs are active
//Returns true on success;
bool Network::activate_CTRNN(double timeStep)
{
	std::list<NNode*>::iterator curnode;
	//double add_amount;  //For adding to the activesum

	//Keep activating until all the outputs have become active 
	//(This only happens on the first activation, because after that they
	// are always active)

	bool notYetActivated = true; //Make sure we at least activate once
	int abortcount=0;  //Used in case the output is somehow truncated from the network

	while(true == someoutputsoff() || true == notYetActivated)
	{
		++abortcount;

		if (abortcount==30) 
		{
			return false;
			std::cout<<"Inputs disconnected from output!"<<std::endl;
		}
		//std::cout<<"Outputs are off"<<std::endl;

		/* For each node, compute the sum of its incoming activation */
		for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode)
		{
			assert(timeStep < 2*((*curnode)->time_constant));

			//Ignore SENSORS

			//std::cout<<"On node "<<(*curnode)->node_id<<std::endl;

			if (((*curnode)->type)!=SENSOR)
			{
				(*curnode)->synapticInput=0;

				/* For each incoming connection, add the activity from the connection
				to the activesum */
				std::list<Link*>::iterator curlink;
				for(curlink=((*curnode)->incoming).begin();curlink!=((*curnode)->incoming).end();++curlink)
				{
					(*curnode)->synapticInput += 
						((*curlink)->weight)*(((*curlink)->in_node)->get_firing_rate());
				} //End for over incoming links
			} //End if (((*curnode)->type)!=SENSOR) 
		} //End for over all nodes

		/* Now activate all the non-sensor nodes off their incoming activation */
		for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode)
		{
			if (((*curnode)->type)!=SENSOR)
			{
				//std::cout<<"Activating "<<(*curnode)->node_id<<" with "<<(*curnode)->activesum<<": ";

				//Keep a memory of activations for potential time delayed connections
				//(*curnode)->last_activation2=(*curnode)->last_activation;
				//(*curnode)->last_activation=(*curnode)->membranePotential;

				double constant = timeStep/(*curnode)->time_constant;

				(*curnode)->membranePotential = (1.0 - constant)*((*curnode)->membranePotential)
					+ constant*((*curnode)->synapticInput);

				//Now run the net activation through an activation function
				//if ((*curnode)->ftype==SIGMOID)
				//{
				//	(*curnode)->output=fsigmoid((*curnode)->activation+(*curnode)->bias, 0.0, 0.0);
				//}

				(*curnode)->calculate_firing_rate();

				//Increment the activation_count
				//First activation cannot be from nothing!!
				(*curnode)->activation_count++;
			}
		}

		notYetActivated = false;
	}

	//Load inputs into MRL system.
	//Sensory inputs are already loaded in load_sensors().

	//Load link weights.
	//std::list<Link*>::iterator linkIter;
	//int i=0;
	//for (linkIter = all_links.begin(); linkIter != all_links.end(); linkIter++)
	//{
	//	float weight = (*linkIter)->weight*MRL_INPUT_SCALAR;

	//	if (weight > MRL_MAX_INT)
	//	{
	//		weight = MRL_MAX_INT;
	//	}
	//	else if (weight < -MRL_MAX_INT)
	//	{
	//		weight = -MRL_MAX_INT;
	//	}

	//	mMRLInputArray[inputs.size()+i] = weight;
	//	i++;
	//}

	////Load node biases and time constants.
	//std::list<NNode*>::iterator nodeIter;
	//i=0;
	//for (nodeIter = all_nodes.begin(); nodeIter != all_nodes.end(); nodeIter++)
	//{
	//	float bias = (*nodeIter)->bias*MRL_INPUT_SCALAR;

	//	if (bias > MRL_MAX_INT)
	//	{
	//		bias = MRL_MAX_INT;
	//	}
	//	else if (bias < -MRL_MAX_INT)
	//	{
	//		bias = -MRL_MAX_INT;
	//	}

	//	float tc = (*nodeIter)->time_constant*MRL_INPUT_SCALAR;

	//	if (tc > MRL_MAX_INT)
	//	{
	//		tc = MRL_MAX_INT;
	//	}
	//	else if (tc < -MRL_MAX_INT)
	//	{
	//		tc = -MRL_MAX_INT;
	//	}

	//	mMRLInputArray[inputs.size()+all_links.size()+i] = bias;
	//	mMRLInputArray[inputs.size()+all_links.size()+i+all_nodes.size()] = tc;
	//	i++;
	//}

	//UpdateMRLInputs(mNumMRLInputs, mMRLInputArray);

	////Do MRL
	//RunMRL();

	if (false == mInModSequence)
	{
		SSA();
	}

	UseAnalyzingNodes();
	UseModifyingNodes();

	mCurrentTime += 1.0;

	return true;
}

void Network::UseAnalyzingNodes()
{
	double anaIndex = 0.0; //index of param to analyze
	Link* link = NULL;
	NNode* node = NULL;
	int numberOfLinks = all_links.size();
	int numberOfNodes = all_nodes.size();

	//Select type and index of param to analyze.
	if (mAnaTypeNode->firingRate < 0.333333) //Param type == link weight
	{
		anaIndex = numberOfLinks * mAnaIndexNode->firingRate;
		if (anaIndex >= numberOfLinks)
		{
			anaIndex = numberOfLinks - 1;
		}
		link = GetLink((int)anaIndex);
		mIntrospectiveInput = link->weight;
	}
	else if (mAnaTypeNode->firingRate < 0.666667) //Param type == bias
	{
		anaIndex = numberOfNodes * mAnaIndexNode->firingRate;
		if (anaIndex >= numberOfNodes)
		{
			anaIndex = numberOfNodes - 1;
		}
		node = GetNode((int)anaIndex);
		mIntrospectiveInput = node->bias;
	}
	else //Param type == time constant
	{
		anaIndex = numberOfNodes * mAnaIndexNode->firingRate;
		if (anaIndex >= numberOfNodes)
		{
			anaIndex = numberOfNodes - 1;
		}
		node = GetNode((int)anaIndex);
		mIntrospectiveInput = node->time_constant;
	}
}

void Network::UseModifyingNodes()
{
	//double modEnableOutput = mModEnableNode->output;

	////Keep the mod enable value from getting too low or too high.
	//if (modEnableOutput < MIN_ENABLE_MOD_PROB)
	//{
	//	modEnableOutput = MIN_ENABLE_MOD_PROB;
	//}
	//else if (modEnableOutput > MAX_ENABLE_MOD_PROB)
	//{
	//	modEnableOutput = MAX_ENABLE_MOD_PROB;
	//}

	//Try using a fixed probability; end mod sequence every 100 time steps.
	double modEnableOutput = 0.99;

	//if (mModEnableNode->output <= 0.5)
	//{
	//	mInModSequence = false;

	//	//Mods are disabled, so don't change anything.
	//	return;
	//}
	if (randfloat() > modEnableOutput)
	{
		mInModSequence = false;

		//Mods are disabled, so don't change anything.
		return;
	}
	else
	{
		//Mods are enabled.
		int numberOfLinks = all_links.size();
		int numberOfNodes = all_nodes.size();

		paramType modType = LINK_WEIGHT_PARAM; //type of param to modify

		//get index of param to modify; add noise to output
		//double modIndex = AddNoise(mModIndexNode->output, MOD_INDEX_NOISE);
		double modIndex = randfloat(); //REVERT
		
		//Clamp the index to 0 if the noise threw it down too far.
		if (modIndex < 0)
		{
			modIndex = 0;
		}

		//double modTypeOutput = mModTypeNode->output;
		double modTypeOutput = randfloat(); //REVERT

		//Select type and index of param to modify.
		if (modTypeOutput < 0.333333)
		{
			modType = LINK_WEIGHT_PARAM;
			modIndex *= numberOfLinks;
			if (modIndex >= numberOfLinks)
			{
				modIndex = numberOfLinks - 1;
			}
		}
		else if (modTypeOutput < 0.666667)
		{
			modType = BIAS_PARAM;
			modIndex *= numberOfNodes;
			if (modIndex >= numberOfNodes)
			{
				modIndex = numberOfNodes - 1;
			}
		}
		else
		{
			modType = TIME_CONSTANT_PARAM;
			modIndex *= numberOfNodes;
			if (modIndex >= numberOfNodes)
			{
				modIndex = numberOfNodes - 1;
			}
		}

		//Save current param before modifying it.
		//Pass in current mInModSequence state before changing it.
		PushPolicyOntoStack(mInModSequence, modType, (int)modIndex);
		mInModSequence = true;

		//Now modify the param.  The modIndex should be within the correct range by now.
		
		Link* link = NULL;
		NNode* node = NULL;
		double modValue = AddNoise(mModLevelNode->firingRate, MOD_LEVEL_NOISE);
		switch(modType)
		{
			case LINK_WEIGHT_PARAM:
				link = GetLink((int)modIndex);
				modValue *= (NEAT::link_weight_range * 0.1);
				link->AddToWeight(modValue);
				break;
			case BIAS_PARAM:
				node = GetNode((int)modIndex);
				modValue *= (NEAT::bias_range * 0.1);
				node->AddToBias(modValue);
				break;
			case TIME_CONSTANT_PARAM:
				node = GetNode((int)modIndex);
				modValue *= (NEAT::time_constant_range * 0.1);
				node->AddToTimeConstant(modValue);
				break;
			default:
				assert(false);
				break;
		}
	}
}

Link* Network::GetLink(int linkNum)
{
	std::list<Link*>::iterator iter = all_links.begin();

	for (int i=0; i<linkNum; i++)
	{
		iter++;
	}

	assert(iter != all_links.end());

	return (*iter);
}

NNode* Network::GetNode(int nodeNum)
{
	std::list<NNode*>::iterator iter = all_nodes.begin();

	for (int i=0; i<nodeNum; i++)
	{
		iter++;
	}

	assert(iter != all_nodes.end());

	return (*iter);
}

//THIS WAS NOT USED IN THE FINAL VERSION, AND NOT FULLY IMPLEMENTED,
//BUT IT SHOWS HOW SOMETHING LIKE THIS COULD BE INITIATED
//Note that checking networks for loops in general in not necessary
// and therefore I stopped writing this function
//Check Network for loops.  Return true if its ok, false if there is a loop.
//bool Network::integrity() {
//  std::list<NNode*>::iterator curnode;
//  std::list<std::list<NNode*>*> paths;
//  int count;
//  std::list<NNode*> *newpath;
//  std::list<std::list<NNode*>*>::iterator curpath;

//  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
//    newpath=new std::list<NNode*>();
//    paths.push_back(newpath);
//    if (!((*curnode)->integrity(newpath))) return false;
//  }

  //Delete the paths now that we are done
//  curpath=paths.begin();
//  for(count=0;count<paths.size();count++) {
//    delete (*curpath);
//    curpath++;
//  }

//  return true;
//}

//Prints the values of its outputs
void Network::show_activation() {
  std::list<NNode*>::iterator curnode;
  int count;

  if (name!=0)
    std::cout<<"Network "<<name<<" with id "<<net_id<<" outputs: (";
  else std::cout<<"Network id "<<net_id<<" outputs: (";

  count=1;
  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    std::cout<<"[Output #"<<count<<": "<<(*curnode)<<"] ";
    count++;
  }

  std::cout<<")"<<std::endl;
}

void Network::show_input() {
  std::list<NNode*>::iterator curnode;
  int count;

  if (name!=0)
    std::cout<<"Network "<<name<<" with id "<<net_id<<" inputs: (";
  else std::cout<<"Network id "<<net_id<<" outputs: (";

  count=1;
  for(curnode=inputs.begin();curnode!=inputs.end();++curnode) {
    std::cout<<"[Input #"<<count<<": "<<(*curnode)<<"] ";
    count++;
  }

  std::cout<<")"<<std::endl;
}

//Add an input
void Network::add_input(NNode *in_node) 
{
  inputs.push_back(in_node);
}

//Add an output
void Network::add_output(NNode *out_node) 
{
  outputs.push_back(out_node);
}

//Takes an array of sensor values and loads it into SENSOR inputs ONLY
void Network::load_sensors(double *sensvals)
{
	//MRL stuff
	//for (int i=0; i<inputs.size(); i++)
	//{
	//	float value = sensvals[i]*MRL_INPUT_SCALAR;

	//	if (value > MRL_MAX_INT)
	//	{
	//		value = MRL_MAX_INT;
	//	}
	//	else if (value < -MRL_MAX_INT)
	//	{
	//		value = -MRL_MAX_INT;
	//	}

	//	mMRLInputArray[i] = value;
	//}

	//int counter=0;  //counter to move through array
	std::list<NNode*>::iterator sensPtr;

	int i=0;
	for(sensPtr=inputs.begin();sensPtr!=inputs.end();++sensPtr)
	{
		//only load values into SENSORS (not BIASes)
		if (((*sensPtr)->type)==SENSOR)
		{
			(*sensPtr)->sensor_load(*sensvals);
			sensvals++;
		}
	}
}

void Network::give_name(char *newname) 
{
  char *temp;
  char *temp2;
  temp=new char[strlen(newname)+1];
  strcpy(temp,newname);
  if (name==0) name=temp;
  else {
    temp2=name;
    delete temp2;
    name=temp;
  }
}

//The following two methods recurse through a network from outputs
//down in order to count the number of nodes and links in the network.
//This can be useful for debugging genotype->phenotype spawning 
//(to make sure their counts correspond)

int Network::nodecount() {
  int counter=0;
  std::list<NNode*>::iterator curnode;
  std::list<NNode*>::iterator location;
  std::list<NNode*> seenlist;  //std::list of nodes not to doublecount

  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    
    location=find(seenlist.begin(),seenlist.end(),(*curnode));
    if (location==seenlist.end()) {
      counter++;
      seenlist.push_back(*curnode);
      nodecounthelper((*curnode),counter,seenlist);
    }
  }

  numnodes=counter;

  return counter;

}

void Network::nodecounthelper(NNode *curnode,int &counter,std::list<NNode*> &seenlist) {
  std::list<Link*> innodes=curnode->incoming;
  std::list<Link*>::iterator curlink;
  std::list<NNode*>::iterator location;

  if (!((curnode->type)==SENSOR)) {
    for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {
      location=find(seenlist.begin(),seenlist.end(),((*curlink)->in_node));
      if (location==seenlist.end()) {
	counter++;
	seenlist.push_back((*curlink)->in_node);
	nodecounthelper((*curlink)->in_node,counter,seenlist);
      }
    }

  }

}

int Network::linkcount() {
  int counter=0;
  std::list<NNode*>::iterator curnode;
  std::list<NNode*> seenlist;  //std::list of nodes not to doublecount

  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    linkcounthelper((*curnode),counter,seenlist);
  }

  numlinks=counter;

  return counter;

}

void Network::linkcounthelper(NNode *curnode,int &counter,std::list<NNode*> &seenlist) {
  std::list<Link*> inlinks=curnode->incoming;
  std::list<Link*>::iterator curlink;
  std::list<NNode*>::iterator location;

  location=find(seenlist.begin(),seenlist.end(),curnode);
  if ((!((curnode->type)==SENSOR))&&(location==seenlist.end())) {
    seenlist.push_back(curnode);

    for(curlink=inlinks.begin();curlink!=inlinks.end();++curlink) {
      counter++;
      linkcounthelper((*curlink)->in_node,counter,seenlist);
    }

  }

}


//Destroy will find every node in the network and subsequently
//delete them one by one.  Since deleting a node deletes its incoming
//links, all nodes and links associated with a network will be destructed
//Note: Traits are parts of genomes and not networks, so they are not
//      deleted here
void Network::destroy() {
  std::list<NNode*>::iterator curnode;
  //std::list<NNode*>::iterator location;
  std::list<NNode*> seenlist;  //std::list of nodes not to doublecount

  /* Erase all nodes from all_nodes std::list */

  for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode) {
    delete (*curnode);
  }


  /* ----------------------------------- 

    OLD WAY-the old way collected the nodes together and then deleted them

  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    //std::cout<<seenlist<<std::endl;
    //std::cout<<curnode<<std::endl;
    //std::cout<<curnode->node_id<<std::endl;
    
    location=find(seenlist.begin(),seenlist.end(),(*curnode));
    if (location==seenlist.end()) {
      seenlist.push_back(*curnode);
      destroy_helper((*curnode),seenlist);
    }
  }

  //Now destroy the seenlist, which is all the NNodes in the network
  for(curnode=seenlist.begin();curnode!=seenlist.end();++curnode) {
    delete (*curnode);
  }

  */

}

void Network::destroy_helper(NNode *curnode,std::list<NNode*> &seenlist) {
  std::list<Link*> innodes=curnode->incoming;
  std::list<Link*>::iterator curlink;
  std::list<NNode*>::iterator location;

  if (!((curnode->type)==SENSOR)) {
    for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {
      location=find(seenlist.begin(),seenlist.end(),((*curlink)->in_node));
      if (location==seenlist.end()) {
	seenlist.push_back((*curlink)->in_node);
	destroy_helper((*curlink)->in_node,seenlist);
      }
    }

  }

}

/* This checks a POTENTIAL link between a potential in_node
   and potential out_node to see if it must be recurrent */
//bool Network::is_recur(NNode *potin_node,NNode *potout_node,int &count,int thresh)
//{
//	++count;  //Count the node as visited
//
//	if (count>thresh)
//	{
//		//std::cout<<"returning false"<<std::endl;
//		return false;  //Short out the whole thing- loop detected
//	}
//
//	if (potin_node==potout_node)
//	{
//		return true;
//	}
//	else
//	{
//		//Check back on all links...
//		std::list<Link*>::iterator curlink;
//		for(curlink=(potin_node->incoming).begin();curlink!=(potin_node->incoming).end();curlink++)
//		{
//			//But skip links that are already recurrent
//			//(We want to check back through the forward flow of signals only
//			if (!((*curlink)->is_recurrent))
//			{
//				if (is_recur((*curlink)->in_node,potout_node,count,thresh))
//				{
//					return true;
//				}
//			}
//		}
//
//		return false;
//	}
//}

//Find the maximum number of neurons between an ouput and an input
int Network::max_depth()
{
  std::list<NNode*>::iterator curoutput; //The current output we are looking at
  int cur_depth; //The depth of the current node
  int max=0; //The max depth
  
  for(curoutput=outputs.begin();curoutput!=outputs.end();curoutput++)
  {
    cur_depth=(*curoutput)->depth(0,this);
    if (cur_depth>max) max=cur_depth;
  }

  return max;
}

//---------------------------------------------
//MRL/SSA stuff
//---------------------------------------------

//Pre: The instruction and its arguments have already been
//put into the appropriate program cells.
//Return true if there was a syntax error.
//bool Network::ExecuteInstruction()
//{
//	bool syntaxError = false;
//
//	switch(GetCellContents(mInstructionPointer))
//	{
//		case 0:
//			syntaxError = IncP(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2), GetCellContents(mInstructionPointer+3));
//			break;
//		case 1:
//			syntaxError = DecP(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2), GetCellContents(mInstructionPointer+3));
//			break;
//		case 2:
//			syntaxError = GetP(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2), GetCellContents(mInstructionPointer+3));
//			break;
//		case 3:
//			syntaxError = EndSelfMod();
//			break;
//		case 4:
//			syntaxError = ResetInstructionPointer();
//			break;
//		case 5:
//			syntaxError = Jmp(GetCellContents(mInstructionPointer+1));
//			break;
//		case 6:
//			syntaxError = Jmpleq(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2), GetCellContents(mInstructionPointer+3));
//			break;
//		case 7:
//			syntaxError = Jmpeq(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2), GetCellContents(mInstructionPointer+3));
//			break;
//		case 8:
//			syntaxError = Add(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2), GetCellContents(mInstructionPointer+3));
//			break;
//		case 9:
//			syntaxError = Sub(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2), GetCellContents(mInstructionPointer+3));
//			break;
//		case 10:
//			syntaxError = Mul(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2), GetCellContents(mInstructionPointer+3));
//			break;
//		case 11:
//			syntaxError = Div(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2), GetCellContents(mInstructionPointer+3));
//			break;
//		case 12:
//			syntaxError = Rem(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2), GetCellContents(mInstructionPointer+3));
//			break;
//		case 13:
//			syntaxError = Inc(GetCellContents(mInstructionPointer+1));
//			break;
//		case 14:
//			syntaxError = Dec(GetCellContents(mInstructionPointer+1));
//			break;
//		case 15:
//			syntaxError = Mov(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2));
//			break;
//		case 16:
//			syntaxError = Init(GetCellContents(mInstructionPointer+1), 
//				GetCellContents(mInstructionPointer+2));
//			break;
//		case 17:
//			syntaxError = ResetNodePointer();
//			break;
//		case 18:
//			syntaxError = ResetLinkPointer();
//			break;
//		case 19:
//			syntaxError = IncrementNodePointer();
//			break;
//		case 20:
//			syntaxError = IncrementLinkPointer();
//			break;
//		case 21:
//			syntaxError = DecrementNodePointer();
//			break;
//		case 22:
//			syntaxError = DecrementLinkPointer();
//			break;
//		case 23:
//			syntaxError = SetNodePointer(GetCellContents(mInstructionPointer+1));
//			break;
//		case 24:
//			syntaxError = SetLinkPointer(GetCellContents(mInstructionPointer+1));
//			break;
//		case 25:
//			syntaxError = MultiplyNodeTimeConstant(GetCellContents(mInstructionPointer+1));
//			break;
//		case 26:
//			syntaxError = MultiplyNodeBias(GetCellContents(mInstructionPointer+1));
//			break;
//		case 27:
//			syntaxError = MultiplyLinkWeight(GetCellContents(mInstructionPointer+1));
//			break;
//		default:
//			assert(false);
//			break;
//	}
//
//	return syntaxError;
//}
//
//int Network::GetNumArgs(int instrNum)
//{
//	return mInstrArgNums[instrNum];
//}
//
////Input array is the beginning of the negative addresses of the work cells.
//void Network::UpdateMRLInputs(int numInputs, int* newInputs)
//{
//	for(int i=0; i<numInputs; i++)
//	{
//		SetCellContents(-i-1, newInputs[i]);
//	}
//}

void Network::SSA()
{
	if (mSSAStack.empty())
	{
		//Generate the initial stack element.
		SSARecord initialRecord;
		initialRecord.time = 0.0;
		initialRecord.reinforcement = 0.0;
		//The other values don't matter for this initial record.
		
		mSSAStack.push_back(initialRecord);

		mSSAStack.back().SMSStartIndex = 0;
	}

	std::vector<SSARecord>::iterator sp = mSSAStack.end();
	sp--;
	std::vector<SSARecord>::iterator beforesp = sp;
	beforesp--;

	while(sp != mSSAStack.begin()
		&& ReinforcementRate(mSSAStack.at((*sp).SMSStartIndex).time, mSSAStack.at((*sp).SMSStartIndex).reinforcement, 
		mCurrentTime, mTotalReinforcement) <= ReinforcementRate(mSSAStack.at((*beforesp).SMSStartIndex).time, 
		mSSAStack.at((*beforesp).SMSStartIndex).reinforcement, mCurrentTime, mTotalReinforcement))
	{
		//This mod wasn't helpful, so restore the old policy.
		Link* link = NULL;
		NNode* node = NULL;
		std::vector<SSARecord>::iterator stackBack = mSSAStack.end();
		stackBack--;
		switch((*stackBack).modType)
		{
			case LINK_WEIGHT_PARAM:
				link = GetLink((*stackBack).modIndex);
				link->weight = (*stackBack).paramValue;
				break;
			case BIAS_PARAM:
				node = GetNode((*stackBack).modIndex);
				node->bias = (*stackBack).paramValue;
				break;
			case TIME_CONSTANT_PARAM:
				node = GetNode((*stackBack).modIndex);
				node->time_constant = (*stackBack).paramValue;
				break;
			default:
				assert(false);
				break;
		}

		//Remove the policy from the stack.
		mSSAStack.pop_back();
		sp = mSSAStack.end();
		sp--;
		beforesp = sp;
		beforesp--;

		mCurrentTime += 1.0;
	}
}

//Pre: The modIndex should be within the correct range for the given modType.
void Network::PushPolicyOntoStack(bool sequenceInProgress, paramType modType, int modIndex)
{
	SSARecord newRecord;
	newRecord.time = mCurrentTime;
	newRecord.reinforcement = mTotalReinforcement;
	newRecord.modType = modType;
	newRecord.modIndex = modIndex;

	switch(modType)
	{
		case LINK_WEIGHT_PARAM:
			newRecord.paramValue = GetLink(modIndex)->weight;
			break;
		case BIAS_PARAM:
			newRecord.paramValue = GetNode(modIndex)->bias;
			break;
		case TIME_CONSTANT_PARAM:
			newRecord.paramValue = GetNode(modIndex)->time_constant;
			break;
		default:
			assert(false);
			break;
	}

	mSSAStack.push_back(newRecord);

	if (true == sequenceInProgress)
	{
		//The previous entry points to the beginning of the sequence.
		std::vector<SSARecord>::iterator iter = mSSAStack.end();
		iter--;
		iter--;
		int startIndex = (*iter).SMSStartIndex;
		mSSAStack.back().SMSStartIndex = startIndex;
	}
	else
	{
		//This is the beginning of the sequence.
		mSSAStack.back().SMSStartIndex = mSSAStack.size()-1;
	}

	mCurrentTime += 1.0;
}
#ifndef __NEAT_UTILITIES_H__
#define __NEAT_UTILITIES_H__

#include "NEAT.h"
#include <math.h>

//Forward declarations
class Innovation;
class Organism;
class Species;
class Gene;
class Link;
class NNode;
//class Trait;
class Genome;

//std::list<Innovation*> *new_innov_list(); //Retrns a brand new empty std::list of innovations (for Guile)

/* Inline Random Functions */
inline bool randbit() {return rand()%2;}
inline int randposneg()
{
  if (randbit()) return 1; 
  else return -1;
}

inline int randint(int x,int y) {return rand()%(y-x+1)+x;}

//Return random value between 0.0 and 1.0.
inline double randfloat() {return (rand())/(RAND_MAX+1.0);}

//Returns a normally distributed deviate with 0 mean and unit variance
//Algorithm is from Numerical Recipes in C, Second Edition
inline double gaussrand()
{
  static int iset=0;
  static double gset;
  double fac,rsq,v1,v2;

  if (iset==0) {
    do {
      v1=2.0*((rand())/(RAND_MAX+1.0))-1.0;
      v2=2.0*((rand())/(RAND_MAX+1.0))-1.0;
      rsq=v1*v1+v2*v2;
    } while (rsq>=1.0 || rsq==0.0);
    fac=sqrt(-2.0*log(rsq)/rsq);
    gset=v1*fac;
    iset=1;
    return v2*fac;
  }
  else {
    iset=0;
    return gset;
  }
}

//This is an incorrect gassian distribution...but it is faster than gaussrand (maybe it's good enough?)
inline double gaussrand_wrong()
{
	return (randposneg())*(sqrt(-log((rand()*1.0)/RAND_MAX)));
}

//This is used for std::list sorting of Organisms by fitness..highest fitness first
bool order_orgs(Organism *x, Organism *y);
  
//This is used for std::list sorting of Species by fitness of best organism
//highest fitness first
bool order_species(Species *x, Species *y);

//Gene printing method
//std::ostream& operator<< (std::ostream& os, const Gene *thegene);

//Genome printing method
//std::ostream& operator<< (std::ostream& os, const Genome *thegenome);

//Not used for now...
//std::ostream& operator<< (std::ostream& os, const Trait *thetrait);

//int print_Genome_tofile(Genome *g, std::string filename);

/* Returns a brand new empty std::list of innovations (for Guile) */
//std::list<Innovation*> *new_innov_list();

#endif

#include "NEAT_Utilities.h"
#include "Trait.h"

/* ************************************************************** */
/* *                       TRAIT METHODS HERE                   * */
/* ************************************************************** */

//Genetic trait operation: Reserved for future system expansion
void Trait::mutate() {
  for(int count=0;count<NEAT::num_trait_params;count++) {
	  if (randfloat()>NEAT::trait_param_mut_prob) {
		  params[count]+=(randposneg()*randfloat())*NEAT::trait_mutation_power;
      if (params[count]<0) params[count]=0;
    }
  }
}

void Trait::print_to_file(std::ofstream &outFile) { 
  outFile<<"trait "<<trait_id<<" ";
  for(int count=0;count<NEAT::num_trait_params;count++)
    outFile<<params[count]<<" ";

  outFile<<std::endl;
}

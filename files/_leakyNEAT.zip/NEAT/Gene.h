#ifndef __NEAT_GENE_H__
#define __NEAT_GENE_H__

#include "NEAT.h"

//Forward declarations
class Link;
class NNode;
//class Trait;

//Description: 

/* ----------------------------------------------------------------------- */
/* The Gene class in this system specifies a "Connection Gene." 
   Nodes are represented using the Node class, which serves as both
   a genotypic and phenotypic representation of nodes.
   Genetic Representation of connections uses this special class because
   it calls for special operations better served by a specific genetic 
   representation  */
/* A Gene object in this system specifies a link      */
/* between two nodes along with an "innovation number" which tells when    */
/* in the history of a population the gene first arose.   This allows      */
/* the system to track innovations and use those to determine which        */
/* organisms are compatible.  (i.e. in the same species)                   */
/* A mutation_num gives a rough sense of how much mutation the gene has    */
/* experienced since it originally appeared.  (Since it was first          */
/* innovated.) In the current implenetation the mutation number is the
   same as the weight */

class Gene
{
public:
  //Construct a gene from the given params and a vector of nodes
  //Gene(int sourceID, int targetID, double weight, bool recurrent, int innovNum, 
	 // bool isEnabled, std::list<NNode*> &nodes);
  Gene(int sourceID, int targetID, double weight, int innovNum, bool isEnabled, 
	  std::list<NNode*> &nodes);

  //Construct a gene with no trait
  //Gene(double w,NNode *inode,NNode *onode,bool recur,double innov,double mnum);
  Gene(double w,NNode *inode,NNode *onode,double innov,double mnum);

  //Construct a gene with a trait
  //Gene(Trait *tp,double w,NNode *inode,NNode *onode,bool recur,double innov,double mnum);

  ////Construct a gene off of another gene as a duplicate
  //Gene(Gene *g,Trait *tp,NNode *inode,NNode *onode);
  //Construct a gene off of another gene as a duplicate
  Gene(Gene *g,NNode *inode,NNode *onode);

  //Construct a gene from a file spec given traits and nodes
  //Gene(std::ifstream &iFile,std::vector<Trait*> &traits,std::list<NNode*> &nodes);

  ~Gene();

 public:

  Link *lnk;
  double innovation_num;
  double mutation_num;  //Used to see how much mutation has changed the link

  bool enable;  //When this is off the Gene is disabled

  //void print_to_file(std::ofstream &outFile); //Print gene to a file- called from Genome

  //friend std::ostream& operator<< (std::ostream& os, const Gene *thegene);
};

#endif

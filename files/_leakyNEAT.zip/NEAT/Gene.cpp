//#include "Trait.h"
#include "Link.h"
#include "NNode.h"
#include "Gene.h"

//Gene::Gene(int sourceID, int targetID, double weight, bool recurrent, int innovNum, 
//				bool isEnabled, std::list<NNode*> &nodes)
Gene::Gene(int sourceID, int targetID, double weight, int innovNum, 
				bool isEnabled, std::list<NNode*> &nodes)
{
   //Set the gene parameters
   innovation_num = innovNum;
   mutation_num = weight;
   enable = isEnabled;

   //Get a pointer to the input node
   std::list<NNode*>::iterator curnode = nodes.begin();
   while(((*curnode)->node_id)!=sourceID)
	{
		++curnode;
	}
   NNode* inputNode = (*curnode);
   
   //Get a pointer to the output node
   curnode=nodes.begin();
   while(((*curnode)->node_id)!=targetID)
	{
		++curnode;
	}
   NNode* outputNode = (*curnode);

   //lnk=new Link(weight, inputNode, outputNode, recurrent);
	lnk=new Link(weight, inputNode, outputNode);
}

//Construct a gene with no trait
//Gene::Gene(double w,NNode *inode,NNode *onode,bool recur,double innov,double mnum)
Gene::Gene(double w,NNode *inode,NNode *onode,double innov,double mnum)
{
   //lnk=new Link(w,inode,onode,recur);
	lnk=new Link(w,inode,onode);
   innovation_num=innov;
   mutation_num=mnum;

   enable=true;
}

////Construct a gene with a trait
//Gene::Gene(Trait *tp,double w,NNode *inode,NNode *onode,bool recur,double innov,double mnum)
//{
//   lnk=new Link(tp,w,inode,onode,recur);
//   innovation_num=innov;
//   mutation_num=mnum;
//
//   enable=true;
//}

////Construct a gene off of another gene as a duplicate
//Gene::Gene(Gene *g,Trait *tp,NNode *inode,NNode *onode)
//{
//   //std::cout<<"Trying to attach nodes: "<<inode<<" "<<onode<<std::endl;
//   lnk=new Link(tp,(g->lnk)->weight,inode,onode,(g->lnk)->is_recurrent);
//   innovation_num=g->innovation_num;
//   mutation_num=g->mutation_num;
//   enable=g->enable;
//}
Gene::Gene(Gene *g,NNode *inode,NNode *onode)
{
   //std::cout<<"Trying to attach nodes: "<<inode<<" "<<onode<<std::endl;
   //lnk=new Link((g->lnk)->weight,inode,onode,(g->lnk)->is_recurrent);
	lnk=new Link((g->lnk)->weight,inode,onode);
   innovation_num=g->innovation_num;
   mutation_num=g->mutation_num;
   enable=g->enable;
}

////Construct a gene from a file spec given traits and nodes
//Gene::Gene(std::ifstream &iFile,std::vector<Trait*> &traits,std::list<NNode*> &nodes) {
//   //Gene parameter holders
//   int traitnum;
//   int inodenum;
//   int onodenum;
//   NNode *inode;
//   NNode *onode;
//   double weight;
//   int recur;
//   Trait *traitptr;
//
//std::vector<Trait*>::iterator curtrait;
//   std::list<NNode*>::iterator curnode;
//
//   //Get the gene parameters
//   iFile>>traitnum;
//   iFile>>inodenum;
//   iFile>>onodenum;
//   iFile>>weight;
//   iFile>>recur;
//   iFile>>innovation_num;
//   iFile>>mutation_num;
//   iFile>>enable;
//   
//   //Get a pointer to the linktrait
//   if (traitnum==0) traitptr=0;
//   else {
//   curtrait=traits.begin();
//   while(((*curtrait)->trait_id)!=traitnum)
//++curtrait;
//   traitptr=(*curtrait);
//   }
//   
//   //Get a pointer to the input node
//   curnode=nodes.begin();
//   while(((*curnode)->node_id)!=inodenum)
//   ++curnode;
//   inode=(*curnode);
//   
//   //Get a pointer to the output node
//   curnode=nodes.begin();
//   while(((*curnode)->node_id)!=onodenum)
//   ++curnode;
//   onode=(*curnode);
//
//   lnk=new Link(traitptr,weight,inode,onode,recur);
//}

Gene::~Gene() {
   delete lnk;
}

//void Gene::print_to_file(std::ofstream &outFile) {
//  outFile<<"gene ";
//  //Start off with the trait number for this gene
//  if ((lnk->linktrait)==0) outFile<<"0 ";
//  else outFile<<((lnk->linktrait)->trait_id)<<" ";
//  outFile<<(lnk->in_node)->node_id<<" ";
//  outFile<<(lnk->out_node)->node_id<<" ";
//  outFile<<(lnk->weight)<<" ";
//  outFile<<(lnk->is_recurrent)<<" ";
//  outFile<<innovation_num<<" ";
//  outFile<<mutation_num<<" ";
//  outFile<<enable<<std::endl;
//}

#ifndef __NEAT_NETWORK_H__
#define __NEAT_NETWORK_H__

#include "NEAT.h"
#include "NEAT_Utilities.h"

//#include "../MRLSystem.h"
//#define MRL_INSTR_PER_TIME_STEP 10000

//Scale real inputs/ANN params before sending to the integer-basedMRL system.
//#define MRL_INPUT_SCALAR 1000

//Forward declarations
//class NNode;
#include "NNode.h"
#include "Link.h"

enum paramType
{
	LINK_WEIGHT_PARAM,
	BIAS_PARAM,
	TIME_CONSTANT_PARAM
};

//Description: 

/* A NETWORK is a list of input NODEs and a list of output NODEs
   The point of the network is to define a single entity which can evolve
   or learn on its own, even though it may be part of a larger framework */
class Network
{
public:
	//This constructor allows the input and output lists to be supplied
	Network::Network(std::list<NNode*> in,std::list<NNode*> out,
		std::list<NNode*> allNodes, std::list<Link*> allLinks, int netid);

	//This constructs a net with empty input and output lists
	//Network::Network(int netid);

	Network::~Network();

  friend class Genome;
  //friend class Population;
  //friend std::ostream& operator<< (std::ostream& os, const NNode *thenode);

 protected:

  int numnodes; //The number of nodes in the net (-1 means not yet counted)
  int numlinks; //The number of links in the net (-1 means not yet counted)

  std::list<NNode*> all_nodes;  //A std::list of all the nodes

  //Added by Tyler...
  std::list<Link*> all_links;  //A std::list of all the links

  void destroy();  //Kills all nodes and links within
  void destroy_helper(NNode *curnode,std::list<NNode*> &seenlist); //helper for above

  void nodecounthelper(NNode *curnode,int &counter,std::list<NNode*> &seenlist);
  void linkcounthelper(NNode *curnode,int &counter,std::list<NNode*> &seenlist);

 public:

  Genome *genotype;  //Allows Network to be matched with its Genome

  char *name; //Every Network or subNetwork can have a name
  std::list<NNode*> inputs;  //NNodes that input into the network
  std::list<NNode*> outputs; //Values output by the network

  int net_id; //Allow for a network id
  
  //friend std::ostream& operator<< (std::ostream& os, const Network &thenet);

  void flush();  //Puts the network back into an inactive state
  //void flush_check();  //Verify flushedness for debugging
 
  //bool activate(); //Activates the net such that all outputs are active
  bool activate_CTRNN(double timeStep); //CTRNN version

  void show_activation(); //Prints the values of its outputs
  void show_input();
  void add_input(NNode*);  //Add a new input node
  void add_output(NNode*);  //Add a new output node
  void load_sensors(double*); //Takes an array of sensor values and loads it into SENSOR inputs ONLY
  void give_name(char*); //Name the network

  int nodecount(); //Counts the number of nodes in the net if not yet counted

  int linkcount(); //Counts the number of links in the net if not yet counted

  /* This checks a POTENTIAL link between a potential in_node
     and potential out_node to see if it must be recurrent */
  /* Use count and thresh to jump out in the case of an infinite loop */
  //bool is_recur(NNode *potin_node,NNode *potout_node,int &count,int thresh);

  bool someoutputsoff(); //If some outputs are not active then return true

  //Find the maximum number of neurons between an ouput and an input
  int max_depth();

	//------------------------------------------------------------------------------------
	//MRL/SSA stuff ("self-modifying network" approach)
	//------------------------------------------------------------------------------------
	void UseAnalyzingNodes();
	void UseModifyingNodes();

	void SSA();
	void PushPolicyOntoStack(bool sequenceInProgress, paramType modType, int modIndex);

	//This functions finds the reinforcement/time ratio between t1 and t2 given
	//that the reinforcements earned at t1 were r1 and at t2 were r2.  Usually
	//t2 will be the current time.
	float ReinforcementRate(double t1, float r1, double t2, float r2)
	{
		assert(t1 != t2);
		assert(t1 >= 0.0 && t2 >= 0.0);
		return ((r2 - r1)/(t2 - t1));
	}

	void AddReinforcement(float value)
	{
		mTotalReinforcement += value;
	}

	double GetIntrospectionValue()
	{
		return mIntrospectiveInput;
	}

	//Add random noise to originalValue within +/- noiseLevel.
	double AddNoise(double originalValue, double noiseLevel)
	{
		return (originalValue + noiseLevel*randposneg()*randfloat());
	}

	Link* GetLink(int linkNum);
	NNode* GetNode(int nodeNum);

	//There are 6 special output nodes here.  One extra input node is required for introspection.
	double mIntrospectiveInput;
	NNode* mAnaTypeNode; //selects type of param
	NNode* mAnaIndexNode; //selects param index
	NNode* mModTypeNode; //selects type of param
	NNode* mModIndexNode; //selects param index
	NNode* mModLevelNode; //outputs level of modification
	NNode* mModEnableNode; //output is > 0.5 when we should enable modifications, <= 0.5 otherwise

	//SSA Stack Stuff
	//TODO: modify this to work with adding/deleting nodes/links
	struct SSARecord
	{
		double time;
		float reinforcement;
		//int address;
		paramType modType;
		int modIndex;
		//float policy[MRL_NUM_INSTRUCTIONS];
		double paramValue;
		int SMSStartIndex;
	};

	std::vector<SSARecord> mSSAStack;

	double mCurrentTime;
	bool mInModSequence;
	float mTotalReinforcement;

	//------------------------------------------------------------------------------------
	//MRL/SSA stuff ("assembly instructions" approach)
	//All instructions return true if there was a syntax error, false otherwise.
	//------------------------------------------------------------------------------------
	//bool ExecuteInstruction();
	//int GetNumArgs(int instrNum);
	////bool IsInstrSelfModifying(int instrNum);
	//void UpdateMRLInputs(int numInputs, int* newInputs);

	////Self-Referential Instructions (0-3)
	//bool IncP(int a1, int a2, int a3) //instruction 0
	//{
	//	int ca1 = GetCellContents(a1);
	//	int ca3 = GetCellContents(a3);

	//	if (ca3 < MRL_MIN_ADDRESS || ca3 > MRL_MAX_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}

	//	int cca3 = GetCellContents(ca3);

	//	if (cca3 < 1 || cca3 > 99 || ca1 < MRL_PROGRAM_START_ADDRESS || ca1 > MRL_MAX_ADDRESS)
	//	{
	//		//No syntax error, just return.
	//		return false;
	//	}
	//
	//	//Copy the current policy at program cell ca1 into a temp array.
	//	float tempPolicy[MRL_NUM_INSTRUCTIONS];
	//	for (int i=0; i<mNumInstructions; i++)
	//	{
	//		tempPolicy[i] = mPolicy[ca1][i];
	//	}

	//	//Adjust probability distribution.
	//	for (int i=0; i<mNumInstructions; i++)
	//	{
	//		if (i != a2)
	//		{
	//			//Decrease all other probs to normalize the distribution.
	//			tempPolicy[i] = 0.01*(float)cca3 * tempPolicy[i];
	//		}
	//	}

	//	//Now increase this prob.
	//	tempPolicy[a2] = 1.0 - 0.01*(float)cca3 * (1.0 - tempPolicy[a2]);

	//	//Check if any of the probabilities fell below MRL_MIN_PROB.
	//	for (int i=0; i<mNumInstructions; i++)
	//	{
	//		if (tempPolicy[i] < MRL_MIN_PROB)
	//		{
	//			//No syntax error, just return.
	//			return false;
	//		}
	//	}

	//	//Everything worked, so save the old policy and copy the temp policy into the real one.
	//	PushPolicyOntoStack(mInSelfModSequence);

	//	for (int i=0; i<mNumInstructions; i++)
	//	{
	//		mPolicy[ca1][i] = tempPolicy[i];
	//	}

	//	//We're now in a self-mod sequence (though one might already be in progress).
	//	mInSelfModSequence = true;
	//	return false;
	//}

	//bool DecP(int a1, int a2, int a3) //instruction 1
	//{
	//	int ca1 = GetCellContents(a1);
	//	int ca3 = GetCellContents(a3);

	//	if (ca3 < MRL_MIN_ADDRESS || ca3 > MRL_MAX_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}

	//	int cca3 = GetCellContents(ca3);

	//	if (cca3 < 1 || cca3 > 99 || ca1 < MRL_PROGRAM_START_ADDRESS || ca1 > MRL_MAX_ADDRESS)
	//	{
	//		//No syntax error, just return.
	//		return false;
	//	}
	//
	//	//Copy the current policy at program cell ca1 into a temp array.
	//	float tempPolicy[MRL_NUM_INSTRUCTIONS];
	//	for (int i=0; i<mNumInstructions; i++)
	//	{
	//		tempPolicy[i] = mPolicy[ca1][i];
	//	}

	//	//Adjust probability distribution.
	//	for (int i=0; i<mNumInstructions; i++)
	//	{
	//		if (i != a2)
	//		{
	//			//Increase all other probs to normalize the distribution.
	//			tempPolicy[i] = ((1.0 - 0.01*(float)cca3*tempPolicy[a2])/(1.0 - tempPolicy[a2]))
	//				* tempPolicy[i];
	//		}
	//	}

	//	//Now decrease this prob.
	//	tempPolicy[a2] = 0.01*(float)cca3 * tempPolicy[a2];

	//	//Check if any of the probabilities fell below MRL_MIN_PROB.
	//	for (int i=0; i<mNumInstructions; i++)
	//	{
	//		if (tempPolicy[i] < MRL_MIN_PROB)
	//		{
	//			//No syntax error, just return.
	//			return false;
	//		}
	//	}

	//	//Everything worked, so save the old policy and copy the temp policy into the real one.
	//	PushPolicyOntoStack(mInSelfModSequence);

	//	for (int i=0; i<mNumInstructions; i++)
	//	{
	//		mPolicy[ca1][i] = tempPolicy[i];
	//	}

	//	//We're now in a self-mod sequence (though one might already be in progress).
	//	mInSelfModSequence = true;
	//	return false;
	//}

	//bool GetP(int a1, int a2, int a3) //instruction 2
	//{
	//	int ca1 = GetCellContents(a1);
	//	int ca2 = GetCellContents(a2);
	//	int ca3 = GetCellContents(a3);

	//	if (ca1 < MRL_PROGRAM_START_ADDRESS || ca1 > MRL_MAX_ADDRESS
	//		|| ca2 < 0 || ca2 >= mNumInstructions
	//		|| ca3 < MRL_MIN_ADDRESS || ca3 >= MRL_PROGRAM_START_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		SetCellContents(ca3, (int)(MRL_MAX_INT * mPolicy[ca1][ca2]));
	//		return false;
	//	}
	//}

	//bool EndSelfMod() //instruction 3
	//{
	//	mInSelfModSequence = false;
	//	return false;
	//}

	////Normal Assembly Instructions (4-16)
	//bool ResetInstructionPointer() //instruction 4
	//{
	//	mInstructionPointer = MRL_PROGRAM_START_ADDRESS;
	//	return false;
	//}

	//bool Jmp(int a1) //instruction 5
	//{
	//	int ca1 = GetCellContents(a1);
	//	
	//	if (ca1 < MRL_PROGRAM_START_ADDRESS || ca1 > MRL_MAX_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		mInstructionPointer = ca1;
	//		return false;
	//	}
	//}

	//bool Jmpleq(int a1, int a2, int a3) //instruction 6
	//{
	//	//int cca1 = GetCellContents(GetCellContents(a1));
	//	//int cca2 = GetCellContents(GetCellContents(a2));

	//	int ca1 = GetCellContents(a1);
	//	int ca2 = GetCellContents(a2);
	//	int ca3 = GetCellContents(a3);

	//	if (ca1 < MRL_MIN_ADDRESS || ca1 > MRL_MAX_ADDRESS || ca2 < MRL_MIN_ADDRESS || ca2 > MRL_MAX_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}

	//	int cca1 = GetCellContents(ca1);
	//	int cca2 = GetCellContents(ca2);
	//	
	//	if (ca3 < MRL_PROGRAM_START_ADDRESS || ca3 > MRL_MAX_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else if (cca1 <= cca2)
	//	{
	//		mInstructionPointer = ca3;
	//		return false;
	//	}
	//	else
	//	{
	//		return false;
	//	}
	//}

	//bool Jmpeq(int a1, int a2, int a3) //instruction 7
	//{
	//	//int cca1 = GetCellContents(GetCellContents(a1));
	//	//int cca2 = GetCellContents(GetCellContents(a2));
	//	//int ca3 = GetCellContents(a3);

	//	int ca1 = GetCellContents(a1);
	//	int ca2 = GetCellContents(a2);
	//	int ca3 = GetCellContents(a3);

	//	if (ca1 < MRL_MIN_ADDRESS || ca1 > MRL_MAX_ADDRESS || ca2 < MRL_MIN_ADDRESS || ca2 > MRL_MAX_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}

	//	int cca1 = GetCellContents(ca1);
	//	int cca2 = GetCellContents(ca2);
	//	
	//	if (ca3 < MRL_PROGRAM_START_ADDRESS || ca3 > MRL_MAX_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else if (cca1 = cca2)
	//	{
	//		mInstructionPointer = ca3;
	//		return false;
	//	}
	//	else
	//	{
	//		return false;
	//	}
	//}

	//bool Add(int a1, int a2, int a3) //instruction 8
	//{
	//	//int cca1 = GetCellContents(GetCellContents(a1));
	//	//int cca2 = GetCellContents(GetCellContents(a2));
	//	//int ca3 = GetCellContents(a3);
	//	
	//	int ca1 = GetCellContents(a1);
	//	int ca2 = GetCellContents(a2);
	//	int ca3 = GetCellContents(a3);

	//	if (ca1 < MRL_MIN_ADDRESS || ca1 > MRL_MAX_ADDRESS || ca2 < MRL_MIN_ADDRESS || ca2 > MRL_MAX_ADDRESS
	//		|| ca3 < MRL_MIN_ADDRESS || ca3 >= MRL_PROGRAM_START_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		int cca1 = GetCellContents(ca1);
	//		int cca2 = GetCellContents(ca2);

	//		int result = cca1 + cca2;

	//		if (result < -MRL_MAX_INT)
	//		{
	//			result = -MRL_MAX_INT;
	//		}
	//		else if (result > MRL_MAX_INT)
	//		{
	//			result = MRL_MAX_INT;
	//		}

	//		SetCellContents(ca3, result);
	//		return false;
	//	}
	//}

	//bool Sub(int a1, int a2, int a3) //instruction 9
	//{
	//	//int cca1 = GetCellContents(GetCellContents(a1));
	//	//int cca2 = GetCellContents(GetCellContents(a2));
	//	//int ca3 = GetCellContents(a3);
	//	
	//	int ca1 = GetCellContents(a1);
	//	int ca2 = GetCellContents(a2);
	//	int ca3 = GetCellContents(a3);

	//	if (ca1 < MRL_MIN_ADDRESS || ca1 > MRL_MAX_ADDRESS || ca2 < MRL_MIN_ADDRESS || ca2 > MRL_MAX_ADDRESS
	//		|| ca3 < MRL_MIN_ADDRESS || ca3 >= MRL_PROGRAM_START_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		int cca1 = GetCellContents(ca1);
	//		int cca2 = GetCellContents(ca2);

	//		int result = cca1 - cca2;

	//		if (result < -MRL_MAX_INT)
	//		{
	//			result = -MRL_MAX_INT;
	//		}
	//		else if (result > MRL_MAX_INT)
	//		{
	//			result = MRL_MAX_INT;
	//		}

	//		SetCellContents(ca3, result);
	//		return false;
	//	}
	//}

	//bool Mul(int a1, int a2, int a3) //instruction 10
	//{
	//	//int ca1 = GetCellContents(a1);
	//	//int cca1 = GetCellContents(ca1);
	//	//int ca2 = GetCellContents(a2);
	//	//int cca2 = GetCellContents(ca2);
	//	//int ca3 = GetCellContents(a3);
	//	
	//	int ca1 = GetCellContents(a1);
	//	int ca2 = GetCellContents(a2);
	//	int ca3 = GetCellContents(a3);


	//	if (ca1 < MRL_MIN_ADDRESS || ca1 > MRL_MAX_ADDRESS || ca2 < MRL_MIN_ADDRESS || ca2 > MRL_MAX_ADDRESS
	//		|| ca3 < MRL_MIN_ADDRESS || ca3 >= MRL_PROGRAM_START_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		int cca1 = GetCellContents(ca1);
	//		int cca2 = GetCellContents(ca2);

	//		int result = cca1 * cca2;

	//		if (result < -MRL_MAX_INT)
	//		{
	//			result = -MRL_MAX_INT;
	//		}
	//		else if (result > MRL_MAX_INT)
	//		{
	//			result = MRL_MAX_INT;
	//		}

	//		SetCellContents(ca3, result);
	//		return false;
	//	}
	//}

	//bool Div(int a1, int a2, int a3) //instruction 11
	//{
	//	//int cca1 = GetCellContents(GetCellContents(a1));
	//	//int cca2 = GetCellContents(GetCellContents(a2));
	//	//int ca3 = GetCellContents(a3);
	//	
	//	int ca1 = GetCellContents(a1);
	//	int ca2 = GetCellContents(a2);
	//	int ca3 = GetCellContents(a3);

	//	if (ca1 < MRL_MIN_ADDRESS || ca1 > MRL_MAX_ADDRESS || ca2 < MRL_MIN_ADDRESS || ca2 > MRL_MAX_ADDRESS
	//		|| ca3 < MRL_MIN_ADDRESS || ca3 >= MRL_PROGRAM_START_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		int cca1 = GetCellContents(ca1);
	//		int cca2 = GetCellContents(ca2);

	//		int result = 0;

	//		if (cca2 == 0)
	//		{
	//			if (cca1 == 0)
	//			{
	//				result = 0;
	//			}
	//			else if (cca1 > 0)
	//			{
	//				result = MRL_MAX_INT;
	//			}
	//			else
	//			{
	//				result = -MRL_MAX_INT;
	//			}
	//		}
	//		else
	//		{
	//			result = cca1 / cca2;

	//			if (result < -MRL_MAX_INT)
	//			{
	//				result = -MRL_MAX_INT;
	//			}
	//			else if (result > MRL_MAX_INT)
	//			{
	//				result = MRL_MAX_INT;
	//			}
	//		}

	//		SetCellContents(ca3, result);
	//		return false;
	//	}
	//}

	//bool Rem(int a1, int a2, int a3) //instruction 12
	//{
	//	//int cca1 = GetCellContents(GetCellContents(a1));
	//	//int cca2 = GetCellContents(GetCellContents(a2));
	//	//int ca3 = GetCellContents(a3);
	//	
	//	int ca1 = GetCellContents(a1);
	//	int ca2 = GetCellContents(a2);
	//	int ca3 = GetCellContents(a3);

	//	if (ca1 < MRL_MIN_ADDRESS || ca1 > MRL_MAX_ADDRESS || ca2 < MRL_MIN_ADDRESS || ca2 > MRL_MAX_ADDRESS
	//		|| ca3 < MRL_MIN_ADDRESS || ca3 >= MRL_PROGRAM_START_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		int cca1 = GetCellContents(ca1);
	//		int cca2 = GetCellContents(ca2);

	//		int result = 0;

	//		if (cca2 == 0)
	//		{
	//			result = 0;
	//		}
	//		else
	//		{
	//			result = cca1 % cca2;

	//			if (result < -MRL_MAX_INT)
	//			{
	//				result = -MRL_MAX_INT;
	//			}
	//			else if (result > MRL_MAX_INT)
	//			{
	//				result = MRL_MAX_INT;
	//			}
	//		}

	//		SetCellContents(ca3, result);
	//		return false;
	//	}
	//}

	//bool Inc(int a1) //instruction 13
	//{
	//	//int ca1 = GetCellContents(a1);
	//	//int cca1 = GetCellContents(ca1);
	//	
	//	int ca1 = GetCellContents(a1);

	//	if (ca1 < MRL_MIN_ADDRESS || ca1 >= MRL_PROGRAM_START_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}

	//	int cca1 = GetCellContents(ca1);

	//	if (cca1 + 1 > MRL_MAX_INT)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		SetCellContents(ca1, cca1+1);
	//		return false;
	//	}
	//}

	//bool Dec(int a1) //instruction 14
	//{
	//	//int ca1 = GetCellContents(a1);
	//	//int cca1 = GetCellContents(ca1);
	//	
	//	int ca1 = GetCellContents(a1);

	//	if (ca1 < MRL_MIN_ADDRESS || ca1 >= MRL_PROGRAM_START_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}

	//	int cca1 = GetCellContents(ca1);

	//	if (cca1 - 1 < -MRL_MAX_INT)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		int cca1 = GetCellContents(ca1);
	//		SetCellContents(ca1, cca1-1);
	//		return false;
	//	}
	//}

	//bool Mov(int a1, int a2) //instruction 15
	//{
	//	//int cca1 = GetCellContents(GetCellContents(a1));
	//	//int ca2 = GetCellContents(a2);

	//	int ca1 = GetCellContents(a1);
	//	int ca2 = GetCellContents(a2);

	//	if (ca1 < MRL_MIN_ADDRESS || ca1 > MRL_MAX_ADDRESS || ca2 < MRL_MIN_ADDRESS || ca2 >= MRL_PROGRAM_START_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		int cca1 = GetCellContents(ca1);
	//		SetCellContents(ca2, cca1);
	//		return false;
	//	}
	//}

	//bool Init(int a1, int a2) //instruction 16
	//{
	//	//Note: a1 is guaranteed to be within {0,...,numInstructions-1}.
	//	int modified_a1 = a1 - MRL_PROGRAM_START_ADDRESS - 2;

	//	if (modified_a1 < MRL_MIN_ADDRESS)
	//	{
	//		//syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		SetCellContents(modified_a1, a2);
	//		return false;
	//	}
	//}

	////ANN-Modifying Instructions (17-27)
	//bool ResetNodePointer() //instruction 17
	//{
	//	mNodePointer = all_nodes.begin();
	//	return false;
	//}

	//bool ResetLinkPointer() //instruction 18
	//{
	//	mLinkPointer = all_links.begin();
	//	return false;
	//}

	//bool IncrementNodePointer() //instruction 19
	//{
	//	mNodePointer++;

	//	if (mNodePointer == all_nodes.end())
	//	{
	//		//Don't go off the end; syntax error.
	//		mNodePointer--;
	//		return true;
	//	}
	//	else
	//	{
	//		return false;
	//	}
	//}

	//bool IncrementLinkPointer() //instruction 20
	//{
	//	mLinkPointer++;

	//	if (mLinkPointer == all_links.end())
	//	{
	//		//Don't go off the end; syntax error.
	//		mLinkPointer--;
	//		return true;
	//	}
	//	else
	//	{
	//		return false;
	//	}
	//}

	//bool DecrementNodePointer() //instruction 21
	//{
	//	if (mNodePointer == all_nodes.begin())
	//	{
	//		//Don't go off the beginning; syntax error.
	//		return true;
	//	}
	//	else
	//	{
	//		mNodePointer--;
	//		return false;
	//	}
	//}

	//bool DecrementLinkPointer() //instruction 22
	//{
	//	if (mLinkPointer == all_links.begin())
	//	{
	//		//Don't go off the beginning; syntax error.
	//		return true;
	//	}
	//	else
	//	{
	//		mLinkPointer--;
	//		return false;
	//	}
	//}

	//bool SetNodePointer(int a1) //instruction 23
	//{
	//	int ca1 = GetCellContents(a1);

	//	if (ca1 < 0 || ca1 >= all_nodes.size())
	//	{
	//		//out of range; syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		mNodePointer = all_nodes.begin();

	//		for (int i=0; i<ca1; i++)
	//		{
	//			mNodePointer++;
	//		}

	//		return false;
	//	}
	//}

	//bool SetLinkPointer(int a1) //instruction 24
	//{
	//	int ca1 = GetCellContents(a1);

	//	if (ca1 < 0 || ca1 >= all_links.size())
	//	{
	//		//out of range; syntax error
	//		return true;
	//	}
	//	else
	//	{
	//		mLinkPointer = all_links.begin();

	//		for (int i=0; i<ca1; i++)
	//		{
	//			mLinkPointer++;
	//		}

	//		return false;
	//	}
	//}

	//bool MultiplyNodeTimeConstant(int a1) //instruction 25
	//{
	//	int ca1 = GetCellContents(a1);

	//	//if (ca1 < 0)
	//	//{
	//	//	ca1 *= -1;
	//	//}
	//	//(*mNodePointer)->time_constant *= (0.01*(double)ca1);
	//	double tcRange = NEAT::max_time_constant - NEAT::min_time_constant;
	//	if (ca1 > 0)
	//	{
	//		(*mNodePointer)->time_constant += (0.1 * tcRange);
	//	}
	//	else
	//	{
	//		(*mNodePointer)->time_constant -= (0.1 * tcRange);
	//	}

	//	//clamp the time constant value
	//	if ((*mNodePointer)->time_constant > NEAT::max_time_constant)
	//	{
	//		(*mNodePointer)->time_constant = NEAT::max_time_constant;
	//	}
	//	else if ((*mNodePointer)->time_constant < NEAT::min_time_constant)
	//	{	
	//		(*mNodePointer)->time_constant = NEAT::min_time_constant;
	//	}

	//	return false;
	//}

	//bool MultiplyNodeBias(int a1) //instruction 26
	//{
	//	int ca1 = GetCellContents(a1);

	//	//(*mNodePointer)->bias *= (0.01*(double)ca1);
	//	double biasRange = 2.0 * NEAT::bias_clamp;
	//	if (ca1 > 0)
	//	{
	//		(*mNodePointer)->bias += (0.1 * biasRange);
	//	}
	//	else
	//	{
	//		(*mNodePointer)->bias -= (0.1 * biasRange);
	//	}

	//	//clamp the bias value
	//	if ((*mNodePointer)->bias > NEAT::bias_clamp)
	//	{
	//		(*mNodePointer)->bias = NEAT::bias_clamp;
	//	}
	//	else if ((*mNodePointer)->bias < -NEAT::bias_clamp)
	//	{	
	//		(*mNodePointer)->bias = -NEAT::bias_clamp;
	//	}

	//	return false;
	//}

	//bool MultiplyLinkWeight(int a1) //instruction 27
	//{
	//	int ca1 = GetCellContents(a1);

	//	//(*mLinkPointer)->weight *= (0.01*(double)ca1);
	//	double weightRange = 2.0 * NEAT::link_weight_clamp;
	//	if (ca1 > 0)
	//	{
	//		(*mLinkPointer)->weight += (0.1 * weightRange);
	//	}
	//	else
	//	{
	//		(*mLinkPointer)->weight -= (0.1 * weightRange);
	//	}

	//	//clamp the weight value
	//	if ((*mLinkPointer)->weight > NEAT::link_weight_clamp) 
	//	{
	//		(*mLinkPointer)->weight = NEAT::link_weight_clamp;
	//	}
	//	else if ((*mLinkPointer)->weight < -NEAT::link_weight_clamp)
	//	{
	//		(*mLinkPointer)->weight = -NEAT::link_weight_clamp;
	//	}

	//	return false;
	//}

	//std::list<NNode*>::iterator mNodePointer;
	//std::list<Link*>::iterator mLinkPointer;
	//int mInstrArgNums[MRL_NUM_INSTRUCTIONS];
	//int* mMRLInputArray;
	//int mNumMRLInputs;
 };

#endif

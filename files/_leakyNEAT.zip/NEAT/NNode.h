#ifndef __NEAT_NNODE_H__
#define __NEAT_NNODE_H__

#include "NEAT.h"
#include <math.h>

//Forward declarations
//class Trait;
class Link;

/* Activation Types */
typedef int functype;
const int SIGMOID=0;
const int POS_OR_NEG_SIGMOID=1;
const int LINEAR=2;

/* These are NNode types */
typedef int nodetype;
const int NEURON=0;
const int SENSOR=1;

typedef int nodeplace;
const int HIDDEN=0;
const int INPUT=1;
const int OUTPUT=2;
const int BIAS=3;

//Description: 

/* ----------------------------------------------------------------------- */
/* A NODE is either a NEURON or a SENSOR.  
   If it's a sensor, it can be loaded with a value for output
   If it's a neuron, it has a std::list of its incoming input signals (std::list<Link> is used) */
//Use an activation count to avoid flushing
class NNode
{
public:
  //NNode(nodetype ntype,int nodeid, double timeConstant, double newBias);

  NNode(nodetype ntype,int nodeid, nodeplace placement, double timeConstant, double newBias);

  //Construct a NNode off another NNode for genome purposes
  //NNode(NNode *n,Trait *t);
  NNode(NNode *n);

  //Construct the node out of a file specification using given list of traits
  //NNode (std::ifstream &iFile,std::vector<Trait*> &traits);

  ~NNode();

  friend class Network;
  friend class Genome;
  //friend class Population;

 protected:

  int activation_count;  //keeps track of which activation the node is currently in
  //double last_activation; //Holds the previous step's activation for recurrency
  //double last_activation2; //Holds the activation BEFORE the prevous step's
  //This is necessary for a special recurrent case when the innode 
  // of a recurrent link is one time step ahead of the outnode.
  // The innode then needs to send from TWO time steps ago

  //Trait *nodetrait; //Points to a trait of parameters

  NNode *analogue;  //Used for Gene decoding 
  NNode *dup;       //Used for Genome duplication

 public:
	functype ftype; //type is either SIGMOID ..or others that can be added
	nodetype type; //type is either NEURON or SENSOR 

	double synapticInput;  //The incoming activity before being processed 
	//double activation; //The total activation entering the NNode 
	double membranePotential; //The total activation entering the NNode 
	//bool active_flag;  //To make sure outputs are active
  
	//CTRNN stuff
	double time_constant;
	double bias;
	double firingRate; //firingRate = sigmoid(membranePotential)

  /* ************ LEARNING PARAMETERS *********** */
  /* The following parameters are for use in
     neurons that learn through habituation,
     sensitization, or Hebbian-type processes  */

  //double params[NEAT::num_trait_params];

  std::list<Link*> incoming; //A std::list of pointers to incoming weighted signals from other nodes
  std::list<Link*> outgoing;  //A std::list of pointers to links carrying this node's signal

  ////These members are used for graphing with GTK+/GDK
  //std::list<double> rowlevels;  //Depths from output where this node appears
  //int row;  //Final row decided upon for drawing this NNode in
  //int ypos;
  //int xpos;

  //friend std::ostream& operator<< (std::ostream& os, const NNode &thenode);
  //friend std::ostream& operator<< (std::ostream& os, const NNode *thenode); 

  int node_id;  //A node can be given an identification number for saving in files

  nodeplace gen_node_label;  //Used for genetic marking of nodes

  //double get_active_out(); //Just return activation for step
  double get_firing_rate(); //CTRNN version
  //double get_active_out_td(); //Return activation from PREVIOUS time step

  const nodetype get_type(); //Returns the type of the node, NEURON or SENSOR
  nodetype set_type(nodetype);  //Allows alteration between NEURON and SENSOR.  Returns its argument
  bool sensor_load(double); //If the node is a SENSOR, returns true and loads the value
  void add_incoming(NNode*,double); //Adds a Link to a new NNode in the incoming std::list
  //void add_incoming(NNode*,double,bool); //Adds a Link to a new NNode in the incoming std::list
  void flushback();  //Recursively deactivate backwards through the network
  //void flushback_check(std::list<NNode*> &seenlist);  //Verify flushing for debuginh

  //void  print_to_file(std::ofstream &outFile); //Print the node to a file

  //void derive_trait(Trait *curtrait);//Have NNode gain its properties from the trait

  //Find the greatest depth starting from this neuron at depth d
  int depth(int d,Network *mynet);

	void AddToBias(double value);
	void AddToTimeConstant(double value);

	// SIGMOID FUNCTION ********************************
	//This is a signmoidal activation function, which is an S-shaped squashing function
	//It smoothly limits the amplitude of the output of a neuron to between 0 and 1
	//It is a helper to the neural-activation function get_active_out
	//It is made inline so it can execute quickly since it is at every non-sensor 
	// node in a network.
	//NOTE:  In order to make node insertion in the middle of a link possible,
	// the signmoid can be shifted to the right and more steeply sloped:
	// slope=4.924273
	// constant= 2.4621365
	// These parameters optimize mean squared error between the old output,
	// and an output of a node inserted in the middle of a link between
	// the old output and some other node. 
	// When not right-shifted, the steepened slope is closest to a linear
	// ascent as possible between -0.5 and 0.5
	inline double fsigmoid(double activesum,double slope,double constant) 
	{
		//RIGHT SHIFTED ---------------------------------------------------------
		//return (1/(1+(exp(-(slope*activesum-constant)))));
		//41394 with 1 failure on 8 runs

		//LEFT SHIFTED ----------------------------------------------------------
		//return (1/(1+(exp(-(slope*activesum+constant)))));

		//PLAIN SIGMOID ---------------------------------------------------------
		return (1.0/(1.0+(exp(-activesum*0.4))));

		//LEFT SHIFTED NON-STEEPENED---------------------------------------------
		//return (1/(1+(exp(-activesum-constant)))); //simple left shifted

		//NON-SHIFTED STEEPENED
		//return (1/(1+(exp(-(slope*activesum))))); //Compressed
	}

	inline double pos_or_neg_sigmoid(double activesum,double slope,double constant) 
	{
		return (2.0/(1.0+(exp(-activesum))) - 1.0);
	}

	//output range: 0.0 to 1.0; scales the slope of the linear activation depending
	//on the range of activesum values since we want to avoid clamping the output.
	double mMinActiveSum;
	double mMaxActiveSum;
	inline double dynamic_linear(double activesum)
	{
		//Note: The first time this is called, both mMinActiveSum and mMaxActiveSum
		//will be set to activesum.

		if (activesum < mMinActiveSum)
		{
			mMinActiveSum = activesum;
		}

		if (activesum > mMaxActiveSum)
		{
			mMaxActiveSum = activesum;
		}

		double activeSumRange = mMaxActiveSum - mMinActiveSum;
		double output = 0.0;

		if (activeSumRange <= 0.0)
		{
			output = 0.0;
		}
		else
		{
			//output = (1.0/activeSumRange)*activesum + 0.5;
			output = (activesum - mMinActiveSum)/activeSumRange;
		}

		assert(output >= 0.0 && output <= 1.0);

		return output;

		//if (activesum < -1.0)
		//{
		//	return 0.0;
		//}
		//else if (activesum > 1.0)
		//{
		//	return 1.0;
		//}
		//else
		//{
		//	return (0.1*activesum + 0.5);
		//}
	}

	//inline double gaussianActivation(double activesum)
	//{
	//	return (exp(-0.3*activesum*activesum));
	//}

	void calculate_firing_rate()
	{
		if (SIGMOID == ftype)
		{
			firingRate=fsigmoid(membranePotential+bias, 0.0, 0.0);
		}
		else if (POS_OR_NEG_SIGMOID == ftype)
		{
			firingRate=pos_or_neg_sigmoid(membranePotential+bias, 0.0, 0.0);
		}
		else if (LINEAR == ftype)
		{
			firingRate=dynamic_linear(membranePotential+bias);
		}
		else
		{
			assert(false);
		}
	}
};

#endif

#include "NEAT_Utilities.h"
#include "Gene.h"
#include "Innovation.h"
#include "Link.h"
//#include "Trait.h"
#include "NNode.h"
#include "Network.h"
#include "Genome.h"

//Constructor which creates a genome from the given parameters.  isOscillatory
//decides whether to use fully-connected outputs and all recurrent links.
Genome::Genome(int id, int numInputs, int numOutputs, bool isOscillatory)
{
	double timeConstant = (NEAT::max_time_constant + NEAT::min_time_constant)/2.0;
	double bias = 0.0;

	genome_id = id;

	//Loop over neurons
	for (int i=1; i<=numInputs+numOutputs; i++)
	{
		NNode* newNode = NULL;

		if (i <= numInputs)
		{
			//input nodes
			newNode = new NNode(SENSOR, i, INPUT, timeConstant, bias);
		}
		else
		{
			//output nodes
			newNode = new NNode(NEURON, i, OUTPUT, timeConstant, bias);
		}

		nodes.push_back(newNode);
	}

	//Loop over connections
	Gene* newGene = NULL;
	int innovNum = 1;
	for (int j=1; j<=numOutputs; j++)
	{
		for (int k=1; k<=numInputs; k++)
		{
			//newGene = new Gene(k, j+numInputs, 0.0, isOscillatory, innovNum, true, nodes);
			newGene = new Gene(k, j+numInputs, 0.0, innovNum, true, nodes);
			genes.push_back(newGene);
			innovNum++;
		}
	}

	if (isOscillatory)
	{
		//Add more connections to make fully-connected output nodes...
		for (int j=1; j<=numOutputs; j++)
		{
			for (int k=1; k<=numOutputs; k++)
			{
				//newGene = new Gene(k+numInputs, j+numInputs, 0.0, isOscillatory, innovNum, true, nodes);
				newGene = new Gene(k+numInputs, j+numInputs, 0.0, innovNum, true, nodes);
				genes.push_back(newGene);
				innovNum++;
			}
		}
	}
}

//Constructor which spawns off an input XML file
Genome::Genome(std::string filename)
{
	TiXmlDocument newGenome;
	bool success = newGenome.LoadFile(filename);
	if (false == success)
	{
		std::cout << "Error: Failed to load controller file: " << filename << std::endl;
		return;
	}
	
	//Read in unique genome ID
	TiXmlElement* rootElement = newGenome.RootElement();
	genome_id = atoi(rootElement->FirstChild("title")->FirstChild()->Value());

	//Loop over neurons
	TiXmlNode* nodePtr = NULL;
	TiXmlElement* elementPtr = NULL;
	while (nodePtr = rootElement->IterateChildren("neuron", nodePtr))
	{
		elementPtr = nodePtr->ToElement();

		nodetype type;
		nodeplace placement;
		int id = atoi(elementPtr->Attribute("id"));
		double timeConstant = atof(elementPtr->Attribute("time-constant"));
		double bias = atof(elementPtr->Attribute("bias"));
		std::string typeString = elementPtr->Attribute("type");

		if ("input" == typeString)
		{
			type = SENSOR;
			placement = INPUT;
		}
		else if ("hidden" == typeString)
		{
			type = NEURON;
			placement = HIDDEN;
		}
		else if ("output" == typeString)
		{
			type = NEURON;
			placement = OUTPUT;
		}
		else
		{
			//Note that no BIAS nodes are used...
			assert(false);
		}

		NNode* newNode = new NNode(type, id, placement, timeConstant, bias); 
		nodes.push_back(newNode);
	}

	//Loop over connections
	nodePtr = NULL;
	elementPtr = NULL;
	while (nodePtr = rootElement->IterateChildren("connection", nodePtr))
	{
		elementPtr = nodePtr->ToElement();

		int sourceID = atoi(elementPtr->Attribute("src-id"));
		int targetID = atoi(elementPtr->Attribute("tgt-id"));
		double weight = atof(elementPtr->Attribute("weight"));
		//bool recurrent = atoi(elementPtr->Attribute("recurrent"));
		int innovNum = atoi(elementPtr->Attribute("innovation"));
		bool enable = atoi(elementPtr->Attribute("enable"));

		//Gene* newGene = new Gene(sourceID, targetID, weight, recurrent, innovNum, enable, nodes);
		Gene* newGene = new Gene(sourceID, targetID, weight, innovNum, enable, nodes);
		genes.push_back(newGene);
	}
}

//Special constructor which spawns off an input file
//This constructor assumes that some routine has already read in GENOMESTART
//Genome::Genome(int id, std::ifstream &iFile)
//{
//   char curword[20];  //max word size of 20 characters
//
//   int done=0;
//
//   genome_id=id;
//
//   //Loop until file is finished, parsing each line
//   while (!done)
//	{
//		iFile>>curword;
//
//		//Check for end of Genome
//		if (strcmp(curword,"genomeend")==0)
//		{
//			int idcheck;
//			iFile>>idcheck;
//			if (idcheck!=genome_id) std::cout<<"ERROR: id mismatch in genome"<<std::endl;
//			done=1;
//		}
//
//		//Ignore comments surrounded by /* */ - they get printed to screen
//		else if (strcmp(curword,"/*")==0) 
//		{
//			iFile>>curword;
//			while (strcmp(curword,"*/")!=0) 
//			{
//				std::cout<<curword<<" ";
//				iFile>>curword;
//			}
//			std::cout<<std::endl;
//		}
//
//		//Read in a trait
//		else if (strcmp(curword,"trait")==0) 
//		{
//			Trait *newtrait;
//
//			//Allocate the new trait
//			newtrait=new Trait(iFile);
//
//			//Add trait to vector of traits
//			traits.push_back(newtrait);
//		}
//
//		//Read in a node
//		else if (strcmp(curword,"node")==0)
//		{
//			NNode *newnode;
//
//			//Allocate the new node
//			newnode=new NNode(iFile,traits);
//
//			//Add the node to the std::list of nodes
//			nodes.push_back(newnode);
//		}
//
//		//Read in a Gene
//		else if (strcmp(curword,"gene")==0)
//		{
//			Gene *newgene;
//
//			//Allocate the new Gene
//			newgene=new Gene(iFile,traits,nodes);
//
//			//Add the gene to the genome
//			genes.push_back(newgene);
//
//			//std::cout<<"Added gene "<<newgene<<std::endl;
//		}
//	} //end of while loop
//}

////Constructor which takes full genome specs and puts them into the new one
//Genome::Genome(int id,std::vector<Trait*> t, std::list<NNode*> n, std::list<Gene*> g) {
//   genome_id=id;
//   traits=t;
//   nodes=n; 
//   genes=g;
//}
//Constructor which takes full genome specs and puts them into the new one
Genome::Genome(int id, std::list<NNode*> n, std::list<Gene*> g)
{
	genome_id=id;
   //traits=t;
   nodes=n; 
   genes=g;
}

//Constructor which takes in links (not genes) and creates a Genome
//Genome::Genome(int id,std::vector<Trait*> t, std::list<NNode*> n, std::list<Link*> links)
//{
//   std::list<Link*>::iterator curlink;
//   Gene *tempgene;
//   traits=t;
//   nodes=n;
//
//   genome_id=id;
//   
//   //We go through the links and turn them into original genes
//   for(curlink=links.begin();curlink!=links.end();++curlink)
//	{
//   //Create genes one at a time
//   tempgene=new Gene((*curlink)->linktrait, (*curlink)->weight,(*curlink)->in_node,(*curlink)->out_node,(*curlink)->is_recurrent,1.0,0.0);
//   genes.push_back(tempgene);
//   }
//}
Genome::Genome(int id, std::list<NNode*> n, std::list<Link*> links)
{
   std::list<Link*>::iterator curlink;
   Gene *tempgene;
   //traits=t;
   nodes=n;

   genome_id=id;
   
   //We go through the links and turn them into original genes
   for(curlink=links.begin();curlink!=links.end();++curlink)
	{
		//Create genes one at a time
		//tempgene=new Gene((*curlink)->weight,(*curlink)->in_node,(*curlink)->out_node,(*curlink)->is_recurrent,1.0,0.0);
		tempgene=new Gene((*curlink)->weight,(*curlink)->in_node,(*curlink)->out_node,1.0,0.0);
		genes.push_back(tempgene);
   }
}

/* This special constructor creates a Genome
with i inputs, o outputs, n out of nmax hidden units, and random
connectivity.  If r is true then recurrent connections will
be included. 
The last input is a bias
Linkprob is the probability of a link 
*/
//Genome::Genome(int new_id,int i, int o, int n,int nmax, bool r, double linkprob)
//{
//   int totalnodes;
//   bool *cm; //The connection matrix which will be randomized
//   bool *cmp; //Connection matrix pointer
//   int matrixdim;
//   int count;
//   
//   int ncount; //Node and connection counters
//   int ccount;
//
//   int row;  //For navigating the matrix
//   int col;
//
//   double new_weight;
//
//   int maxnode; //No nodes above this number for this genome
//
//   int first_output; //Number of first output node
//
//   totalnodes=i+o+nmax;
//   matrixdim=totalnodes*totalnodes;
//   cm=new bool[matrixdim];  //Dimension the connection matrix
//   maxnode=i+n;
//
//   first_output=totalnodes-o+1;
//
//   //For creating the new genes
//   NNode *newnode;
//   Gene *newgene;
//   Trait *newtrait;
//   NNode *in_node;
//   NNode *out_node;
//
//   //Retrieves the nodes pointed to by connection genes
//   std::list<NNode*>::iterator node_iter;
//
//   //Assign the id
//   genome_id=new_id;
//
//   std::cout<<"Assigned id "<<genome_id<<std::endl;
//
//   //Step through the connection matrix, randomly assigning bits
//   cmp=cm;
//   for(count=0;count<matrixdim;count++)
//	{
//		if (randfloat()<linkprob)
//		{
//			*cmp=true;
//		}
//		else
//		{
//			*cmp=false;
//		}
//
//		cmp++;
//   }
//
//   //Create a dummy trait (this is for future expansion of the system)
//   newtrait=new Trait(1,0,0,0,0,0,0,0,0,0);
//   traits.push_back(newtrait);
//
//   //Build the input nodes
//   for(ncount=1;ncount<=i;ncount++)
//	{
//		double newTimeConstant = (NEAT::min_time_constant+NEAT::max_time_constant)*0.5 
//			+ gaussrand()*NEAT::time_constant_mut_power;
//		if (newTimeConstant < NEAT::min_time_constant)
//		{
//			newTimeConstant = NEAT::min_time_constant;
//		}
//		double newBias = gaussrand()*NEAT::bias_mut_power;
//
//		if (ncount<i)
//		{
//			newnode=new NNode(SENSOR,ncount,INPUT,newTimeConstant, newBias);
//		}
//		else 
//		{
//			newnode=new NNode(SENSOR,ncount,BIAS,newTimeConstant, newBias);
//		}
//
//		newnode->nodetrait=newtrait;
//
//		//Add the node to the std::list of nodes
//		nodes.push_back(newnode);
//   }
//
//   //Build the hidden nodes
//   for(ncount=i+1;ncount<=i+n;ncount++)
//	{
//		double newTimeConstant = (NEAT::min_time_constant+NEAT::max_time_constant)*0.5 
//			+ gaussrand()*NEAT::time_constant_mut_power;
//		if (newTimeConstant < NEAT::min_time_constant)
//		{
//			newTimeConstant = NEAT::min_time_constant;
//		}
//		double newBias = gaussrand()*NEAT::bias_mut_power;
//
//		newnode=new NNode(NEURON,ncount,HIDDEN,newTimeConstant,newBias);
//		newnode->nodetrait=newtrait;
//		//Add the node to the std::list of nodes
//		nodes.push_back(newnode);
//   }
//   
//   //Build the output nodes
//   for(ncount=first_output;ncount<=totalnodes;ncount++)
//	{
//		double newTimeConstant = (NEAT::min_time_constant+NEAT::max_time_constant)*0.5 
//			+ gaussrand()*NEAT::time_constant_mut_power;
//		if (newTimeConstant < NEAT::min_time_constant)
//		{
//			newTimeConstant = NEAT::min_time_constant;
//		}
//		double newBias = gaussrand()*NEAT::bias_mut_power;
//
//		newnode=new NNode(NEURON,ncount,OUTPUT,newTimeConstant,newBias);
//		newnode->nodetrait=newtrait;
//		//Add the node to the std::list of nodes
//		nodes.push_back(newnode);
//   }
//
//   std::cout<<"Built nodes"<<std::endl;
//
//   //Connect the nodes 
//   ccount=1;  //Start the connection counter
//   
//   //Step through the connection matrix, creating connection genes
//   cmp=cm;
//   count=0;
//   for(col=1;col<=totalnodes;col++)
//   for(row=1;row<=totalnodes;row++) {
////Only try to create a link if it is in the matrix
////and not leading into a sensor
//	
//if ((*cmp==true)&&(col>i)&&
//	   ((col<=maxnode)||(col>=first_output))&&
//	   ((row<=maxnode)||(row>=first_output))) {
//	//If it isn't recurrent, create the connection no matter what
//	if (col>row) {
//
//	   //Retrieve the in_node
//	   node_iter=nodes.begin();
//	   while((*node_iter)->node_id!=row)
//	   node_iter++;
//
//	   in_node=(*node_iter);
//
//	   //Retrieve the out_node
//	   node_iter=nodes.begin();
//	   while((*node_iter)->node_id!=col)
//	   node_iter++;
//
//	   out_node=(*node_iter);
//
//	   //Create the gene
//	   new_weight=randposneg()*randfloat();
//	   newgene=new Gene(newtrait,new_weight, in_node, out_node,false,count,new_weight);
//
//	   //Add the gene to the genome
//	   genes.push_back(newgene);
//	}
//	else if (r) {
//	   //Create a recurrent connection
//	    	   
//	   //Retrieve the in_node
//	   node_iter=nodes.begin();
//	   while((*node_iter)->node_id!=row)
//	   node_iter++;
//	   
//	   in_node=(*node_iter);
//	   
//	   //Retrieve the out_node
//	   node_iter=nodes.begin();
//	   while((*node_iter)->node_id!=col)
//	   node_iter++;
//	   
//	   out_node=(*node_iter);
//	   
//	   //Create the gene
//	   new_weight=randposneg()*randfloat();
//	   newgene=new Gene(newtrait,new_weight, in_node, out_node,true,count,new_weight);
//
//	   //Add the gene to the genome
//	   genes.push_back(newgene);
//
//	}
//
//}
//
//count++; //increment gene counter	    
//cmp++;
//   }
//
//   delete [] cm;
//}

//Destructor kills off all std::lists (including the trait vector)
Genome::~Genome()
{
	//std::vector<Trait*>::iterator curtrait;
   std::list<NNode*>::iterator curnode;
   std::list<Gene*>::iterator curgene;

   //for(curtrait=traits.begin();curtrait!=traits.end();++curtrait) {
   //delete (*curtrait);
   //}

   for(curnode=nodes.begin();curnode!=nodes.end();++curnode) {
   delete (*curnode);
   }
   
   for(curgene=genes.begin();curgene!=genes.end();++curgene) {
   delete (*curgene);
   }

}

//Non-operator printing of genome to screen
//void Genome::print_genome()
//{
//	std::list<NNode*>::iterator curnode;
//	std::list<Gene*>::iterator curgene;
//	std::vector<Trait*>::iterator curtrait;
//
//	Genome *thegenome=this;
//
//	std::list<NNode*> nodes=thegenome->nodes;
//	std::list<Gene*> genes=thegenome->genes;
//	std::vector<Trait*> traits=thegenome->traits;
//
//	std::cout<<"GENOME START"<<std::endl;
//
//	for(curnode=nodes.begin();curnode!=nodes.end();++curnode)
//	{
//		if (((*curnode)->gen_node_label)==INPUT)
//			std::cout<<"I";
//		else if (((*curnode)->gen_node_label)==OUTPUT)
//			std::cout<<"O";
//		else if (((*curnode)->gen_node_label)==HIDDEN)
//			std::cout<<"H";
//		else if (((*curnode)->gen_node_label)==BIAS)
//			std::cout<<"B";
//
//		std::cout<<(*curnode)<<" ";
//	}
//	std::cout<<std::endl;
//
//	for(curgene=genes.begin();curgene!=genes.end();++curgene)
//	{
//		std::cout<<(*curgene)<<" ";
//	}
//	std::cout<<std::endl;
//
//	std::cout<<"Traits: ";
//	for(curtrait=traits.begin();curtrait!=traits.end();++curtrait)
//	{
//		std::cout<<(*curtrait)<<" ";
//	}
//	std::cout<<std::endl;
//
//	std::cout<<"GENOME END"<<std::endl;
//}

//For debugging: A number of tests can be run on a genome to check its
// integrity
//Note: Some of these tests do not indicate a bug, but rather are meant
//  to be used to detect specific system states
//bool Genome::verify()
//{
//	std::list<NNode*>::iterator curnode;
//	std::list<Gene*>::iterator curgene;
//	std::list<Gene*>::iterator curgene2;
//	NNode *inode;
//	NNode *onode;
//
//	bool disab;
//
//	int last_id;
//
//	int pause;
//
//	//std::cout<<"Verifying Genome id: "<<this->genome_id<<std::endl;
//
//	if (this==0)
//	{
//		std::cout<<"ERROR GENOME EMPTY"<<std::endl;
//		std::cin>>pause;
//	}
//
//	//Check each gene's nodes
//	for(curgene=genes.begin();curgene!=genes.end();++curgene)
//	{
//		inode=((*curgene)->lnk)->in_node;
//		onode=((*curgene)->lnk)->out_node;
//
//		//Look for inode
//		curnode=nodes.begin();
//		while((curnode!=nodes.end())&&((*curnode)!=inode))
//		{
//			++curnode;
//		}
//
//		if (curnode==nodes.end())
//		{
//			std::cout<<"MISSING iNODE FROM GENE NOT IN NODES OF GENOME!!"<<std::endl;
//			std::cin>>pause;
//			return false;
//		}
//
//		//Look for onode
//		curnode=nodes.begin();
//		while((curnode!=nodes.end())&&
//		((*curnode)!=onode))
//		++curnode;
//
//		if (curnode==nodes.end())
//		{
//			std::cout<<"MISSING oNODE FROM GENE NOT IN NODES OF GENOME!!"<<std::endl;
//			std::cin>>pause;
//			return false;
//		}
//	}
//
//	//Check for NNodes being out of order
//	last_id=0;
//	for(curnode=nodes.begin();curnode!=nodes.end();++curnode)
//	{
//		if ((*curnode)->node_id<last_id)
//		{
//		std::cout<<"ALERT: NODES OUT OF ORDER in "<<this<<std::endl;
//		std::cin>>pause;
//		return false;
//		}
//
//		last_id=(*curnode)->node_id;
//	}
//
//
//	//Make sure there are no duplicate genes
//	for(curgene=genes.begin();curgene!=genes.end();++curgene)
//	{
//		for(curgene2=genes.begin();curgene2!=genes.end();++curgene2)
//		{
//			if (((*curgene)!=(*curgene2))&&
//			((((*curgene)->lnk)->is_recurrent)==(((*curgene2)->lnk)->is_recurrent))&&
//			((((((*curgene2)->lnk)->in_node)->node_id)==((((*curgene)->lnk)->in_node)->node_id))&&
//			(((((*curgene2)->lnk)->out_node)->node_id)==((((*curgene)->lnk)->out_node)->node_id))))
//			{
//				std::cout<<"ALERT: DUPLICATE GENES: "<<(*curgene)<<(*curgene2)<<std::endl;
//				std::cout<<"INSIDE GENOME: "<<this<<std::endl;
//
//				std::cin>>pause;
//			}
//		}
//	}
//
//	//See if a gene is not disabled properly
//	//Note this check does not necessary mean anything is wrong
//	/*
//	if (nodes.size()>=15) {
//	disab=false;
//	//Go through genes and see if one is disabled
//	for(curgene=genes.begin();curgene!=genes.end();++curgene) {
//	if (((*curgene)->enable)==false) disab=true;
//	}
//
//	if (disab==false) {
//	std::cout<<"ALERT: NO DISABLED GENE IN GENOME: "<<this<<std::endl;
//	//std::cin>>pause;
//	}
//
//	}
//	*/
//
//	//Check for 2 disables in a row
//	//Note:  Again, this is not necessarily a bad sign
//	if (nodes.size()>=500)
//	{
//		disab=false;
//		for(curgene=genes.begin();curgene!=genes.end();++curgene)
//		{
//			if ((((*curgene)->enable)==false)&&(disab==true))
//			{
//				std::cout<<"ALERT: 2 DISABLES IN A ROW: "<<this<<std::endl;
//			}
//			if (((*curgene)->enable)==false)
//			{
//				disab=true;
//			}
//			else
//			{
//				disab=false;
//			}
//		}
//	}
//
//	//std::cout<<"GENOME OK!"<<std::endl;
//
//	return true;
//}

//Create a network from a genome
Network *Genome::genesis(int id)
{
  std::list<NNode*>::iterator curnode; 
  std::list<Gene*>::iterator curgene;
  NNode *newnode;
  //Trait *curtrait;
  Link *curlink;
  Link *newlink;
  
  //Inputs and outputs will be collected here for the network
  //All nodes are collected in an all_list- 
  //this will be used for later safe destruction of the net
  std::list<NNode*> inlist;
  std::list<NNode*> outlist;
  std::list<NNode*> all_nodes_list;

  std::list<Link*> all_links_list;

  //Gene translation variables
  NNode *inode;
  NNode *onode;

  //The new network
  Network *newnet;

  //DEBUG: Remove
  //print_Genome_tofile(this,"genesisfile");

  //Create the nodes
  for(curnode=nodes.begin();curnode!=nodes.end();++curnode)
  {
	  //The following constructor has now been removed.  6/23/04
	  //newnode=new NNode((*curnode)->type,(*curnode)->node_id, (*curnode)->time_constant, (*curnode)->bias);
	  
	  newnode=new NNode((*curnode)->type,(*curnode)->node_id, (*curnode)->gen_node_label, 
		  (*curnode)->time_constant, (*curnode)->bias);

    //Derive the node parameters from the trait pointed to
    //curtrait=(*curnode)->nodetrait;
    //newnode->derive_trait(curtrait);
 
    //Check for input or output designation of node
    if (((*curnode)->gen_node_label)==INPUT) 
      inlist.push_back(newnode);
    if (((*curnode)->gen_node_label)==BIAS) 
      inlist.push_back(newnode);
    if (((*curnode)->gen_node_label)==OUTPUT)
      outlist.push_back(newnode);

    //Keep track of all nodes, not just input and output
    all_nodes_list.push_back(newnode);

    //Have the node specifier point to the node it generated
    (*curnode)->analogue=newnode;

  }

  //Create the links by iterating through the genes
  for(curgene=genes.begin();curgene!=genes.end();++curgene) {
    //Only create the link if the gene is enabled
    if (((*curgene)->enable)==true) {
      curlink=(*curgene)->lnk;
      inode=(curlink->in_node)->analogue;
      onode=(curlink->out_node)->analogue;
      //NOTE: This line could be run through a recurrency check if desired
      // (no need to in the current implementation of NEAT)
      //newlink=new Link(curlink->weight,inode,onode,curlink->is_recurrent);
		newlink=new Link(curlink->weight,inode,onode);
      
      (onode->incoming).push_back(newlink);
      (inode->outgoing).push_back(newlink);

		all_links_list.push_back(newlink);

      //Derive link's parameters from its Trait pointer
      //curtrait=(curlink->linktrait);
      
      //curlink->derive_trait(curtrait);
    }
  }

  //Create the new network
  newnet=new Network(inlist,outlist,all_nodes_list,all_links_list,id);

  //Attach genotype and phenotype together
  newnet->genotype=this;
  phenotype=newnet;

  return newnet;
}

//Save this Genome as an XML file.
void Genome::save_as_xml(const std::string& filename)
{
	TiXmlDocument newDocument(filename);

	//Add the XML declaration
	TiXmlDeclaration declaration("1.0", "", "yes");
	newDocument.InsertEndChild(declaration);

	//Create the single top-level element
	TiXmlElement networkElement("network");

	//Add the genome id
	TiXmlElement genomeIDElement("title");
	char genomeIDString[32];
	sprintf(genomeIDString, "%d", genome_id);
	TiXmlText genomeIDText(genomeIDString);
	genomeIDElement.InsertEndChild(genomeIDText);
	networkElement.InsertEndChild(genomeIDElement);

	//Loop over neurons
	//The following variables are used only for generating NEVT tags.
	int inputCount = 0;
	int hiddenCount = 0;
	int outputCount = 0;
	//int numInputs = CountInputNodes();
	int numHidden = CountHiddenNodes();
	//int numOutputs = CountOutputNodes();
	//double networkSideLength = sqrtf(nodes.size());
	int hiddenNodesSize = (int)ceil(sqrtf((float)numHidden));

	std::list<NNode*>::iterator curnode;
	for(curnode = nodes.begin(); curnode != nodes.end(); curnode++)
	{
		TiXmlElement newNeuron("neuron");

		//Node ID attribute
		newNeuron.SetAttribute("id", (*curnode)->node_id);

		//Node type attribute
		std::string typeString;
		switch((*curnode)->gen_node_label)
		{
			case HIDDEN:
				typeString = "hidden";
				break;
			case INPUT:
				typeString = "input";
				break;
			case OUTPUT:
				typeString = "output";
				break;
			default:
				//Should never get here; no BIAS nodes are used.
				assert(false);
		}

		newNeuron.SetAttribute("type", typeString);

		if (NEAT::use_nevt)
		{
			//Generating tags used by NEVT (nevt.sourceforge.net) to generate SVG files;
			//NEVT needs a "layer hint" attribute (left to right position in the SVG file)
			//and a "position hint" (top to bottom position in the SVG file).

			if ("input" == typeString)
			{
				//First layer of nodes
				newNeuron.SetAttribute("hint-layer", 1);
				newNeuron.SetDoubleAttribute("hint-position", inputCount + 1.0);
				inputCount++;
			}
			else if ("hidden" == typeString)
			{
				//All hidden nodes
				newNeuron.SetAttribute("hint-layer", hiddenCount/hiddenNodesSize + 3);
				double hintPosition = hiddenCount % hiddenNodesSize + 1.0;
				newNeuron.SetDoubleAttribute("hint-position", hintPosition);
				hiddenCount++;
			}
			else if ("output" == typeString)
			{
				//Last layer of nodes
				int outputLayer = 0;
				if (0 == numHidden)
				{
					outputLayer = 4;
				}
				else
				{
					outputLayer = (numHidden-1)/hiddenNodesSize + 5;
				}
				newNeuron.SetAttribute("hint-layer", outputLayer);
				double hintPosition = outputCount + 1.0;
				newNeuron.SetDoubleAttribute("hint-position", hintPosition);
				outputCount++;
			}
			else
			{
				assert(false);
			}
		}

		//Time constant attribute
		newNeuron.SetDoubleAttribute("time-constant", (*curnode)->time_constant);

		//Bias attribute
		newNeuron.SetDoubleAttribute("bias", (*curnode)->bias);

		networkElement.InsertEndChild(newNeuron);
	}

	//Loop over connections
	std::list<Gene*>::iterator curgene;
	for(curgene = genes.begin(); curgene != genes.end(); curgene++)
	{
		TiXmlElement newConnection("connection");

		newConnection.SetAttribute("src-id", (*curgene)->lnk->in_node->node_id);
		newConnection.SetAttribute("tgt-id", (*curgene)->lnk->out_node->node_id);
		newConnection.SetDoubleAttribute("weight", (*curgene)->lnk->weight);
		//newConnection.SetAttribute("recurrent", (*curgene)->lnk->is_recurrent);
		newConnection.SetAttribute("innovation", (int)(*curgene)->innovation_num);
		newConnection.SetAttribute("enable", (*curgene)->enable);

		networkElement.InsertEndChild(newConnection);
	}

	//Add the single top-level element to the document
	newDocument.InsertEndChild(networkElement);

	//Write the document to a file.
	if (false == newDocument.SaveFile())
	{
		std::cout << "Error: Failed to save controller file: " << filename << std::endl;
		return;
	}
}

////Print the genome to a file
//void Genome::print_to_file(std::ofstream &outFile)
//{
// std::vector<Trait*>::iterator curtrait;
//  std::list<NNode*>::iterator curnode;
//  std::list<Gene*>::iterator curgene;
//
//  outFile<<"genomestart "<<genome_id<<std::endl;
// 
//  //Output the traits
//  for(curtrait=traits.begin();curtrait!=traits.end();++curtrait) {
//    (*curtrait)->trait_id=curtrait-traits.begin()+1;
//    (*curtrait)->print_to_file(outFile);
//  }
//
//  //Output the nodes
//  for(curnode=nodes.begin();curnode!=nodes.end();++curnode) {
//    (*curnode)->print_to_file(outFile);
//  }
//
//  //Output the genes
//  for(curgene=genes.begin();curgene!=genes.end();++curgene) {
//    (*curgene)->print_to_file(outFile);
//  }
//
//  outFile<<"genomeend "<<genome_id<<std::endl;
//}

//void Genome::print_to_filename(char *filename) {
//  std::ofstream oFile(filename,std::ios::out);
//  print_to_file(oFile);
//  oFile.close();
//}

//Return id of final NNode in Genome
int Genome::get_last_node_id() {
  return ((*(nodes.rbegin()))->node_id)+1;
}  

//Return last innovation number in Genome
double Genome::get_last_gene_innovnum() {
  return ((*(genes.rbegin()))->innovation_num)+1;       
}

//Return a pointer to a new genome that is a copy of this one
Genome *Genome::duplicate(int new_id)
{
  //Collections for the new Genome
 //std::vector<Trait*> traits_dup;
  std::list<NNode*> nodes_dup;
  std::list<Gene*> genes_dup;

  //Iterators for the old Genome
 //std::vector<Trait*>::iterator curtrait;
  std::list<NNode*>::iterator curnode;
  std::list<Gene*>::iterator curgene;

  //New item pointers
  //Trait *newtrait;
  NNode *newnode;
  Gene *newgene;
  //Trait *assoc_trait;  //Trait associated with current item
  
  NNode *inode; //For forming a gene 
  NNode *onode; //For forming a gene
  //Trait *traitptr;

  Genome *newgenome;

  //verify();

  ////Duplicate the traits
  //for(curtrait=traits.begin();curtrait!=traits.end();++curtrait) {
  //  newtrait=new Trait(*curtrait);
  //  traits_dup.push_back(newtrait);
  //}

  //Duplicate NNodes
  for(curnode=nodes.begin();curnode!=nodes.end();++curnode)
  {
    //First, find the trait that this node points to
 //   if (((*curnode)->nodetrait)==0) assoc_trait=0;
 //   else {
 //     curtrait=traits_dup.begin();
 //     while(((*curtrait)->trait_id)!=(((*curnode)->nodetrait)->trait_id))
	//++curtrait;
 //     assoc_trait=(*curtrait);
 //   }
    
    //newnode=new NNode(*curnode,assoc_trait);
	 newnode=new NNode(*curnode);

    (*curnode)->dup=newnode;  //Remember this node's old copy
    //(*curnode)->activation_count=55;
    nodes_dup.push_back(newnode);    
  }

  //Duplicate Genes
  for(curgene=genes.begin();curgene!=genes.end();++curgene) {
    //First find the nodes connected by the gene's link

    inode=(((*curgene)->lnk)->in_node)->dup;
    onode=(((*curgene)->lnk)->out_node)->dup;

    //Get a pointer to the trait expressed by this gene
 //   traitptr=((*curgene)->lnk)->linktrait;
 //   if (traitptr==0) assoc_trait=0;
 //   else {
 //     curtrait=traits_dup.begin();
 //     while(((*curtrait)->trait_id)!=(traitptr->trait_id))
	//++curtrait;
 //     assoc_trait=(*curtrait);
 //   }
    
    //newgene=new Gene(*curgene,assoc_trait,inode,onode);
	 newgene=new Gene(*curgene,inode,onode);
    genes_dup.push_back(newgene);
  }

  //Finally, return the genome
  //newgenome=new Genome(new_id,traits_dup,nodes_dup,genes_dup);
  newgenome=new Genome(new_id,nodes_dup,genes_dup);

  return newgenome;
}

//void Genome::mutate_random_trait() {
// std::vector<Trait*>::iterator thetrait; //Trait to be mutated
//  int traitnum;
//
//  //Choose a random traitnum
//  traitnum=randint(0,(traits.size())-1);
//
//  //Retrieve the trait and mutate it
//  thetrait=traits.begin();
//  (*(thetrait[traitnum])).mutate();
//  
//  //TRACK INNOVATION? (future possibility)
//  
//}

//This chooses a random gene, extracts the link from it,
//and repoints the link to a random trait
//void Genome::mutate_link_trait(int times) {
//  int traitnum;
//  int genenum;
//  std::list<Gene*>::iterator thegene;     //Link to be mutated
// std::vector<Trait*>::iterator thetrait; //Trait to be attached
//  int count;
//  int loop;
//
//  for(loop=1;loop<=times;loop++) {
//
//    //Choose a random traitnum
//    traitnum=randint(0,(traits.size())-1);
//    
//    //Choose a random linknum
//    genenum=randint(0,genes.size()-1);
//    
//    //set the link to point to the new trait
//    thegene=genes.begin();
//    for(count=0;count<genenum;count++)
//      ++thegene;
//    
//    thetrait=traits.begin();
//    
//    ((*thegene)->lnk)->linktrait=thetrait[traitnum];
//    
//    //TRACK INNOVATION- future use
//    //(*thegene)->mutation_num+=randposneg()*randfloat()*linktrait_mut_sig;
//
//  }
//}

//This chooses a random node
//and repoints the node to a random trait
//void Genome::mutate_node_trait(int times) {
//  int traitnum;
//  int nodenum;
//  std::list<NNode*>::iterator thenode;     //Link to be mutated
//  std::list<Gene*>::iterator thegene;  //Gene to record innovation
// std::vector<Trait*>::iterator thetrait; //Trait to be attached
//  int count;
//  int loop;
//
//  for(loop=1;loop<=times;loop++) {
//
//    //Choose a random traitnum
//    traitnum=randint(0,(traits.size())-1);
//    
//    //Choose a random nodenum
//    nodenum=randint(0,nodes.size()-1);
//    
//    //set the link to point to the new trait
//    thenode=nodes.begin();
//    for(count=0;count<nodenum;count++)
//      ++thenode;
//    
//    thetrait=traits.begin();
//    
//    (*thenode)->nodetrait=thetrait[traitnum];
//    
//    //TRACK INNOVATION! - possible future use
//    //for any gene involving the mutated node, perturb that gene's
//    //mutation number
//    //for(thegene=genes.begin();thegene!=genes.end();++thegene) {
//    //  if (((((*thegene)->lnk)->in_node)==(*thenode))
//    //  ||
//    //  ((((*thegene)->lnk)->out_node)==(*thenode)))
//    //(*thegene)->mutation_num+=randposneg()*randfloat()*nodetrait_mut_sig;
//    //}
//  }
//}

//Set all link weights, node biases, and node time constants to random values.
//This is useful at the beginning of evolution to generate totally random networks.
void Genome::randomize_all_parameters()
{
	double randomNum = 0.0;

	//Loop over all genes (links)
	std::list<Gene*>::iterator curgene;
	for(curgene = genes.begin(); curgene != genes.end(); curgene++)
	{
		randomNum = (2*NEAT::link_weight_clamp) * randfloat() - NEAT::link_weight_clamp;
		(*curgene)->lnk->weight = randomNum;
		(*curgene)->mutation_num = randomNum;
	}

	//Loop over all node biases
	std::list<NNode*>::iterator curnode;
	for(curnode = nodes.begin(); curnode != nodes.end(); curnode++)
	{
		randomNum = (2*NEAT::bias_clamp) * randfloat() - NEAT::bias_clamp;
		(*curnode)->bias = randomNum;
	}

	//Loop over all node time constants
	for(curnode = nodes.begin(); curnode != nodes.end(); curnode++)
	{
		randomNum = (NEAT::max_time_constant - NEAT::min_time_constant) * randfloat()
			+ NEAT::min_time_constant;
		(*curnode)->time_constant = randomNum;
	}
}

//Add Gaussian noise to some parameters.
void Genome::mutate_some_parameters()
{
	//Calculate probability of each parameter getting mutated.
	double perParamMutationProb = NEAT::avg_mutations_per_genome/((double)GetNumParams());

	bool severe;  //Once in a while really shake things up.
	if (randfloat() > 0.9)
	{
		severe=true;
	}
	else
	{
		severe=false;
	}

	//MUTATE WEIGHTS
	double geneIndex = 0.0;  //counts gene placement
	double gene_total = (double)genes.size();
	double geneEndPart = gene_total * 0.8; //Signifies the last part of the genome

	std::list<Gene*>::iterator curgene;
	for(curgene=genes.begin();curgene!=genes.end();curgene++)
	{
		if (randfloat() < perParamMutationProb)
		{
			//Mutate this gene.

			//The following if determines the probabilities of doing cold gaussian
			//mutation, meaning the probability of replacing a link weight with
			//another, entirely random weight.  It is meant to bias such mutations
			//to the tail of a genome, because that is where less time-tested genes
			//reside.  The gausspoint and coldgausspoint represent values above
			//which a random float will signify that kind of mutation.  

			//Probability of doing cold Gaussian (as opposed to a normal Gaussian mutation).
			double coldGaussProb = 0.0;

			if (severe) 
			{
				coldGaussProb = 0.8;
			}
			else if ((gene_total >= 10.0) && (geneIndex > geneEndPart))
			{
				coldGaussProb = 0.5;
			}
			else 
			{
				////"Normal" case...

				////Half the time don't do any cold mutations
				//if (randfloat() > 0.5)
				//{
					coldGaussProb = 0.0;
				//}
				//else
				//{
				//	coldGaussProb = 0.5;
				//}
			}

			//double randnum = randposneg() * randfloat() * NEAT::weight_mut_power;
			double randnum = gaussrand() * NEAT::weight_mut_power;

			//Decide what kind of mutation to do
			if (randfloat() > coldGaussProb)
			{
				//Normal Gaussian; add a random Gaussian value.
				((*curgene)->lnk)->weight += randnum;
			}
			else
			{
				//Cold Gaussian; reset to a random Gaussian value.
				((*curgene)->lnk)->weight = randnum;
			}

			//clamp the weights (experimental)
			if (((*curgene)->lnk)->weight > NEAT::link_weight_clamp)
			{
				((*curgene)->lnk)->weight = NEAT::link_weight_clamp;
			}
			else if (((*curgene)->lnk)->weight < -NEAT::link_weight_clamp)
			{
				((*curgene)->lnk)->weight = -NEAT::link_weight_clamp;
			}

			//Record the innovation
			(*curgene)->mutation_num=((*curgene)->lnk)->weight;
		}

		geneIndex+=1.0;
	} //End of for loop

	//MUTATE TIME CONSTANTS AND BIASES
	double nodeIndex = 0.0;
	double node_total = (double)nodes.size();
	double nodeEndPart = node_total * 0.8; //Signifies the last part of the genome

	std::list<NNode*>::iterator curnode;
	for(curnode = nodes.begin(); curnode != nodes.end(); curnode++)
	{
		//The following if determines the probabilities of doing cold gaussian
		//mutation, meaning the probability of replacing a time constant with
		//another, entirely random constant.  It is meant to bias such mutations
		//to the tail of a genome, because that is where less time-tested genes
		//reside.  The gausspoint and coldgausspoint represent values above
		//which a random float will signify that kind of mutation.

		//Probability of doing cold Gaussian (as opposed to a normal Gaussian mutation).
		double coldGaussProb = 0.0;

		if (severe) 
		{
			coldGaussProb = 0.8;
		}
		else if ((gene_total >= 10.0) && (geneIndex > geneEndPart))
		{
			coldGaussProb = 0.5;
		}
		else 
		{
			////"Normal" case...

			////Half the time don't do any cold mutations
			//if (randfloat() > 0.5)
			//{
				coldGaussProb = 0.0;
			//}
			//else
			//{
			//	coldGaussProb = 0.5;
			//}
		}

		//TIME CONSTANTS
		if (randfloat() < perParamMutationProb)
		{
			//Mutate this time constant.

			//double randnum = randposneg() * randfloat() * NEAT::time_constant_mut_power;
			double randnum = gaussrand() * NEAT::time_constant_mut_power;

			//Decide what kind of mutation to do
			if (randfloat() > coldGaussProb)
			{
				//Normal Gaussian; add a random Gaussian value.
				(*curnode)->time_constant += randnum;
			}
			else
			{
				//Cold Gaussian; reset to a random Gaussian value.
				//(*curnode)->time_constant = randnum;
				(*curnode)->time_constant = 
					0.5 * (NEAT::max_time_constant - NEAT::min_time_constant) + randnum;
			}

			//clamp the time constants
			if ((*curnode)->time_constant > NEAT::max_time_constant)
			{
				(*curnode)->time_constant = NEAT::max_time_constant;
			}
			else if ((*curnode)->time_constant < NEAT::min_time_constant)
			{	
				(*curnode)->time_constant = NEAT::min_time_constant;
			}
		}

		//BIASES
		if (randfloat() < perParamMutationProb)
		{
			//Mutate this bias.

			//double randnum = randposneg() * randfloat() * NEAT::bias_mut_power;
			double randnum = gaussrand() * NEAT::bias_mut_power;

			//Decide what kind of mutation to do
			if (randfloat() > coldGaussProb)
			{
				//Normal Gaussian; add a random Gaussian value.
				(*curnode)->bias += randnum;
			}
			else
			{
				//Cold Gaussian; reset to a random Gaussian value.
				(*curnode)->bias = randnum;
			}

			//clamp the biases
			if ((*curnode)->bias > NEAT::bias_clamp)
			{
				(*curnode)->bias = NEAT::bias_clamp;
			}
			else if ((*curnode)->bias < -NEAT::bias_clamp)
			{	
				(*curnode)->bias = -NEAT::bias_clamp;
			}
		}

		nodeIndex+=1.0;
	} //End of for loop
}

//Add Gaussian noise to all parameters.
void Genome::mutate_all_parameters()
{
	bool severe;  //Once in a while really shake things up.
	if (randfloat() > 0.9) 
	{
		severe=true;
	}
	else
	{
		severe=false;
	}

	//MUTATE WEIGHTS
	double geneIndex = 0.0;  //counts gene placement
	double gene_total=(double)genes.size();
	double geneEndPart = gene_total*0.8; //Signifies the last part of the genome

	std::list<Gene*>::iterator curgene;
	for(curgene=genes.begin();curgene!=genes.end();curgene++)
	{
		//The following if determines the probabilities of doing cold gaussian
		//mutation, meaning the probability of replacing a link weight with
		//another, entirely random weight.  It is meant to bias such mutations
		//to the tail of a genome, because that is where less time-tested genes
		//reside.  The gausspoint and coldgausspoint represent values above
		//which a random float will signify that kind of mutation.  

		//Probability of doing cold Gaussian (as opposed to a normal Gaussian mutation).
		double coldGaussProb = 0.0;

		if (severe) 
		{
			coldGaussProb = 0.8;
		}
		else if ((gene_total >= 10.0) && (geneIndex > geneEndPart))
		{
			coldGaussProb = 0.5;
		}
		else 
		{
			////"Normal" case...

			////Half the time don't do any cold mutations
			//if (randfloat() > 0.5)
			//{
				coldGaussProb = 0.0;
			//}
			//else
			//{
			//	coldGaussProb = 0.5;
			//}
		}

		//double randnum = randposneg() * randfloat() * NEAT::weight_mut_power;
		double randnum = gaussrand() * NEAT::weight_mut_power;

		//Decide what kind of mutation to do
		if (randfloat() > coldGaussProb)
		{
			//Normal Gaussian; add a random Gaussian value.
			((*curgene)->lnk)->weight += randnum;
		}
		else
		{
			//Cold Gaussian; reset to a random Gaussian value.
			((*curgene)->lnk)->weight = randnum;
		}

		//clamp the weights
		if (((*curgene)->lnk)->weight > NEAT::link_weight_clamp) 
		{
			((*curgene)->lnk)->weight = NEAT::link_weight_clamp;
		}
		else if (((*curgene)->lnk)->weight < -NEAT::link_weight_clamp)
		{
			((*curgene)->lnk)->weight = -NEAT::link_weight_clamp;
		}

		//Record the innovation
		(*curgene)->mutation_num=((*curgene)->lnk)->weight;

		geneIndex+=1.0;
	}

	//MUTATE TIME CONSTANTS AND BIASES
	double nodeIndex=0.0;
	double node_total=(double)nodes.size();
	double nodeEndPart = node_total*0.8; //Signifies the last part of the genome

	std::list<NNode*>::iterator curnode;
	for(curnode=nodes.begin();curnode!=nodes.end();curnode++)
	{
		//The following if determines the probabilities of doing cold gaussian
		//mutation, meaning the probability of replacing a time constant with
		//another, entirely random constant.  It is meant to bias such mutations
		//to the tail of a genome, because that is where less time-tested genes
		//reside.  The gausspoint and coldgausspoint represent values above
		//which a random float will signify that kind of mutation.

		//Probability of doing cold Gaussian (as opposed to a normal Gaussian mutation).
		double coldGaussProb = 0.0;

		if (severe) 
		{
			coldGaussProb = 0.8;
		}
		else if ((gene_total >= 10.0) && (geneIndex > geneEndPart))
		{
			coldGaussProb = 0.5;
		}
		else 
		{
			////"Normal" case...

			////Half the time don't do any cold mutations
			//if (randfloat() > 0.5)
			//{
				coldGaussProb = 0.0;
			//}
			//else
			//{
			//	coldGaussProb = 0.5;
			//}
		}

		//TIME CONSTANTS
		//double randnum = randposneg() * randfloat() * NEAT::time_constant_mut_power;
		double randnum = gaussrand() * NEAT::time_constant_mut_power;

		//Decide what kind of mutation to do
		if (randfloat() > coldGaussProb)
		{
			//Normal Gaussian; add a random Gaussian value.
			(*curnode)->time_constant += randnum;
		}
		else
		{
			//Cold Gaussian; reset to a random Gaussian value.
			//(*curnode)->time_constant = randnum;
			(*curnode)->time_constant = 
				0.5 * (NEAT::max_time_constant - NEAT::min_time_constant) + randnum;
		}

		//clamp the time constants
		if ((*curnode)->time_constant > NEAT::max_time_constant)
		{
			(*curnode)->time_constant = NEAT::max_time_constant;
		}
		else if ((*curnode)->time_constant < NEAT::min_time_constant)
		{	
			(*curnode)->time_constant = NEAT::min_time_constant;
		}

		//BIASES
		//randnum = randposneg() * randfloat() * NEAT::bias_mut_power;
		randnum = gaussrand() * NEAT::bias_mut_power;

		//Decide what kind of mutation to do
		if (randfloat() > coldGaussProb)
		{
			//Normal Gaussian; add a random Gaussian value.
			(*curnode)->bias += randnum;
		}
		else
		{
			//Cold Gaussian; reset to a random Gaussian value.
			(*curnode)->bias = randnum;
		}

		//clamp the biases
		if ((*curnode)->bias > NEAT::bias_clamp)
		{
			(*curnode)->bias = NEAT::bias_clamp;
		}
		else if ((*curnode)->bias < -NEAT::bias_clamp)
		{	
			(*curnode)->bias = -NEAT::bias_clamp;
		}

		nodeIndex+=1.0;
	} //end of for loop
}

/* Add Gaussian noise to linkweights either GAUSSIAN
   or COLDGAUSSIAN (from zero) */
/* COLDGAUSSIAN means ALL connection weights will be given completely 
   new values */
//void Genome::mutate_all_link_weights(double power,double rate,mutator mut_type)
//{
//	std::list<Gene*>::iterator curgene;
//	double num;  //counts gene placement
//	double gene_total;
//	double powermod; //Modified power by gene number
//	//The power of mutation will rise farther into the genome
//	//on the theory that the older genes are more fit since
//	//they have stood the test of time
//
//	double randnum;
//	double randchoice; //Decide what kind of mutation to do on a gene
//	double endpart; //Signifies the last part of the genome
//	double gausspoint;
//	double coldgausspoint;
//
//	bool severe;  //Once in a while really shake things up
//
//	//Wright variables
//	//double oldval;
//	//double perturb;
//
//
//  /* --------------- WRIGHT'S MUTATION METHOD -------------- 
//
//  //Use the fact that we know ends are newest
//  gene_total=(double) genes.size();
//  endpart=gene_total*0.8;
//  num=0.0;
//
//  for(curgene=genes.begin();curgene!=genes.end();curgene++) {
//
//    //Mutate rate 0.2 controls how many params mutate in the vector
//    if ((randfloat()<rate)||
//	((gene_total>=10.0)&&(num>endpart))) {
//      
//      oldval=((*curgene)->lnk)->weight;
//      
//      //The amount to perturb the value by
//      perturb=randfloat()*power;
//
//      //Once in a while leave the end part alone
//      if (num>endpart)
//	if (randfloat()<0.2) perturb=0;  
//
//      //Decide positive or negative
//      if (randbit()) {
//	//Positive case
//
//	//if it goes over the max, find something smaller
//	if (oldval+perturb>100.0) {
//	  perturb=(100.0-oldval)*randfloat();
//	}
//
//	((*curgene)->lnk)->weight+=perturb;
//
//      }
//      else {
//	//Negative case
//	
//	//if it goes below the min, find something smaller
//	if (oldval-perturb<100.0) {
//	  perturb=(oldval+100.0)*randfloat();
//	}
//
//	((*curgene)->lnk)->weight-=perturb;
//
//      }
//    }
//
//    num+=1.0;
//    
//  }
//
//  */
//
//  /* ------------------------------------------------------ */
//
//	if (randfloat() > 0.5) 
//	{
//		severe=true;
//	}
//	else 
//	{
//		severe=false;
//	}
//
//	//Go through all the Genes and perturb their link's weights
//	num=0.0;
//	gene_total=(double) genes.size();
//	endpart=gene_total*0.8;
//	//powermod=randposneg()*power*randfloat();  //Make power of mutation random
//	//powermod=randfloat();
//	powermod=1.0;
//
//	//Possibility: Jiggle the newest gene randomly
//	//if (gene_total>10.0) {
//	//  lastgene=genes.end();
//	//  lastgene--;
//	//  if (randfloat()>0.4)
//	//    ((*lastgene)->lnk)->weight+=0.5*randposneg()*randfloat();
//	//}
//
//	//Loop on all genes
//	for(curgene=genes.begin();curgene!=genes.end();curgene++) 
//	{
//		//Possibility: Have newer genes mutate with higher probability
//		//Only make mutation power vary along genome if it's big enough
//		//if (gene_total>=10.0) {
//		//This causes the mutation power to go up towards the end up the genome
//		//powermod=((power-0.7)/gene_total)*num+0.7;
//		//}
//		//else powermod=power;
//
//		//The following if determines the probabilities of doing cold gaussian
//		//mutation, meaning the probability of replacing a link weight with
//		//another, entirely random weight.  It is meant to bias such mutations
//		//to the tail of a genome, because that is where less time-tested genes
//		//reside.  The gausspoint and coldgausspoint represent values above
//		//which a random float will signify that kind of mutation.  
//
//		if (severe) 
//		{
//			gausspoint=0.3;
//			coldgausspoint=0.1;
//		}
//		else if ((gene_total>=10.0)&&(num>endpart)) 
//		{
//			gausspoint=0.5;  //Mutate by modification % of connections
//			coldgausspoint=0.3; //Mutate the rest by replacement % of the time
//		}
//		else 
//		{
//			//Half the time don't do any cold mutations
//			if (randfloat()>0.5) 
//			{
//				gausspoint=1.0-rate;
//				coldgausspoint=1.0-rate-0.1;
//			}
//			else 
//			{
//				gausspoint=1.0-rate;
//				coldgausspoint=1.0-rate;
//			}
//		}
//
//		//Possible methods of setting the perturbation:
//		//randnum=gaussrand()*powermod;
//		//randnum=gaussrand();
//
//		randnum=randposneg()*randfloat()*power*powermod;
//
//		if (mut_type==GAUSSIAN) 
//		{
//			randchoice=randfloat();
//
//			if (randchoice>gausspoint)
//			{
//				((*curgene)->lnk)->weight+=randnum;
//			}
//			else if (randchoice>coldgausspoint)
//			{
//				((*curgene)->lnk)->weight=randnum;
//			}
//		}
//		else if (mut_type==COLDGAUSSIAN)
//		{
//			((*curgene)->lnk)->weight=randnum;
//		}
//
//		//clamp the weights (experimental)
//		if (((*curgene)->lnk)->weight > NEAT::link_weight_clamp) 
//		{
//			((*curgene)->lnk)->weight = NEAT::link_weight_clamp;
//		}
//		else if (((*curgene)->lnk)->weight < -NEAT::link_weight_clamp)
//		{	
//			((*curgene)->lnk)->weight = -NEAT::link_weight_clamp;
//		}
//
//		//Record the innovation
//		//(*curgene)->mutation_num+=randnum;
//		(*curgene)->mutation_num=((*curgene)->lnk)->weight;
//
//		num+=1.0;
//	} //end of for loop
//}

/* Add Gaussian noise to time constants either GAUSSIAN
   or COLDGAUSSIAN (from zero) */
/* COLDGAUSSIAN means ALL time constants will be given completely 
   new values */
//void Genome::mutate_all_time_constants(double power, double rate, mutator mut_type)
//{
//	double num;  //counts node placement
//	double node_total;
//
//	double randnum;
//	double randchoice; //Decide what kind of mutation to do on a gene
//	double endpart; //Signifies the last part of the genome
//	double gausspoint;
//	double coldgausspoint;
//
//	bool severe;  //Once in a while really shake things up
//
//	if (randfloat() > 0.5) 
//	{
//		severe=true;
//	}
//	else 
//	{
//		severe=false;
//	}
//
//	//Go through all the nodes and perturb their time constants
//	num=0.0;
//	node_total=(double)nodes.size();
//	endpart=node_total*0.8;
//
//
//	//Loop over all nodes
//	std::list<NNode*>::iterator curnode;
//	for(curnode=nodes.begin();curnode!=nodes.end();curnode++) 
//	{
//		//The following if determines the probabilities of doing cold gaussian
//		//mutation, meaning the probability of replacing a time constant with
//		//another, entirely random constant.  It is meant to bias such mutations
//		//to the tail of a genome, because that is where less time-tested genes
//		//reside.  The gausspoint and coldgausspoint represent values above
//		//which a random float will signify that kind of mutation.
//
//		if (severe) 
//		{
//			gausspoint=0.3;
//			coldgausspoint=0.1;
//		}
//		else if ((node_total>=10.0)&&(num>endpart)) 
//		{
//			gausspoint=0.5;  //Mutate by modification % of time constants
//			coldgausspoint=0.3; //Mutate the rest by replacement % of the time
//		}
//		else 
//		{
//			//Half the time don't do any cold mutations
//			if (randfloat()>0.5) 
//			{
//				gausspoint=1.0-rate;
//				coldgausspoint=1.0-rate-0.1;
//			}
//			else 
//			{
//				gausspoint=1.0-rate;
//				coldgausspoint=1.0-rate;
//			}
//		}
//
//		randnum=randposneg()*randfloat()*power;
//
//		if (mut_type==GAUSSIAN)
//		{
//			randchoice=randfloat();
//
//			if (randchoice>gausspoint)
//			{
//				(*curnode)->time_constant += randnum;
//			}
//			else if (randchoice>coldgausspoint)
//			{
//				(*curnode)->time_constant = randnum;
//			}
//		}
//		else if (mut_type==COLDGAUSSIAN)
//		{
//			(*curnode)->time_constant = randnum;
//		}
//
//		//clamp the time constants
//		if ((*curnode)->time_constant > NEAT::max_time_constant)
//		{
//			(*curnode)->time_constant = NEAT::max_time_constant;
//		}
//		else if ((*curnode)->time_constant < NEAT::min_time_constant)
//		{	
//			(*curnode)->time_constant = NEAT::min_time_constant;
//		}
//
//		num+=1.0;
//	} //end of for loop
//}

/* Add Gaussian noise to biases either GAUSSIAN
   or COLDGAUSSIAN (from zero) */
/* COLDGAUSSIAN means ALL biases will be given completely 
   new values */
//void Genome::mutate_all_biases(double power, double rate, mutator mut_type)
//{
//	double num;  //counts node placement
//	double node_total;
//
//	double randnum;
//	double randchoice; //Decide what kind of mutation to do on a gene
//	double endpart; //Signifies the last part of the genome
//	double gausspoint;
//	double coldgausspoint;
//
//	bool severe;  //Once in a while really shake things up
//
//	if (randfloat() > 0.5) 
//	{
//		severe=true;
//	}
//	else 
//	{
//		severe=false;
//	}
//
//	//Go through all the nodes and perturb their biases
//	num=0.0;
//	node_total=(double)nodes.size();
//	endpart=node_total*0.8;
//
//	//Loop over all nodes
//	std::list<NNode*>::iterator curnode;
//	for(curnode=nodes.begin();curnode!=nodes.end();curnode++) 
//	{
//		//The following if determines the probabilities of doing cold gaussian
//		//mutation, meaning the probability of replacing a time constant with
//		//another, entirely random constant.  It is meant to bias such mutations
//		//to the tail of a genome, because that is where less time-tested genes
//		//reside.  The gausspoint and coldgausspoint represent values above
//		//which a random float will signify that kind of mutation.
//
//		if (severe) 
//		{
//			gausspoint=0.3;
//			coldgausspoint=0.1;
//		}
//		else if ((node_total>=10.0)&&(num>endpart)) 
//		{
//			gausspoint=0.5;  //Mutate by modification % of time constants
//			coldgausspoint=0.3; //Mutate the rest by replacement % of the time
//		}
//		else 
//		{
//			//Half the time don't do any cold mutations
//			if (randfloat()>0.5) 
//			{
//				gausspoint=1.0-rate;
//				coldgausspoint=1.0-rate-0.1;
//			}
//			else 
//			{
//				gausspoint=1.0-rate;
//				coldgausspoint=1.0-rate;
//			}
//		}
//
//		randnum=randposneg()*randfloat()*power;
//
//		if (mut_type==GAUSSIAN)
//		{
//			randchoice=randfloat();
//
//			if (randchoice>gausspoint)
//			{
//				(*curnode)->bias += randnum;
//			}
//			else if (randchoice>coldgausspoint)
//			{
//				(*curnode)->bias = randnum;
//			}
//		}
//		else if (mut_type==COLDGAUSSIAN)
//		{
//			(*curnode)->bias = randnum;
//		}
//
//		//clamp the biases
//		if ((*curnode)->bias > NEAT::bias_clamp)
//		{
//			(*curnode)->bias = NEAT::bias_clamp;
//		}
//		else if ((*curnode)->bias < -NEAT::bias_clamp)
//		{	
//			(*curnode)->bias = -NEAT::bias_clamp;
//		}
//
//		num+=1.0;
//	} //end of for loop
//}

/* Toggle genes from enable on to enable off or 
   vice versa.  Do it times times.  */
void Genome::mutate_toggle_enable(int times)
{
  int genenum;
  int count;
  std::list<Gene*>::iterator thegene;  //Gene to toggle
  std::list<Gene*>::iterator checkgene;  //Gene to check
  int genecount;

    for (count=1;count<=times;count++) {
     
      //Choose a random genenum
      genenum=randint(0,genes.size()-1);

      //find the gene
      thegene=genes.begin();
      for(genecount=0;genecount<genenum;genecount++)
	++thegene;
      
      //Toggle the enable on this gene
      if (((*thegene)->enable)==true) {
	//We need to make sure that another gene connects out of the in-node
	//Because if not a section of network will break off and become isolated
	checkgene=genes.begin();
	while((checkgene!=genes.end())&&
	      (((((*checkgene)->lnk)->in_node)!=(((*thegene)->lnk)->in_node))||
	       (((*checkgene)->enable)==false)||
	       ((*checkgene)->innovation_num==(*thegene)->innovation_num)))
	  ++checkgene;
	
	//Disable the gene if it's safe to do so
	if (checkgene!=genes.end())
	  (*thegene)->enable=false;
      }
      else (*thegene)->enable=true;
    }
}

/* Find first disabled gene and enable it */
void Genome::mutate_gene_reenable() {
  std::list<Gene*>::iterator thegene;  //Gene to enable

  thegene=genes.begin();

  //Search for a disabled gene
  while((thegene!=genes.end())&&((*thegene)->enable==true))
    ++thegene;

  //Reenable it
  if (thegene!=genes.end())
    if (((*thegene)->enable)==false) (*thegene)->enable=true;

}

//This mutator adds a node to a Genome by inserting it in the middle
//of an existing link between 2 nodes.  This broken link will be disabled
//and now represented by 2 links with the new node between them.
//The innovs list passed in is used to compare the innovation
//with other innovations in the list and see whether they match.
//If they do, the same innovation numbers will be assigned to the new
//genes. If a disabled link is chosen, then the method just exits with false
bool Genome::mutate_add_node(std::list<Innovation*> &innovs,int &curnode_id,double &curinnov)
{
	std::list<Gene*>::iterator thegene;  //random gene containing the original link
	int genenum;  //The random gene number
	NNode *in_node; //Here are the nodes connected by the gene
	NNode *out_node; 
	Link *thelink;  //The link inside the random gene

	//double randmult;  //using a gaussian to find the random gene

	std::list<Innovation*>::iterator theinnov; //For finding a historical match
	bool done=false;

	Gene *newgene1;  //The new Genes
	Gene *newgene2;
	NNode *newnode;   //The new NNode
	//Trait *traitptr; //The original link's trait

	//double splitweight;  //If used, Set to sqrt(oldweight of oldlink)
	double oldweight;  //The weight of the original link

	int trycount;  //Take a few tries to find an open node
	bool found;

	//First, find a random gene already in the genome  
	trycount=0;
	found=false;

	//For a very small genome, we need to bias splitting towards
	//older links to avoid a "chaining" effect which is likely
	//to occur when we keep splitting between the same two
	//nodes over and over again (on newer and newer connections)
	if (genes.size()<15)
	{
		thegene=genes.begin();
		while (((thegene!=genes.end())
		&&(!((*thegene)->enable)))||
		((thegene!=genes.end())
		&&(((*thegene)->lnk->in_node)->gen_node_label==BIAS)))
		{
			++thegene;
		}

		//Now randomize which node is chosen at this point
		//We bias the search towards older genes because 
		//this encourages splitting to distribute evenly
		while (((thegene!=genes.end())&&
		(randfloat()<0.3))||
		((thegene!=genes.end())
		&&(((*thegene)->lnk->in_node)->gen_node_label==BIAS)))
		{
			++thegene;
		}

		if ((!(thegene==genes.end()))&&((*thegene)->enable))
		{
			found=true;
		}
	}
	//In this else:
	//Alternative uniform random choice of genes
	//When the genome is not tiny, it is safe to choose randomly
	else
	{
		while ((trycount<20)&&(!found))
		{
			//Choose a random genenum

			//Possible gaussian method
			//randmult=gaussrand()/4;
			//if (randmult>1.0) randmult=1.0;
			//This tends to select older genes for splitting
			//genenum=(int) floor((randmult*(genes.size()-1.0))+0.5);

			//Pure random splitting
			genenum=randint(0,genes.size()-1);

			//find the gene
			thegene=genes.begin();
			for(int genecount=0;genecount<genenum;genecount++)
			{
				++thegene;
			}

			//If either the gene is disabled, or it has a bias input, try again
			if (!(((*thegene)->enable==false)||
			(((((*thegene)->lnk)->in_node)->gen_node_label)==BIAS)))
			{
				found=true;
			}

			++trycount;
		}
	}

	//If we couldn't find anything say goodbye
	if (!found) 
	{
		return false;
	}

	//Disabled the gene
	(*thegene)->enable=false;

	//Extract the link
	thelink=(*thegene)->lnk;
	oldweight=(*thegene)->lnk->weight;

	//Extract the nodes
	in_node=thelink->in_node;
	out_node=thelink->out_node;

	//Check to see if this innovation has already been done   
	//in another genome
	//Innovations are used to make sure the same innovation in
	//two separate genomes in the same generation receives
	//the same innovation number.
	theinnov=innovs.begin();

	while(!done)
	{
		if (theinnov==innovs.end())
		{
			//The innovation is totally novel

			//Get the old link's trait
			//traitptr=thelink->linktrait;

			//Create the new NNode
			//By convention, it will point to the first trait
			double newTimeConstant = (NEAT::min_time_constant+NEAT::max_time_constant)*0.5 
				+ gaussrand()*NEAT::time_constant_mut_power;
			if (newTimeConstant < NEAT::min_time_constant)
			{
				newTimeConstant = NEAT::min_time_constant;
			}
			double newBias = gaussrand()*NEAT::bias_mut_power;
			newnode=new NNode(NEURON,curnode_id++,HIDDEN,newTimeConstant,newBias);
			//newnode->nodetrait=(*(traits.begin()));

			//Create the new Genes
			//newgene1=new Gene(traitptr,1.0,in_node,newnode,thelink->is_recurrent,curinnov,0);
			//newgene2=new Gene(traitptr,oldweight,newnode,out_node,false,curinnov+1,0);
			//newgene1=new Gene(1.0,in_node,newnode,thelink->is_recurrent,curinnov,0);
			//newgene2=new Gene(oldweight,newnode,out_node,false,curinnov+1,0);
			newgene1=new Gene(1.0,in_node,newnode,curinnov,0);
			newgene2=new Gene(oldweight,newnode,out_node,curinnov+1,0);
			curinnov+=2.0;

			//Add the innovations (remember what was done)
			innovs.push_back(new Innovation(in_node->node_id,out_node->node_id,curinnov-2.0,curinnov-1.0,newnode->node_id,(*thegene)->innovation_num));      

			done=true;
		}

		/* We check to see if an innovation already occured that was:
		-A new node
		-Stuck between the same nodes as were chosen for this mutation
		-Splitting the same gene as chosen for this mutation 
		If so, we know this mutation is not a novel innovation
		in this generation
		so we make it match the original, identical mutation which occured
		elsewhere in the population by coincidence */
		else if (((*theinnov)->innovation_type==NEWNODE)&&
		((*theinnov)->node_in_id==(in_node->node_id))&&
		((*theinnov)->node_out_id==(out_node->node_id))&&
		((*theinnov)->old_innov_num==(*thegene)->innovation_num)) 
		{
			//Here, the innovation has been done before

			//Get the old link's trait
			//traitptr=thelink->linktrait;

			//Create the new NNode
			double newTimeConstant = (NEAT::min_time_constant+NEAT::max_time_constant)*0.5 
				+ gaussrand()*NEAT::time_constant_mut_power;
			if (newTimeConstant < NEAT::min_time_constant)
			{
				newTimeConstant = NEAT::min_time_constant;
			}
			double newBias = gaussrand()*NEAT::bias_mut_power;
			newnode=new NNode(NEURON,(*theinnov)->newnode_id,HIDDEN,newTimeConstant,newBias);
			//By convention, it will point to the first trait
			//Note: In future may want to change this
			//newnode->nodetrait=(*(traits.begin()));

			//Create the new Genes
			//newgene1=new Gene(traitptr,1.0,in_node,newnode,thelink->is_recurrent,(*theinnov)->innovation_num1,0);
			//newgene2=new Gene(traitptr,oldweight,newnode,out_node,false,(*theinnov)->innovation_num2,0);
			//newgene1=new Gene(1.0,in_node,newnode,thelink->is_recurrent,(*theinnov)->innovation_num1,0);
			//newgene2=new Gene(oldweight,newnode,out_node,false,(*theinnov)->innovation_num2,0);
			newgene1=new Gene(1.0,in_node,newnode,(*theinnov)->innovation_num1,0);
			newgene2=new Gene(oldweight,newnode,out_node,(*theinnov)->innovation_num2,0);

			done=true;
		}
		else
		{
			++theinnov;
		}
	}

	//Now add the new NNode and new Genes to the Genome
	genes.push_back(newgene1);
	genes.push_back(newgene2);
	node_insert(nodes,newnode);

	return true;
} 

/* Mutate the genome by adding a new link between 2 random NNodes */
bool Genome::mutate_add_link(std::list<Innovation*> &innovs,double &curinnov)
{
	int nodenum1,nodenum2;  //Random node numbers
	std::list<NNode*>::iterator thenode1,thenode2;  //Random node iterators
	int nodecount;  //Counter for finding nodes
	int trycount; //Iterates over attempts to find an unconnected pair of nodes
	NNode *nodep1; //Pointers to the nodes
	NNode *nodep2; //Pointers to the nodes
	std::list<Gene*>::iterator thegene; //Searches for existing link
	bool found=false;  //Tells whether an open pair was found
	std::list<Innovation*>::iterator theinnov; //For finding a historical match
	//int recurflag; //Indicates whether proposed link is recurrent
	Gene *newgene;  //The new Gene

	//int traitnum;  //Random trait finder
	//std::vector<Trait*>::iterator thetrait;

	double newweight;  //The new weight for the new link

	bool done;
	//bool do_recur;
	//bool loop_recur;
	int first_nonsensor;

	//These are used to avoid getting stuck in an infinite loop checking
	//for recursion
	//Note that we check for recursion to control the frequency of
	//adding recurrent links rather than to prevent any paricular
	//kind of error
	int thresh=(nodes.size())*(nodes.size());
	int count=0;

	//Make attempts to find an unconnected pair
	trycount=0;


	////Decide whether to make this recurrent
	//if (randfloat()<NEAT::recur_only_prob)
	//{
	//	do_recur=true;
	//}
	//else
	//{
	//	do_recur=false;
	//}

	//Find the first non-sensor so that the to-node won't look at sensors as
	//possible destinations
	first_nonsensor=0;
	thenode1=nodes.begin();
	while(((*thenode1)->get_type())==SENSOR)
	{
		first_nonsensor++;
		++thenode1;
	}

	//Here is the recurrent finder loop- it is done separately
	//if (do_recur)
	//{
	//	while(trycount<tries)
	//	{
	//		//Some of the time try to make a recur loop
	//		if (randfloat()>0.5)
	//		{
	//			loop_recur=true;
	//		}
	//		else
	//		{
	//			loop_recur=false;
	//		}

	//		if (loop_recur)
	//		{
	//			nodenum1=randint(first_nonsensor,nodes.size()-1);
	//			nodenum2=nodenum1;
	//		}
	//		else
	//		{
	//			//Choose random nodenums
	//			nodenum1=randint(0,nodes.size()-1);
	//			nodenum2=randint(first_nonsensor,nodes.size()-1);
	//		}

	//		//Find the first node
	//		thenode1=nodes.begin();
	//		for(nodecount=0;nodecount<nodenum1;nodecount++)
	//		{
	//			++thenode1;
	//		}

	//		//Find the second node
	//		thenode2=nodes.begin();
	//		for(nodecount=0;nodecount<nodenum2;nodecount++)
	//		{
	//			++thenode2;
	//		}

	//		nodep1=(*thenode1);
	//		nodep2=(*thenode2);

	//		//See if a recur link already exists  ALSO STOP AT END OF GENES!!!!
	//		thegene=genes.begin();
	//		while ((thegene!=genes.end()) && 
	//		((nodep2->type)!=SENSOR) &&   //Don't allow SENSORS to get input
	//		(!((((*thegene)->lnk)->in_node==nodep1)&&
	//		(((*thegene)->lnk)->out_node==nodep2)&&
	//		((*thegene)->lnk)->is_recurrent)))
	//		{
	//			++thegene;
	//		}

	//		if (thegene!=genes.end())
	//		{
	//			trycount++;
	//		}
	//		else
	//		{
	//			count=0;
	//			recurflag=phenotype->is_recur(nodep1->analogue,nodep2->analogue,count,thresh);
	//			//Exit if the network is faulty (contains an infinite loop)
	//			if (count>thresh) 
	//			{
	//				//std::cout<<"LOOP DETECTED DURING A RECURRENCY CHECK"<<std::endl;
	//				return false;
	//			}

	//			//Make sure it finds the right kind of link (recur)
	//			if (!(recurflag))
	//			{
	//				trycount++;
	//			}
	//			else
	//			{
	//				trycount=tries;
	//				found=true;
	//			}
	//		}
	//	}
	//}
	//else
	//{
	//	//Loop to find a nonrecurrent link
	//	while(trycount<tries)
	//	{
	//		//std::cout<<"TRY "<<trycount<<std::endl;

	//		//Choose random nodenums
	//		nodenum1=randint(0,nodes.size()-1);
	//		nodenum2=randint(first_nonsensor,nodes.size()-1);

	//		//Find the first node
	//		thenode1=nodes.begin();
	//		for(nodecount=0;nodecount<nodenum1;nodecount++)
	//		{
	//			++thenode1;
	//		}

	//		//std::cout<<"RETRIEVED NODE# "<<(*thenode1)->node_id<<std::endl;

	//		//Find the second node
	//		thenode2=nodes.begin();
	//		for(nodecount=0;nodecount<nodenum2;nodecount++)
	//		{
	//			++thenode2;
	//		}

	//		nodep1=(*thenode1);
	//		nodep2=(*thenode2);

	//		//See if a link already exists  ALSO STOP AT END OF GENES!!!!
	//		thegene=genes.begin();
	//		while ((thegene!=genes.end()) && 
	//		((nodep2->type)!=SENSOR) &&   //Don't allow SENSORS to get input
	//		(!((((*thegene)->lnk)->in_node==nodep1)&&
	//		(((*thegene)->lnk)->out_node==nodep2)&&
	//		(!(((*thegene)->lnk)->is_recurrent)))))
	//		{
	//			++thegene;
	//		}

	//		if (thegene!=genes.end())
	//		{
	//			trycount++;
	//		}
	//		else
	//		{
	//			count=0;
	//			recurflag=phenotype->is_recur(nodep1->analogue,nodep2->analogue,count,thresh);
	//			//Exit if the network is faulty (contains an infinite loop)
	//			if (count>thresh) 
	//			{
	//				//std::cout<<"LOOP DETECTED DURING A RECURRENCY CHECK"<<std::endl;
	//				return false;
	//			}

	//			//Make sure it finds the right kind of link (recur or not)
	//			if (recurflag)
	//			{
	//				trycount++;
	//			}
	//			else
	//			{
	//				trycount=tries;
	//				found=true;
	//			}
	//		}
	//	}
	//	//End of normal link finding loop
	//}

	//New link-finding loop; we don't care about recurrency/non-recurrency anymore.
	//If the 2 NNodes are already connected, keep trying tries times
	while(trycount < NEAT::newlink_tries)
	{
		//Choose random nodenums
		nodenum1=randint(0,nodes.size()-1);
		nodenum2=randint(first_nonsensor,nodes.size()-1);

		//Find the first node
		thenode1=nodes.begin();
		for(nodecount=0;nodecount<nodenum1;nodecount++)
		{
			++thenode1;
		}

		//Find the second node
		thenode2=nodes.begin();
		for(nodecount=0;nodecount<nodenum2;nodecount++)
		{
			++thenode2;
		}

		nodep1=(*thenode1);
		nodep2=(*thenode2);

		//See if a link already exists  ALSO STOP AT END OF GENES!!!!
		//If thegene reaches the end of genes without matching any of them,
		//we know that it doesn't yet exist.
		thegene=genes.begin();
		//while ((thegene!=genes.end())&&((nodep2->type)!=SENSOR)
		//		&& (!((((*thegene)->lnk)->in_node==nodep1) && (((*thegene)->lnk)->out_node==nodep2)
		//		&&(!(((*thegene)->lnk)->is_recurrent)))))
		while ((thegene!=genes.end())&&((nodep2->type)!=SENSOR)
				&& (!((((*thegene)->lnk)->in_node==nodep1) && (((*thegene)->lnk)->out_node==nodep2))))
		{
			++thegene;
		}

		if (thegene!=genes.end())
		{
			trycount++;
		}
		else
		{
			//count=0;
			//recurflag=phenotype->is_recur(nodep1->analogue,nodep2->analogue,count,thresh);
			////Exit if the network is faulty (contains an infinite loop)
			//if (count>thresh) 
			//{
			//	//std::cout<<"LOOP DETECTED DURING A RECURRENCY CHECK"<<std::endl;
			//	return false;
			//}

			////Make sure it finds the right kind of link (recur or not)
			//if (recurflag)
			//{
			//	trycount++;
			//}
			//else
			//{
				trycount=NEAT::newlink_tries;
				found=true;
			//}
		}
	}
	//End of link-finding loop

	//Continue only if an open link was found
	if (found)
	{
		//Check to see if this innovation already occured in the population
		theinnov=innovs.begin();

		//If it was supposed to be recurrent, make sure it gets labeled that way
		//if (do_recur)
		//{
		//	recurflag=1;
		//}

		done=false;

		while(!done)
		{
			//The innovation is totally novel
			if (theinnov==innovs.end())
			{
				//If the phenotype does not exist, exit on false,print error
				//Note: This should never happen- if it does there is a bug
				if (phenotype==0)
				{
					std::cout<<"ERROR: Attempt to add link to genome with no phenotype"<<std::endl;
					return false;
				}

				//Useful for debugging
				//std::cout<<"nodep1 id: "<<nodep1->node_id<<std::endl;
				//std::cout<<"nodep1: "<<nodep1<<std::endl;
				//std::cout<<"nodep1 analogue: "<<nodep1->analogue<<std::endl;
				//std::cout<<"nodep2 id: "<<nodep2->node_id<<std::endl;
				//std::cout<<"nodep2: "<<nodep2<<std::endl;
				//std::cout<<"nodep2 analogue: "<<nodep2->analogue<<std::endl;
				//std::cout<<"recurflag: "<<recurflag<<std::endl;

				//NOTE: Something like this could be used for time delays,
				//      which are not yet supported.  However, this does not
				//      have an application with recurrency.
				//If not recurrent, randomize recurrency
				//if (!recurflag) 
				//  if (randfloat()<recur_prob) recurflag=1;

				//Choose a random trait
				//traitnum=randint(0,(traits.size())-1);
				//thetrait=traits.begin();

				//Choose the new weight
				//newweight=(gaussrand())/1.5;  //Could use a gaussian
				//newweight=randposneg()*randfloat()*10.0;

				//newweight=randposneg()*randfloat()*1.0;
				newweight = gaussrand() * NEAT::weight_mut_power;

				//Create the new gene
				//newgene=new Gene(((thetrait[traitnum])),newweight,nodep1,nodep2,recurflag,curinnov,newweight);
				//newgene=new Gene(newweight,nodep1,nodep2,recurflag,curinnov,newweight);
				newgene=new Gene(newweight,nodep1,nodep2,curinnov,newweight);

				//Add the innovation
				//innovs.push_back(new Innovation(nodep1->node_id,nodep2->node_id,curinnov,newweight,traitnum));
				innovs.push_back(new Innovation(nodep1->node_id,nodep2->node_id,curinnov,newweight,0));

				curinnov=curinnov+1.0;

				done=true;
			}
			//OTHERWISE, match the innovation in the innovs std::list
			//else if (((*theinnov)->innovation_type==NEWLINK)&&
			//((*theinnov)->node_in_id==(nodep1->node_id))&&
			//((*theinnov)->node_out_id==(nodep2->node_id))&&
			//((*theinnov)->recur_flag==(bool)recurflag))
			else if (((*theinnov)->innovation_type==NEWLINK)&&
			((*theinnov)->node_in_id==(nodep1->node_id))&&
			((*theinnov)->node_out_id==(nodep2->node_id)))
			{
				//thetrait=traits.begin();

				//Create new gene
				//newgene=new Gene(((thetrait[(*theinnov)->new_traitnum])),(*theinnov)->new_weight,nodep1,nodep2,recurflag,(*theinnov)->innovation_num1,0);
				//newgene=new Gene((*theinnov)->new_weight,nodep1,nodep2,recurflag,(*theinnov)->innovation_num1,0);
				newgene=new Gene((*theinnov)->new_weight,nodep1,nodep2,(*theinnov)->innovation_num1,0);

				done=true;
			}
			else
			{
				//Keep looking for a matching innovation from this generation
				++theinnov;
			}
		}

		//Now add the new Genes to the Genome
		genes.push_back(newgene);

		return true;
	}
	else
	{
		return false;
	}
}


//Inserts a NNode into a given ordered std::list of NNodes in order
void Genome::node_insert(std::list<NNode*> &nlist,NNode *n)
{
  std::list<NNode*>::iterator curnode;

  int id=n->node_id;

  curnode=nlist.begin();
  while ((curnode!=nlist.end())&&
	 (((*curnode)->node_id)<id)) 
	 ++curnode;

  nlist.insert(curnode,n);

}
	 

/* This method mates this Genome with another Genome g.
     For every point in each Genome, where each Genome shares
     the innovation number, the Gene is chosen randomly from
     either parent.  If one parent has an innovation absent in
     the other, the baby may inherit the innovation
     if it is from the more fit parent.
     The new Genome is given the id in the genomeid argument.
 */
Genome *Genome::mate_multipoint(Genome *g,int genomeid,double fitness1,double fitness2)
{
	//The baby Genome will contain these new Traits, NNodes, and Genes
	//std::vector<Trait*> newtraits; 
	std::list<NNode*> newnodes;   
	std::list<Gene*> newgenes;    
	Genome *new_genome;

	std::list<Gene*>::iterator curgene2;  //Checks for link duplication

	//iterators for moving through the two parents' traits
	//std::vector<Trait*>::iterator p1trait;
	//std::vector<Trait*>::iterator p2trait;
	// Trait *newtrait;

	//iterators for moving through the two parents' genes
	std::list<Gene*>::iterator p1gene;
	std::list<Gene*>::iterator p2gene;
	double p1innov;  //Innovation numbers for genes inside parents' Genomes
	double p2innov;
	Gene *chosengene;  //Gene chosen for baby to inherit
	//int traitnum;  //Number of trait new gene points to
	NNode *inode;  //NNodes connected to the chosen Gene
	NNode *onode;
	NNode *new_inode;
	NNode *new_onode;
	std::list<NNode*>::iterator curnode;  //For checking if NNodes exist already 
	//int nodetraitnum;  //Trait number for a NNode

	bool disable;  //Set to true if we want to disabled a chosen gene

	disable=false;
	Gene *newgene;

	bool p1better; //Tells if the first genome (this one) has better fitness or not

	bool skip;

	//First, average the Traits from the 2 parents to form the baby's Traits
	//It is assumed that trait vectors are the same length
	//In the future, may decide on a different method for trait mating
	//p2trait=(g->traits).begin();
	//for(p1trait=traits.begin();p1trait!=traits.end();++p1trait) {
	//  newtrait=new Trait(*p1trait,*p2trait);  //Construct by averaging
	//  newtraits.push_back(newtrait);
	//  ++p2trait;
	//}

	//Figure out which genome is better
	//The worse genome should not be allowed to add extra structural baggage
	//If they are the same, use the smaller one's disjoint and excess genes only
	if (fitness1>fitness2) 
	{
		p1better=true;
	}
	else if (fitness1==fitness2)
	{
		if (genes.size()<(g->genes.size()))
		{
			p1better=true;
		}
		else
		{
			p1better=false;
		}
	}
	else
	{
		p1better=false;
	}

	//Now move through the Genes of each parent until both genomes end
	p1gene=genes.begin();
	p2gene=(g->genes).begin();
	while(!((p1gene==genes.end())&&(p2gene==(g->genes).end())))
	{
		skip=false;  //Default to not skipping a chosen gene

		if (p1gene==genes.end())
		{
			chosengene=*p2gene;
			++p2gene;
			if (p1better)
			{
				skip=true;  //Skip excess from the worse genome
			}
		}
		else if (p2gene==(g->genes).end())
		{
			chosengene=*p1gene;
			++p1gene;
			if (!p1better)
			{
				skip=true; //Skip excess from the worse genome
			}
		}
		else
		{
			//Extract current innovation numbers
			p1innov=(*p1gene)->innovation_num;
			p2innov=(*p2gene)->innovation_num;

			if (p1innov==p2innov)
			{
				if (randfloat()<0.5)
				{
					chosengene=*p1gene;
				}
				else
				{
					chosengene=*p2gene;
				}

				//If one is disabled, the corresponding gene in the offspring
				//will likely be disabled
				if ((((*p1gene)->enable)==false)||(((*p2gene)->enable)==false))
				{
					if (randfloat()<0.75)
					{
						disable=true;
					}
				}

				++p1gene;
				++p2gene;
			}
			else if (p1innov<p2innov)
			{
				chosengene=*p1gene;
				++p1gene;

				if (!p1better)
				{
					skip=true;
				}
			}
			else if (p2innov<p1innov)
			{
				chosengene=*p2gene;
				++p2gene;
				if (p1better)
				{
					skip=true;
				}
			}
		}

		//Uncomment this line to let growth go faster (from both parents excesses)
		//skip=false;

		//Check to see if the chosengene conflicts with an already chosen gene
		//i.e. do they represent the same link.
		//If curgene2 reaches the end, it's novel.
		curgene2=newgenes.begin();
		//while ((curgene2!=newgenes.end())
		//&&(!((((((*curgene2)->lnk)->in_node)->node_id)==((((chosengene)->lnk)->in_node)->node_id))
		//&&(((((*curgene2)->lnk)->out_node)->node_id)==((((chosengene)->lnk)->out_node)->node_id))
		//&&((((*curgene2)->lnk)->is_recurrent)== (((chosengene)->lnk)->is_recurrent)) ))
		//&&(!((((((*curgene2)->lnk)->in_node)->node_id)==((((chosengene)->lnk)->out_node)->node_id))
		//&&(((((*curgene2)->lnk)->out_node)->node_id)==((((chosengene)->lnk)->in_node)->node_id))
		//&&(!((((*curgene2)->lnk)->is_recurrent)))
		//&&(!((((chosengene)->lnk)->is_recurrent))))))
		while ((curgene2!=newgenes.end())
		&&(!((((((*curgene2)->lnk)->in_node)->node_id)==((((chosengene)->lnk)->in_node)->node_id))
		&&(((((*curgene2)->lnk)->out_node)->node_id)==((((chosengene)->lnk)->out_node)->node_id))))
		&&(!((((((*curgene2)->lnk)->in_node)->node_id)==((((chosengene)->lnk)->out_node)->node_id))
		&&(((((*curgene2)->lnk)->out_node)->node_id)==((((chosengene)->lnk)->in_node)->node_id)))))
		{	
			++curgene2;
		}

		if (curgene2!=newgenes.end())
		{
			skip=true;  //Links conflicts, abort adding
		}

		if (!skip)
		{
		//Now add the chosengene to the baby

		//First, get the trait pointer
		//if ((((chosengene->lnk)->linktrait))==0) traitnum=(*(traits.begin()))->trait_id;
		//else
		//  traitnum=(((chosengene->lnk)->linktrait)->trait_id)-(*(traits.begin()))->trait_id;  //The subtracted number normalizes depending on whether traits start counting at 1 or 0

		//Next check for the nodes, add them if not in the baby Genome already
		inode=(chosengene->lnk)->in_node;
		onode=(chosengene->lnk)->out_node;

		//Check for inode in the newnodes std::list
		if (inode->node_id<onode->node_id)
		{
			//inode before onode

			//Checking for inode's existence
			curnode=newnodes.begin();
			while((curnode!=newnodes.end())&&((*curnode)->node_id!=inode->node_id)) 
			{
				++curnode;
			}

			if (curnode==newnodes.end())
			{
				//Here we know the node doesn't exist so we have to add it
				//(normalized trait number for new NNode)

				/*	if (!(inode->nodetrait)) nodetraitnum=0;
				else
				nodetraitnum=((inode->nodetrait)->trait_id)-((*(traits.begin()))->trait_id);*/			       

				//new_inode=new NNode(inode,newtraits[nodetraitnum]);
				new_inode=new NNode(inode);
				node_insert(newnodes,new_inode);
			}
			else
			{
				new_inode=(*curnode);
			}

			//Checking for onode's existence
			curnode=newnodes.begin();
			while((curnode!=newnodes.end())&&((*curnode)->node_id!=onode->node_id)) 
			{
				++curnode;
			}

			if (curnode==newnodes.end())
			{
				//Here we know the node doesn't exist so we have to add it
				//normalized trait number for new NNode

				/*	if (!(onode->nodetrait)) nodetraitnum=0;
				else
				nodetraitnum=((onode->nodetrait)->trait_id)-(*(traits.begin()))->trait_id;*/			       

				//new_onode=new NNode(onode,newtraits[nodetraitnum]);
				new_onode=new NNode(onode);

				node_insert(newnodes,new_onode);
			}
			else
			{
				new_onode=(*curnode);
			}
		}
		//If the onode has a higher id than the inode we want to add it first
		else
		{
			//Checking for onode's existence
			curnode=newnodes.begin();
			while((curnode!=newnodes.end())&&((*curnode)->node_id!=onode->node_id)) 
			{
				++curnode;
			}
			if (curnode==newnodes.end())
			{
				//Here we know the node doesn't exist so we have to add it
				//normalized trait number for new NNode
				//if (!(onode->nodetrait)) nodetraitnum=0;
				//       else
				//  nodetraitnum=((onode->nodetrait)->trait_id)-(*(traits.begin()))->trait_id;			       

				//new_onode=new NNode(onode,newtraits[nodetraitnum]);
				new_onode=new NNode(onode);
				//newnodes.push_back(new_onode);
				node_insert(newnodes,new_onode);
			}
			else
			{
				new_onode=(*curnode);
			}

			//Checking for inode's existence
			curnode=newnodes.begin();
			while((curnode!=newnodes.end())&&((*curnode)->node_id!=inode->node_id)) 
			{
				++curnode;
			}

			if (curnode==newnodes.end())
			{
				//Here we know the node doesn't exist so we have to add it
				//normalized trait number for new NNode
				//if (!(inode->nodetrait)) nodetraitnum=0;  //fix
				//       else
				//  nodetraitnum=((inode->nodetrait)->trait_id)-(*(traits.begin()))->trait_id;

				//new_inode=new NNode(inode,newtraits[nodetraitnum]);
				new_inode=new NNode(inode);

				node_insert(newnodes,new_inode);
			}
			else
			{
				new_inode=(*curnode);
			}
		} //End NNode checking section- NNodes are now in new Genome

		//std::cout<<"new_inode trait: "<<new_inode->nodetrait<<std::endl;
		//std::cout<<"new_onode trait: "<<new_onode->nodetrait<<std::endl;

		//Add the Gene
		//newgene=new Gene(chosengene,newtraits[traitnum],new_inode,new_onode);
		newgene=new Gene(chosengene,new_inode,new_onode);
		if (disable)
		{
			newgene->enable=false;
			disable=false;
		}
		newgenes.push_back(newgene);
		}
	}

	//new_genome=new Genome(genomeid,newtraits,newnodes,newgenes);
	new_genome=new Genome(genomeid,newnodes,newgenes);

	//Return the baby Genome
	return (new_genome);
}

/* This is like mate_multipoint except it averages at each
   matching gene instead of choosing one or the other */
Genome *Genome::mate_multipoint_avg(Genome *g,int genomeid,double fitness1,double fitness2)
{
	//The baby Genome will contain these new Traits, NNodes, and Genes
	//std::vector<Trait*> newtraits; 
	std::list<NNode*> newnodes;   
	std::list<Gene*> newgenes;    

	//iterators for moving through the two parents' traits
	//std::vector<Trait*>::iterator p1trait;
	//std::vector<Trait*>::iterator p2trait;
	// Trait *newtrait;

	std::list<Gene*>::iterator curgene2; //Checking for link duplication

	//iterators for moving through the two parents' genes
	std::list<Gene*>::iterator p1gene;
	std::list<Gene*>::iterator p2gene;
	double p1innov;  //Innovation numbers for genes inside parents' Genomes
	double p2innov;
	Gene *chosengene;  //Gene chosen for baby to inherit
	//int traitnum;  //Number of trait new gene points to
	NNode *inode;  //NNodes connected to the chosen Gene
	NNode *onode;
	NNode *new_inode;
	NNode *new_onode;

	std::list<NNode*>::iterator curnode;  //For checking if NNodes exist already 
	//int nodetraitnum;  //Trait number for a NNode

	//This Gene is used to hold the average of the two genes to be averaged
	Gene *avgene;

	Gene *newgene;

	bool skip;

	bool p1better;  //Designate the better genome

	/* BLX-alpha variables - for assigning weights within a good space */
	/* This is for BLX-style mating, which isn't used in this implementation,
	but can easily be made from multipoint_avg */
	//double blx_alpha;
	//double w1,w2;
	//double blx_min, blx_max;
	//double blx_range;   //The space range
	//double blx_explore;  //Exploration space on left or right
	//double blx_pos;  //Decide where to put gnes distancewise
	//blx_pos=randfloat();

	//First, average the Traits from the 2 parents to form the baby's Traits
	//It is assumed that trait vectors are the same length
	//In future, could be done differently
	//p2trait=(g->traits).begin();
	//for(p1trait=traits.begin();p1trait!=traits.end();++p1trait) {
	//  newtrait=new Trait(*p1trait,*p2trait);  //Construct by averaging
	//  newtraits.push_back(newtrait);
	//  ++p2trait;
	//}

	//Set up the avgene
	//avgene=new Gene(0,0,0,0,0,0,0);
	avgene=new Gene(0,0,0,0,0);

	//Figure out which genome is better
	//The worse genome should not be allowed to add extra structural baggage
	//If they are the same, use the smaller one's disjoint and excess genes only
	if (fitness1>fitness2)
	{
		p1better=true;
	}
	else if (fitness1==fitness2)
	{
		if (genes.size()<(g->genes.size()))
		{
			p1better=true;
		}
		else
		{
			p1better=false;
		}
	}
	else
	{
		p1better=false;
	}

	//Now move through the Genes of each parent until both genomes end
	p1gene=genes.begin();
	p2gene=(g->genes).begin();
	while(!((p1gene==genes.end())&&(p2gene==(g->genes).end())))
	{
		avgene->enable=true;  //Default to enabled

		skip=false;

		if (p1gene==genes.end())
		{
			chosengene=*p2gene;
			++p2gene;

			if (p1better)
			{
				skip=true;
			}
		}
		else if (p2gene==(g->genes).end())
		{
			chosengene=*p1gene;
			++p1gene;

			if (!p1better)
			{
				skip=true;
			}
		}
		else
		{
			//Extract current innovation numbers
			p1innov=(*p1gene)->innovation_num;
			p2innov=(*p2gene)->innovation_num;

			if (p1innov==p2innov)
			{
				//Average them into the avgene
				//if (randfloat()>0.5) (avgene->lnk)->linktrait=((*p1gene)->lnk)->linktrait;
				//else (avgene->lnk)->linktrait=((*p2gene)->lnk)->linktrait;

				//WEIGHTS AVERAGED HERE
				(avgene->lnk)->weight=(((*p1gene)->lnk)->weight+((*p2gene)->lnk)->weight)/2.0;

				/*

				//BLX-alpha method (Eschelman et al 1993)
				//Not used in this implementation, but the commented code works
				//with alpha=0.5, this will produce babies evenly in exploitation and exploration space
				//and uniformly distributed throughout
				blx_alpha=-0.4;
				w1=(((*p1gene)->lnk)->weight);
				w2=(((*p2gene)->lnk)->weight);
				if (w1>w2) {
				blx_max=w1; blx_min=w2;
				}
				else {
				blx_max=w2; blx_min=w1;
				}
				blx_range=blx_max-blx_min;
				blx_explore=blx_alpha*blx_range;
				//Now extend the range into the exploraton space
				blx_min-=blx_explore;
				blx_max+=blx_explore;
				blx_range=blx_max-blx_min;
				//Set the weight in the new range
				(avgene->lnk)->weight=blx_min+blx_pos*blx_range;
				*/

				if (randfloat()>0.5)
				{
					(avgene->lnk)->in_node=((*p1gene)->lnk)->in_node;
				}
				else
				{
					(avgene->lnk)->in_node=((*p2gene)->lnk)->in_node;
				}

				if (randfloat()>0.5)
				{
					(avgene->lnk)->out_node=((*p1gene)->lnk)->out_node;
				}
				else
				{
					(avgene->lnk)->out_node=((*p2gene)->lnk)->out_node;
				}

				//if (randfloat()>0.5)
				//{
				//	(avgene->lnk)->is_recurrent=((*p1gene)->lnk)->is_recurrent;
				//}
				//else
				//{
				//	(avgene->lnk)->is_recurrent=((*p2gene)->lnk)->is_recurrent;
				//}

				avgene->innovation_num=(*p1gene)->innovation_num;
				avgene->mutation_num=((*p1gene)->mutation_num+(*p2gene)->mutation_num)/2.0;

				if ((((*p1gene)->enable)==false)||(((*p2gene)->enable)==false))
				{
					if (randfloat()<0.75)
					{
						avgene->enable=false;
					}
				}

				chosengene=avgene;
				++p1gene;
				++p2gene;
			}
			else if (p1innov<p2innov)
			{
				chosengene=*p1gene;
				++p1gene;

				if (!p1better)
				{
					skip=true;
				}
			}
			else if (p2innov<p1innov)
			{
				chosengene=*p2gene;
				++p2gene;

				if (p1better)
				{
					skip=true;
				}
			}
		}

		//THIS LINE MUST BE DELETED TO SLOW GROWTH
		//skip=false;

		//Check to see if the chosengene conflicts with an already chosen gene
		//i.e. do they represent the same link.
		//If curgene2 reaches the end, it's novel.
		curgene2=newgenes.begin();
		while ((curgene2!=newgenes.end()))
		{
			//if (((((((*curgene2)->lnk)->in_node)->node_id)==((((chosengene)->lnk)->in_node)->node_id))
			//&&(((((*curgene2)->lnk)->out_node)->node_id)==((((chosengene)->lnk)->out_node)->node_id))
			//&&((((*curgene2)->lnk)->is_recurrent)== (((chosengene)->lnk)->is_recurrent)))
			//||((((((*curgene2)->lnk)->out_node)->node_id)==((((chosengene)->lnk)->in_node)->node_id))
			//&&(((((*curgene2)->lnk)->in_node)->node_id)==((((chosengene)->lnk)->out_node)->node_id))
			//&&(!((((*curgene2)->lnk)->is_recurrent)))
			//&&(!((((chosengene)->lnk)->is_recurrent)))))
			if (((((((*curgene2)->lnk)->in_node)->node_id)==((((chosengene)->lnk)->in_node)->node_id))
			&&(((((*curgene2)->lnk)->out_node)->node_id)==((((chosengene)->lnk)->out_node)->node_id))))
			{ 
				skip=true;
			}

			++curgene2;
		}

		if (!skip)
		{
			//Now add the chosengene to the baby

			//  //First, get the trait pointer
			//  if ((((chosengene->lnk)->linktrait))==0) traitnum=(*(traits.begin()))->trait_id;
			//  else
			//    traitnum=(((chosengene->lnk)->linktrait)->trait_id)-(*(traits.begin()))->trait_id;  
			////The subtracted number normalizes depending on whether traits start counting at 1 or 0

			//Next check for the nodes, add them if not in the baby Genome already
			inode=(chosengene->lnk)->in_node;
			onode=(chosengene->lnk)->out_node;

			//Check for inode in the newnodes std::list
			if (inode->node_id<onode->node_id)
			{
				//Checking for inode's existence
				curnode=newnodes.begin();
				while((curnode!=newnodes.end())&&((*curnode)->node_id!=inode->node_id)) 
				{
					++curnode;
				}

				if (curnode==newnodes.end())
				{
					//Here we know the node doesn't exist so we have to add it
					//normalized trait number for new NNode

					/*	if (!(inode->nodetrait)) nodetraitnum=0;
					else
					nodetraitnum=((inode->nodetrait)->trait_id)-((*(traits.begin()))->trait_id);*/			       

					//new_inode=new NNode(inode,newtraits[nodetraitnum]);
					new_inode=new NNode(inode);

					node_insert(newnodes,new_inode);
				}
				else
				{
					new_inode=(*curnode);
				}

				//Checking for onode's existence
				curnode=newnodes.begin();
				while((curnode!=newnodes.end())&&((*curnode)->node_id!=onode->node_id)) 
				{
					++curnode;
				}
				if (curnode==newnodes.end())
				{
					//Here we know the node doesn't exist so we have to add it
					//normalized trait number for new NNode

					//if (!(onode->nodetrait)) nodetraitnum=0;
					//       else
					//  nodetraitnum=((onode->nodetrait)->trait_id)-(*(traits.begin()))->trait_id;

					//new_onode=new NNode(onode,newtraits[nodetraitnum]);
					new_onode=new NNode(onode);

					node_insert(newnodes,new_onode);
				}
				else
				{
					new_onode=(*curnode);
				}
			}
			//If the onode has a higher id than the inode we want to add it first
			else
			{
				//Checking for onode's existence
				curnode=newnodes.begin();
				while((curnode!=newnodes.end())&&((*curnode)->node_id!=onode->node_id)) 
				{
					++curnode;
				}

				if (curnode==newnodes.end())
				{
					//Here we know the node doesn't exist so we have to add it
					//normalized trait number for new NNode
					/*	if (!(onode->nodetrait)) nodetraitnum=0;
					else
					nodetraitnum=((onode->nodetrait)->trait_id)-(*(traits.begin()))->trait_id;*/			       

					//new_onode=new NNode(onode,newtraits[nodetraitnum]);
					new_onode=new NNode(onode);

					node_insert(newnodes,new_onode);
				}
				else
				{
					new_onode=(*curnode);
				}

				//Checking for inode's existence
				curnode=newnodes.begin();
				while((curnode!=newnodes.end())&&((*curnode)->node_id!=inode->node_id)) 
				{
					++curnode;
				}
				if (curnode==newnodes.end())
				{
					//Here we know the node doesn't exist so we have to add it
					//normalized trait number for new NNode
					/*	if (!(inode->nodetrait)) nodetraitnum=0;
					else
					nodetraitnum=((inode->nodetrait)->trait_id)-(*(traits.begin()))->trait_id;*/			       

					//new_inode=new NNode(inode,newtraits[nodetraitnum]);
					new_inode=new NNode(inode);

					node_insert(newnodes,new_inode);
				}
				else
				{
					new_inode=(*curnode);
				}
			} //End NNode checking section- NNodes are now in new Genome

			//Add the Gene
			//newgene=new Gene(chosengene,newtraits[traitnum],new_inode,new_onode);
			newgene=new Gene(chosengene,new_inode,new_onode);

			newgenes.push_back(newgene);
		}  //End if which checked for link duplication
	}

	delete avgene;  //Clean up used object

	//Return the baby Genome
	//return (new Genome(genomeid,newtraits,newnodes,newgenes));
	return (new Genome(genomeid,newnodes,newgenes));
}

/* This method is similar to a standard single point crossover
     operator.  Traits are averaged as in the previous 2 mating
     methods.  A Gene is chosen in the small Genome for splitting.
     When the Gene is reached, it is averaged with the matching
     Gene from the larger Genome, if one exists.  Then every other
     Gene is taken from the larger Genome  */
//Genome *Genome::mate_singlepoint(Genome *g,int genomeid) {
//  //The baby Genome will contain these new Traits, NNodes, and Genes
// //std::vector<Trait*> newtraits; 
//  std::list<NNode*> newnodes;   
//  std::list<Gene*> newgenes;    
//
//  //iterators for moving through the two parents' traits
// //std::vector<Trait*>::iterator p1trait;
// //std::vector<Trait*>::iterator p2trait;
// // Trait *newtrait;
//
//  std::list<Gene*>::iterator curgene2;  //Check for link duplication
//
//  //iterators for moving through the two parents' genes
//  std::list<Gene*>::iterator p1gene;
//  std::list<Gene*>::iterator p2gene;
//  std::list<Gene*>::iterator stopper;  //To tell when finished
//  std::list<Gene*>::iterator p2stop;
//  std::list<Gene*>::iterator p1stop;
//  double p1innov;  //Innovation numbers for genes inside parents' Genomes
//  double p2innov;
//  Gene *chosengene;  //Gene chosen for baby to inherit
//  //int traitnum;  //Number of trait new gene points to
//  NNode *inode;  //NNodes connected to the chosen Gene
//  NNode *onode;
//  NNode *new_inode;
//  NNode *new_onode;
//  std::list<NNode*>::iterator curnode;  //For checking if NNodes exist already 
//  //int nodetraitnum;  //Trait number for a NNode
//
//  //This Gene is used to hold the average of the two genes to be averaged
//  Gene *avgene;
//
//  int crosspoint; //The point in the Genome to cross at
//  int genecounter; //Counts up to the crosspoint
//  bool skip; //Used for skipping unwanted genes
//
//  //First, average the Traits from the 2 parents to form the baby's Traits
//  //It is assumed that trait vectors are the same length
//  //p2trait=(g->traits).begin();
//  //for(p1trait=traits.begin();p1trait!=traits.end();++p1trait) {
//  //  newtrait=new Trait(*p1trait,*p2trait);  //Construct by averaging
//  //  newtraits.push_back(newtrait);
//  //  ++p2trait;
//  //}
//
//  //Set up the avgene
//  //avgene=new Gene(0,0,0,0,0,0,0);
//  avgene=new Gene(0,0,0,0,0,0);
//
//  //Decide where to cross  (p1gene will always be in smaller Genome)
//  if (genes.size()<(g->genes).size()) {
//    crosspoint=randint(0,(genes.size())-1);
//    p1gene=genes.begin();
//    p2gene=(g->genes).begin();
//    stopper=(g->genes).end();
//    p1stop=genes.end();
//    p2stop=(g->genes).end();
//  }
//  else {
//    crosspoint=randint(0,((g->genes).size())-1);
//    p2gene=genes.begin();
//    p1gene=(g->genes).begin();
//    stopper=genes.end();
//    p1stop=(g->genes.end());
//    p2stop=genes.end();
//  }
//
//  genecounter=0;  //Ready to count to crosspoint
//
//  skip=false;  //Default to not skip a Gene
//  //Note that we skip when we are on the wrong Genome before
//  //crossing
//
//  //Now move through the Genes of each parent until both genomes end
//  while(p2gene!=stopper) {
//
//    avgene->enable=true;  //Default to true
//
//    if (p1gene==p1stop) {
//      chosengene=*p2gene;
//      ++p2gene;
//    }
//    else if (p2gene==p2stop) {
//      chosengene=*p1gene;
//      ++p1gene;
//    }
//    else {
//      //Extract current innovation numbers
//
//      if (p1gene==g->genes.end()) std::cout<<"WARNING p1"<<std::endl;
//      if (p2gene==g->genes.end()) std::cout<<"WARNING p2"<<std::endl;
//
//      p1innov=(*p1gene)->innovation_num;
//      p2innov=(*p2gene)->innovation_num;
//
//      if (p1innov==p2innov) {
//
//	//Pick the chosengene depending on whether we've crossed yet
//	if (genecounter<crosspoint) {
//	  chosengene=*p1gene;
//	}
//	else if (genecounter>crosspoint) {
//	  chosengene=*p2gene;
//	}
//	//We are at the crosspoint here
//	else {
//
//	  //Average them into the avgene
//	  //if (randfloat()>0.5) (avgene->lnk)->linktrait=((*p1gene)->lnk)->linktrait;
//	  //else (avgene->lnk)->linktrait=((*p2gene)->lnk)->linktrait;
//	  
//	  //WEIGHTS AVERAGED HERE
//	  (avgene->lnk)->weight=(((*p1gene)->lnk)->weight+((*p2gene)->lnk)->weight)/2.0;
//	
//	  
//	  if (randfloat()>0.5) (avgene->lnk)->in_node=((*p1gene)->lnk)->in_node;
//	  else (avgene->lnk)->in_node=((*p2gene)->lnk)->in_node;
//	  
//	  if (randfloat()>0.5) (avgene->lnk)->out_node=((*p1gene)->lnk)->out_node;
//	  else (avgene->lnk)->out_node=((*p2gene)->lnk)->out_node;
//	  
//	  if (randfloat()>0.5) (avgene->lnk)->is_recurrent=((*p1gene)->lnk)->is_recurrent;
//	  else (avgene->lnk)->is_recurrent=((*p2gene)->lnk)->is_recurrent;
//	  
//	  avgene->innovation_num=(*p1gene)->innovation_num;
//	  avgene->mutation_num=((*p1gene)->mutation_num+(*p2gene)->mutation_num)/2.0;
//
//	if ((((*p1gene)->enable)==false)||
//	    (((*p2gene)->enable)==false)) 
//	  avgene->enable=false;
//
//	  chosengene=avgene;
//	}
//
//	++p1gene;
//	++p2gene;
//	++genecounter;
//      }
//      else if (p1innov<p2innov) {
//	if (genecounter<crosspoint) {
//	  chosengene=*p1gene;
//	  ++p1gene;
//	  ++genecounter;
//	}
//	else {
//	  chosengene=*p2gene;
//	  ++p2gene;
//	}
//      }
//      else if (p2innov<p1innov) {
//	++p2gene;
//	skip=true;  //Special case: we need to skip to the next iteration
//	//becase this Gene is before the crosspoint on the wrong Genome
//      }
//    }
//    
//    //Check to see if the chosengene conflicts with an already chosen gene
//    //i.e. do they represent the same link    
//    curgene2=newgenes.begin();
//
//    while ((curgene2!=newgenes.end())&&
//	   (!((((((*curgene2)->lnk)->in_node)->node_id)==((((chosengene)->lnk)->in_node)->node_id))&&
//	      (((((*curgene2)->lnk)->out_node)->node_id)==((((chosengene)->lnk)->out_node)->node_id))&&((((*curgene2)->lnk)->is_recurrent)== (((chosengene)->lnk)->is_recurrent)) ))&&
//	   (!((((((*curgene2)->lnk)->in_node)->node_id)==((((chosengene)->lnk)->out_node)->node_id))&&
//	      (((((*curgene2)->lnk)->out_node)->node_id)==((((chosengene)->lnk)->in_node)->node_id))&&
//	      (!((((*curgene2)->lnk)->is_recurrent)))&&
//	      (!((((chosengene)->lnk)->is_recurrent))) )))
//      {
//
//	++curgene2;
//      }
//
//      
//    if (curgene2!=newgenes.end()) skip=true;  //Link is a duplicate
//
//    if (!skip) {
//      //Now add the chosengene to the baby
//      
// //     //First, get the trait pointer
// //     if ((((chosengene->lnk)->linktrait))==0) traitnum=(*(traits.begin()))->trait_id;
// //     else
//	//traitnum=(((chosengene->lnk)->linktrait)->trait_id)-(*(traits.begin()))->trait_id;  
//	//	//The subtracted number normalizes depending on whether traits start counting at 1 or 0
//      
//      //Next check for the nodes, add them if not in the baby Genome already
//      inode=(chosengene->lnk)->in_node;
//      onode=(chosengene->lnk)->out_node;
//      
//      //Check for inode in the newnodes std::list
//      if (inode->node_id<onode->node_id) {
//	//std::cout<<"inode before onode"<<std::endl;
//	//Checking for inode's existence
//	curnode=newnodes.begin();
//	while((curnode!=newnodes.end())&&
//	      ((*curnode)->node_id!=inode->node_id)) 
//	  ++curnode;
//
//	if (curnode==newnodes.end()) {
//	  //Here we know the node doesn't exist so we have to add it
//	  //normalized trait number for new NNode
//	
///*	  if (!(inode->nodetrait)) nodetraitnum=0;
//	  else
//	    nodetraitnum=((inode->nodetrait)->trait_id)-((*(traits.begin()))->trait_id);*/			       
//	  
//	  //new_inode=new NNode(inode,newtraits[nodetraitnum]);
//	  new_inode=new NNode(inode);
//
//	  node_insert(newnodes,new_inode);
//	}
//	else {
//	  new_inode=(*curnode);
//	}
//	
//	//Checking for onode's existence
//	curnode=newnodes.begin();
//	while((curnode!=newnodes.end())&&
//	      ((*curnode)->node_id!=onode->node_id)) 
//	  ++curnode;
//	if (curnode==newnodes.end()) {
//	  //Here we know the node doesn't exist so we have to add it
//	  //normalized trait number for new NNode
//	  
///*	  if (!(onode->nodetrait)) nodetraitnum=0;
//	  else
//	    nodetraitnum=((onode->nodetrait)->trait_id)-(*(traits.begin()))->trait_id;	*/		     
//
//	  //new_onode=new NNode(onode,newtraits[nodetraitnum]);
//	  new_onode=new NNode(onode);
//	  node_insert(newnodes,new_onode);
//
//	}
//	else {
//	  new_onode=(*curnode);
//	}
//      }
//      //If the onode has a higher id than the inode we want to add it first
//      else {
//	//Checking for onode's existence
//	curnode=newnodes.begin();
//	while((curnode!=newnodes.end())&&
//	      ((*curnode)->node_id!=onode->node_id)) 
//	  ++curnode;
//	if (curnode==newnodes.end()) {
//	  //Here we know the node doesn't exist so we have to add it
//	  //normalized trait number for new NNode
///*	  if (!(onode->nodetrait)) nodetraitnum=0;
//	  else
//	    nodetraitnum=((onode->nodetrait)->trait_id)-(*(traits.begin()))->trait_id;	*/		       
//	
//	  //new_onode=new NNode(onode,newtraits[nodetraitnum]);
//	  new_onode=new NNode(onode);
//	  node_insert(newnodes,new_onode);
//	}
//	else {
//	  new_onode=(*curnode);
//	}
//
//	//Checking for inode's existence
//	curnode=newnodes.begin();
//
//	while((curnode!=newnodes.end())&&
//	      ((*curnode)->node_id!=inode->node_id)) 
//	  ++curnode;
//	if (curnode==newnodes.end()) {
//	  //Here we know the node doesn't exist so we have to add it
//	  //normalized trait number for new NNode
///*	  if (!(inode->nodetrait)) nodetraitnum=0;
//	  else
//	    nodetraitnum=((inode->nodetrait)->trait_id)-(*(traits.begin()))->trait_id;*/			       
//
//	  //new_inode=new NNode(inode,newtraits[nodetraitnum]);
//	  new_inode=new NNode(inode);
//	  //newnodes.push_back(new_inode);
//	  node_insert(newnodes,new_inode);
//	}
//	else {
//	  new_inode=(*curnode);
//	}
//	
//      } //End NNode checking section- NNodes are now in new Genome
//      
//      //Add the Gene
//      //newgenes.push_back(new Gene(chosengene,newtraits[traitnum],new_inode,new_onode));
//		newgenes.push_back(new Gene(chosengene,new_inode,new_onode));
//
//    }  //End of if (!skip)
//
//    skip=false;
//
//  }
//
//
//  delete avgene;  //Clean up used object
//
//  //Return the baby Genome
//  //return (new Genome(genomeid,newtraits,newnodes,newgenes));
//  return (new Genome(genomeid,newnodes,newgenes));
//  
//}

/* This function gives a measure of compatibility between
     two Genomes by computing a linear combination of 3
     characterizing variables of their compatibilty.
     The 3 variables represent PERCENT DISJOINT GENES,
     PERCENT EXCESS GENES, MUTATIONAL DIFFERENCE WITHIN
     MATCHING GENES.  So the formula for compatibility
     is:  disjoint_coeff*pdg+excess_coeff*peg+mutdiff_coeff*mdmg.
     The 3 coefficients are global system parameters */
double Genome::compatibility(Genome *g)
{
	//iterators for moving through the two potential parents' Genes
	std::list<Gene*>::iterator p1gene;
	std::list<Gene*>::iterator p2gene;  

	//Innovation numbers
	double p1innov;
	double p2innov;

	//Set up the counters
	double num_disjoint=0.0;
	double num_excess=0.0;
	double mut_diff_total=0.0;
	double bias_diff_total=0.0;
	double time_constant_diff_total=0.0;

	double num_matching=0.0;  //Used to normalize mutation_num differences

	//double max_genome_size; //Size of larger Genome

	//Get the length of the longest Genome for percentage computations
	//if (genes.size()<(g->genes).size())
	//{
	//	max_genome_size=(g->genes).size();
	//}
	//else
	//{
	//	max_genome_size=genes.size();
	//}

	//Now move through the Genes of each potential parent 
	//until both Genomes end
	p1gene=genes.begin();
	p2gene=(g->genes).begin();
	while(!((p1gene==genes.end())&&(p2gene==(g->genes).end())))
	{
		if (p1gene==genes.end())
		{
			++p2gene;
			num_excess+=1.0;
		}
		else if (p2gene==(g->genes).end())
		{
			++p1gene;
			num_excess+=1.0;
		}
		else
		{
			//Extract current innovation numbers
			p1innov=(*p1gene)->innovation_num;
			p2innov=(*p2gene)->innovation_num;

			if (p1innov==p2innov)
			{
				num_matching+=1.0;

				//Calculate difference in link weights
				double mut_diff=((*p1gene)->mutation_num)-((*p2gene)->mutation_num);
				if (mut_diff<0.0)
				{
					mut_diff=0.0-mut_diff;
				}
				mut_diff_total+=mut_diff;

				//Calculate difference in outgoing nodes' biases
				double bias_diff=((*p1gene)->lnk->out_node->bias)
					- ((*p2gene)->lnk->out_node->bias);
				if (bias_diff<0.0)
				{
					bias_diff=0.0-bias_diff;
				}
				bias_diff_total+=bias_diff;

				//Calculate difference in outgoing nodes' time constants
				double time_constant_diff=((*p1gene)->lnk->out_node->time_constant)
					- ((*p2gene)->lnk->out_node->time_constant);
				if (time_constant_diff<0.0)
				{
					time_constant_diff=0.0-time_constant_diff;
				}
				time_constant_diff_total+=time_constant_diff;

				++p1gene;
				++p2gene;
			}
			else if (p1innov<p2innov)
			{
				++p1gene;
				num_disjoint+=1.0;
			}
			else if (p2innov<p1innov)
			{
				++p2gene;
				num_disjoint+=1.0;
			}
		}
	} //End while

	//Return the compatibility number using compatibility formula
	//Note that mut_diff_total/num_matching gives the AVERAGE
	//difference between mutation_nums for any two matching Genes
	//in the Genome

	/*
	//Normalizing for genome size
	return (disjoint_coeff*(num_disjoint/max_genome_size)+
	excess_coeff*(num_excess/max_genome_size)+
	mutdiff_coeff*(mut_diff_total/num_matching));
	*/

	//Original version...
	//Look at disjointedness and excess in the absolute (ignoring size)
	//return (
	//	NEAT::disjoint_coeff*(num_disjoint/1.0)+
	//	NEAT::excess_coeff*(num_excess/1.0)+
	//	NEAT::mutdiff_coeff*(mut_diff_total/num_matching));

	return (NEAT::disjoint_coeff*(num_disjoint/1.0)+
		NEAT::excess_coeff*(num_excess/1.0)+
		NEAT::mutdiff_coeff*(mut_diff_total/num_matching)+
		NEAT::biasdiff_coeff*(bias_diff_total/num_matching)+
		NEAT::time_constant_diff_coeff*(time_constant_diff_total/num_matching));
}

/* Return # of non-disabled genes */
int Genome::extrons() {
  std::list<Gene*>::iterator curgene;
  int total=0;

  for(curgene=genes.begin();curgene!=genes.end();curgene++)
  {
	  if ((*curgene)->enable) ++total;
  }

  return total;
}

int Genome::CountInputNodes()
{
	std::list<NNode*>::iterator iter;
	int total = 0;

	for(iter = nodes.begin(); iter != nodes.end(); iter++)
	{
		if (INPUT == (*iter)->gen_node_label)
		{
			total++;
		}
	}

	return total;
}

int Genome::CountHiddenNodes()
{
	std::list<NNode*>::iterator iter;
	int total = 0;

	for(iter = nodes.begin(); iter != nodes.end(); iter++)
	{
		if (HIDDEN == (*iter)->gen_node_label)
		{
			total++;
		}
	}

	return total;
}

int Genome::CountOutputNodes()
{
	std::list<NNode*>::iterator iter;
	int total = 0;

	for(iter = nodes.begin(); iter != nodes.end(); iter++)
	{
		if (OUTPUT == (*iter)->gen_node_label)
		{
			total++;
		}
	}

	return total;
}

//return a measure of this genome's complexity
int Genome::GetComplexity()
{
	return (CountEnabledLinks());
}

//returns the number of enabled links
int Genome::CountEnabledLinks()
{
	int enabledLinks = 0;

	//Add enabled genes
	std::list<Gene*>::iterator geneIter;
	for (geneIter = genes.begin(); geneIter != genes.end(); geneIter++)
	{
		if (true == (*geneIter)->enable)
		{
			enabledLinks++;
		}
	}

	return enabledLinks;
}

//adds together all the mutatable parameters in this genome
int Genome::GetNumParams()
{
	//Currently, the number of parameters = twice the number of nodes (each 
	//has a bias and time constant) plus the number of link weights.
	return (2*nodes.size() + CountEnabledLinks());
}

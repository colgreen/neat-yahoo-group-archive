#ifndef __NEAT_LINK_H__
#define __NEAT_LINK_H__

#include "NEAT.h"

//Forward declarations
//class Trait;
class NNode;

//Description: 

/* ----------------------------------------------------------------------- */
/* A LINK is a connection from one node to another with an associated weight */
/* It can be marked as recurrent */
/* Its parameters are made public for efficiency */
class Link
{
public:
  //Link(double w,NNode *inode,NNode *onode,bool recur);
  Link(double w,NNode *inode,NNode *onode);

  //Including a trait pointer in the Link creation
  //Link(Trait *lt,double w,NNode *inode,NNode *onode,bool recur);

  Link(double w);

  ~Link()
  {
    //if (linktrait!=0) delete linktrait;
  }

	void AddToWeight(double value);

 public: 
  double weight; //Weight of connection
  NNode *in_node; //NNode inputting into the link
  NNode *out_node; //NNode that the link affects
  //bool is_recurrent; //true or false
  //bool time_delay; //true or false

  //Trait *linktrait; //Points to a trait of parameters for genetic creation
  
  /* ************ LEARNING PARAMETERS *********** */
  /* These are link-related parameters that change
     during Hebbian type learning */
  double added_weight;  /* The amount of weight adjustment */

  //double params[NEAT::num_trait_params];

  //void derive_trait(Trait *curtrait);  //Derive a trait into link params

};

#endif

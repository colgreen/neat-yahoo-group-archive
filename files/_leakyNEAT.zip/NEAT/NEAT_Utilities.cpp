#include "Innovation.h"
#include "Organism.h"
#include "Species.h"
#include "Gene.h"
#include "Link.h"
#include "NNode.h"
//#include "Trait.h"
#include "Genome.h"
#include "NEAT_Utilities.h"

//This is used for std::list sorting of Organisms by fitness..highest fitness first
bool order_orgs(Organism *x, Organism *y) {
  return (x)->fitness > (y)->fitness;
}
  
//This is used for std::list sorting of Species by fitness of best organism
//highest fitness first
bool order_species(Species *x, Species *y) {

  //std::cout<<"Comparing "<<((*((x->organisms).begin()))->orig_fitness)<<" and "<<((*((y->organisms).begin()))->orig_fitness)<<": "<<(((*((x->organisms).begin()))->orig_fitness) > ((*((y->organisms).begin()))->orig_fitness))<<std::endl;

  return (((*((x->organisms).begin()))->orig_fitness) > 
	  ((*((y->organisms).begin()))->orig_fitness));
}

////Gene printing method
//std::ostream& operator<< (std::ostream& os, const Gene *thegene) {
//  Link *thelink=thegene->lnk;
//  NNode *inode=thelink->in_node;
//  NNode *onode=thelink->out_node;
//
//  std::cout<<"[Link ("<<inode->node_id<<", "<<onode->node_id<<") INNOV ("<<thegene->innovation_num<<", "<<thegene->mutation_num<<")";
//  std::cout<<" Weight "<<(thegene->lnk)->weight;
//  if (((thegene->lnk)->linktrait)!=0)
//    std::cout<<" Link's trait_id "<<((thegene->lnk)->linktrait)->trait_id;
//  if (thegene->enable==false) std::cout<<"-DISABLED-";
//  if (((thegene->lnk)->is_recurrent)) std::cout<<"RECUR";
//  std::cout<<"]"<<std::endl;
//  return os;
//
//}

//Genome printing method
//std::ostream& operator<< (std::ostream& os, const Genome *thegenome) 
//{
//	std::list<NNode*>::iterator curnode;
//	std::list<Gene*>::iterator curgene;
//	std::vector<Trait*>::iterator curtrait;
//
//	std::list<NNode*> nodes=thegenome->nodes;
//	std::list<Gene*> genes=thegenome->genes;
//	std::vector<Trait*> traits=thegenome->traits;
//
//	std::cout<<"GENOME START"<<std::endl;
//
//	for(curnode=nodes.begin();curnode!=nodes.end();++curnode) {
//	if (((*curnode)->gen_node_label)==INPUT) std::cout<<"I";
//	else if (((*curnode)->gen_node_label)==OUTPUT) std::cout<<"O";
//	else if (((*curnode)->gen_node_label)==HIDDEN) std::cout<<"H";
//	else if (((*curnode)->gen_node_label)==BIAS) std::cout<<"B";
//	std::cout<<(*curnode)<<" ";
//	}
//	std::cout<<std::endl;
//
//	for(curgene=genes.begin();curgene!=genes.end();++curgene) {
//	std::cout<<(*curgene)<<" ";
//	}
//	std::cout<<std::endl;
//
//	std::cout<<"Traits: ";
//	for(curtrait=traits.begin();curtrait!=traits.end();++curtrait) {
//	std::cout<<(*curtrait)<<" ";
//	}
//	std::cout<<std::endl;
//
//	std::cout<<"GENOME END"<<std::endl;
//
//	return os;
//}

//Not used for now...
//std::ostream& operator<< (std::ostream& os, const Trait *thetrait) {
//  if (thetrait==0) std::cout<<"EMPTY TRAIT"<<std::endl;
//  else {
//
//    std::cout<<"Trait #"<<thetrait->trait_id<<std::endl;
//    for (int count=0;count<NEAT::num_trait_params;count++) {
//      std::cout<<(thetrait->params)[count]<<" ";
//    }
//    std::cout<<std::endl; 
//  }
//}

//int print_Genome_tofile(Genome *g, std::string filename) 
//{
//	std::ofstream oFile(filename.c_str(), std::ios::out);
//
//  //Make sure it worked
//  if (!oFile) {
//	  std::cerr << "Can't open " << filename.c_str() << " for output" <<std::endl;
//    return 0;
//  }
//
//  g->print_to_file(oFile);
//
//  oFile.close();
//
//  return 1;
//}

/* Retrns a brand new empty std::list of innovations (for Guile) */
//std::list<Innovation*> *new_innov_list() {
//  std::list<Innovation*> *il=new std::list<Innovation*>();
//
//  return il;
//}

#include "Network.h"
#include "Genome.h"
#include "Species.h"
#include "Organism.h"

Organism::Organism(double fit, Genome *g,int gen) 
{
	evaluated = false;
   fitness=fit;
   orig_fitness=fitness;
   gnome=g;
   net=gnome->genesis(gnome->genome_id);
   species=0;  //Start it in no Species
   expected_offspring=0;
   generation=gen;
   eliminate=false;
   error=0;
   winner=false;
   champion=false;
   super_champ_offspring=0;

   //DEBUG vars
   pop_champ=false;
   pop_champ_child=false;
   high_fit=0;
   mut_struct_baby=0;
   mate_baby=0;
}

Organism::~Organism() 
{
	delete net;
	delete gnome;
}

/* Regenerate the network based on a change
   in the genotype */
void Organism::update_phenotype()
{
  //First, delete the old phenotype (net)
  delete net;

  //Now, recreate the phenotype off the new genotype
  net=gnome->genesis(gnome->genome_id);
}

#ifndef __NEAT_ORGANISM_H__
#define __NEAT_ORGANISM_H__

#include "NEAT.h"

//Forward declarations
class Network;
class Genome;
class Species;

//Description: 

/* ---------------------------------------------  */
/* ORGANISM CLASS:
   Organisms are Genomes and Networks with fitness
   information 
   i.e. The genotype and phenotype together
                                                  */
/* ---------------------------------------------  */
class Organism
{

 public:
  double fitness;  //A measure of fitness for the Organism

  double orig_fitness;  //A fitness measure that won't change during adjustments

  double error;  //Used just for reporting purposes

  bool winner;  //Win marker (if needed for a particular task)

  Network *net;  //The Organism's phenotype

  Genome *gnome; //The Organism's genotype 

  Species *species;  //The Organism's Species 

  double expected_offspring; //Number of children this Organism may have

  int generation;  //Tells which generation this Organism is from

  bool eliminate;  //Marker for destruction of inferior Organisms

  bool champion; //Marks the species champ

  int super_champ_offspring;  //Number of reserved offspring for a population leader

  bool pop_champ;  //Marks the best in population
  
  bool pop_champ_child; //Marks the duplicate child of a champion (for tracking purposes)

  double high_fit; //DEBUG variable- high fitness of champ

	bool evaluated; //true if fitness has been evaluated

  void update_phenotype(); /* Regenerate the network based on a change
			      in the genotype */
           
  //Track its origin- for debugging or analysis- we can tell how the organism was born
  bool mut_struct_baby;
  bool mate_baby;
                
  Organism(double fit, Genome *g,int gen);

  ~Organism();

};

#endif

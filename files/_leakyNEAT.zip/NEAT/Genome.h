#ifndef __NEAT_GENOME_H__
#define __NEAT_GENOME_H__

#include "NEAT.h"
#include <math.h>

//Forward declarations
class NNode;
//class Trait;
class Gene;
class Network;
class Link;
class Innovation;

//Now just use Gaussian all the time.
/* Mutators are variables that specify a kind of mutation */
//typedef int mutator;
//const mutator GAUSSIAN=0;  //This adds Gaussian noise to the weights
//const mutator COLDGAUSSIAN=1;  //This sets weights to numbers chosen from a Gaussian distribution

//Description: 

/* ----------------------------------------------------------------------- */  
/* A Genome is the primary source of genotype information used to create   */
/* a phenotype.  It contains 3 major constituents:                         */
/*   1) A std::vector of Traits                                                 */
/*   2) A std::list of NNodes pointing to a Trait from (1)                      */
/*   3) A std::list of Genes with Links that point to Traits from (1)           */
/* (1) Reserved parameter space for future use                             */
/* (2) NNode specifications                                                */
/* (3) Is the primary source of innovation in the evolutionary Genome.     */
/*     Each Gene in (3) has a marker telling when it arose historically.   */
/*     Thus, these Genes can be used to speciate the population, and the   */
/*     std::list of Genes provide an evolutionary history of innovation and     */
/*     link-building. */
class Genome
{         
public:
	//Constructor which spawns off an input XML file
	Genome(std::string filename);

	//Constructor which creates a genome from the given parameters.  isOscillatory
	//decides whether to use fully-connected outputs and all recurrent links.
	Genome(int id, int numInputs, int numOutputs, bool isOscillatory);

	//Special constructor which spawns off an input file
	//This constructor assumes that some routine has already read in GENOMESTART
	//Genome(int id, std::ifstream &iFile);

	//Constructor which takes full genome specs and puts them into the new one
	//Genome(int id,std::vector<Trait*> t, std::list<NNode*> n, std::list<Gene*> g);
	//Constructor which takes full genome specs and puts them into the new one
	Genome(int id, std::list<NNode*> n, std::list<Gene*> g);

	//Constructor which takes in links (not genes) and creates a Genome
	//Genome(int id,std::vector<Trait*> t, std::list<NNode*> n, std::list<Link*> links);
	//Constructor which takes in links (not genes) and creates a Genome
	Genome(int id, std::list<NNode*> n, std::list<Link*> links);

	/* This special constructor creates a Genome
	with i inputs, o outputs, n out of nmax hidden units, and random
	connectivity.  If r is true then recurrent connections will
	be included. 
	The last input is a bias
	Linkprob is the probability of a link  */
	//Genome(int new_id,int i, int o, int n,int nmax, bool r, double linkprob);

	//Destructor kills off all std::lists (including the trait vector)
	~Genome();

	Network *genesis(int);  //Generate a network phenotype from this Genome with specified id

protected:
	//Inserts a NNode into a given ordered std::list of NNodes in order
	void node_insert(std::list<NNode*> &nlist,NNode *n);

public:             
	//friend std::ostream& operator<< (std::ostream& os, const Genome *thegenome);

	int genome_id;

	//std::vector<Trait*> traits; //parameter conglomerations
	std::list<NNode*> nodes;     //std::list of NNodes for the Network
	std::list<Gene*> genes;     //std::list of innovation-tracking genes

	Network *phenotype;  //Allows Genome to be matched with its Network

	int get_last_node_id();  //Return id of final NNode in Genome
	double get_last_gene_innovnum();  //Return last innovation number in Genome

	//void print_genome();  //Displays Genome on screen

	void save_as_xml(const std::string& filename);

	//void print_to_file(std::ofstream &outFile); //Dump this genome to specified file

	//void print_to_filename(char *filename); //Dump genome to file

	Genome *duplicate(int new_id);  /* Duplicate this Genome to create a new one
	with the specified id */

	//bool verify();  //For debugging- tests node integrity; returns true on success

  /* ******* MUTATORS ******* */

  //void mutate_random_trait(); /* Perturb params in one trait */

  //void mutate_link_trait(int times);  /* Change random link's trait. 
		//			 Repeat times times */

  //void mutate_node_trait(int times); /* Change random node's trait times 
		//			times */

	//Set all link weights, node biases, and node time constants to random values.
	//This is useful at the beginning of evolution to generate totally random networks.
	void randomize_all_parameters();

	//Add Gaussian noise to some parameters.
	void mutate_some_parameters();

	//Add Gaussian noise to all parameters.
	void mutate_all_parameters();

  void mutate_toggle_enable(int times); /* toggle genes on or off */

  void mutate_gene_reenable();  /* Find first disabled gene and enable it */

  /* These last kinds of mutations return false if they fail
     They can fail under certain conditions,  being unable
     to find a suitable place to make the mutation.
     Generally, if they fail, they can be called again if desired. */

  bool mutate_add_node(std::list<Innovation*> &innovs,int &curnode_id,double &curinnov); /* Mutate genome by adding a node respresentation */

  /* Mutate the genome by adding a new link between 2 random NNodes */
  bool mutate_add_link(std::list<Innovation*> &innovs,double &curinnov); 

  /* ****** MATING METHODS ***** */

  /* This method mates this Genome with another Genome g.  
     For every point in each Genome, where each Genome shares
     the innovation number, the Gene is chosen randomly from 
     either parent.  If one parent has an innovation absent in 
     the other, the baby will inherit the innovation */
  Genome *mate_multipoint(Genome *g,int genomeid,double fitness1, double fitness2);

  /* This method mates like multipoint but instead of selecting one
     or the other when the innovation numbers match, it averages their
     weights */
  Genome *mate_multipoint_avg(Genome *g,int genomeid,double fitness1,double fitness2);

  /* This method is similar to a standard single point CROSSOVER
     operator.  Traits are averaged as in the previous 2 mating
     methods.  A point is chosen in the smaller Genome for crossing
     with the bigger one.  */
  //Genome *mate_singlepoint(Genome *g,int genomeid);

  /* ******** COMPATIBILITY CHECKING METHODS * ********/
  
  /* This function gives a measure of compatibility between
     two Genomes by computing a linear combination of 3
     characterizing variables of their compatibilty.
     The 3 variables represent PERCENT DISJOINT GENES, 
     PERCENT EXCESS GENES, MUTATIONAL DIFFERENCE WITHIN
     MATCHING GENES.  So the formula for compatibility 
     is:  disjoint_coeff*pdg+excess_coeff*peg+mutdiff_coeff*mdmg.
     The 3 coefficients are global system parameters */
  double compatibility(Genome *g);

  /* Return number of non-disabled genes */
  int extrons();

  int CountInputNodes();
  int CountHiddenNodes();
  int CountOutputNodes();

	int CountEnabledLinks(); //returns the number of enabled links
	int GetComplexity(); //return a measure of this genome's complexity
	int GetNumParams(); //adds together all the mutatable parameters in this genome
};

#endif

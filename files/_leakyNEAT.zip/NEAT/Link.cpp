#include "NNode.h"
//#include "Trait.h"
#include "Link.h"

/* ************************************************************** */
/* *                       LINK METHODS HERE                    * */
/* ************************************************************** */

//Link::Link(double w,NNode *inode,NNode *onode,bool recur)
Link::Link(double w,NNode *inode,NNode *onode)
{
   weight=w;
   in_node=inode;
   out_node=onode;
   //is_recurrent=recur;
   added_weight=0;
   //linktrait=0;
   //time_delay=false;
}

////Including a trait pointer in the Link creation
//Link::Link(Trait *lt,double w,NNode *inode,NNode *onode,bool recur)
//{
//   weight=w;
//   in_node=inode;
//   out_node=onode;
//   is_recurrent=recur;
//   added_weight=0;
//   linktrait=lt;
//   //time_delay=false;
//}	

Link::Link(double w)
{  //For when you don't know the connections yet
   weight=w;
   in_node=out_node=0;  
   //is_recurrent=false;
   //linktrait=0;
   //time_delay=false;
}

////Reserved for future system expansion
//void Link::derive_trait(Trait *curtrait) {
// 
//  if (curtrait!=0) {
//    for (int count=0;count<NEAT::num_trait_params;count++)
//      params[count]=(curtrait->params)[count];
//  }
//  else {
//    for (int count=0;count<NEAT::num_trait_params;count++)
//      params[count]=0;
//  }
//}

void Link::AddToWeight(double value)
{
	weight += value;

	//clamp the weight
	if (weight > NEAT::link_weight_clamp) 
	{
		weight = NEAT::link_weight_clamp;
	}
	else if (weight < -NEAT::link_weight_clamp)
	{
		weight = -NEAT::link_weight_clamp;
	}
}

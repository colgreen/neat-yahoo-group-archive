#include "Network.h"
#include "Link.h"
//#include "Trait.h"
#include <math.h>
#include <algorithm> //for find() function
#include "NNode.h"

/* ************************************************************** */
/* *                       NODE METHODS HERE                    * */
/* ************************************************************** */

////Only used by Genome::genesis; TODO: maybe remove this constructor?
//NNode::NNode(nodetype ntype,int nodeid, double timeConstant, double newBias)
//{
//   active_flag=false;
//   activesum=0;
//   activation=0;
//	time_constant=timeConstant;
//	bias=newBias;
//   output=0;
//   last_activation=0;
//   last_activation2=0;
//   type=ntype; //NEURON or SENSOR type
//   activation_count=0; //Inactive upon creation
//   node_id=nodeid;
//   ftype=SIGMOID;
//   nodetrait=0;
//   gen_node_label=HIDDEN; //is this right???
//   dup=0;
//   analogue=0;
//}

NNode::NNode(nodetype ntype,int nodeid, nodeplace placement, double timeConstant, double newBias)
{
   //active_flag=false;
   synapticInput=0;
   membranePotential=0;
	time_constant=timeConstant;
	bias=newBias;
   firingRate=0;
	mMinActiveSum = HUGE_VAL; //These must be initialized like this for dynamic_linear().
	mMaxActiveSum = -HUGE_VAL;
   //last_activation=0;
   //last_activation2=0;
   type=ntype; //NEURON or SENSOR type
   activation_count=0; //Inactive upon creation
   node_id=nodeid;
   ftype=SIGMOID;
   //nodetrait=0;
   gen_node_label=placement;
   dup=0;
   analogue=0;
}

//Construct a NNode off another NNode for genome purposes
//NNode::NNode(NNode *n,Trait *t) {
//   active_flag=false;
//   activation=0;
//	time_constant=n->time_constant;
//	bias=n->bias;
//   output=0;
//   last_activation=0;
//   last_activation2=0;
//   type=n->type; //NEURON or SENSOR type
//   activation_count=0; //Inactive upon creation
//   node_id=n->node_id;
//   ftype=SIGMOID;
//   nodetrait=0;
//   gen_node_label=n->gen_node_label;
//   dup=0;
//   analogue=0;
//   nodetrait=t;
//}
NNode::NNode(NNode *n)
{
   //active_flag=false;
	synapticInput=0;
   membranePotential=0;
	time_constant=n->time_constant;
	bias=n->bias;
   firingRate=0;
	mMinActiveSum = HUGE_VAL; //These must be initialized like this for dynamic_linear().
	mMaxActiveSum = -HUGE_VAL;
   //last_activation=0;
   //last_activation2=0;
   type=n->type; //NEURON or SENSOR type
   activation_count=0; //Inactive upon creation
   node_id=n->node_id;
   ftype=SIGMOID;
   //nodetrait=0;
   gen_node_label=n->gen_node_label;
   dup=0;
   analogue=0;
   //nodetrait=t;
}

//Warning: don't use this without fixing it first -> it doesn't initialize everything
//that the other constructors do.
//Construct the node out of a file specification using given list of traits
//NNode::NNode(std::ifstream &iFile,std::vector<Trait*> &traits)
//{
//   int traitnum;
//	std::vector<Trait*>::iterator curtrait;
//
//   activesum=0;
//	output=0;
//
//   //Get the node parameters
//   iFile>>node_id;
//   iFile>>traitnum;
//   iFile>>type;
//   iFile>>gen_node_label;
//	iFile>>time_constant;
//	iFile>>bias;
//
//   //Get a pointer to the trait this node points to
//   if (traitnum==0)
//	{
//		nodetrait=0;
//	}
//   else 
//	{
//		curtrait=traits.begin();
//
//		while(((*curtrait)->trait_id)!=traitnum)
//			++curtrait;
//
//		nodetrait=(*curtrait);
//   }
//}

NNode::~NNode()
{
   std::list<Link*>::iterator curlink;

   //Kill off all incoming links
   for(curlink=incoming.begin();curlink!=incoming.end();++curlink)
	{
		delete (*curlink);
   }

   //if (nodetrait!=0) delete nodetrait;
}

//Returns the type of the node, NEURON or SENSOR
const nodetype NNode::get_type()
{
  return type;
}

//Allows alteration between NEURON and SENSOR.  Returns its argument
nodetype NNode::set_type(nodetype newtype)
{
  type=newtype;
  return newtype;
}

//If the node is a SENSOR, returns true and loads the value
bool NNode::sensor_load(double value)
{
  if (type==SENSOR)
  {
    //Time delay memory
    //last_activation2=last_activation;
    //last_activation=membranePotential;

    activation_count++;  //Puts sensor into next time-step
    membranePotential=value;
	 firingRate=value; //only used in CTRNN version
    return true;
  }
  else
  {
	  return false;
  }
}

//NNode Display
//std::ostream& operator<<(std::ostream &os,const NNode &thenode)
//{
//  if (thenode.type==SENSOR)
//    std::cout<<"(S"<<thenode.node_id<<", step "<<thenode.activation_count<<":"<<thenode.activation<<")";
//  else if (thenode.type==NEURON)
//    std::cout<<"(N"<<thenode.node_id<<", step "<<thenode.activation_count<<":"<<thenode.activation<<")";
//  return os;
//}

//NNode Pointer Display
//std::ostream& operator<<(std::ostream &os,const NNode *thenode)
//{
//  if ((*thenode).type==SENSOR)
//    std::cout<<"(S"<<(*thenode).node_id<<","<<" step "<<(*thenode).activation_count<<":"<<(*thenode).activation<<")";
//  else if ((*thenode).type==NEURON)
//    std::cout<<"(N"<<(*thenode).node_id<<","<<" step "<<(*thenode).activation_count<<":"<<(*thenode).activation<<")";
//  return os;
//}

//Note: NEAT keeps track of which links are recurrent and which
//are not even though this is unnecessary for activation.
//It is useful to do so for 2 other reasons: 
//1. It makes networks visualization of recurrent networks possible
//2. It allows genetic control of the proportion of connections
//    that may become recurrent

//Add an incoming connection a node
//void NNode::add_incoming(NNode *feednode,double weight,bool recur)
//{
//  Link *newlink=new Link(weight,feednode,this,recur);
//  incoming.push_back(newlink);
//  (feednode->outgoing).push_back(newlink);
//}

void NNode::add_incoming(NNode *feednode,double weight)
{
  //Link *newlink=new Link(weight,feednode,this,false);
  Link *newlink=new Link(weight,feednode,this);
  incoming.push_back(newlink);
  (feednode->outgoing).push_back(newlink);
}

//Return activation currently in node, if it has been activated
//double NNode::get_active_out()
//{
//  if (activation_count>0)
//    return activation;
//  else return 0.0;
//}

//Return leaky integrator neuron output value
double NNode::get_firing_rate()
{
  if (activation_count>0)
  {
    return firingRate;
  }
  else
  {
	  return 0.0;
  }
}

////Return activation currently in node from PREVIOUS (time-delayed) time step,
//// if there is one
//double NNode::get_active_out_td() {
//  if (activation_count>1)
//    return last_activation;
//  else return 0.0;
//}

//This recursively flushes everything leading into and including this NNode, including recurrencies
void NNode::flushback()
{
	//A sensor should not flush black
	if (type!=SENSOR)
	{
		if (activation_count>0)
		{
			synapticInput = 0.0;
			activation_count=0;
			membranePotential=0;
			//last_activation=0;
			//last_activation2=0;
			firingRate=0;
			mMinActiveSum = HUGE_VAL; //These must be initialized like this for dynamic_linear().
			mMaxActiveSum = -HUGE_VAL;
		}

		//Flush back recursively
		std::list<Link*>::iterator curlink;
		for(curlink=incoming.begin();curlink!=incoming.end();++curlink)
		{
			//Flush the link itself (For future learning parameters possibility) 
			(*curlink)->added_weight=0;

			if ((((*curlink)->in_node)->activation_count>0))
			{
				((*curlink)->in_node)->flushback();
			}
		}
	}
	else
	{
		//Flush the SENSOR
		synapticInput = 0.0;
		activation_count=0;
		membranePotential=0;
		//last_activation=0;
		//last_activation2=0;
		firingRate=0;
		mMinActiveSum = HUGE_VAL; //These must be initialized like this for dynamic_linear().
		mMaxActiveSum = -HUGE_VAL;
	}
}

//This recursively checks everything leading into and including this NNode, 
// including recurrencies
// Useful for debugging
//void NNode::flushback_check(std::list<NNode*> &seenlist) {
//  std::list<Link*>::iterator curlink;
//  int pause;
//  std::list<Link*> innodes=incoming;
//  std::list<NNode*>::iterator location;
//
//  if (!(type==SENSOR)) {
//    
//
//      std::cout<<"ALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
//      std::cout<<"ALERT: "<<this<<" has activation  "<<activation<<std::endl;
//      std::cout<<"ALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
//      std::cout<<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;
//
//    if (activation_count>0) {
//      std::cout<<"ALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
//      std::cin>>pause;
//    }
//
//    if (activation>0) {
//      std::cout<<"ALERT: "<<this<<" has activation  "<<activation<<std::endl;
//      std::cin>>pause;
//    }
//
//    if (last_activation>0) {
//      std::cout<<"ALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
//      std::cin>>pause;
//    }
//
//    if (last_activation2>0) {
//      std::cout<<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;
//      std::cin>>pause;
//    }
//
//    for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {
//		 location=std::find(seenlist.begin(),seenlist.end(),((*curlink)->in_node));
//      if (location==seenlist.end()) {
//	seenlist.push_back((*curlink)->in_node);
//	((*curlink)->in_node)->flushback_check(seenlist);
//      }
//    }
//
//  }
//  else {
//    //Flush_check the SENSOR
//
//    
//      std::cout<<"sALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
//      std::cout<<"sALERT: "<<this<<" has activation  "<<activation<<std::endl;
//      std::cout<<"sALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
//      std::cout<<"sALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;
//    
//
//    if (activation_count>0) {
//      std::cout<<"ALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
//      std::cin>>pause;
//    }
//    
//    if (activation>0) {
//      std::cout<<"ALERT: "<<this<<" has activation  "<<activation<<std::endl;
//      std::cin>>pause;
//    }
//    
//    if (last_activation>0) {
//      std::cout<<"ALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
//      std::cin>>pause;
//    }
//    
//    if (last_activation2>0) {
//      std::cout<<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;
//      std::cin>>pause;
//    }
//    
//  }
//  
//}

//Reserved for future system expansion
//void NNode::derive_trait(Trait *curtrait) {
//
//  if (curtrait!=0) {
//    for (int count=0;count<NEAT::num_trait_params;count++)
//      params[count]=(curtrait->params)[count];
//  }
//  else {
//    for (int count=0;count<NEAT::num_trait_params;count++)
//      params[count]=0;
//  }
//
//}



//Find the greatest depth starting from this neuron at depth d
int NNode::depth(int d, Network *mynet)
{
  std::list<Link*> innodes=this->incoming;
  std::list<Link*>::iterator curlink;
  int cur_depth; //The depth of the current node
  int max=d; //The max depth
  //int pause;

  if (d>100) {
    //std::cout<<mynet->genotype<<std::endl;
    std::cout<<"** DEPTH NOT DETERMINED FOR NETWORK WITH LOOP"<<std::endl;
    return 10;
  }

  //Base Case
  if ((this->type)==SENSOR)
    return d;
  //Recursion
  else {

    for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {
      cur_depth=((*curlink)->in_node)->depth(d+1,mynet);
      if (cur_depth>d) max=cur_depth;
    }
  
    return max;

  } //end else

}

//void NNode::print_to_file(std::ofstream &outFile)
//{
//  outFile << "node " << node_id << " ";
//
//  if (nodetrait!=0)
//  {
//	  outFile<<nodetrait->trait_id << " ";
//  }
//  else
//  {
//	  outFile << "0 ";
//  }
//
//  outFile << type << " ";
//  outFile << gen_node_label << " ";
//  outFile << time_constant << " ";
//  outFile << bias << std::endl;
//}

void NNode::AddToBias(double value)
{
	bias += value;

	//clamp the biase
	if (bias > NEAT::bias_clamp)
	{
		bias = NEAT::bias_clamp;
	}
	else if (bias < -NEAT::bias_clamp)
	{	
		bias = -NEAT::bias_clamp;
	}
}

void NNode::AddToTimeConstant(double value)
{
	time_constant += value;

	//clamp the time constant
	if (time_constant > NEAT::max_time_constant)
	{
		time_constant = NEAT::max_time_constant;
	}
	else if (time_constant < NEAT::min_time_constant)
	{	
		time_constant = NEAT::min_time_constant;
	}
}

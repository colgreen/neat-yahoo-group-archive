#ifndef _NETWORK_H_
#define _NETWORK_H_

#include "Node.h"
#include "InnovationFactory.h"
#include "Genome.h"
#include <string>
#include <iostream>

using namespace std;

#define STEPS 2

/**
 * This class defines the decision network.  It is composed of nodes and
 * innovations.  Links are made from target node to innovation to source
 * node.  In this case it is easiest to think of an innovation as a
 * connection (although, in fact, they are simply enabling connections).
 * The links in the network run contrary to the signal path as the nodes
 * utilize a "collect" mechanism which queries and sums all parent nodes.
 * Then the node is "clocked" and the process repeats.  Each innovation
 * stores the weight associated with the connection provided by the
 * innovation.
 *
 * The geometry of the network is that of a fixed number of inputs and
 * outputs with a non-fixed number of hidden nodes.  Recurrence is
 * allowed in all nodes except input nodes.
*/
class Network
{
public:
  Network();

  /**
   * Copy constructor
   * @param n reference network
   * @return new network
   */
  Network( const Network * n );

  /**
   * Construct n
   * @param genome Genome describing desired network
   * @return new network
   */
  Network( const Genome & genome );

  virtual ~Network();

  /**
   * Reset the signal state of this network.  This call does not effect the 
   * geometry of the network in any way.
   */
  void Reset()
  {
    NodeVectorConstIt it;

    // Reset network
    for(it=_hidden.begin();it!=_hidden.end();++it)
      (*it)->source = 0;
    for(it=_outputs.begin();it!=_outputs.end();++it)
      (*it)->source = 0;
  }

  /**
   * Sets the input state of the network
   * @param inputs an array of fixed length INPUT_COUNT specifying the
   * input vector
   */
  void SetInput( PBSink * inputs )
  {
    int i;
    Node * pn;
    for(i=0;i<INPUT_COUNT;i++)
    {
      pn = _inputs[i];
      pn->sink = inputs[i];
      // go ahead and move these signals to source since this will be
      // the only input to the input nodes.
      pn->Transfer();
    }
  }

  /**
   * Simulates (runs) the network and copies the result into a caller-
   * supplied vector of fixed length OUTPUT_COUNT.
   * @param outputs A user-supplied array of fixed length
   */
  void Result( PBSource * outputs )
  {
    unsigned int i;
    NodeVectorConstIt it;
    for(i=0;i<STEPS;i++)
    {
      /* Collect signals from parental nodes */
      for(it=_hidden.begin();it!=_hidden.end();++it)
        (*it)->Collect();
      for(it=_outputs.begin();it!=_outputs.end();++it)
        (*it)->Collect();
      for(it=_hidden.begin();it!=_hidden.end();++it)
        (*it)->Transfer();
      for(it=_outputs.begin();it!=_outputs.end();++it)
        (*it)->Transfer();
    }

    // Gather outputs
    for(i=0;i<OUTPUT_COUNT;i++)
      outputs[i] = _outputs[i]->source;
  }

  unsigned long HiddenCount() const
  {
    return (unsigned long)_hidden.size();
  }

  unsigned long InnovationCount() const
  {
    return (unsigned long)_innovations.size();
  }

  /**
   * This computes the Stanley distance function described as
   *
   * \f[d=(c_1*E)/N+(c_2*D)/N+c_3*W\f]
   *
   * where \f$E\f$ represents the number of excess genes from one
   * network to the other and \f$D\f$ represents the number of disjoint
   * genes.  \f$W\f$ is the average weight difference between matching
   * genes.  The coefficients are determined empircally.
   *
   * NOTE : This implementation assumes all innovations are 
   * continually ascending.  I think this is true, but it depends
   * on how the rest of this works out.  May want to revisit this. 
   * Also, if we're going to stick with the initial state of full 
   * connection, we can probably further optimize this.
   *
   * @param n the comparison network
   * @return The Stanley-distance
   */
  float Distance( const Network * n ) const;

  /**
   * Returns a new network that is the offspring of this network and
   * the specified mate.
   * @param mate The mate network
   * @return a new offspring network
   */
  Network * Crossover( const Network * mate ) const;

  /**
   * Causes a point mutation to occur in this network.  Mutation occurs at
   * a the network level whereas crossover occurs at the genome level.
   */
  void Mutate();

  /**
   * Get the genome that fully describes this network
   * @param genome the genome or "dna" of this network
   */
  void Serialize( Genome & genome ) const;

  /**
   * @return Complexity of the network
   */
  float Complexity() const
  {
    // there's probably a better metric for this but for now...
    return (float)_activeInnovations();
  }


  /**
   * Writes out a file that can be parsed with Graphviz dot.
   * For example, try running :
   * @code dot graph.out -Tpng > graph.png @endcode
   * to generate a PNG of the network.
   * @param pszFile file to write to
   * @return true on success
   */
  bool WriteGraph( const char * pszFile, const char * label = 0 ) const;
  
  void Print()
  {
    Genome g;
    Serialize(g);
    g.Print();
  }
  

private:

  /* Methods */

  /**
   * Create the input (sensor) and output nodes
   */
  inline void _createFixedNodes();
  
  inline void _createRandomNode();
  
  inline void _createRandomConnection();
  
  inline void _mutateRandomConnection();

  inline void _disableRandomConnection();
  
  /**
   * Add an innovation to this network.
   * @param innovation A caller-supplied innovation.
   */
  inline bool _addInnovation( Innovation * innovation );

  inline bool _addInnovation( Node * source, Node * dest );

  inline bool _addInnovation( unsigned long id, Node * source, Node * dest );

  inline bool _addInnovation( unsigned long id, Node * source, Node * dest,
                              PBWeight weight, bool enabled );

  inline void _addHiddenNode( Node * n );

  inline Node * _findSinkableNode( unsigned long id ) const;

  inline Node * _findSourcableNode( unsigned long id ) const;

  /**
   * The number of sinkable (signal-recieving) nodes in the network.
   * @return count
   */
  int _sinkableNodeCount() const
  {
    return OUTPUT_COUNT + HiddenCount();
  }

  /**
   * The number of sourcable (signal-providing) nodes in the network. 
   * @return count
   */
  int _sourcableNodeCount() const
  {
    return BASE_NODE_COUNT + HiddenCount();
  }

  /**
   * Returns a sinkable (signal-recieving) node from the network with
   * uniform distribution.
   * @return Random sinkable Node
   */
  inline Node * _randomSinkableNode() const;

  /**
   * Returns a sourcable (signal-providing) node from the network with
   * uniform distribution.
   * @return Random sourceable Node
   */
  inline Node * _randomSourcableNode() const;

  unsigned int _activeInnovations() const;

  /* Variables */

  InnovationVector _innovations;
  NodeVector       _inputs;
  NodeVector       _hidden;
  NodeVector       _outputs;

  unsigned long    _maxHiddenId;
  unsigned long    _maxInnovationId;

};

#endif /*_NETWORK_H_*/

/***************************************************************************
 *   Copyright (C) 2005 by jeff   *
 *   jeff@deardorff.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "Node.h"

void Node::Collect()
{
  sink = 0;
  InnovationVectorConstIt it;
  for(it=begin();it!=end();++it)
    sink += (*it)->Result();
}

bool Node::Mutate( Node * p ) const
{
  InnovationVectorConstIt it;
  for(it=begin();it!=end();++it)
  {
    if((*it)->Parent() == p)
    {
      (*it)->Mutate();
      return true;
    }
  }
  return false;
}

// TODO this could be smarter about always trying to
// do what's asked of it...
Node * Node::DisableRandomConnection() const
{
  Innovation *n = _innovations[RNG::RandInt( ConnectionCount() )];
  if(!n->IsEnabled())
    return NULL;
  n->SetEnabled( false );
  return n->Parent();
}

void Node::MutateRandomConnectedNode() const
{
  _innovations[RNG::RandInt( ConnectionCount() )]->Mutate();
}


/***************************************************************************
 *   Copyright (C) 2005 by jeff   *
 *   jeff@deardorff.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __RING_H__
#define __RING_H__

template<class T>
class Ring
{
public:
  template<class>
  class node
  {
  public:
    node( T d ) {}
    node( T d, node<T> * p = 0, node<T> * n = 0 ) :
    data(d), prev(p), next(n) {}

    T data;
    node<T> *prev;
    node<T> *next;
  };

  template<class>
  class iterator
  {
  private:
    node<T> * _node;

  public:
    iterator( node<T> * n = 0 ) : _node(n) {}

    const T& operator*() const
    {
      return _node->data;
    }

    iterator<T> & operator++()
    {
      _node = _node->next;
      return *this;
    }

    iterator<T> prev()
    {
      return iterator<T>( _node->prev );
    }

    iterator<T> next()
    {
      return iterator<T>( _node->next );
    }
  };

  Ring() : _begin(0), _count(0) {}

  void add( const T& d )
  {
    if(!_begin)
    {
      _begin = _end = new node<T>( d );
      _begin->prev = _begin;
      _begin->next = _begin;
    }
    else
    {
      _end->next = new node<T>( d, _end, _begin );
      _end = _end->next;
      _begin->prev = _end;
    }
    _count++;
  }

  iterator<T> begin() const
  {
    return iterator<T>(_begin);
  }
  
  private:
    node<T> * _begin;
    node<T> * _end;
    unsigned int  _count;
};

#endif // __RING_H__

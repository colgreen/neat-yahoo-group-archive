#include "InnovationFactory.h"

InnovationFactory::InnovationFactory()
{
}

InnovationFactory::~InnovationFactory()
{
}

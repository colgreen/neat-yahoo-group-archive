#ifndef _NODEFACTORY_H_
#define _NODEFACTORY_H_

static const unsigned int INPUT_COUNT = 11;
static const unsigned int OUTPUT_COUNT = 9;
static const unsigned int BASE_NODE_COUNT = INPUT_COUNT + OUTPUT_COUNT;

class NodeFactory
{
private:
  NodeFactory() : _nodeCount(BASE_NODE_COUNT) {}
  long _nodeCount;

public:
  static NodeFactory & Singleton()
  {
    static NodeFactory f;
    return f;
  }

  static unsigned long GetId()
  {
    static NodeFactory f;
    return f._nodeCount++;
  }
};

#endif /*_NODEFACTORY_H_*/

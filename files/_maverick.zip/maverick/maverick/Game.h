/***************************************************************************
*   Copyright (C) 2005 by jeff   *
*   jeff@deardorff.com   *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
***************************************************************************/
#ifndef __GAME_H__
#define __GAME_H__

#include "Player.h"
#include <vector>

#include <iostream>

using namespace std;

typedef vector<Player*> PlayerList;
typedef vector<Player*>::iterator PlayerListIter;

/**
@brief 
A device for comparing multiple players in the context of a game.
*/
class Game
{
public:
  Game() {}
  virtual ~Game() {}

  virtual void AddPlayer( Player * p )
  {
    if(Players()<MaxPlayers())
      m_players.push_back( p );
    else cout << "Too many players in game" << endl;
  }

  virtual unsigned int Players()
  {
    return (unsigned int)m_players.size();
  }

  virtual bool Ready()
  {
    return (Players()>=MinPlayers());
  }

  virtual unsigned int MinPlayers() = 0;
  virtual unsigned int MaxPlayers() = 0;
  virtual void Evaluate() = 0;

  virtual void Clear()
  {
    m_players.clear();
  }

protected:
  PlayerList m_players;
};

/**
@brief 
Tic-Tac-Toe game.
*/
class TicTacToe : public Game
{
public:
  TicTacToe() 
  {
    if(INPUT_COUNT!=11 || OUTPUT_COUNT!=9)
      cout << "This game cannot be used with current settings" << endl;
  }

  virtual ~TicTacToe() {}

  unsigned int MaxPlayers() { return 2; }
  unsigned int MinPlayers() { return 2; }

  struct tttInput
  {
    tttInput() : bias(Weight_Max), rand(RNG::RandWeight()) {}
    PBSource bias;
    PBSource rand;
    PBSource board[9];
  };

  void Evaluate()
  {
    int turns,j,k,q,pos;
    bool bAtLeastOnePlayer;
    tttInput input;
    PBSource result[9];
    static const int winningMoves[8][9] =
    {
      1, 1, 1, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 0, 0, 1, 0, 0, 1, 0, 0,
      0, 1, 0, 0, 1, 0, 0, 1, 0,
      0, 0, 1, 0, 0, 1, 0, 0, 1,
      1, 0, 0, 0, 1, 0, 0, 0, 1,
      0, 0, 1, 0, 1, 0, 1, 0, 0
    };

    memset( input.board, 0x0, 9*sizeof(PBSource) );

    for(turns=0;turns<9;turns++)
    {
      bAtLeastOnePlayer = false;
      for(j=0;j<2;j++)
      {
        if(m_players[j]->IsAlive())
        {
          m_players[j]->ResetNetwork();
          m_players[j]->Process( (PBSource*)&input, result );

          // move position is max output position
          pos = 0;
          for(k=0;k<9;k++)
          {
            if(result[k] > result[pos])
              pos = k;
          }

          // make move on board
          if(input.board[pos] == 0)
          {
            // valid move, transfer it to board
            // get correct player "marker"
            PBSource marker = (PBSource)((j==0) ? Weight_Min : Weight_Max);
            input.board[pos] = marker;

            // check for win if enough moves have transpired
            if(turns>2)
            {
              bool bWin;

              // check for win
              for(k=0;k<8;k++)
              {
                bWin = true;
                for(q=0;q<9;q++)
                {
                  if(winningMoves[k][q] == 1)
                  {
                    bWin &= (input.board[q] == marker);
                  }
                }

                // this player won
                if(bWin)
                {
                  cout << "win" << endl;
                  m_players[j]->AddFitness( 100 );
                  break;
                }
              } 
              if(bWin) break;
            }

            bAtLeastOnePlayer = true;

            // each successful move earns some fitness
            //cout << "(" << m_players[j]->Uid() << ")mv" << endl;
            m_players[j]->AddFitness( 1 );
          }
          else
          {
            // invalid move
            ;//m_players[j]->Kill();
            // the other player can continue to play
          }
        }
      }
      if(!bAtLeastOnePlayer)
        break;
    }

    //cout << "turns: " << turns << endl

    Player * player1 = m_players[0];
    Player * player2 = m_players[1];

    if(turns==9 && player1->IsAlive() && player2->IsAlive())
    {
      // tie
      cout << "TIE" << endl;
      player1->AddFitness(100);
      player2->AddFitness(100);
    }

    if(player1->Fitness() == player2->Fitness())
      m_players[( RNG::CoinToss() ? 0 : 1 )]->Advance();
    else if(player1->Fitness() > player2->Fitness())
      player1->Advance();
    else 
      player2->Advance();
  }

};

#endif // __GAME_H__

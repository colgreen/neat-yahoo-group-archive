#ifndef _NODE_H_
#define _NODE_H_

#include "Innovation.h"
#include "NodeFactory.h"
#include "types.h"
#include <vector>

class Innovation;

/**
 * This class defines the fundamental unit of a network, the node.
 * Each node is identified by a system-wide unique id number.
 * Each node points to a list of connections that each, in turn,
 * link back to the innovation associated with the connection.
 * Each node is able to Collect values from the parental nodes
 * through the innovations and each node is able to "clock" the
 * resultant value from it's sink to it's source, in preperation
 * for supplying the value when a child node requests it.  In this
 * fashion, signals are clocked piecemeal through the network for
 * a fixed number of iterations (or possibly until the output is
 * believed to have stablized - tbd).
 */
class Node
{
public:
  Node() : next(0), _id( NodeFactory::GetId() ) { _innovations.reserve( INPUT_COUNT ); }
  Node( unsigned long id ) : next(0), _id(id) { _innovations.reserve( INPUT_COUNT ); }
  Node( const Node * n ) : next(0), _id(n->_id) { _innovations.reserve( INPUT_COUNT ); }

  virtual ~Node()
  {
  }

  InnovationVectorConstIt begin() const
  {
    return _innovations.begin();
  }

  InnovationVectorConstIt end() const
  {
    return _innovations.end();
  }

  /**
   * Sums all inputs
   */
  void Collect();

  /**
   * "Clock" sink to source through transfer function
   */
  void Transfer()
  {
    source = Math::Transfer(sink);
  }

  /**
   * Get the id for this node
   * @return node id
   */
  unsigned long Id() const
  {
    return _id;
  }

  /**
   * Add a connection to an innovation
   * @param i innovation to be connected to
   */
  void ConnectInnovation( Innovation * i )
  {
    _innovations.push_back( i );
  }

  /**
   * Total number of connections to innovations owned by this node
   * @return count
   */
  unsigned long ConnectionCount() const
  {
    return (unsigned long)_innovations.size();
  }

  /**
   * Try and mutate the innovation associated with this connection to
   * the passed node.
   * 
   * @param p the "parent" (upstream) node we're intrested in
   * @return true if the connection exists and mutation succeeded
   */
  bool Mutate( Node * p ) const;

  /**
   * Instructs the node to randomly pick an innovation and
   * mutate it.  This method gets a lot of buisness.
   */
  void MutateRandomConnectedNode() const;

  /**
   * Instructs the node to randomly pick an innovation and disable it
   * @return the node connected through the innovation
   */
  Node * DisableRandomConnection() const;

  // variables
  Node * next;       ///< pointer to next node in list
  PBSink sink;       ///< collector value of node
  PBSource source;   ///< emitter value of node

private:
  const long _id;
  InnovationVector _innovations;
};

typedef std::vector<Node*> NodeVector;
typedef NodeVector::iterator NodeVectorIt;
typedef NodeVector::const_iterator NodeVectorConstIt;

#endif /*_NODE_H_*/

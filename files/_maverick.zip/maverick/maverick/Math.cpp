#include "Math.h"
#ifdef __linux__
// TODO replace builtin!  I have no idea why exp isn't working...arg
#define EXP( x ) __builtin_expf(x)
#elif _WIN32
#include <complex>
#define EXP( x ) exp(x)
#endif

/* The steep activation function is from Stanley.
 * Not sure how I feel about it yet...
 */
Math::Math()
{
  f_factor = (PBSource) (f_Table_Length - 1) / f_Table_Length;
  for (int i = 0; i < f_Table_Length; i++)
  {
    f_f[i] = Sigmoid_Y_Unit_P / 
      ((PBSink)(1.0 + EXP(-(Sigmoid_Steepness*(PBSource)i))/
      (f_factor*Sigmoid_Y_Unit_P)));

    if(i)
      f_d[i-1] = f_f[i] - f_f[i-1];
  }
}

Math::~Math()
{}

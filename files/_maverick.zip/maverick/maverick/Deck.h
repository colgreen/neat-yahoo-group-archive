/***************************************************************************
 *   Copyright (C) 2005 by Jeff   *
 *   jeff@deardorff.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __CDECK_H__
#define __CDECK_H__

#include "RNG.h"

extern "C"
{
#include "poker_defs.h"
#include "inlines/eval.h"
#include "deck_std.h"
#include "rules_std.h"
}

static const uint32 gNewDeck[StdDeck_N_CARDS] =
{
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11,12,
  13,14,15,16,17,18,19,20,21,22,23,24,25,
  26,27,28,29,30,31,32,33,34,35,36,37,38,
  39,40,41,42,43,44,45,46,47,48,49,50,51
};

typedef uint32 card;

class CDeck
{
public:
  CDeck()
  {
    memcpy( _cards, gNewDeck, StdDeck_N_CARDS*sizeof(card) );
  }
  
  void Shuffle()
  {
    card temp;
    card * pcards=_cards;
    card * pecards=_cards+StdDeck_N_CARDS;
    unsigned char swap[StdDeck_N_CARDS];
    unsigned char * pswap = swap;

    // get random swap positions
    RNG::RandBuffer( swap, StdDeck_N_CARDS, StdDeck_N_CARDS-1 );

    while(pcards!=pecards)
    {
      temp = *pcards;
      *pcards++ = *(_cards+*pswap);
      *(_cards+*pswap++) = temp;
    }
    _pCurrent = _cards;
  }
  
  // this function is currently optimistic...it assumes there
  // are cards to be dealt.
  card GetCard()
  {
    return *_pCurrent++;
  }
  
  card operator [] (unsigned int x)
  {
    return _cards[x];
  }
  
private:
  card _cards[StdDeck_N_CARDS];
  card * _pCurrent;
};

#endif // __CDECK_H__

// maverick.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Tournament.h"
#include "Population.h"
#include "Player.h"
#include "Game.h"
//#include "xor.h"
//#include "Tournament.h"
#include "Symmetry.h"
#include <iostream>
#include "types.h"

#define PLAYERS 64

long gUidCounter = 0;

int _tmain(int argc, _TCHAR* argv[])
{
	
  //Network n;
  
  Math::Singleton();
 
  Population<Player> pop(PLAYERS);
  
  
  SETournament<TicTacToe> tourney(&pop);
  
  for(int i=0;i<10000;i++)
  {
    tourney.Play();
    pop.Reproduce();
  }

  
  /*
  Symmetry<Player> x;
  
  for(int i=0;i<10000;i++)
  {
    x.Evaluate( &pop );
    pop.Reproduce();
  }
  */
  return 0;
}


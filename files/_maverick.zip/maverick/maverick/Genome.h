/***************************************************************************
*   Copyright (C) 2005 by jeff                                            *
*   jeff@deardorff.com                                                    *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
***************************************************************************/
#ifndef _GENOME_H_
#define _GENOME_H_

#include "Innovation.h"
#include "Buffer.h"
#include <list>
#include <string>

#define P_INHERITED_DISABLE 0.75 ///< P a gene inherits "disabledness"

struct Gene
{
  Gene() {}
  Gene( long i, unsigned long src, unsigned long dst, PBWeight w, bool enable = true ) : 
  id( i ), sourceId( src ), destId( dst ), weight( w ), enabled( enable ) {}

  Gene( const Innovation * i ) : 
    id( i->Id() ), 
    sourceId( i->Parent()->Id() ),
    destId( i->Child()->Id() ),
    weight( i->Weight() ),
    enabled( i->IsEnabled() ) {}

  long id;
  unsigned long sourceId;
  unsigned long destId;
  PBWeight weight;
  bool enabled;
};

/**
* This class defines the "dna" of a network.  It is simply a list
* of Gene structures.  Crossover occurs at the Genome level owing 
* to the complex mechanism that would be required at the network 
* level.
*/
class Genome : public std::list<Gene>
{
public:
  Genome() {}

  Genome( const Genome & p1, const Genome & p2 )
  {
    Recombine( p1, p2 );
  }

  /**
  * Really just copy in a "gene".  I apologize to any molecular biologists
  * for the use of "replicate" here.
  * @param i 
  */
  void Replicate( const Innovation * i )
  {
    push_back( Gene( i ) );
  }

  void Replicate( const Gene & g )
  {
    push_back( g );
  }

  void Replicate( const Gene & a, const Gene & b )
  {
    Gene g( a.id, a.sourceId, a.destId, (a.weight+b.weight)/2 );
    if(a.enabled == b.enabled)
      g.enabled = a.enabled;
    // if innovation is disabled in either parent, there is a probability it
    // will be disabled in offspring gene
    g.enabled = !(RNG::CoinToss(P_INHERITED_DISABLE));
    Replicate( g );
  }

  void Recombine( const Genome & p1, const Genome & p2 )
  {
    Genome::const_iterator ita = p1.begin();
    Genome::const_iterator itb = p2.begin();

    clear();

    while( ita!=p1.end() && itb!=p2.end() )
    {
      if((*ita).id == (*itb).id)
      {
        Replicate( *ita, *itb );

        // ids match: move to next gene in both parents
        ita++;
        itb++;
      }
      else
      {
        if((*ita).id>(*itb).id)
        {
          Replicate( *itb ); // add gene unique to b
          itb++; // just move ahead in parent 1
        }
        else
        {
          Replicate( *ita ); // add gene unique to a
          ita++; // just move ahead in parent 2
        }
      }
    }

    // replicate excess (if any)
    while(ita!=p1.end())
    {
      Replicate( *ita );
      ita++;
    }

    // or
    while(itb!=p2.end())
    {
      Replicate( *itb );
      itb++;
    }
  }

  /**
  * Serialize this genome into raw binary (for storing, etc).
  * @param outBuffer address method should allocate at
  * @param len method will set this to the resultant length
  */
  void Serialize( Buffer & outGenome ) const
  {
    outGenome.Resize( sizeof( Gene ) * (unsigned long)size() );
    unsigned char * pd = outGenome.GetBuffer();

    Genome::const_iterator it;
    for(it=begin();it!=end();++it)
    {
      memcpy( pd, &(*it), sizeof( Gene ) );
      pd += sizeof( Gene );
    }
  }

  bool SetGenome( const Buffer & inGenome )
  {
    if( inGenome.Empty() || inGenome.Size()%sizeof( Gene ) != 0 )
    {
      cout << "INVALID GENOME LENGTH" << endl;
      return false;
    }

    clear();

    Gene g;
    unsigned int genes = inGenome.Size()/sizeof( Gene );
    for(unsigned int i=0;i<genes;i++)
    {
      memcpy( &g, inGenome.GetBuffer() + i*sizeof( Gene ), sizeof( Gene ) );
      push_back( g );
    }
  }

  void Print() const
  {
    Genome::const_iterator it;
    for(it=begin();it!=end();++it)
    {
      if((*it).weight > 0)
        printf( "%2.2lu|+%2.2f ", (*it).id, (*it).weight );
      else
        printf( "%2.2lu|%2.2f ", (*it).id, (*it).weight );
    }
    printf( "\n" );
  }
};

typedef Genome::iterator GenomeIt;
typedef Genome::const_iterator GenomeConstIt;

#endif // _GENOME_H_

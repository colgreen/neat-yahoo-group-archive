/***************************************************************************
 *   Copyright (C) 2005 by Jeff   *
 *   jeff@deardorff.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
 /*
#include "Table.h"

void Table::Play()
{
  PlayerPointerListIter it;
  
  _dealAll();
  

}

void Table::_dealAll()
{
  PlayerPointerListIter it;

  _deck.Shuffle();

  for(it=_players.begin();it!=_players.end();it++)
    (*it)->Deal( _deck.GetCard(), _deck.GetCard() );

  _flop1 = _deck.GetCard();
  _flop2 = _deck.GetCard();
  _flop3 = _deck.GetCard();
  _turn = _deck.GetCard();
  _river = _deck.GetCard();

  _state = PREFLOP;
}

Player * Table::_winner()
{
  PlayerPointerListIter it;
  StdDeck_CardMask com_cards;
  StdDeck_CardMask player_cards;
  HandVal val, max_val = 0;
  Player * pWinner;
  
    // set community cards
  StdDeck_CardMask_RESET(com_cards);
  StdDeck_CardMask_SET(com_cards, _flop1);
  StdDeck_CardMask_SET(com_cards, _flop2);
  StdDeck_CardMask_SET(com_cards, _flop3);
  StdDeck_CardMask_SET(com_cards, _turn);
  StdDeck_CardMask_SET(com_cards, _river);

  for(it=_players.begin();it!=_players.end();it++)
  {
    player_cards = com_cards;
    
    // set player cards
    StdDeck_CardMask_SET(player_cards, (*it)->CardA() );
    StdDeck_CardMask_SET(player_cards, (*it)->CardB() );
    val = StdDeck_StdRules_EVAL_N(player_cards, 7);

    if( max_val < val )
    {
      max_val = val;
      pWinner = *it;
    }
    
    //printf("%s: %d: ", DmaskString(StdDeck, player_cards), val);
    //StdRules_HandVal_print(val);
    //printf("\n");
  }
  
  return pWinner;
}
 */

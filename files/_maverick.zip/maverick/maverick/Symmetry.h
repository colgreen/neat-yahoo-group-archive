/***************************************************************************
 *   Copyright (C) 2005 by jeff   *
 *   jeff@deardorff.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __SYMMETRY_H__
#define __SYMMETRY_H__

#include "Problem.h"
#include "NodeFactory.h"

#define SAMPLES 32

template <class IndividualType>
class Symmetry : public Problem<IndividualType>
{
  public:
    Symmetry() {}

    void Evaluate( Population<IndividualType> * p )
    {
      float err;
      unsigned int i, j;
      PBSink input[SAMPLES][INPUT_COUNT] = { 
        10, -10, -10, -10, -10, -10,
        10, -10, -10, -10, -10, 10,
        10, -10, -10, -10, 10, -10,
        10, -10, -10, -10, 10, 10,
        10, -10, -10, 10, -10, -10,
        10, -10, -10, 10, -10, 10,
        10, -10, -10, 10, 10, -10,
        10, -10, -10, 10, 10, 10,
        10, -10, 10, -10, -10, -10,
        10, -10, 10, -10, -10, 10,
        10, -10, 10, -10, 10, -10,
        10, -10, 10, -10, 10, 10,
        10, -10, 10, 10, -10, -10,
        10, -10, 10, 10, -10, 10,
        10, -10, 10, 10, 10, -10,
        10, -10, 10, 10, 10, 10,
        10, 10, -10, -10, -10, -10,
        10, 10, -10, -10, -10, 10,
        10, 10, -10, -10, 10, -10,
        10, 10, -10, -10, 10, 10,
        10, 10, -10, 10, -10, -10,
        10, 10, -10, 10, -10, 10,
        10, 10, -10, 10, 10, -10,
        10, 10, -10, 10, 10, 10,
        10, 10, 10, -10, -10, -10,
        10, 10, 10, -10, -10, 10,
        10, 10, 10, -10, 10, -10,
        10, 10, 10, -10, 10, 10,
        10, 10, 10, 10, -10, -10,
        10, 10, 10, 10, -10, 10,
        10, 10, 10, 10, 10, -10,
        10, 10, 10, 10, 10, 10
      };
      
      PBSource result[SAMPLES][OUTPUT_COUNT];
      PBSource correct[SAMPLES][OUTPUT_COUNT] = 
      { 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 
        0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1};

        if(INPUT_COUNT != 6 || OUTPUT_COUNT != 1)
        {
          cout << "Check input/output counts" << endl;
          return;
        }
        
        for(i=0;i<p->Size();i++)
        {
          for(j=0;j<SAMPLES;j++)
          {
            (*p)[i]->Reset();
            (*p)[i]->Process( input[j], result[j] );
          }
          err = 0;
          for(j=0;j<SAMPLES;j++)
          {
            err += ABS(correct[j][0]-result[j][0]);
          }
          if(err<6)
          {
            printf("\n-----------------------\n");
            cout << "err: " << err << endl;
            for(j=0;j<SAMPLES;j++)
            {
              printf( "%4.4f | %4.4f\n", correct[j][0], result[j][0] );
            }
          }
         
          (*p)[i]->SetFitness((SAMPLES-err)*(SAMPLES-err));
        }
    }
};

#endif // __SYMMETRY_H__

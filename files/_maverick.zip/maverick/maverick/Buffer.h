/***************************************************************************
 *   Copyright (C) 2005 by jeff   *
 *   jeff@deardorff.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __BUFFER_H__
#define __BUFFER_H__

class Buffer
{
public:
  Buffer( unsigned long len = 0 ) : _pData(0), _ulLength(len)
  {
    if(_ulLength)
      _pData = (unsigned char*)malloc( len );
  }
  
  Buffer( unsigned char * data, unsigned long len )
  {
    SetBuffer( data, len );
  }
  
  Buffer( const Buffer & b )
  {
    SetBuffer( b._pData, b._ulLength );
  }

  void Clear()
  {
    if(_pData)
    {
      delete _pData;
      _pData = 0;
      _ulLength = 0;
    }
  }
  
  void SetBuffer( unsigned char * data, unsigned long len )
  {
    if(_pData)
    {
      if(_ulLength != len)
      {
        Clear();
        _pData = (unsigned char*)malloc( len );
        _ulLength = len;
      }
    }
    else
    {
      _pData = (unsigned char*)malloc( len );
      _ulLength = len;
    }
    
    if(data)
      memcpy( _pData, data, len );
  }
  
  unsigned char * GetBuffer() const
  {
    return _pData;
  }
  
  unsigned long Size() const
  {
    return _ulLength;
  }

  bool Empty() const
  {
    return (_ulLength == 0);
  }
  
  void Resize( unsigned long length )
  {
    SetBuffer( 0, length );
  }
  
  unsigned char operator[]( unsigned int idx ) const
  {
    return _pData[idx];
  }

private:
  unsigned char * _pData;
  unsigned long _ulLength;
};

#endif // __BUFFER_H__


#ifndef __POPULATION_H__
#define __POPULATION_H__

#include "InnovationFactory.h"
#include "Array.h"
#include "RNG.h"
#include <vector>
#include <list>

#include <iostream>
using namespace std;

#define SPECIES_THRESHOLD            8
#define P_INTERSPECIES_CROSSOVER     0.1f

#define RANDOM_INDIVIDUAL            (Selection::RandomIndividual\
                                     (_individuals))
#define RANDOM_CONSINDIVIDUAL(x)     (Selection::RandomConspecificIndividual\
                                     ( _individuals, x))

template <class IndividualType>
class DefaultSelection;


//
// The idea for the templates on this class would be to specificy a
// type derived from Network ( i.e. PokerPlayer ) as the type of
// individual in the population and also a selection type if you want
// to override the default selection methods.
//
// I also had thought there would be a Speciation template type that
// would allow one to define the speciation used for a particular
// population.
//
// The array class can probably be collapsed, but I wanted to use
// something like that to encapsulate the functionality at first just
// to get it working.  It will probably be more efficient in the end
// to collapse it down to a simple array, but it will be easier to
// develop everything using a more robust container class.
//
// There is a problem with how mutation and crossover occur now.  The
// idea was that the population individual would be a derivation of
// network and would be templated in the population class.  HOWEVER,
// given both of these facts, it is impossible to perform crossover
// and mutation given the current interface.  The always create new
// Networks and not new *IndividualType* objects which is what we need
// to maintain additional metadata. To fix, we need to do one of the
// following:
//
// 1.  Change interfaces to accept input parameter like we had
// discussed earlier.  Then it is the populations respsonsiblity to
// create and destroy individuals.
//
// 2. Template the network class <bleh>
//
// 3. Make individuals contain a network as an attribute rather than
// deriving from them.  Then expose a Set()/Get() on all individual
// types.
//
// 4. Put constructor that accepts a network in each of the individual
// types, and use that to create a new individual based on the new
// network.  Potentially double the construction cost.
//

///////////////////////////////////////////////////////////////////////////////
template <class IndividualType, class Selection = DefaultSelection<IndividualType> >
class Population
{
public:

  // Types of selection available
  enum enSelectionType
  {
    Crossover = 0,
    Elitism,
    Creation,
    Mutation
  };

  ///////////////////////////////////////////////////////////////////////////
  Population(unsigned long inSize)
  : _individuals(inSize), _generations(0), _fitMax(0), _ticks(0)
  {
    _InitializePopulation();
  };

  ///////////////////////////////////////////////////////////////////////////
  virtual ~Population(){}
  
  IndividualType * operator[]( int i )
  {
    return _individuals[i];
  }
  
  IndividualType * At( int i )
  { 
    return _individuals[i];
  }
  
  IndividualType * First()
  {
    return _individuals[0];
  }

  unsigned int Size() const
  {
    return _individuals.Size();
  }
  
  void Reset()
  {
    for(unsigned int i=0;i<Size();i++)
    {
      _individuals[i]->Reset();
    }
  }
  

  /**
   * This implements the fitness sharing function between individuals
   * whose Stanley distance is less than some threshold.  The purpose of
   * this is to protect topolgical innovation.  "More unique" individuals
   * will end up with a greater fitness (all other things being equal).
   */
  void Speciate()
  {
    unsigned int i,j;
    std::list<IndividualType*> smembers;
    typename std::list<IndividualType*>::iterator it;
    IndividualType *sind, *cind;

    unsigned int species = 0;
    
    for(i = 0; i < _individuals.Size(); i++)
    {
      sind = _individuals[i];
      // make sure we're not already assigned to a species
      if(sind->Species() == 0)
      {
        for(j = i; j < _individuals.Size(); j++)
        {
          cind = _individuals[j];
          if( sind->Distance( cind ) < SPECIES_THRESHOLD)
          {
            // 0 means speciesless
            cind->SetSpecies( i+1 );
            smembers.push_front( cind );
          }
        }

        // if we're so much more than a one-individual species...
        if(smembers.size() > 1)
        {
          species++;
          for(it=smembers.begin();it!=smembers.end();it++)
          {
            (*it)->SetFitness( (*it)->Fitness()/smembers.size() );
          }
        }
        smembers.clear();
      }
    }
    //cout << "Number of species: " << species << endl;
  }
  
  ///////////////////////////////////////////////////////////////////////////
  // Perform selection to create the next generation of individuals
  ///////////////////////////////////////////////////////////////////////////
  void Reproduce()
  {
    IndividualPointerArray<IndividualType> tempArray(_individuals.Size());
    
    //_individuals.QuickSort();
   
    
    Speciate();

    // Sort networks based on fitness.  This isn't necessary but the
    // thought is that it may optimize the selection process as
    // randomly chosen individuals will be found closer to the top
    // of the list.
    _individuals.QuickSort();
    
    //cout << "Max Fitness: " << _individuals[0]->Fitness() << endl;

    unsigned long before = GetTickCount();

	  float fitTotal = 0;

    // Elitism, creation, mutation, crossover
    for( unsigned int i = 0; i < _individuals.Size(); i++)
    {
	  fitTotal+=_individuals[i]->Fitness();

      switch( Selection::RandomSelectionType() )
      {
      case Crossover:
        if(RNG::CoinToss(P_INTERSPECIES_CROSSOVER))
          tempArray[i] = (IndividualType*)(RANDOM_INDIVIDUAL->Crossover( *RANDOM_INDIVIDUAL ));
        else
        {
          IndividualType * ind = RANDOM_INDIVIDUAL;
          tempArray[i] = (IndividualType*)(ind->Crossover(*RANDOM_CONSINDIVIDUAL(ind->Species())));
        }
        break;
      case Elitism:
        tempArray[i] = new IndividualType( *RANDOM_INDIVIDUAL );
        break;
      case Creation:
        tempArray[i] = new IndividualType;
        break;
      case Mutation:
        tempArray[i] = (IndividualType*)(RANDOM_INDIVIDUAL->MutateNew());
        break;
      }
    }

    if(First()->Fitness()>_fitMax)
    {
      //cout << _generations << "------------- fitness improvement" << endl;
      //cout << "Max Fitness: " << _individuals[0]->Fitness() << endl;
      /*
      char file[256];
      char label[256];
      sprintf( file, "graphs/BEST%5.5d.out", _generations );
      sprintf( label, "gen: %d\\nfit: %f", _generations, First()->Fitness() );
      First()->Print( file, label );
      sprintf( file, "dot graphs/BEST%5.5d.out -Tpng > graphs/BEST%5.5d.png", _generations, _generations );
      system( file );
      */
      _fitMax = First()->Fitness();
    }

    
    _ticks += GetTickCount() - before;
    cout << _ticks/(_generations+1) << endl;

	cout << _generations;
	cout << ". AF/MF/ATMF: " << fitTotal/Size();
	cout << "/" << First()->Fitness();
	cout << "/" << _fitMax;
	cout << " C: " << First()->Complexity();
	cout << endl;

    _individuals.Swap( tempArray );
    InnovationFactory::Clear();
    _generations++;
  }

  void Randomize()
  {
    int swap;
    IndividualType *temp;
    for( unsigned int i = 0; i < _individuals.Size(); i++)
    {
      swap = RNG::RandInt( 0, _individuals.Size() );
      temp = _individuals[i];
      _individuals[i] = _individuals[swap];
      _individuals[swap] = temp;
    }
  }

private:

  ///////////////////////////////////////////////////////////////////////////
  // Initialize the worlds population
  ///////////////////////////////////////////////////////////////////////////
  void _InitializePopulation()
  {
    // Initialize the population
    for( unsigned int i = 0; i < _individuals.Size(); i++ )
      _individuals[i] = new IndividualType;
  }

  ///////////////////////////////////////////////////////////////////////////
  IndividualPointerArray<IndividualType> _individuals;
  long _generations;
  float _fitMax;
  unsigned long _ticks;
};

///////////////////////////////////////////////////////////////////////////////
template <class IndividualType>
class DefaultSelection
{
public:
  ///////////////////////////////////////////////////////////////////////////
  static int RandomSelectionType()
  {
    typename Population<IndividualType>::enSelectionType enType;

    // Hard code for now
    float _fElitism =     10;
    float _fCreationism = 10;
    float _fMutation =    10;
    float _fCrossover =   50;

    float total = _fElitism + _fCreationism + _fMutation + _fCrossover;
    float pick = RNG::RandFlt( total );
    float sum = 0;

    if( pick < (sum+=_fElitism) ) 
      enType = Population<IndividualType>::Elitism;
    else if( pick < (sum+=_fCreationism) ) 
      enType = Population<IndividualType>::Creation;
    else if( pick < (sum+=_fMutation) ) 
      enType = Population<IndividualType>::Mutation;
    else enType = Population<IndividualType>::Crossover;

    return enType;
  }

  ///////////////////////////////////////////////////////////////////////////
  static IndividualType * RandomIndividual(IndividualPointerArray<IndividualType> & inIndividuals)
  {
    unsigned long i;
    float fFitnessSum = 0;

    for(i = 0; i < inIndividuals.Size(); i++)
      fFitnessSum += inIndividuals[i]->Fitness();

    float fValue = RNG::RandFlt(fFitnessSum);
    float fSum = 0;
    for(i = 0; i < inIndividuals.Size(); i++)
    {
      fSum += inIndividuals[i]->Fitness();
      if( fValue <= fSum ) break;
    }
    return (IndividualType*) inIndividuals[i];
  }
  
  // Fun fact!  Conspecific means "from the same species".
  // TODO this function could definitely be faster.
  static IndividualType * RandomConspecificIndividual(
      IndividualPointerArray<IndividualType> & inIndividuals, int species )
  {
    unsigned long i;
    float fFitnessSum = 0;

    for(i = 0; i < inIndividuals.Size(); i++)
    {
      if(inIndividuals[i]->Species() == species)
        fFitnessSum += inIndividuals[i]->Fitness();
    }

    float fValue = RNG::RandFlt(fFitnessSum);
    float fSum = 0;
    for(i = 0; i < inIndividuals.Size(); i++)
    {
      if(inIndividuals[i]->Species() == species)
        fSum += inIndividuals[i]->Fitness();
      if( fValue <= fSum ) break;
    }
    return (IndividualType*) inIndividuals[i];
  }
};

#endif // __POPULATION_H__

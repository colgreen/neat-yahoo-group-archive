#ifndef _INNOVATIONFACTORY_H_
#define _INNOVATIONFACTORY_H_

#include "Innovation.h"
#include "Network.h"

#define BASE_INNOVATIONS (INPUT_COUNT * OUTPUT_COUNT)

// i'd like to include an id in this but every little BIT helps! ah...
struct InnovationRecord
{
  long src;
  long dest;
  InnovationRecord * next;
};

/**
 * The InnovationFactory produces innovation identification numbers used
 * to track unique innovations that exist for a given generation.  By
 * convention, the first N innovation IDs are assigned to the initial
 * network connections, where N is the number of inputs times the
 * number of outputs.  The factory should be reset every generation.
 */
class InnovationFactory
{
private:
  InnovationFactory() : _innovationId( BASE_INNOVATIONS ) {}

public:
  static InnovationFactory & Singleton()
  {
    static InnovationFactory f;
    return f;
  }

  /**
   * This clears all listed innovations but retains the current "global"
   * innovation count so we always get unique ids.
   */
  static void Clear()
  {
    static InnovationFactory f;
    InnovationRecord *pir, *pnir;

    for(pir=*f._innovations;pir;pir=pnir)
    {
      pnir = pir->next;
      delete pir;
    }
  }

  /**
   * Creates a new id (or returns an existing one)
   * @param srcNodeId the node of signal origin
   * @param destNodeId the signal target node
   * @return the id that should be used to describe the associated innovation
   */
  static unsigned long GetId( unsigned long srcNodeId, unsigned long destNodeId )
  {
    static InnovationFactory f;
    if(f._innovationId == BASE_INNOVATIONS )
    {
      // first entry
      f._last = f._innovations[0] = new InnovationRecord;
    }
    else
    {
      InnovationRecord * pir;
      unsigned long id;
      for(id=0,pir = *(f._innovations);pir;id++,pir=pir->next)
        if(pir->src==srcNodeId && pir->dest==destNodeId)
          return id;

      // otherwise, append an entry to our list
      // reminder: equals operator is right associative
      // (start at the bottom and assign up)
      f._last =
        f._last->next =
          f._innovations[f._innovationId] =
            new InnovationRecord;
    }

    f._last->src = srcNodeId;
    f._last->dest = destNodeId;
    f._last->next = 0;
    return f._innovationId++;
  }

  // these functions are very trusting...they don't check for a valid id.
  // however, if these eat it, it means there's a bug somewhere else in the
  // system.  I simply don't have the time or inclination to check here.
  // Frankly I'm tired of having dinner ready every day with out a word of
  // thanks.  My mom said you were no good.
  /*
  static unsigned long GetSrcNodeId( unsigned long id )
  {
    static InnovationFactory f;
    return f._innovations[id]->src;
  }
  
  static unsigned long GetDestNodeId( unsigned long id )
  {
    static InnovationFactory f;
    return f._innovations[id]->dest;
  }
  
  static void GetNodeIds( unsigned long id, 
                          unsigned long & srcNodeId, 
                          unsigned long & destNodeId )
  {
    static InnovationFactory f;
    srcNodeId = f._innovations[id]->src;
    destNodeId = f._innovations[id]->dest;
  }
  */
private:
  unsigned long _innovationId;
  InnovationRecord *_innovations[MAX_INNOVATIONS], *_last;
};

#endif /*_INNOVATIONFACTORY_H_*/

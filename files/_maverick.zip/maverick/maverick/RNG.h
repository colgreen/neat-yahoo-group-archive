/***************************************************************************
*   Copyright (C) 2005 by jeff   *
*   jeff@deardorff.com   *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
***************************************************************************/
#ifndef _RNG_H_
#define _RNG_H_
#include "Math.h"
#include <stdio.h>
#include <limits.h>
#include <string>
#include <iostream>
#ifdef _WIN32
#include <windows.h>
#include <wincrypt.h>
#endif

using namespace std;

#define RNG_BUFFER_LENGTH 8192

/**
* The Random Number Generator (RNG) produces the psuedorandom numbers for
* everything in the simulation that needs them.  All it does is read the
* PRNG /dev/urandom and farms it out.  I realize these numbers are not
* really entropic, but they should be fine for our purposes.
* All we really want are decorrelated numbers for the various runs and events
* in the simulation.  If my understanding of the internals of urandom
* are correct, this will do the job.  If it turns out I'm wrong, the
* thing to do would be to occasionally mix in some /dev/random.  However,
* I suspect that's pretty much what happens anyway.
*/
class RNG
{
private:
  RNG()
  {
#ifdef __linux__
    _hdev = fopen( "/dev/urandom", "r" );
    _pbuf = _pebuf = &_buffer[RNG_BUFFER_LENGTH-1];
#elif _WIN32
    if(!CryptAcquireContext( &_hdev, NULL, NULL, PROV_RSA_FULL, 0))
    {
      if (GetLastError() == NTE_BAD_KEYSET)
      {
        CryptAcquireContext( &_hdev, NULL, NULL, 
          PROV_RSA_FULL, CRYPT_NEWKEYSET);
      }
    }
#endif
  }

  virtual ~RNG()
  {
#ifdef __linux__
    if( _hdev ) fclose( _hdev );
#elif _WIN32
    CryptReleaseContext( _hdev, 0 );
#endif
  }

public:
  static float RandFlt( float min, float max )
  {
    unsigned long r;
    static RNG rng;
    rng._read( (char*)&r, sizeof( unsigned long ) );
    return (r/float(ULONG_MAX)) * ( max-min ) + min;
  }

  static PBSource RandWeight()
  {
    return (PBSource)RandFlt( Weight_Min, Weight_Max );
  }

  static float RandFlt( float max )
  {
    unsigned long r;
    static RNG rng;
    rng._read( (char*)&r, sizeof( unsigned long ) );
    return (r/float(ULONG_MAX)) * max;
  }

  static int RandInt( int min, int max )
  {
    return (int)RandFlt((float)min, (float)max);
  }

  static int RandInt( int max )
  {
    return (int)RandFlt((float)max);
  }

  static float RandFlt()
  {
    static RNG rng;
    return RandFlt( 0, 1 );
  }

  // some people call this "roulette", but when you think 
  // about it it's really more like a weighted coin...
  static bool CoinToss( float p )
  {
    return (RandFlt()<p);
  }

  static char RandChar()
  {
    char result;
    static RNG rng;
    rng._read( &result, 1 );
    return result;
  }

  static void RandBuffer( char * b, unsigned int len )
  {
    static RNG rng;
    rng._read( b, len );
  }

  static void RandBuffer( char * b, unsigned int len, int min, int max )
  {
    char * pb = b;
    char * pbend = b + len;
    static RNG rng;
    rng._read( b, len );
    while(pb!=pbend)
      *pb++ = (char)((*pb)/float(UCHAR_MAX)) * ( max-min ) + min;
  }

  static void RandBuffer( unsigned char * b, unsigned int len, int max )
  {
    unsigned char * pb = b;
    unsigned char * pbend = b + len;
    static RNG rng;
    rng._read( (char*)b, len );
    while(pb!=pbend)
    {
      *pb = (unsigned char)((((unsigned char)*pb)/float(UCHAR_MAX)) * max);
      *pb++;
    }
  }

  static bool CoinToss()
  {
    static RNG rng;
    return ( rng.RandChar() & 0x01 ); // just need one bit
  }

private:
  // NOTE : In case you're wondering, the local buffering does speed this up
  void _read( char * b, unsigned int len ) const
  {
    static RNG rng;
    if(len < RNG_BUFFER_LENGTH)
    {
      if((int)len > (rng._pebuf - rng._pbuf))
      {
        // This works b/c we're generally asking for small values so
        // we can afford to throw away any excess buffer
#ifdef __linux__
        fread( (char*)&rng._buffer[0], 1, RNG_BUFFER_LENGTH, rng._hdev );
#elif _WIN32
        CryptGenRandom( rng._hdev, RNG_BUFFER_LENGTH, (BYTE*)&rng._buffer[0] );
#endif
        // reset pointer
        rng._pbuf = rng._buffer;
      }
      memcpy( b, rng._pbuf+=len, len );
    }
    else
    {
      // o/w read directly from the device
#ifdef __linux__
      fread( b, 1, len, rng._hdev );
#elif _WIN32
      CryptGenRandom( rng._hdev, len, (BYTE*)b );
#endif
    }
  }

#ifdef __linux__
  FILE* _hdev;
#elif _WIN32
  HCRYPTPROV _hdev;
#endif
  char * _pbuf, * _pebuf;
  char _buffer[RNG_BUFFER_LENGTH];
};

#endif // _RNG_H_

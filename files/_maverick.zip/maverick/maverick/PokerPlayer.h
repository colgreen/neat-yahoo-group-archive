#ifndef __PLAYER_H__
#define __PLAYER_H__

#include "Individual.h"

#include "Deck.h"

///////////////////////////////////////////////////////////////////////////////
class Player : public Individual
{
  public:
    Player(){};
    ~Player(){};

    ///////////////////////////////////////////////////////////////////////////
    void SetRank(unsigned long inRank)
    {
      SetFitness( inRank );
    };

    ///////////////////////////////////////////////////////////////////////////
    unsigned long Rank() const
    {
      return (unsigned long)Fitness();
    }

    void Deal( card a, card b )
    {
      _cardA = a;
      _cardB = b;
    }
    
    card CardA()
    {
      return _cardA;
    }
    
    card CardB()
    {
      return _cardB;
    }

    void SetChips( unsigned int chips )
    {
      _chips = chips;
    }

    // we'll probably use the error return to cause the player to lose
    // for the "bad behavior" of betting more than it has.
    bool TakeChips( unsigned int chips )
    {
      if(chips<_chips)
        return false;
      _chips-=chips;
      return true;
    }
    
    void GiveChips( unsigned int chips )
    {
      _chips+=chips;
    }
    
    bool IsIn() const
    {
      return (_chips) && IsAlive();
    }

  private:
    card _cardA, _cardB;
    unsigned int _chips;
};

#endif // __PLAYER_H__


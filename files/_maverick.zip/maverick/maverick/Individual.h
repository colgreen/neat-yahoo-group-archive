/***************************************************************************
 *   Copyright (C) 2005 by jeff                                            *
 *   jeff@deardorff.com                                                    *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef _INDIVIDUAL_H_
#define _INDIVIDUAL_H_

#include "Network.h"

extern long gUidCounter;

/**
 * This class defines the fundamental unit of the evolutionary simulation.
 * This interface can be thought of as serving two primary purposes.  Process,
 * Reset, and SetFitness are used to evaluate the network.  Mutate, Crossover,
 * Fitness, and Distance are used by the EA to process future generations.
 */
class Individual
{
public:
  Individual() :
    _uid( gUidCounter++ ), _pNetwork( new Network ), _bAlive(true),
  _fitness(0), _species(0), _generationalAge(0) {}

  Individual( Network * network ) :
      _uid( gUidCounter++ ), _pNetwork( network ), _bAlive(true),
  _fitness(0), _species(0), _generationalAge(0) {}

  Individual( const Individual & i ) :
      _uid( i._uid ), _bAlive(true), _fitness(0), _species(0), _generationalAge(0)
  {
    _pNetwork = new Network( i._pNetwork );
  }

  virtual ~Individual()
  {
    delete _pNetwork;
  }

  /**************************************************************************
  * Evaluation Interface
  ***************************************************************************/
  void Process( PBSink * inputs, PBSource * outputs )
  {
    _pNetwork->SetInput( inputs );
    _pNetwork->Result( outputs );
  }

  void Reset()
  {
    ResetNetwork();
    ResetFitness();
  }

  void ResetNetwork()
  {
    _pNetwork->Reset();
  }

  void ResetFitness()
  {
    _bAlive = true;
    _fitness = 0;
  }

  void SetFitness( float f )
  {
    _fitness = f;
  }

  void AddFitness( float f )
  {
    _fitness+=f;
  }

  void Kill()
  {
    _bAlive = false;
  }

  /**************************************************************************
  * Evolutionary Interface
  ***************************************************************************/
  void Mutate()
  {
    _pNetwork->Mutate();
  }

  virtual Individual * MutateNew()
  {
    Network * mutatedNetwork = new Network( _pNetwork );
    mutatedNetwork->Mutate();
    return new Individual( mutatedNetwork );
  }

  virtual Individual * Crossover( const Individual & mate ) const
  {
    if(&mate == this)
      return new Individual( *this );
    return new Individual( _pNetwork->Crossover( mate._pNetwork ) );
  }

  bool IsAlive() const
  {
    return _bAlive;
  }

  float Fitness() const
  {
    return _fitness;
  }

  void SetSpecies( unsigned long species )
  {
    _species = species;
  }
  
  unsigned long Species()
  {
    return _species;
  }
  
  long Uid() const
  {
    return _uid;
  }
  
  void Print( const char * path, const char * label = 0 )
  {
    _pNetwork->WriteGraph( path, label );
  }
  
  void Print()
  {
    _pNetwork->Print();
  }
  
  /**
   * Get species distance for this individual.
   * @param i comparative individual
   * @return distance
   */
  float Distance( const Individual * i ) const
  {
    if( i == this ) return 0;
    return _pNetwork->Distance( i->_pNetwork );
  }

  float Complexity() const
  {
    // There's probably a better metric for this but for now...
    return _pNetwork->Complexity();
  }

protected:

  unsigned long _uid;
  Network *     _pNetwork;
  bool          _bAlive;
  float         _fitness;
  unsigned long _species;
  unsigned long _generationalAge;
};


#endif // _INDIVIDUAL_H_

/***************************************************************************
 *   Copyright (C) 2005 by jeff   *
 *   jeff@deardorff.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "Tournament.h"
#include "Population.h"
#include "Player.h"
#include "Game.h"
//#include "xor.h"
//#include "Tournament.h"
#include "Symmetry.h"
#include <iostream>
#include "types.h"

#define PLAYERS 200

long gUidCounter = 0;

using namespace std;

int main(int argc, char *argv[])
{
  //Network n;
  
  Math::Singleton();
 
  Population<Player> pop(PLAYERS);
  //Population<Individual> pop(PLAYERS);
  
  SETournament<TicTacToe> tourney(&pop);
  
  tourney.Play();
  
  /*
  Player p1;
  Player p2;
  TicTacToe game;
  game.AddPlayer( &p1 );
  game.AddPlayer( &p2 );
  game.Evaluate();
  */
  
  
  //Symmetry<Player> x;
  /*
  Symmetry<Individual> x;
  
  for(int i=0;i<10000;i++)
  {
    x.Evaluate( &pop );
    pop.Reproduce();
  }
  */
  
  return EXIT_SUCCESS;
}

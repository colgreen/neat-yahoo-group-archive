/***************************************************************************
 *   Copyright (C) 2005 by jeff   *
 *   jeff@deardorff.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __TOURNAMENT_H__
#define __TOURNAMENT_H__

#include "Population.h"
#include "Game.h"
#include <math.h>

#ifdef _WIN32
#include <complex>
#endif

template <class GameType>
class Tournament
{
public:
  Tournament( Population<Player> * p ) : m_population(p)
  {
    m_population->Randomize();
  }

  virtual void Play() {}

protected:

  GameType & game()
  {
    return m_game;
  }

  Population<Player> * population() const
  {
    return m_population;
  }

  GameType m_game;
  Population<Player> * m_population;
};

/* NOTE: the name of this class does not directly imply that the
type of game being played is poker (although I suppose it strongly
implies it).  Poker simply has it's own style of tournament rules, 
distinguishing it from most other styles of tournament.  So here, 
"poker" is simply specifying a set of rules at the tournament level.
*/
template <class GameType>
class PokerTournament : public Tournament< GameType >
{
public:
  PokerTournament( Population<Player> * p ) :
  Tournament<GameType>(p) {}

  void Play()
  {
  }
};

// Single elimination
template <class GameType>
class SETournament : public Tournament< GameType >
{
public:
  SETournament( Population<Player> * pop ) :
      Tournament<GameType>(pop)
  {
    //TODO how to enforce well-sized population?
    float p = log((float)(population()->Size()));
    float q = log((float)2);
    m_tiers = (int)(p/q);
  }

  void Play()
  { 
    unsigned int tierPlayers;
    population()->Reset();
    
    for(int tier=0;tier<m_tiers;tier++)
    {
      cout << "tier " << tier << endl;
      game().Clear();
      tierPlayers = population()->Size()/(tier+1);
      for(unsigned int i=0;i<tierPlayers;i++)
      {
        /* collect players in pairs of two from
           current tier
        */
        if(population()->At(i)->MaxRound()==tier)
        {
          game().AddPlayer( population()->At(i) );
        }
        
        if(game().Ready())
        {
          game().Evaluate();
          game().Clear();
        }
      }
    }
  }

protected:
  int m_tiers;
};



#endif // __TOURNAMENT_H__

/***************************************************************************
 *   Copyright (C) 2005 by jeff   *
 *   jeff@deardorff.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __XOR_H__
#define __XOR_H__

#include "Problem.h"
#include "NodeFactory.h"


#define XOR_BIAS 0

template <class IndividualType>
class Xor : public Problem<IndividualType>
{
public:
  Xor() {}

  void Evaluate( Population<IndividualType> * p )
  {
    float fit, d;
    // the first is a bias node
    PBSink input[4][INPUT_COUNT] = { 
      XOR_BIAS, 0, 0, 
      XOR_BIAS, 0, 1, 
      XOR_BIAS, 1, 0, 
      XOR_BIAS, 1, 1 };
      
    PBSource result[4][OUTPUT_COUNT];
    PBSource correct[4][OUTPUT_COUNT] = { 0, 1, 1, 0 };

    for(int i=0;i<p->Size();i++)
    {
      for(int j=0;j<4;j++)
      {
        (p->GetIndividual(i))->Reset();
        (p->GetIndividual(i))->Process( input[j], result[j] );
      }
      fit = 0;
      for(int j=0;j<4;j++)
      {
        fit += ABS(correct[j][0]-result[j][0]);
      }
      (p->GetIndividual(i))->SetFitness((4-fit)*(4-fit));
    }
  }
};

#endif // __XOR_H__

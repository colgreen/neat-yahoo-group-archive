#ifndef __QGRAPH_H__
#define __QGRAPH_H__

#include "Node.h"

class QNode : public QWidget
{
public:
  QNode();
  ~QNode();

protected:
  void paintEvent( QPaintEvent * );
};

class QGraph
{

};

#endif

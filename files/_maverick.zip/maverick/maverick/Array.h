#ifndef _ARRAY_H_
#define _ARRAY_H_

//#include "Individual.h"

//
// This management would be easier with a smart pointer/ref counting
// class
// 

///////////////////////////////////////////////////////////////////////////////
template<class T>
class DefaultCompare;

///////////////////////////////////////////////////////////////////////////////
template<class T>
class DefaultDealloc;

///////////////////////////////////////////////////////////////////////////////
template<class T>
class HeapDealloc;

///////////////////////////////////////////////////////////////////////////////
template<class IndividualType>
class DefaultIndividualCompare;

///////////////////////////////////////////////////////////////////////////////
//template<class T, class Compare = DefaultCompare<T>, class Dealloc = DefaultDealloc<T> >
template<class T, class Compare = DefaultIndividualCompare<T>, class Dealloc = HeapDealloc<T> >
class IndividualPointerArray
{
public:

  ///////////////////////////////////////////////////////////////////////////////
  IndividualPointerArray(unsigned long inSize)
  {
    _array = new T*[inSize];
    _ulSize = inSize;
  }

  ///////////////////////////////////////////////////////////////////////////////
  ~IndividualPointerArray()
  {
    for( unsigned int i = 0; i < _ulSize; i++ )
      Dealloc::Destroy(_array[i]);

    delete [] _array;
  }

  ///////////////////////////////////////////////////////////////////////////////
  const T* & operator[](unsigned long inIndex) const
  {
    return _array[inIndex];
  }

  ///////////////////////////////////////////////////////////////////////////////
  T* & operator[](unsigned long inIndex)
  {
    return _array[inIndex];
  }

  ///////////////////////////////////////////////////////////////////////////////
  unsigned long Size() const
  {
    return _ulSize;
  }

  ///////////////////////////////////////////////////////////////////////////////
  void Swap( IndividualPointerArray<T> & inArray )
  {
    T ** pTempArray = _array;
    unsigned long ulTempSize = _ulSize;

    _array=inArray._array;
    inArray._array = pTempArray;

    _ulSize = inArray._ulSize;
    inArray._ulSize = ulTempSize;
  }

  ///////////////////////////////////////////////////////////////////////////////
  // Sort the array based on the Compare template using the quick
  // sort algorithm.
  ///////////////////////////////////////////////////////////////////////////////
  void QuickSort()
  {
    _QuickSort(0, _ulSize - 1);
  }


private:

  ///////////////////////////////////////////////////////////////////////////////
  // Helper recursive function for the quick sort implementation
  // 
  // Use inLeftIndex as pivot
  ///////////////////////////////////////////////////////////////////////////////
  void _QuickSort(unsigned long inLeftIndex, unsigned long inRightIndex)
  {
    unsigned long inLeftOriginal, inRightOriginal;
    inLeftOriginal = inLeftIndex;
    inRightOriginal = inRightIndex;
    T* ulPivot = _array[inLeftIndex];

    while( inLeftIndex < inRightIndex )
    {
      // Move past all numbers on right larger than pivot
      //	while((_array[inRightIndex] >= ulPivot ) && (inLeftIndex < inRightIndex))
      while( !Compare::LessThan(_array[inRightIndex], ulPivot) && (inLeftIndex < inRightIndex))
        inRightIndex--;

      // Move number smaller than pivot to left
      if( inLeftIndex != inRightIndex )
      {
        _array[inLeftIndex] = _array[inRightIndex];
        inLeftIndex++;
      }

      // Move past all numbers on left larger than pivot
      //	while (( _array[inLeftIndex] <= ulPivot) && (inLeftIndex < inRightIndex))
      while ( !Compare::LessThan( ulPivot, _array[inLeftIndex] ) && (inLeftIndex < inRightIndex))
        inLeftIndex++;

      // Move number bigger than pivot to right
      if( inLeftIndex != inRightIndex )
      {
        _array[inRightIndex] = _array[inLeftIndex];
        inRightIndex--;
      }

      _array[inLeftIndex] = ulPivot;

      // Recursively call on sub-arrays
      if( inLeftOriginal < inLeftIndex )
        _QuickSort( inLeftOriginal, inLeftIndex-1);
      if( inRightOriginal > inRightIndex )
        _QuickSort( inLeftIndex+1, inRightOriginal);
    }

  }

  T ** _array;
  unsigned long _ulSize;
};


///////////////////////////////////////////////////////////////////////////////
template<class T>
class DefaultCompare
{
public:
  static bool LessThan(T a, T b)
  {
    return a<b;
  }
};

///////////////////////////////////////////////////////////////////////////////
template<class T>
class DefaultDealloc
{
public:
  static void Destroy(T & inoutItem)
  {
    // Deallocation will happen automatically
  }
};

///////////////////////////////////////////////////////////////////////////////
template<class T>
class HeapDealloc
{
public:
  static void Destroy(T* & pInoutItem)
  {
    if( pInoutItem ) delete pInoutItem;
    pInoutItem = 0;
  }
};

///////////////////////////////////////////////////////////////////////////////
template <class IndividualType>
class DefaultIndividualCompare
{
public:
  static bool LessThan(IndividualType * a, IndividualType * b)
  {
    return a->Fitness() > b->Fitness();
  }
};

#endif


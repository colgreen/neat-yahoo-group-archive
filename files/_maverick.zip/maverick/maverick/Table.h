/***************************************************************************
 *   Copyright (C) 2005 by Jeff   *
 *   jeff@deardorff.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __TABLE_H__
#define __TABLE_H__

#include "Tournament.h"
#include "Player.h"
#include "Deck.h"
#include "Ring.h"
#include <list>

typedef std::list<Player*> PlayerPointerList;
typedef PlayerPointerList::iterator PlayerPointerListIter;

class Table
{
  enum eState { PREFLOP=0, FLOP, TURN, RIVER, GAME };

public:
  Table( Tournament * tourney = 0 ) : _tourney( tourney ), _dealer( 0 ) {}

  void Assign( Player * p )
  {
    _players.push_front( p );
    if(_dealer==0)
      _dealer = _players.begin();
  }
  
  unsigned int InCount()
  {
    unsigned int count;
    PlayerPointerListIter it;
    for(it=_players.begin();it!=_players.end();it++)
      if((*it)->IsIn())
        count++;
    return count;
  }
  
  Player * RemoveRandom()
  {
    unsigned int i, pos = RNG::RandInt( _players.size() );
    PlayerPointerListIter it = _players.begin();
    for(i=0;i<pos;i++)
      it++;
    return *(_players.erase( it ));
  }
  
  unsigned int SmallBlind()
  {
    return _tourney->SmallBlind();
  }
  
  unsigned int  BigBlind()
  {
    return _tourney->BigBlind();
  }
  
  
  void Play();

private:
  void _dealAll();
  Player * _winner();

private:
  Tournament * _tourney;
  unsigned int _state;
  
  Ring<Player*> _playerz;
  
  PlayerPointerList _players;
  PlayerPointerListIter _dealer;
  CDeck _deck;
  card _flop1, _flop2, _flop3, _turn, _river;
};

#endif // __TABLE_H__

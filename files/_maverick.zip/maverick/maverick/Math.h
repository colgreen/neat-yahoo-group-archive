#ifndef __MATH_H_
#define __MATH_H

#include <limits.h>
#include "types.h"

#define MAX(x,y) (((x) > (y)) ? (x) : (y))
#define MIN(x,y) (((x) < (y)) ? (x) : (y))
#define ABS(a)   (((a) < 0) ? -(a) : (a))

static const int f_Table_Length = 2048;

static const PBWeight Weight_Max = 5.0f;
static const PBWeight Weight_Min = -5.0f;

static const PBSource Sigmoid_Y_Unit_P = 1.0f;
static const PBSource Sigmoid_Y_Unit_N = -Sigmoid_Y_Unit_P;

static const PBSink   Sigmoid_X_Max = Sigmoid_Y_Unit_P * Weight_Max;
static const PBSink   Sigmoid_X_Min = Sigmoid_Y_Unit_P * Weight_Min;

static const float Sigmoid_Steepness = 4.9f;

class Math
{
private:
  Math();

public:
  static Math & Singleton()
  {
    static Math m;
    return m;
  }

  virtual ~Math();

  static PBSource Transfer( PBSink x )
  {
    int ixd;
    PBSource xd;
    static Math m;

    if (x == 0) return 0;

    if (x > 0)
    {
      if (x > Sigmoid_X_Max)
      {
        // this is technically wrong, but it's fast!
        return Sigmoid_Y_Unit_P;
      }

      xd = x * m.f_factor;
      ixd = (int)xd;

      if (ixd >= (f_Table_Length - 1))
        return m.f_f[f_Table_Length - 1];
      return m.f_f[ixd] + m.f_d[ixd] * (xd - ixd);
    }
    else
    {
      if (x < Sigmoid_X_Min)
      {
        // this is technically wrong, but it's fast!
        return Sigmoid_Y_Unit_N;
      }

      xd = -x * m.f_factor;
      ixd = (int)xd;

      if (ixd >= (f_Table_Length - 1))
        return Sigmoid_Y_Unit_P - m.f_f[f_Table_Length - 1];
      return Sigmoid_Y_Unit_P - (m.f_f[ixd] + m.f_d[ixd] * (xd - ixd));
    }
  }

private:
  PBSource f_factor;
  PBSource f_f[f_Table_Length];
  PBSource f_d[f_Table_Length];
};

#endif /*_MATH_H_*/

#ifndef __PLAYER_H__
#define __PLAYER_H__

#include "Individual.h"

///////////////////////////////////////////////////////////////////////////////
class Player : public Individual
{
public:
  Player() : 
     m_iMaxRound( 0 ) {};

  Player( Network * network ) : Individual( network ),
     m_iMaxRound( 0 ) {};

  Player( const Player & p ) : Individual( p ),
     m_iMaxRound( 0 ) {};

  virtual ~Player()
  {
  }

  void Advance()
  {
    m_iMaxRound++;
  }
  
  int MaxRound() const
  {
    return m_iMaxRound;
  }

  void Reset()
  {
    m_iMaxRound = 0;
    Individual::Reset();
  }

  virtual Player * MutateNew()
  {
    Network * mutatedNetwork = new Network( _pNetwork );
    mutatedNetwork->Mutate();
    return new Player( mutatedNetwork );
  }

  virtual Player * Crossover( const Player & mate ) const
  {
    if(&mate == this)
      return new Player( *this );
    return new Player( _pNetwork->Crossover( mate._pNetwork ) );
  }

protected:
  int m_iMaxRound;
};

#endif // __PLAYER_H__


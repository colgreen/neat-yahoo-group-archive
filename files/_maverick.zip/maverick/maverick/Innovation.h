#ifndef _INNOVATION_H_
#define _INNOVATION_H_

#include "types.h"
#include "RNG.h"
#include <vector>
#include <iostream>

using namespace std;

#define MAX_INNOVATIONS 1000
#define P_PERTURBATION 0.9

class Node;

/**
 * This class defines an innovation.  An innovation is essentially equivalent
 * to a connection in the network.  It has an id which it shares with any
 * other identical innovations that are created during the same generation as
 * it is.  An innovation is either enabled or disabled at any given time.  It
 * will supply a non-zero signal iff it is enabled and the product of its
 * weight and source signal are non-zero.
 */
class Innovation
{
public:
  Innovation( unsigned long id, Node * parent, Node * child, PBWeight weight, bool enabled = true ) :
      next(0),
      _id(id),
      _pParent( parent ),
      _pChild( child ),
      _weight( weight ),
      _bEnabled( enabled )
  {}

  Innovation( unsigned long id, Node * parent, Node * child ) :
      next(0),
      _id(id),
      _pParent( parent ),
      _pChild( child ),
      _weight( RNG::RandWeight() ),
      _bEnabled( true )
  {}

  /**
   * Evaluate the innovation
   * @return The resultant signal,  Zero if disabled.
   */
  PBSink Result() const;

  /**
   * Randomly change the innovation weight.  Also, make sure the 
   * innovation is enabled.
   */
  void Mutate()
  {
    if(RNG::CoinToss( (float)P_PERTURBATION ) && 
       _weight < Weight_Max && 
       _weight > Weight_Min )
    {
      _weight += RNG::RandFlt( -0.05F, 0.05F );
    }
    else
    {
      _weight = RNG::RandWeight();
    }
    _bEnabled = true;
  }
  
  /**
   * Return generation-unique identifier for this innovation
   * @return 
   */
  unsigned long Id() const
  {
    return _id;
  }

  /**
   * Return path weight of this innovation
   * @return 
   */
  PBWeight Weight() const
  {
    return _weight;
  }

  /**
   * Return pointer to upstream node of this innovation
   * @return 
   */
  Node * Parent() const
  {
    return _pParent;
  }
  
  /**
   * Return pointer to downstream node of this innovation.
   * @return 
   */
  Node * Child() const
  {
    return _pChild;
  }

  /**
   * Set this innovation enabled or disabled
   * @param enabled true if innovation is to be enabled
   */
  void SetEnabled( bool enabled )
  {
    _bEnabled = enabled;
  }
  
  /**
   * Call to determine if this innovation is enabled or not
   * @return true if enabled
   */
  bool IsEnabled() const
  {
    return _bEnabled;
  }

  Innovation * next;          ///< pointer to next Innovation in a list

private:
  unsigned long _id;          ///< global unique node id
  Node *        _pParent;     ///< signal-supplying parent
  Node *        _pChild;      ///< target node (only used for reproduction/copy)
  PBWeight      _weight;      ///< connection weight
  bool          _bEnabled;    ///< connection enabled/disabled
};

typedef std::vector<Innovation*> InnovationVector;
typedef InnovationVector::iterator InnovationVectorIt;
typedef InnovationVector::const_iterator InnovationVectorConstIt;

#endif /*_INNOVATION_H_*/

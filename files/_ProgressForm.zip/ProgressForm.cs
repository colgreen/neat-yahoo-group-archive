using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using SharpNeatLib.Evolution;
using ZedGraph;

namespace SharpNeat
{
	public partial class ProgressForm : Form
	{
		/// <summary>
		/// Replacement for original RudyGraph-based progress display. Changes:
		/// * Now uses ZedGraph (personal whim)
		/// * Form uses Splitter controls to make sizing a little more flexible
		/// * Complexity, species and compat. threshold get their own graphs
		/// * Added graph of evals per second
		/// 
		/// Areas for consideration
		/// * More graphs! Possibilities:
		///		* Steps to converge (for multi-step "relaxing" networks)
		///		* Species size stacked chart
		///		* cool stuff as in NEVT
		/// * More configurability (for practice in form development within C# in, if nothing else)
		/// 
		/// To-Dos
		/// * Tidy up: there's a fair bit of repeated code that could stand to be refactored. The
		///		line graphs and their logic are all very similar and could be folded into something
		///		that would thin down this code considerably. A Friday afternoon job.
		/// </summary>
		GraphPane fitnessPane;
		GraphPane complexityPane;
		GraphPane speciesPane;
		GraphPane compatPane;
		GraphPane evalsPane;

		PointPairList bestFitness = new PointPairList();
		PointPairList meanFitness = new PointPairList();
		PointPairList complexity = new PointPairList();
		PointPairList species = new PointPairList();
		PointPairList compatThreshold = new PointPairList();
		PointPairList evals = new PointPairList();

		ulong lastUpdateEvaluationCount;
		long lastUpdateDateTimeTick;

		public ProgressForm()
		{
			InitializeComponent();

			fitnessPane = fitnessGraph.GraphPane;

			fitnessPane.Title = "Fitness";
			fitnessPane.XAxis.Title = "Generation";
			fitnessPane.YAxis.Title = "Score";
			fitnessPane.XAxis.IsShowGrid = true;
			fitnessPane.YAxis.IsShowGrid = true;

			LineItem bestFitnessCurve = fitnessPane.AddCurve("Best", bestFitness, Color.Red, SymbolType.None);
			LineItem meanFitnessCurve = fitnessPane.AddCurve("Mean", meanFitness, Color.Teal, SymbolType.None);

			complexityPane = complexityGraph.GraphPane;
			complexityPane.Title = "Complexity";
			complexityPane.XAxis.Title = "Generation";
			complexityPane.YAxis.Title = "Value";
			complexityPane.XAxis.IsShowGrid = true;
			complexityPane.YAxis.IsShowGrid = true;

			LineItem complexityCurve = complexityPane.AddCurve("", complexity, Color.Green, SymbolType.None);

			speciesPane = speciesGraph.GraphPane;
			speciesPane.Title = "Species";
			speciesPane.XAxis.Title = "Generation";
			speciesPane.YAxis.Title = "Species";
			speciesPane.YAxis.IsShowGrid = true;
			speciesPane.XAxis.IsShowGrid = true;

			LineItem speciesCurve = speciesPane.AddCurve("# species", species, Color.Red, SymbolType.None);

			compatPane = compatGraph.GraphPane;
			compatPane.Title = "Compatibility Threshold";
			compatPane.XAxis.Title = "Generation";
			compatPane.YAxis.Title = "Threshold Value";
			compatPane.YAxis.IsShowGrid = true;
			compatPane.XAxis.IsShowGrid = true;
			
			LineItem compatCurve = compatPane.AddCurve("Threshold", compatThreshold, Color.Green, SymbolType.None);

			evalsPane = evalsPerSecGraph.GraphPane;
			evalsPane.Title = "Evals Per Second";
			evalsPane.XAxis.Title = "Generation";
			evalsPane.YAxis.Title = "Evals";
			evalsPane.YAxis.IsShowGrid = true;
			evalsPane.XAxis.IsShowGrid = true;

			LineItem evalsCurve = evalsPane.AddCurve("Evals", evals, Color.Black, SymbolType.None);
		}

		public void Update(EvolutionAlgorithm ea)
		{
			Population p = ea.Population;

			bestFitness.Add(bestFitness.Count, ea.BestGenome.Fitness);
			meanFitness.Add(meanFitness.Count, p.MeanFitness);
			complexity.Add(complexity.Count, p.AvgComplexity);
			species.Add(species.Count, p.SpeciesTable.Count);
			compatThreshold.Add(compatThreshold.Count, ea.NeatParameters.compatibilityThreshold);

			long ticksNow = DateTime.Now.Ticks;
			long tickDelta = ticksNow - lastUpdateDateTimeTick;
			lastUpdateDateTimeTick = ticksNow;
			double evaluationsDelta = ea.PopulationEvaluator.EvaluationCount - lastUpdateEvaluationCount;
			lastUpdateEvaluationCount = ea.PopulationEvaluator.EvaluationCount;
			double evaluationsPerSec = evaluationsDelta / (double)tickDelta * 10000000.0;

			evals.Add(evals.Count, evaluationsPerSec);

			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			fitnessGraph.AxisChange();
			fitnessGraph.Invalidate();
			complexityGraph.AxisChange();
			complexityGraph.Invalidate();
			speciesGraph.AxisChange();
			speciesGraph.Invalidate();
			compatGraph.AxisChange();
			compatGraph.Invalidate();
			evalsPerSecGraph.AxisChange();
			evalsPerSecGraph.Invalidate();
		}

		private void ProgressForm_Paint(object sender, PaintEventArgs e)
		{
			UpdateDisplay();
		}

		private void ProgressForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			e.Cancel = true;
			this.Visible = false;
		}
	}
}
//==============================================================================
// File: CommonConstants.h
//
// (c) Copyright 2006 Ryan Capital Limited
//
//==============================================================================
//
// $Revision$
// $Date$
//
//==============================================================================
#ifndef RC_COMMON_CONSTANTS_H
#define	RC_COMMON_CONSTANTS_H

#include <iostream>
//#include "types/types.h"

using namespace std;
namespace RC{

		//void InitEnumLookup();
		//void DestroyEnumLookup();
		
		typedef unsigned int QTY;
		typedef double PRICE;

		#define ENUM(x) x

		const char CLEAR_FIELD_CHAR = (const char)255;
		const int CLEAR_FIELD_AMOUNT = 0xfffffff; // Number used to signify a numerical field with a value of DB NULL, i.e. no value
		const string CLEAR_FIELD_STRING = "CLEAR_FIELD_STRING";	// String used to signify a field with a value of DB NULL, i.e. no value
		const unsigned short CLEAR_FIELD_SHORT = 0xffff;

		bool isClear(const double aValue);
		bool isClear(const float aValue);
		bool isClear(const int aValue);
		bool isClear(const unsigned int aValue);
		bool isClear(const string& aValue);
		bool isClear(const char aValue);
		bool isClear(const unsigned short aValue);

		// identifies whether an account belongs to a company or trader.
		#define ACCOUNT_TYPE_LIST \
			ENUM( ACCOUNT_COMPANY ),\
			ENUM( ACCOUNT_TRADER ),\
			ENUM( NUM_ACCOUNT_TYPES ),\
			ENUM( ACCOUNT_CLEAR_FIELD = CLEAR_FIELD_AMOUNT )
		enum eAccountType{ ACCOUNT_TYPE_LIST };

		#define CONTRACT_TYPE_LIST \
			ENUM( CONTRACT_TYPE_OUTRIGHT ),\
			ENUM( CONTRACT_TYPE_QUARTERLY_SPREAD ),\
			ENUM( CONTRACT_TYPE_KIPPER_SPREAD ),\
			ENUM( CONTRACT_TYPE_NINE_MONTH_SPREAD ),\
			ENUM( CONTRACT_TYPE_CALENDAR_SPREAD ),\
			ENUM( CONTRACT_TYPE_FIFTEEN_MONTH_SPREAD ),\
			ENUM( CONTRACT_TYPE_EIGHTEEN_MONTH_SPREAD ),\
			ENUM( CONTRACT_TYPE_TWENTY_ONE_MONTH_SPREAD ),\
			ENUM( CONTRACT_TYPE_TWENTY_FOUR_MONTH_SPREAD ),\
			ENUM( CONTRACT_TYPE_BUTTERFLY ),\
			ENUM( CONTRACT_TYPE_NUM_CONTRACT_TYPES ),\
			ENUM( CONTRACT_TYPE_CLEAR_FIELD = CLEAR_FIELD_AMOUNT)

		//enum eContractType{ CONTRACT_TYPE_LIST };
}
#endif



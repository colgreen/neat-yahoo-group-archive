/* Singleton.h
 *
 * Shane Ryan
 *
 * (c) Copyright 2006 Ryan Capital Limited
 *
 */

#ifndef INCLUDE_GUARD_Singleton_h
#define INCLUDE_GUARD_Singleton_h

#include <string>

namespace RC {
namespace Util {

template<class T>
class HeapCreate
{
public:
	static T *Create( T *instance ) 
	{
		if( !instance )
		{
			return new T;
		}
		else
		{
			return instance;
		}
	}
};

template<class T>
class ExplicitHeapCreate : public HeapCreate<T>
{
public:
	static void CheckExistance( T *instance ) { assert( instance ); }
};

template<class T>
class AutoHeapCreate : public HeapCreate<T>
{
public:
	static void CheckExistance( T * &instance ) { if( !instance) instance = Create( instance ); }
};


template 
<
	class T, 
	template <class> class CreationPolicy = ExplicitHeapCreate
> 
class Singleton
{
public:
	~Singleton();

	static T& instance();
	static T* instancePtr();

	static void create();
	static void destroy();

protected:
	Singleton();

private:

	static T *iSingleton;
};

template <class T, template <class> class CreationPolicy>
T *Singleton<T, CreationPolicy>::iSingleton = NULL;

template <class T, template <class> class CreationPolicy>
Singleton<T, CreationPolicy>::Singleton( void )
{
	assert( !iSingleton && "singleton already created!" );
	if( iSingleton!=NULL )
	{
		const std::string tExceptionString = "Singleton already created.";
	}

	size_t offset = reinterpret_cast<size_t>(reinterpret_cast<T*>(1)) -
		reinterpret_cast<size_t>(static_cast<Singleton <T, CreationPolicy>*>(reinterpret_cast<T*>(1)));

	iSingleton = reinterpret_cast<T*>((reinterpret_cast<size_t>(this) + offset));
}

template <class T, template <class> class CreationPolicy>
Singleton<T, CreationPolicy>::~Singleton()
{
	iSingleton = NULL;
}

template <class T, template <class> class CreationPolicy>
T& Singleton<T, CreationPolicy>::instance()
{
	CreationPolicy<T>::CheckExistance( iSingleton );
	return ( *iSingleton );
}

template <class T, template <class> class CreationPolicy>
T* Singleton<T, CreationPolicy>::instancePtr( void )
{
	return ( iSingleton );
}

#pragma warning(push)
#pragma warning(disable: 4291)	// no matching operator delete found

template <class T, template <class> class CreationPolicy>
void Singleton<T, CreationPolicy>::create()
{
	iSingleton = CreationPolicy<T>::Create( iSingleton );
}

#pragma warning(pop)

template <class T, template <class> class CreationPolicy>
void Singleton<T, CreationPolicy>::destroy()
{
	delete iSingleton;
	iSingleton = NULL;
}


} // namespace Util
} // namespace RC

#endif // INCLUDE_GUARD_Singleton_h

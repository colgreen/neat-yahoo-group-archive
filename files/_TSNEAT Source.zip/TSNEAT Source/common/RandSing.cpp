#include "RandSing.h"
#include <iostream>

TRanrotBGenerator* RandSing::gRD = NULL;
uint32 RandSing::gSeed = 0;

RandSing::RandSing()
{
	//If no seed has been specified the choose a random one
	if(gSeed == 0)
		initRandomSeed();
	gRD = new TRanrotBGenerator(gSeed);
}

RandSing::~RandSing()
{
	if(gRD)
		delete gRD;
	gRD = NULL;
}


RandSing& RandSing::Instance()
{
	static RandSing sRandSing;
	return sRandSing;
}


int RandSing::randInt(const int x, const int y)
{
	assert(x <= y);
	return gRD->IRandom(x,y);
}

double RandSing::randFloat()
{
	return gRD->Random();
}

bool RandSing::randBool()
{
	if (randInt(0,1))
		return true;
	else
		return false;
}


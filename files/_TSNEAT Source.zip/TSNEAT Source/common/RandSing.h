#ifndef RC_RANDSING_H
#define RC_RANDSING_H

//------------------------------------------------------------------------
//
//	Name: RandomSingleton
//
//  Author: Shane Ryan
//
//  Desc: Random number generator singleton
//
//------------------------------------------------------------------------
#include <time.h>
#include "randomc.h"

class RandSing
{

private:
	static TRanrotBGenerator* gRD;
	static uint32 gSeed;

	RandSing();
	~RandSing();
	RandSing(RandSing const&);      // copy ctor is hidden
 	 RandSing& operator=(RandSing const&);  // assign op is hidden
	

public:
	
	static void setSeed(const uint32 aSeed)
	{ 	
		assert(!gRD && "No point setting seed after singleton constructor called");
		gSeed = aSeed;
	}
	static uint32 getSeed() { return gSeed;}
	static void initRandomSeed() { gSeed = time(0);}
	static RandSing& Instance();
	
	int randInt(const int x, const int y);
	double randFloat();
	bool randBool();
	 
};
#endif	


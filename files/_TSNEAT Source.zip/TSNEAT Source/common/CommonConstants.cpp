#include "CommonConstants.h"

#include <map>
//#include "helpers/StringCompare.h"
//#include "types/types.h"
//#include "EnumLookup.h"
//#include "FieldToLookup.h"

namespace RC {
 
	#undef ENUM
	#define ENUM(x) #x

	// lookup objects for various enum types.
	// These should be kept static (ie. only visible in this file).
	// Use via their singleton base, eg: 
	//	EnumLookup<eCommand>::instance().getId( id )

	/*char *EnumLookup<eAccountType>::iIdentifiers[] = { ACCOUNT_TYPE_LIST };

	char *EnumLookup<eContractType>::iIdentifiers[] = { CONTRACT_TYPE_LIST };

	void InitEnumLookup()
	{
		new EnumLookup<eAccountType>( NUM_ACCOUNT_TYPES );
		new EnumLookup<eContractType>( CONTRACT_TYPE_NUM_CONTRACT_TYPES );
		//new EnumLookup<eOrderStatus>( NUM_ORDER_STATUSES );
		//new EnumLookup<eContractType>( NUM_STRATEGY_TYPES );
		//new EnumLookup<eTradingStrategy>( NUM_TRADING_STRATEGIES );

		//new FieldToLookup;
	}

	void DestroyEnumLookup()
	{
		EnumLookup<eAccountType>::destroy();
		EnumLookup<eContractType>::destroy();
		EnumLookup<eOrderStatus>::destroy();
		EnumLookup<eContractType>::destroy();
		EnumLookup<eTradingStrategy>::destroy();

		//FieldToLookup::destroy();
	}*/
	
	 bool isClear(const double aValue)
	 {
		return aValue == CLEAR_FIELD_AMOUNT;
	 }

	 bool isClear(const float aValue)
	 {
		return aValue == CLEAR_FIELD_AMOUNT;
	 }

	 bool isClear(const int aValue)
	 {
		return aValue == CLEAR_FIELD_AMOUNT;
	 }

	 bool isClear(const unsigned int aValue)	 
	 {
		return aValue == (const unsigned int)CLEAR_FIELD_AMOUNT;
	 }

	 bool isClear(const string& aValue)
	 {
		 return aValue.compare(CLEAR_FIELD_STRING) == 0;
	 }

	 bool isClear(const char aValue)
	 {
		return aValue == CLEAR_FIELD_CHAR;
	 }

	 bool isClear(const unsigned short aValue)
	 {
		return aValue == CLEAR_FIELD_SHORT;
	 }

} // namespace RC


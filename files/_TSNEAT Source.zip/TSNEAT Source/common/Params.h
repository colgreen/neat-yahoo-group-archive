#ifndef RC_PARAMS_H
#define RC_PARAMS_H

//------------------------------------------------------------------------
//
//	Name: CParams.h
//
//  Author: Mat Buckland 2002 (fup@btinternet.com)
//
//  Desc: class to hold all the parameters used in this project. The values
//        are loaded in from an ini file when an instance of the class is
//        created.
//       
//
//------------------------------------------------------------------------
#include <fstream>
#include "../common/utils.h"
#include "ConfigFile.h"

using namespace std;	


class Params
{
private:
	//Use read<T>(string key) for mandatory parameters
	//Use read(string key, <T> default_value) for optional parameters
	virtual void LoadInParameters(const ConfigFile& aConfigFile) = 0;

public:

	#define GET_PARAM(i)\
		{\
			if(!aInputFile)\
			{\
				const string tExceptionString = (string)(__FUNCTION__) + "Error retrieving parameter";\
				throw tExceptionString;\
			}\
			char burn[40];\
			aInputFile >> burn;\
			aInputFile >> i;\
		}

	//ctor
	Params(){}
	virtual ~Params() {}

	void Initialize(const string& aParamsFile)
	{
		try
		{
			ConfigFile tConfig( aParamsFile );
			LoadInParameters(tConfig);
	
		} catch(ConfigFile::file_not_found file_not_found_exception)
	
		{
			const string tExceptionMessage = (string)(__FUNCTION__) + "Cannot find '" + aParamsFile + "'";
			throw tExceptionMessage;
		} catch(ConfigFile::key_not_found key_not_found_exception)
		{
			const string tExceptionMessage = (string)(__FUNCTION__) + "Cannot find param '" + key_not_found_exception.key + "'";
			throw tExceptionMessage;
	
		}
	}
  
};

#endif


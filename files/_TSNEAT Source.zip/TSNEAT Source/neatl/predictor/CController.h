#ifndef RC_CCONTROLLER_H
#define RC_CCONTROLLER_H

//------------------------------------------------------------------------
//
//	Name: CController.h
//
//  Author: Mat Buckland 2002 (fup@btinternet.com)
//
//  Desc: Controller class for NEAT Genomes  
//
//------------------------------------------------------------------------
#include <vector>
#include <sstream>
#include <string>
#include <cfloat>

#include "Predictor.h"
#include "../common/utils.h"
#include "CParams.h"
#include "Cga.h"
#include "../core/Pattern.h"
#include "../core/PatternManager.h"

class Cga;

using namespace std;

class CController
{

private:
	//storage for the entire population of chromosomes
	Cga*	m_pPop;

	//array of predictors
	vector<Predictor> m_vecPredictors;

	//array of best predictors from last generation (used for
	//display purposes when 'B' is pressed by the user)
	vector<Predictor> m_vecBestPredictors;

	//stores the average fitness per generation 
	vector<double>			m_vecAvFitness;
	double				m_RateChangeAvFitness;

	//stores the best fitness per generation
	vector<double>			m_vecBestFitness;
	double				m_RateChangeBestFitness;

	vector<unsigned int>		m_vecNumSpecies;
	double				m_RateChangeNumSpecies;

	//Number of Patterns presented
	unsigned int			m_iPatternsPresented;
	PatternManager*			m_PatternManager;

	void updateMetrics(const Cga& aPop);

	vector<double>  getFitnessScores() const;

	void adjustMutationRate();

public:

	CController(const string& aPatternFile);
	~CController();

	void Update(bool& aDone, bool& aEpochCompleted);
	
	const double getBestFitness() const { return m_pPop->BestEverFitness();}
	const Cga* getPopulation() const;
	const vector<Predictor>& getBestPredictors() const { return m_vecPredictors;}
	const unsigned int getCurrentGeneration() const { return m_pPop->getCurrentGeneration();}
	const unsigned int getNumSpecies() const { return m_pPop->getNumSpecies();}
	const double getAverageFitness() const { return m_pPop->getAverageFitness();}
	void writeBestToDisk(const string& aFileName) const {m_pPop->writeBestToDisk(aFileName);}

	const double getRateChangeAvFitness() const { return m_RateChangeAvFitness;}
	const double getRateChangeBestFitness() const { return m_RateChangeBestFitness;}
	const double getRateChangeNumSpecies() const { return m_RateChangeNumSpecies;}

	void printPopInfo() const;
};
#endif
	



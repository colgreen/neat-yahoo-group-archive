#include "CParams.h"


int CParams::iNumInputs						= 1;
int CParams::iNumOutputs					= 1;
double CParams::dBias						= -1;
int CParams::iPopSize						= 0;
string CParams::iPatternFile;
unsigned int CParams::iNumPatterns				= 0;
double CParams::dSigmoidResponse				= 1;
int CParams::iNumAddLinkAttempts				= 0;
int CParams::iNumTrysToFindLoopedLink				= 5;
int CParams::iNumTrysToFindOldLink				= 5;
double CParams::dYoungFitnessBonus				= 0;
int CParams::iYoungBonusAgeThreshhold				= 0;
double CParams::dSurvivalRate					= 0;
int CParams::iNumGensAllowedNoImprovement			= 0;
int CParams::iMaxPermittedNeurons				= 0;
double CParams::dChanceAddLink					= 0;
double CParams::dChanceAddNode					= 0;
double CParams::dChanceAddRecurrentLink				= 0;
double CParams::dMutationRate					= 0;
double CParams::dMaxWeightPerturbation				= 0;
double CParams::dProbabilityWeightReplaced			= 0;

double CParams::dActivationMutationRate				= 0;
double CParams::dMaxActivationPerturbation			= 0;

double CParams::dCompatibilityThreshold				= 0;
unsigned int CParams::iNumBestGenomes				= 4;
int CParams::iOldAgeThreshold					= 0;
double CParams::dOldAgePenalty					= 0;
double CParams::dCrossoverRate					= 0;
unsigned int CParams::iMaxNumberOfSpecies			= 0;

float CParams::iStoppingCriteria				= (float)RC::CLEAR_FIELD_AMOUNT;
unsigned int CParams::iStoppingGeneration			= RC::CLEAR_FIELD_AMOUNT;
bool CParams::iDumpNetworkWhenDone				= false;
string CParams::sFilenameToSaveNetToo				= "BestNetwork.txt";

unsigned int CParams::iNumErrorsToDiscard			= 0;
unsigned int CParams::m_iSeedRandom 				= 0;

bool CParams::m_bPrintLogs					= 0;

string CParams::m_sProjectName					= "";

//this function loads in the parameters from a given file name. Returns
//false if there is a problem opening the file.
void CParams::LoadInParameters(const ConfigFile& aConfigFile)
{
	//load in from the file
	//Use read<T>(string key) for mandatory parameters
	//Use read(string key, <T> default_value) for optional parameters

	m_sProjectName =		aConfigFile.read<string>("m_sProjectName", ""); //Optional param
  	iNumInputs = 			aConfigFile.read<int>("iNumInputs");
	iPatternFile = 			aConfigFile.read<string>("iPatternFile");
	iNumPatterns = 			aConfigFile.read<unsigned int>("iNumPatterns");
	iStoppingCriteria = 		aConfigFile.read<float>("iStoppingCriteria");
	iStoppingGeneration = 		aConfigFile.read<unsigned int>("iStoppingGeneration");
	iDumpNetworkWhenDone = 		aConfigFile.read<bool>("iDumpNetworkWhenDone");
	iPopSize = 			aConfigFile.read<int>("iPopSize");
	iNumAddLinkAttempts = 		aConfigFile.read<int>("iNumAddLinkAttempts");
	dSurvivalRate = 		aConfigFile.read<double>("dSurvivalRate");
	iNumGensAllowedNoImprovement = 	aConfigFile.read<int>("iNumGensAllowedNoImprovement");
	iMaxPermittedNeurons = 		aConfigFile.read<int>("iMaxPermittedNeurons");
	dChanceAddLink = 		aConfigFile.read<double>("dChanceAddLink");
	dChanceAddNode = 		aConfigFile.read<double>("dChanceAddNode");
	dChanceAddRecurrentLink = 	aConfigFile.read<double>("dChanceAddRecurrentLink");
	dMutationRate = 		aConfigFile.read<double>("dMutationRate");
	dMaxWeightPerturbation = 	aConfigFile.read<double>("dMaxWeightPerturbation");
	dProbabilityWeightReplaced = 	aConfigFile.read<double>("dProbabilityWeightReplaced");
	dActivationMutationRate = 	aConfigFile.read<double>("dActivationMutationRate");
	dMaxActivationPerturbation = 	aConfigFile.read<double>("dMaxActivationPerturbation");
	dCompatibilityThreshold = 	aConfigFile.read<double>("dCompatibilityThreshold");
	iOldAgeThreshold = 		aConfigFile.read<int>("iOldAgeThreshold");
	dOldAgePenalty = 		aConfigFile.read<double>("dOldAgePenalty");
	dYoungFitnessBonus = 		aConfigFile.read<double>("dYoungFitnessBonus");
	iYoungBonusAgeThreshhold = 	aConfigFile.read<int>("iYoungBonusAgeThreshhold");
	dCrossoverRate = 		aConfigFile.read<double>("dCrossoverRate");
	iMaxNumberOfSpecies = 		aConfigFile.read<unsigned int>("iMaxNumberOfSpecies");
	iNumErrorsToDiscard = 		aConfigFile.read<unsigned int>("iNumErrorsToDiscard");
	m_iSeedRandom = 		aConfigFile.read<unsigned int>("m_iSeedRandom");
	iNumInputs = 			aConfigFile.read<int>("iNumInputs");
	m_bPrintLogs = 			aConfigFile.read<bool>("m_bPrintLogs");

}
 

  
  

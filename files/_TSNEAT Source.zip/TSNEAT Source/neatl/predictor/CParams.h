#ifndef RC_CPARAMS_H
#define RC_CPARAMS_H
//------------------------------------------------------------------------
//
//	Name: CParams.h
//
//  Author: Mat Buckland 2002 (fup@btinternet.com)
//
//  Desc: class to hold all the parameters used in this project. The values
//        are loaded in from an ini file when an instance of the class is
//        created.
//       
//
//------------------------------------------------------------------------
#include <fstream>
#include <cfloat>
#include <limits>
#include "../common/utils.h"
#include "../common/Params.h"

using namespace std;	


class CParams: public Params
{

public:

	//-------------------------------------------------------------------
	//  used to define the population size
	//-------------------------------------------------------------------
	
	static int    iPopSize;
	
	//--------------------------------------controller parameters
	
	// where to find the patterns
	static string iPatternFile;
	//number of patterns to be presented
	static unsigned int    iNumPatterns;
	
	//----------------------------------------------------------------------
	// used in phenotype.h/cpp
	//----------------------------------------------------------------------
	
	static int    iNumInputs;
	static int    iNumOutputs;
	
	//bias value
	static double dBias;
	
	//starting value for the sigmoid response
	static double dSigmoidResponse;
	
	//----------------------------------------------------------------------
	// used in genotype.h/cpp
	//----------------------------------------------------------------------
	
	//number of times we try to find 2 unlinked nodes when adding a link.
	//see CGenome::AddLink()
	static int    iNumAddLinkAttempts;
	
	//number of attempts made to choose a node that is not an input 
	//node and that does not already have a recurrently looped connection 
	//to itself. See CGenome::AddLink()
	static int    iNumTrysToFindLoopedLink;
	
	//the number of attempts made to find an old link to prevent chaining
	//in CGenome::AddNeuron
	static int    iNumTrysToFindOldLink;
	
	//the chance, each epoch, that a neuron or link will be added to the
	//genome
	static double dChanceAddLink;
	static double dChanceAddNode;
	static double dChanceAddRecurrentLink;
	
	//mutation probabilities for mutating the weights in CGenome::Mutate()
	static double dMutationRate;
	static double dMaxWeightPerturbation;
	static double dProbabilityWeightReplaced;
	
	//probabilities for mutating the activation response
	static double dActivationMutationRate;
	static double dMaxActivationPerturbation;
	
	//the smaller the number the more species will be created
	static double dCompatibilityThreshold;
	
	
	
	//----------------------------------------------------------------------
	// used in CSpecies.h/cpp
	//----------------------------------------------------------------------
	
	//during fitness adjustment this is how much the fitnesses of 
	//young species are boosted (eg 1.2 is a 20% boost)
	static double dYoungFitnessBonus;
	
	//if the species are below this age their fitnesses are boosted
	static int    iYoungBonusAgeThreshhold;
	
	//number of population to survive each epoch. (0.2 = 20%)
	static double dSurvivalRate;
	
	//if the species is above this age their fitness gets penalized
	static int    iOldAgeThreshold;
	
	//by this much
	static double dOldAgePenalty;
	
	
	
	//----------------------------------------------------------------------
	// used in Cga.h/cpp
	//----------------------------------------------------------------------
	
	//how long we allow a species to exist without any improvement
	static int    iNumGensAllowedNoImprovement;
	
	//maximum number of neurons permitted in the network
	static int    iMaxPermittedNeurons;
	
	//the number of best performing genomes
	static unsigned int    iNumBestGenomes;
	
	static double dCrossoverRate;
	
	static unsigned int    iMaxNumberOfSpecies;
	
	//Stopping criteria
	static float iStoppingCriteria;
	static unsigned int iStoppingGeneration;
	static bool iDumpNetworkWhenDone;
	static string sFilenameToSaveNetToo;
	
	//Number of Errors to discard
	//This is used when the input set is bigger than the number of patterns
	//that are presented per Epoch. Recurrent networks may expect a continuous
	//stream of inputs that are related to each other to set their internal memory
	//when the weights are randomly initialize or unrelated patterns are presented
	//this may effect the measured error
	//The point of this variable is to discard the errors caused by these calibration
	//patterns.
	static unsigned int iNumErrorsToDiscard;
	
	//Random seed to start with
	static unsigned int m_iSeedRandom;
	
	static bool m_bPrintLogs;
	
	static string m_sProjectName;
	
	
	//---------------------------------------------
	
	//ctor
	CParams(){}
	
	void LoadInParameters(const ConfigFile& aConfigFile);
};

#endif




#include "Predictor.h"

//-----------------------------------constructor-------------------------
//
//-----------------------------------------------------------------------
Predictor::Predictor(): m_dFitness(0)
{
}

//}
//-----------------------------Reset()------------------------------------
//
//	Resets the fitness
//
//------------------------------------------------------------------------
void Predictor::Reset()
{
	m_Errors.clear();
	//and the fitness
	m_dFitness = 0;
}


//-------------------------------Update()--------------------------------
//
//	First we take sensor readings and feed these into the neural net.
//
//	The inputs are:
//	
//
//-----------------------------------------------------------------------
bool Predictor::Update(const Pattern& aPattern)
{
	//this will store all the inputs for the NN
	const vector<float>& tInputs = aPattern.getInputs();
	  
	//update the brain and get feedback
	vector<float> output = m_pItsBrain->Update(tInputs, CNeuralNet::active);

	//make sure there were no errors in calculating the 
	//output
	const unsigned int tOutputSize = (const unsigned int) output.size();
	if ( tOutputSize != (const unsigned int) CParams::iNumOutputs) 
		return false;
	
	const float tOutput = output[0];
	//Calc the error
	const float tError = calcError(tOutput, aPattern.getOutput());

	////update the errors
	m_Errors.push_back(tError);
  
	return true;
}

//------------------------- EndOfRunCalculations() -----------------------
//
//------------------------------------------------------------------------
void Predictor::EndOfRunCalculations()
{
	const unsigned int tTotalNumErrors = m_Errors.size();
	assert(m_dFitness == 0);
	assert(tTotalNumErrors > CParams::iNumErrorsToDiscard);
	std::vector<float>::iterator itError;
	for(unsigned int i= 0; i < CParams::iNumErrorsToDiscard; i++)
		itError++;

	for(itError = m_Errors.begin(); itError != m_Errors.end(); itError++)
	{
		const float tError = *(itError);
		assert(tError <= 1);
		m_dFitness += tError;
	}


	const unsigned int tNumErrors = tTotalNumErrors - CParams::iNumErrorsToDiscard;

	//Sanity check since the errors are all below or equal to one
	assert(m_dFitness <= tNumErrors);
	if(tNumErrors > 0)
		m_dFitness /= tNumErrors;

	//cout << "Average Fitness: " << m_dFitness << endl;
}

const float Predictor::calcError(const float aOutput, const float aActual)
{
	assert((aOutput <= 1) && (aOutput >= 0) &&(aActual <=1) && (aActual >= 0));
	
	float tX = fabs(aActual - aOutput);
	//Prevent divide by zero
	if(aActual)
		tX /= aActual;
	assert(tX >= 0);
	//assert((tX >= -1) && (tX <= 1));
	//if( tX < 0)
	//	tX *= -1;
	//tX = sqrt(tX);
	tX = 1 - tX;
	assert(tX <= 1);
	return tX;

	//assert(aOutput <= 1 && aOutput >= -1);
	//float tDiff = (aOutput - aActual);
	//
	//const float tThreshold = (const float)0.1;
	////The value is close enough
	//if(tDiff < tThreshold && tDiff > tThreshold*(-1) )
	//	return 1;
	//
	//if(tDiff < 0)
	//	tDiff *= -1;
	////Exponentially penalize the further the value is from the ideal
	////Take the square root because squaring a number less the 1 makes it smaller
	//tDiff = sqrt(tDiff);
	//tDiff *= -1;
	//return tDiff;
}


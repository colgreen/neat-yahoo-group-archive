#include "Cga.h"
#include "../core/CInnovation.h"
#include <time.h>

//-------------------------------------------------------------------------
//	this constructor creates a base genome from supplied values and creates 
//	a population of 'size' similar (same topology, varying weights) genomes
//-------------------------------------------------------------------------
Cga::Cga(const unsigned int aSize,
        int  inputs,
        int  outputs,
	const unsigned int aNumBestGenomes,
	const unsigned int aMaxPermittedNeurons):	
			m_pInnovation(NULL),
			m_iGeneration(0),
			m_iNextGenomeID(0),
			m_iNextSpeciesID(0),
			m_iPopSize(aSize),
			m_dTotFitAdj(0),
			m_dAvFitAdj(0),
			m_iFittestGenome(0),
			m_dBestEverFitness(-DBL_MAX),
			m_dAvgFitness(0),
			m_iNumBestGenomes(aNumBestGenomes),
			m_iMaxPermittedNeurons(aMaxPermittedNeurons),
			m_fMutationRate(1)
{
	
	//create the population of genomes
	for (unsigned int i=0; i< m_iPopSize; ++i)
		m_vecGenomes.push_back(CGenome(m_iNextGenomeID++, inputs, outputs));

	assert(aNumBestGenomes <= m_iPopSize);

	//create the innovation list. First create a minimal genome
	CGenome genome(1, inputs, outputs);

	//create the innovations
	m_pInnovation = new CInnovation(genome.LinkGenes(), genome.NeuronGenes());

	//create the network depth lookup table
	m_vecSplits = Split(0, 1, 0);
}

//------------------------------------- dtor -----------------------------
//
//------------------------------------------------------------------------
Cga::~Cga()
{
	if (m_pInnovation)
		delete m_pInnovation;
	m_pInnovation = NULL;
}

//-------------------------------CreatePhenotypes-------------------------
//
//	cycles through all the members of the population and creates their
//  phenotypes. Returns a vector containing pointers to the new phenotypes
//-------------------------------------------------------------------------
vector<CNeuralNet*> Cga::CreatePhenotypes()
{
	vector<CNeuralNet*> networks;

	for (unsigned int i=0; i < m_iPopSize; i++)
	{
		//calculate max network depth
		CalculateNetDepth(m_vecGenomes[i]);

		//create new phenotype
		CNeuralNet* net = m_vecGenomes[i].CreatePhenotype();
		networks.push_back(net);
	}

	return networks;
}

//-------------------------- CalculateNetDepth ---------------------------
//
//  searches the lookup table for the dSplitY value of each node in the 
//  genome and returns the depth of the network based on this figure
//------------------------------------------------------------------------
void Cga::CalculateNetDepth(CGenome &gen)
{
	unsigned int tMaxSoFar = 0;
	for (unsigned int nd=0; nd<gen.getNumNeurons(); ++nd)
	{
		for( vector<SplitDepth>::const_iterator itVecSplits = m_vecSplits.begin(); itVecSplits != m_vecSplits.end(); ++itVecSplits )
		{
			const SplitDepth & tSplitDepth = (*itVecSplits);
			if ((gen.SplitY(nd) == tSplitDepth.val) && (tSplitDepth.depth > tMaxSoFar))
				tMaxSoFar = tSplitDepth.depth;
		}
	}

	gen.setDepth(tMaxSoFar+2);
}


//-----------------------------------AddNeuronID----------------------------
//
//	just checks to see if a node ID has already been added to a vector of
//  nodes. If not 	then the new ID  gets added. Used in Crossover.
//------------------------------------------------------------------------
void Cga::AddNeuronID(const int nodeID, vector<int> &vec)
{
	for (unsigned int i=0; i<vec.size(); i++)
	{
		if (vec[i] == nodeID)
		{
			//already added
			return;
		}
	}

	vec.push_back(nodeID);

	return;
}

//------------------------------------- Epoch ----------------------------
//
//  This function performs one epoch of the genetic algorithm and returns 
//  a vector of pointers to the new phenotypes
//------------------------------------------------------------------------
vector<CNeuralNet*> Cga::Epoch(const vector<double> &FitnessScores)
{
	//first check to make sure we have the correct amount of fitness scores
	if (FitnessScores.size() != m_vecGenomes.size())
	{
		const string tExceptionString = "scores="+itos(FitnessScores.size())+"/gens="+itos(m_vecGenomes.size());
		throw tExceptionString;
	}

	//reset appropriate values and kill off the existing phenotypes and
	//any poorly performing species
	ResetAndKill();

	//update the genomes with the fitnesses scored in the last run
	double tAverageFitnessScore = 0;
	for (unsigned int gen=0; gen < m_vecGenomes.size(); ++gen)
	{
		const double tScore = FitnessScores[gen];
		assert(tScore <= 1);
		m_vecGenomes[gen].setFitness(tScore);
		tAverageFitnessScore += tScore;
	}

	if(m_vecGenomes.size() > 0)
	{
		tAverageFitnessScore /= m_vecGenomes.size();
		m_dAvgFitness = tAverageFitnessScore;
	} else
		//If there is no population you can't have an average fitness
		m_dAvgFitness = 0;

	//sort genomes and keep a record of the best performers
	SortAndRecord();

	//separate the population into species of similar topology, adjust
	//fitnesses and calculate spawn levels
	SpeciateAndCalculateSpawnLevels();

	// uncomment the following if you want to output the species info to a filename
	//SpeciesDump("dbg_SpeciesDump.txt");

	// uncomment the following if you want to output the innovation info to a filename
	//m_pInnovation->Write("dbg_Innovations.txt", m_iGeneration);

	// uncomment the following if you want to output the best genome this generation to a filename
	//WriteGenome("dbg_BestGenome.txt", m_iFittestGenome);

	//this will hold the new population of genomes
	vector<CGenome> NewPop;

	//request the offspring from each species. The number of children to 
	//spawn is a double which we need to convert to an int. 
	unsigned int tNumSpawnedSoFar = 0;

	CGenome baby;

	//now to iterate through each species selecting offspring to be mated and 
	//mutated
	for (unsigned int spc=0; spc<m_vecSpecies.size(); ++spc)
	{
		//because of the number to spawn from each species is a double
		//rounded up or down to an integer it is possible to get an overflow
		//of genomes spawned. This statement just makes sure that doesn't
		//happen
		if (tNumSpawnedSoFar < m_iPopSize)
		{
			//this is the amount of offspring this species is required to
			// spawn. Rounded simply rounds the double up or down.
			int NumToSpawn = Rounded(m_vecSpecies[spc].NumToSpawn());
	
			bool bChosenBestYet = false;
	
			while (NumToSpawn--)
			{
				//first grab the best performing genome from this species and transfer
				//to the new population without mutation. This provides per species
				//elitism
				if (!bChosenBestYet)
				{         
					baby = m_vecSpecies[spc].Leader();
					bChosenBestYet = true;
				}
				else
				{
					//if the number of individuals in this species is only one
					//then we can only perform mutation
					if (m_vecSpecies[spc].NumMembers() == 1)
					{         
						//spawn a child
						baby = m_vecSpecies[spc].Spawn();
					}
					//if greater than one we can use the crossover operator
					else
					{
						//spawn1
						CGenome g1 = m_vecSpecies[spc].Spawn();
	
						if (RandFloat() < CParams::dCrossoverRate)
						{
	
							//spawn2, make sure it's not the same as g1
							CGenome g2 = m_vecSpecies[spc].Spawn();
		
							//number of attempts at finding a different genome
							int tNumAttempts = 5;
		
							while ( (g1.ID() == g2.ID()) && (tNumAttempts-- > 0) )
								g2 = m_vecSpecies[spc].Spawn();
		
							if (g1.ID() != g2.ID())
								baby = Crossover(g1, g2);
						} else
						{
							baby = g1;
						}
					}
				
					//give the offspring its own ID
					++m_iNextGenomeID;
		
					baby.SetID(m_iNextGenomeID);

					//now we have a spawned child lets mutate it!
					MutateGenome(baby, m_pInnovation);
				}
	
				//sort the baby's genes by their innovation numbers
				baby.SortGenes();
	
				//add to new pop
				NewPop.push_back(baby);
	
				++tNumSpawnedSoFar;
	
				if (tNumSpawnedSoFar == m_iPopSize)
					NumToSpawn = 0;
	
			}//end while
		    
		}//end if
		    
	}//next species
	
	//if there is an underflow due to the rounding error and the amount
	//of offspring falls short of the population size additional children
	//need to be created and added to the new population. This is achieved
	//simply, by using tournament selection over the entire population.
	if (tNumSpawnedSoFar < m_iPopSize)
	{
		//calculate amount of additional children required
		int tRqd = m_iPopSize - tNumSpawnedSoFar;

		//grab them
		while (tRqd-- > 0)
			NewPop.push_back(TournamentSelection(m_iPopSize/5));
	}

	//replace the current population with the new one
	m_vecGenomes = NewPop;

	//create the new phenotypes
	vector<CNeuralNet*> new_phenotypes;

	for( vector<CGenome>::iterator itGenomes = m_vecGenomes.begin(); itGenomes != m_vecGenomes.end(); ++itGenomes )
	{
		CGenome& tCGenome = *itGenomes;
		//calculate max network depth
		CalculateNetDepth(tCGenome);
		
		CNeuralNet* tPhenotype = tCGenome.CreatePhenotype();

		new_phenotypes.push_back(tPhenotype);
	}

	//increase generation counter
	++m_iGeneration;
	
	return new_phenotypes;
}

void Cga::MutateGenome(CGenome& aGenome, CInnovation* aInnovation)
{

	// First there is the chance a neuron may be added
	//If m_iMaxPermittedNeurons == 0 there is no limit on the number of neurons
	if ((aGenome.getNumNeurons() < m_iMaxPermittedNeurons) || (m_iMaxPermittedNeurons == 0))
	{      
		aGenome.AddNeuron(	CParams::dChanceAddNode*m_fMutationRate,
					*aInnovation,
					CParams::iNumTrysToFindOldLink);
	}

	//now there's the chance a link may be added
	aGenome.AddLink(	CParams::dChanceAddLink*m_fMutationRate,
				CParams::dChanceAddRecurrentLink*m_fMutationRate,
				*aInnovation,
				CParams::iNumTrysToFindLoopedLink,
				CParams::iNumAddLinkAttempts);

	//mutate the weights
	aGenome.MutateWeights(	CParams::dMutationRate*m_fMutationRate,
				CParams::dProbabilityWeightReplaced*m_fMutationRate,
				CParams::dMaxWeightPerturbation);

	aGenome.MutateActivationResponse(	CParams::dActivationMutationRate*m_fMutationRate,
						CParams::dMaxActivationPerturbation);
}

//--------------------------- SortAndRecord-------------------------------
//
//  sorts the population into descending fitness, keeps a record of the
//  best n genomes and updates any fitness statistics accordingly
//------------------------------------------------------------------------
void Cga::SortAndRecord()
{
	//sort the genomes according to their unadjusted (no fitness sharing)
	//fitnesses
	sort(m_vecGenomes.begin(), m_vecGenomes.end());
	
	//is the best genome this generation the best ever?
	if (m_vecGenomes[0].Fitness() > m_dBestEverFitness)
		m_dBestEverFitness = m_vecGenomes[0].Fitness();
	
	//keep a record of the n best genomes
	StoreBestGenomes();
}

//----------------------------- StoreBestGenomes -------------------------
//
//  used to keep a record of the previous populations best genomes so that 
//  they can be displayed if required.
//------------------------------------------------------------------------
void Cga::StoreBestGenomes()
{
	assert(m_iNumBestGenomes <= m_vecGenomes.size());
	//clear old record
	m_vecBestGenomes.clear();
	const unsigned int tSpeciesSize = m_vecSpecies.size();
	
	//If there is less species than just push back the top genomes. Then only push back one for each species
	unsigned int tNumToPushBack = 0;
	if(tSpeciesSize < m_iNumBestGenomes)
		tNumToPushBack = tSpeciesSize;
	else
		tNumToPushBack = m_iNumBestGenomes;
	vector<unsigned int> tSpeciesIDs;
	for( vector<CGenome>::const_iterator it = m_vecGenomes.begin(); it != m_vecGenomes.end(); ++it )
	{
		const CGenome& tGenome = (*it);
		const unsigned int tSpeciesID = tGenome.getSpecies();
		bool tSpeciesExists = false;
		for( vector<unsigned int>::const_iterator itSpeciesID = tSpeciesIDs.begin(); itSpeciesID != tSpeciesIDs.end(); ++itSpeciesID )
		{
			const unsigned int tCurrentSpeciesID = (*itSpeciesID);
			if(tCurrentSpeciesID == tSpeciesID)
			{
				tSpeciesExists = true;
				break;
			}
		}
		
		if(!tSpeciesExists)
		{
			m_vecBestGenomes.push_back(tGenome);
			tSpeciesIDs.push_back(tSpeciesID);
			if(m_vecBestGenomes.size() == tNumToPushBack)
				break;
		}
	}

// 	cout << "List of species" << endl;
// 	for(vector<CSpecies>::const_iterator it = m_vecSpecies.begin(); it != m_vecSpecies.end(); ++it)
// 	{
// 		const CSpecies& tSpecies = (*it);
// 		cout << tSpecies.ID() << endl;
// 
// 	}

	//TODO: should a species exist if it has no genomes!!!!!	
// 	cout << "List of species in Genome" << endl;
// 	vector<unsigned int> tAllSpeciesIDs;
// 	for( vector<CGenome>::const_iterator it = m_vecGenomes.begin(); it != m_vecGenomes.end(); ++it )
// 	{
// 		const CGenome& tGenome = (*it);
// 		const unsigned int tSpeciesID = tGenome.getSpecies();
// 		bool tSpeciesFound = false;
// 		for( vector<unsigned int>::const_iterator itSpeciesID = tAllSpeciesIDs.begin(); itSpeciesID != tAllSpeciesIDs.end(); ++itSpeciesID )
// 		{
// 			const unsigned int tCurrentSpeciesID = (*itSpeciesID);
// 			if(tCurrentSpeciesID == tSpeciesID)
// 			{
// 				tSpeciesFound = true;
// 				break;
// 			}
// 		}
// 
// 		if(!tSpeciesFound)
// 			tAllSpeciesIDs.push_back(tSpeciesID);
// 	}
// 
// 	cout << "Number is: " << tAllSpeciesIDs.size() << endl;
// 	for( vector<unsigned int>::const_iterator itSpeciesID = tAllSpeciesIDs.begin(); itSpeciesID != tAllSpeciesIDs.end(); ++itSpeciesID )
// 	{
// 		const unsigned int tCurrentSpeciesID = (*itSpeciesID);
// 		cout << tCurrentSpeciesID << endl;
// 	}
}

//----------------- GetBestPhenotypesFromLastGeneration ------------------
//
//  returns a std::vector of the n best phenotypes from the previous
//  generation
//------------------------------------------------------------------------
vector<CNeuralNet*> Cga::GetBestPhenotypesFromLastGeneration()
{
	vector<CNeuralNet*> brains;
	
	for (unsigned int gen=0; gen<m_vecBestGenomes.size(); ++gen)
	{
		//calculate max network depth
		CalculateNetDepth(m_vecBestGenomes[gen]);
		
		brains.push_back(m_vecBestGenomes[gen].CreatePhenotype());
	}
	
	return brains;
}

//--------------------------- AdjustSpecies ------------------------------
//
//  this functions simply iterates through each species and calls 
//  AdjustFitness for each species
//------------------------------------------------------------------------
void Cga::AdjustSpeciesFitnesses()
{
	for(vector<CSpecies>::iterator it = m_vecSpecies.begin(); it != m_vecSpecies.end(); ++it)
		(*it).AdjustFitnesses();
}

//------------------ SpeciateAndCalculateSpawnLevels ---------------------
//
//  separates each individual into its respective species by calculating
//  a compatibility score with every other member of the population and 
//  niching accordingly. The function then adjusts the fitness scores of
//  each individual by species age and by sharing and also determines
//  how many offspring each individual should spawn.
//------------------------------------------------------------------------
void Cga::SpeciateAndCalculateSpawnLevels()
{
  bool bAdded = false;

  //try to keep the number of species below the maximum if user has specified
  //a iMaxNumberOfSpecies in params.ini.
  AdjustCompatibilityThreshold();
    
  //iterate through each genome and speciate
  for (unsigned int gen=0; gen<m_vecGenomes.size(); ++gen)
  {
    
	//calculate its compatibility score with each species leader. If
	//compatible add to species. If not, create a new species
	for (unsigned int spc=0; spc<m_vecSpecies.size(); ++spc)
	{
		const double compatibility = m_vecGenomes[gen].GetCompatibilityScore(m_vecSpecies[spc].Leader());
		//if this individual is similar to this species add to species
		if (compatibility <= CParams::dCompatibilityThreshold)
		{
			m_vecSpecies[spc].AddMember(m_vecGenomes[gen]);
			//let the genome know which species it's in
			m_vecGenomes[gen].setSpecies(m_vecSpecies[spc].ID());
			bAdded = true;
			break;
		}
	}
    
	if (!bAdded)
	{
		//we have not found a compatible species so let's create a new one
		m_vecSpecies.push_back(CSpecies(m_vecGenomes[gen], m_iNextSpeciesID++));
	}

	bAdded = false;
  }

  //now all the genomes have been assigned a species the fitness scores 
  //need to be adjusted to take into account sharing and species age.
  AdjustSpeciesFitnesses();
  
  //calculate new adjusted total & average fitness for the population
  for (unsigned int gen=0; gen<m_vecGenomes.size(); ++gen)
  {   
	m_dTotFitAdj += m_vecGenomes[gen].GetAdjFitness();
  }

  m_dAvFitAdj = m_dTotFitAdj/m_vecGenomes.size();

  //calculate how many offspring each member of the population
  //should spawn
  for (unsigned int gen=0; gen<m_vecGenomes.size(); ++gen)
  {   
     const double ToSpawn = m_vecGenomes[gen].GetAdjFitness() / m_dAvFitAdj;
     m_vecGenomes[gen].SetAmountToSpawn(ToSpawn);
  }

  //iterate through all the species and calculate how many offspring
  //each species should spawn
  for (unsigned int spc=0; spc<m_vecSpecies.size(); ++spc)
  {
    m_vecSpecies[spc].CalculateSpawnAmount();
  }
}

//--------------------- AdjustCompatibilityThreshold ---------------------
//
//  this automatically adjusts the compatibility threshold in an attempt
//  to keep the number of species below a maximum
//------------------------------------------------------------------------
void Cga::AdjustCompatibilityThreshold()
{
	//if iMaxNumberOfSpecies < 1 then the user has effectively
	//switched this feature off.
	if (CParams::iMaxNumberOfSpecies < 1)
		return;

	if (m_iGeneration < 1)
		return;
	
	const unsigned int tNumSpecies  = m_vecSpecies.size();
	const double tThresholdIncrement = 0.01;
	

	//Old method set a range of species and tries to keep them between these limits
	/*tThresholdIncrement = 0.01;
	if (tNumSpecies > CParams::iMaxNumberOfSpecies)
		CParams::dCompatibilityThreshold += tThresholdIncrement;

	else if (tNumSpecies < 2)
		CParams::dCompatibilityThreshold -= tThresholdIncrement;

  	return; */ 

	  
	//Keeping species diverse
	//This code forces the system to aim for 
	// iMaxNumberOfSpecies species at all times, enforcing diversity
	//This tinkers with the compatibility threshold, which
	// normally would be held constant

	if (tNumSpecies < CParams::iMaxNumberOfSpecies)
		CParams::dCompatibilityThreshold -= tThresholdIncrement;

	else if (tNumSpecies > CParams::iMaxNumberOfSpecies)
		CParams::dCompatibilityThreshold +=tThresholdIncrement;

	if (CParams::dCompatibilityThreshold < tThresholdIncrement)
		CParams::dCompatibilityThreshold = tThresholdIncrement;
	
	return;
}
//--------------------------- TournamentSelection ------------------------
//
//------------------------------------------------------------------------
CGenome Cga::TournamentSelection(const int NumComparisons)
{
   double BestFitnessSoFar = 0;
  
   int ChosenOne = 0;

   //Select NumComparisons members from the population at random testing  
   //against the best found so far
   for (int i=0; i<NumComparisons; ++i)
   {
     int ThisTry = RandInt(0, m_vecGenomes.size()-1);

     if (m_vecGenomes[ThisTry].Fitness() > BestFitnessSoFar)
     {
       ChosenOne = ThisTry;

       BestFitnessSoFar = m_vecGenomes[ThisTry].Fitness();
     }
   }

   //return the champion
   return m_vecGenomes[ChosenOne];
}
                                 
//-----------------------------------Crossover----------------------------
//	
//------------------------------------------------------------------------
CGenome Cga::Crossover(CGenome& mum, CGenome& dad)
{
	//helps make the code clearer
	enum parent_type{MUM, DAD};
	
	//first, calculate the genome we will using the disjoint/excess
	//genes from. This is the fittest genome.
	parent_type tBest;

	//if they are of equal fitness use the shorter (because we want to keep
	//the networks as small as possible)
	if (mum.Fitness() == dad.Fitness())
	{
		//if they are of equal fitness and length just choose one at
		//random
		if (mum.NumGenes() == dad.NumGenes())
			tBest = (parent_type)RandInt(0, 1);
		else
		{
			if (mum.NumGenes() < dad.NumGenes())
				tBest = MUM;
			else
				tBest = DAD;
		}
	}  else
	{
		
		if (mum.Fitness() > dad.Fitness())
			tBest = MUM;
		else
			tBest = DAD;
	}
 
 	 //these vectors will hold the offspring's nodes and genes
  	vector<SNeuronGene>  BabyNeurons;
	vector<SLinkGene>    BabyGenes;

 	 //temporary vector to store all added node IDs
  	vector<int> vecNeurons;

  	//create iterators so we can step through each parents genes and set
 	 //them to the first gene of each parent
  	vector<SLinkGene>::iterator curMum = mum.StartOfGenes();
  	vector<SLinkGene>::iterator curDad = dad.StartOfGenes();

 	 //this will hold a copy of the gene we wish to add at each step
	SLinkGene tSelectedGene;

  	//step through each parents genes until we reach the end of both
 	 while (!((curMum == mum.EndOfGenes()) && (curDad == dad.EndOfGenes())))
  	{
	
    		//the end of mum's genes have been reached
    		if ((curMum == mum.EndOfGenes())&&(curDad != dad.EndOfGenes()))
    		{
			//if dad is fittest
			if (tBest == DAD)
			{
				//add dads genes
				tSelectedGene = *curDad;
			}

     			 //move onto dad's next gene
     			 ++curDad;
   		 }
    		//the end of dads's genes have been reached
    		else if ( (curDad == dad.EndOfGenes()) && (curMum != mum.EndOfGenes()))
    		{
			//if mum is fittest
			if (tBest == MUM)
			{
				//add mums genes
				tSelectedGene = *curMum;
			}
			
      			//move onto mum's next gene
      			++curMum;
    		}
    		//if mums innovation number is less than dads
   		 else if (curMum->InnovationID < curDad->InnovationID)
    		{
			//if mum is fittest add gene
			if (tBest == MUM)
				tSelectedGene = *curMum;
			
			//move onto mum's next gene
			++curMum;
   		 }
		//if dads innovation number is less than mums
   		else if (curDad->InnovationID < curMum->InnovationID)
   		{
			//if dad is fittest add gene
			if (tBest == DAD)
				tSelectedGene = *curDad;

      			//move onto dad's next gene
      			++curDad;
   		 }
		//if innovation numbers are the same
		else if (curDad->InnovationID == curMum->InnovationID)
		{
			//grab a gene from either parent
			if (RandFloat() < 0.5f)
				tSelectedGene = *curMum;
			else
				tSelectedGene = *curDad;

			//move onto next gene of each parent
			++curMum;
			++curDad;
    		}
		//add the selected gene if not already added
		if (BabyGenes.size() == 0)
			BabyGenes.push_back(tSelectedGene);
		else
		{
			if (BabyGenes[BabyGenes.size()-1].InnovationID != tSelectedGene.InnovationID)
				BabyGenes.push_back(tSelectedGene);
		}   

		//Check if we already have the nodes referred to in SelectedGene.
		//If not, they need to be added.		
		AddNeuronID(tSelectedGene.FromNeuron, vecNeurons);
		AddNeuronID(tSelectedGene.ToNeuron, vecNeurons);
		
  	}//end while

  	//now create the required nodes. First sort them into order
  	sort(vecNeurons.begin(), vecNeurons.end());
  
  	for (unsigned int i=0; i<vecNeurons.size(); i++)
		BabyNeurons.push_back(m_pInnovation->CreateNeuronFromID(vecNeurons[i]));

	//finally, create the genome
	CGenome babyGenome(m_iNextGenomeID++,
			BabyNeurons,
			BabyGenes,
			mum.NumInputs(),
			mum.NumOutputs());

  	return babyGenome;
}


//--------------------------- ResetAndKill -------------------------------
//
//  This function resets some values ready for the next epoch, kills off
//  all the phenotypes and any poorly performing species.
//------------------------------------------------------------------------
void Cga::ResetAndKill()
{
	m_dTotFitAdj = 0;
	m_dAvFitAdj  = 0;
	
	//purge the species
	vector<CSpecies>::iterator curSp = m_vecSpecies.begin();
	
	while (curSp != m_vecSpecies.end())
	{
		curSp->Purge();
		
		//kill off species if not improving and if not the species which contains 
		//the best genome found so far
		if ( (curSp->GensNoImprovement() > CParams::iNumGensAllowedNoImprovement) &&
			(curSp->BestFitness() < m_dBestEverFitness) )
		{
			curSp = m_vecSpecies.erase(curSp);
			--curSp;
		}
		
		++curSp;
	}
	
	//we can also delete the phenotypes
	for (unsigned int gen=0; gen<m_vecGenomes.size(); ++gen)
		m_vecGenomes[gen].DeletePhenotype();
}

//------------------------------- Split ----------------------------------
//
//  this function is used to create a lookup table that is used to
//  calculate the depth of the network. 
//------------------------------------------------------------------------
vector<SplitDepth> Cga::Split(const double aLow, const double aHigh, const unsigned int aDepth)
{
	static vector<SplitDepth> tVecSplits;
	
	const double tSpan = aHigh - aLow;
	
	tVecSplits.push_back(SplitDepth(aLow + tSpan/2, aDepth + 1));
	
	if (aDepth > 6)
		return tVecSplits;
	else
	{
		Split(aLow, aLow + tSpan/2, aDepth+1);
		Split(aLow+tSpan/2, aHigh, aDepth+1);
		
		return tVecSplits;
	}
}



//--------------------------- WriteGenome --------------------------------
//
//  given an index into m_vecGenomes this function writes the structure of
//  a single genome to a file
//------------------------------------------------------------------------
bool Cga::WriteGenome(const char* szFileName, const int idxGenome)
{
	assert(idxGenome < (const int) m_vecGenomes.size());
	ofstream out(szFileName);

	if (!out)
		return false;  //error

	CalculateNetDepth(m_vecGenomes[idxGenome]);

	if (m_vecGenomes[idxGenome].Write(out))
		return true;

	return false;
}

void Cga::writeBestToDisk(const string& aFileName)
{
	//There are no best to write to disk until at least one generation has passed
	if(m_iGeneration < 1)
		return;	

	unsigned int tCount = 0;
	for( vector<CGenome>::iterator it = m_vecBestGenomes.begin(); it != m_vecBestGenomes.end(); ++it )
	{	
		
		//Create a unique filename
		std::ostringstream tFilenameBestGenomeStream;
		time_t tDate;
		tDate = time (NULL);
		tm * tTm = gmtime ( &tDate );
		tFilenameBestGenomeStream << aFileName << "_" << tCount << "_";
		tFilenameBestGenomeStream << (1900 + tTm->tm_year) << "-" << (1 + tTm->tm_mon) << "-" << tTm->tm_mday << "_";
		tFilenameBestGenomeStream << (tTm->tm_hour + 1) << "-" << tTm->tm_min << "-" << tTm->tm_sec;
		tFilenameBestGenomeStream << ".txt";
		const string tFilenameBestGenome = tFilenameBestGenomeStream.str();
		//end of filename code

		ofstream tOut(tFilenameBestGenome.c_str());
		if (!tOut)
		{
			std::ostringstream tExceptionString;
			tExceptionString << "Exception in '" << __FUNCTION__ << "' creating file '" << tFilenameBestGenome << "'";
			throw tExceptionString.str();
		}

		CGenome& tGenome = (*it);
		CalculateNetDepth(tGenome);
		if(!tGenome.Write(tOut))
		{

			std::ostringstream tExceptionString;
			tExceptionString << "Exception in '" << __FUNCTION__ << "' writing best genome to file  '" << tFilenameBestGenome << "'";
			throw tExceptionString.str();
		}
		tCount++;
	}
}

//--------------------- SpeciesDump -------------------------------------
//
//  Outputs the species info to a file
//-----------------------------------------------------------------------
bool Cga::SpeciesDump(const char* szFileName)
{
	ofstream file(szFileName);
	if (!file) 
		return false;   //error
	file << "Best Ever Fitness is " << m_dBestEverFitness << "\n";

	for (unsigned int i=0; i<m_vecSpecies.size(); ++i)
		file << m_vecSpecies[i];

	return true;
}


void Cga::printPopInfo() const
{
 	for(vector<CSpecies>::const_iterator it = m_vecSpecies.begin(); it != m_vecSpecies.end(); ++it)
 	{
 		const CSpecies& tSpecies = (*it);
 		cout << "ID:\t" << tSpecies.ID() << "\tSize:" << tSpecies.NumMembers() << endl;
 
 	}
}




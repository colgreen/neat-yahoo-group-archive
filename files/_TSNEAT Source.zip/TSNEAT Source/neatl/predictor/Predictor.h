#ifndef RC_PREDICTOR_H
#define RC_PREDICTOR_H

//------------------------------------------------------------------------
//
//	Name: Predictor.h
//
//  Author: Shane Ryan
//
//  Desc: Class to couple Errors with Neural net
//
//------------------------------------------------------------------------
#include "../core/phenotype.h"
#include "../core/Pattern.h"
#include "../common/utils.h"
#include "CParams.h"


using namespace std;

class Predictor
{

private:

	CNeuralNet*  m_pItsBrain; 

	//its memory
	vector<float> m_Errors;

	//the genomes fitness score. 
	float	m_dFitness;

public:
	
	Predictor();

	//updates the ANN with information from the genomes enviroment
	bool		Update(const Pattern& aPattern);

	void		Reset();

	void		EndOfRunCalculations();

	//-------------------accessor functions
	float				Fitness()const{return m_dFitness;}

	void InsertNewBrain(CNeuralNet* brain){m_pItsBrain = brain;}
	static const float calcError(const float aOutput, const float aActual);
	CNeuralNet* getNeuralNet() const { return m_pItsBrain;}
};


#endif



	
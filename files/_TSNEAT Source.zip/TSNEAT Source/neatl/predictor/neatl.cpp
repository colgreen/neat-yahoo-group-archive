#include "../common/utils.h"
#include "../predictor/CController.h"
#include "../predictor/CParams.h"

#ifdef _WIN32
	#include <windows.h>
	#include <conio.h>
	#include <process.h>
#else
	#include <pthread.h>
#endif
#include <time.h>
#include <sys/timeb.h>


bool gExit = false;
CController * gController = NULL;
string gParamsFileName = "params.ini";

#ifdef _WIN32
	CRITICAL_SECTION gMutex;
	HANDLE hEventUIDone;
	HANDLE hEventTrainingDone;
#else
	pthread_mutex_t gMutex = PTHREAD_MUTEX_INITIALIZER;
#endif

void MUTEXON()
{
	#ifdef _WIN32
		EnterCriticalSection( &gMutex );
	#else
		pthread_mutex_lock( &gMutex );
	#endif
}

void MUTEXOFF()
{
	#ifdef _WIN32
		LeaveCriticalSection( &gMutex );
	#else
		pthread_mutex_unlock( &gMutex );
	#endif
}


void printStats(const CController& aController, const int aNumSeconds)
{
	cout << "time:\t" << aNumSeconds;
	cout << "\tBest Fitness:\t" << aController.getBestFitness();
	cout << "\tAverage Fitness: " << aController.getAverageFitness() << endl;
	cout << "\tNum Species: " << aController.getNumSpecies();
	cout << "\tCurrent Generation:\t" << aController.getCurrentGeneration() << endl;
	cout << "\tRateChange Best Fitness:\t" << aController.getRateChangeBestFitness();
	cout << "\tRateChange Avg Fitness:\t" << aController.getRateChangeAvFitness();
	cout << "\tRateChange Num Species:\t" << aController.getRateChangeNumSpecies() << endl << endl;
}


void printLogs(ofstream& aLogOut, const CController& aController, const int aNumSeconds)
{
	const char tDeliniatorChar = ',';
	aLogOut << aNumSeconds << tDeliniatorChar;
	aLogOut << aController.getBestFitness() << tDeliniatorChar;
	aLogOut << aController.getAverageFitness() << tDeliniatorChar;
	aLogOut << aController.getNumSpecies() << tDeliniatorChar;
	aLogOut << aController.getCurrentGeneration() << tDeliniatorChar;
	aLogOut << aController.getRateChangeBestFitness() << tDeliniatorChar;
	aLogOut << aController.getRateChangeAvFitness() << tDeliniatorChar;
	aLogOut << aController.getRateChangeNumSpecies() << endl;
}

//This is the UI for passing commands to the controller class
#ifdef _WIN32
	void ui_thread(void* /*arg*/)
#else
	void *ui_thread(void* /*arg*/)
#endif
	{
		bool tDoneWhile = false;
		while(!tDoneWhile)
		{
			char tCommand;
			#ifdef _WIN32
				tCommand = getch();
			#else
				cin >> tCommand;
			#endif
			switch( tCommand)
			{
				case '\0':
					break;
				case 'Q':
				case 'q':
				{
					cout << "Exited" << endl;
					gExit = true;
					tDoneWhile = true;
					break;
				}

				case 'd':
				case 'D':
				{
					MUTEXON();

					if(gController)
						if(gController->getCurrentGeneration() > 0)
						{
							cout << "Dumping snapshot of best networks" << endl;
							gController->writeBestToDisk("Early-Dump");
						} else
						{
							cout << "You must waite at least one generation before dumping network" << endl;
						}

					MUTEXOFF();

					break;
				}

				default:
					cout << "Command '" << tCommand << "' not understood'" << endl;
					break;
			}
		}
		

		#ifdef _WIN32
			SetEvent(hEventUIDone);
			return;
		#else
			return 0;
		#endif
	}

//The main thread for running the controller class
#ifdef _WIN32
	void training_thread(void* /*arg*/)
#else
	void *training_thread(void* /*arg*/)
#endif
{	
	CParams   g_Params;
	ofstream tLogOut;
	try {

		//load in the parameters for the program
		g_Params.Initialize(gParamsFileName);
		
		if(CParams::m_iSeedRandom != 0)
			RandSing::setSeed(CParams::m_iSeedRandom);
		else
			RandSing::initRandomSeed();
		cout << "Seed: " << RandSing::getSeed() << endl;
		
		
		if(CParams::m_bPrintLogs)
		{
			//Create a unique filename
			std::ostringstream tFilenameLogStream;
			time_t tDate;
			tDate = time (NULL);
			tm * tTm = gmtime ( &tDate );
			if(CParams::m_sProjectName.compare("") != 0)
				tFilenameLogStream << CParams::m_sProjectName << "-";
			tFilenameLogStream << (1900 + tTm->tm_year) << "-" << (1 + tTm->tm_mon) << "-" << tTm->tm_mday << "_";
			tFilenameLogStream << (tTm->tm_hour + 1) << "-" << tTm->tm_min << "-" << tTm->tm_sec;
			tFilenameLogStream << ".log";
			const string tFilenameLogFile = tFilenameLogStream.str();
			//end of filename code

			tLogOut.open(tFilenameLogFile.c_str());
			if (!tLogOut)
			{
				std::ostringstream tExceptionString;
				tExceptionString << "Exception in '" << __FUNCTION__ << "' creating file '" << tFilenameLogFile << "'";
				throw tExceptionString.str();
			}
			
			//TODO: Prob output other variable like popsize and windows size
			
			//Print Seed and Header 
			const char tDeliniatorChar = ',';
			tLogOut << "Seed" << tDeliniatorChar << RandSing::getSeed() << endl;

			tLogOut << "NumSeconds" << tDeliniatorChar;
			tLogOut << "Best Fitness" << tDeliniatorChar;
			tLogOut << "Average Fitness" << tDeliniatorChar;
			tLogOut << "Num Species" << tDeliniatorChar;
			tLogOut << "Current Generation" << tDeliniatorChar;
			tLogOut << "Rate Change Best Fitness" << tDeliniatorChar;
			tLogOut << "Rate Change Average Fitness" << tDeliniatorChar;
			tLogOut << "Rate Change Num Species" << endl;
			//End of Header

		}
		
		gController = new CController(CParams::iPatternFile);
		
		// Enter the message loop
		bool tDone = false;
		//time_t tTempTime1, tTempTime2;
		struct timeb tTempTime1, tTempTime2, tStartOverallTime, tEndOverallTime; 
		ftime(&tStartOverallTime);
		ftime(&tTempTime1);
		while(!tDone)
		{
			MUTEXON();
 			bool tGenerationCompleted = false;
 			gController->Update(tDone, tGenerationCompleted);
			{
// 				#ifdef _WIN32
// 					Sleep(1);
// 				#else
// 					struct timespec timeOut,remains;
// 					timeOut.tv_sec = 0;
// 					timeOut.tv_nsec = 1000000; // 1/10 millisecond
// 					nanosleep(&timeOut, &remains);
// 				#endif				
			}
			MUTEXOFF();

			if(gExit)
				break;
			MUTEXON();
			if(tGenerationCompleted)
			{
				ftime(&tTempTime2);
				
				int tNumSeconds = (tTempTime2.time -  tTempTime1.time)*1000;
				int tNumSecondsMilli = (tTempTime2.millitm - tTempTime1.millitm);
				if(tNumSecondsMilli < 0)
					tNumSecondsMilli *= -1;
				tNumSeconds += tNumSecondsMilli;
				
				printStats(*gController, tNumSeconds);
				//gController->printPopInfo();
				printLogs(tLogOut, *gController, tNumSeconds);
				ftime(&tTempTime1);
			}
			MUTEXOFF();
			
		}

		ftime(&tEndOverallTime);
		int tNumSeconds = (tEndOverallTime.time -  tStartOverallTime.time)*1000;
		int tNumSecondsMilli = (tEndOverallTime.millitm - tStartOverallTime.millitm);
		if(tNumSecondsMilli < 0)
			tNumSecondsMilli *= -1;
		tNumSeconds += tNumSecondsMilli;
		cout << "Overall time:\t" << tNumSeconds << endl;
		cout << "Enter 'Q' to quit" << endl;
		
	} catch(const string aException)
	{
		cout << "Exception:\t" << aException << endl;
		//Make sure the log file is always closed so we can see the results up to the point of the exception
		if(CParams::m_bPrintLogs)
			tLogOut.close();
	}
	
	// Clean up everything and exit the app
	MUTEXON();
 	if (gController) 
		delete gController;
	gController = NULL;
	MUTEXOFF();

	cout << "Seed: " << RandSing::getSeed() << endl;

	//Make sure the log file is closed
	if(CParams::m_bPrintLogs)
		tLogOut.close();

	#ifdef _WIN32
		SetEvent(hEventTrainingDone);
		return;
	#else
		return 0;
	#endif
}

int main(int argc, char* argv[])
{
	
	//Was a file containg the name of the config file passed in
	if(argc == 2)
		gParamsFileName = argv[1];


	#ifdef _WIN32

		InitializeCriticalSection(&gMutex);

		HANDLE tUIThread;
		HANDLE tTrainingThread;

		hEventUIDone = CreateEvent(NULL,FALSE,FALSE,"UIEvent");
		hEventTrainingDone = CreateEvent(NULL,FALSE,FALSE,"TrainingEvent");
		
		tUIThread = (HANDLE) _beginthread( ui_thread,0,NULL);
		if(tUIThread == NULL)
		{
			cout << __FUNCTION__ << "error creating UI thread" << endl;
			return -1;
		}

		tTrainingThread = (HANDLE) _beginthread( training_thread,0,NULL);
		if ( tTrainingThread == NULL)
		{
			cout << __FUNCTION__ << "error creating training thread" << endl;
			MUTEXOFF();
			gExit = true;
			return -1;
		}

		WaitForSingleObject(hEventUIDone,INFINITE);
		WaitForSingleObject(hEventTrainingDone,INFINITE);

	#else
		pthread_t tUIThread;
 		pthread_t tTrainingThread;
		if ( pthread_create( &tUIThread, NULL, ui_thread, NULL) )
		{
			cout << __FUNCTION__ << "error creating UI thread" << endl;
			return -1;
		}

		if ( pthread_create( &tTrainingThread, NULL, training_thread, NULL) )
		{
			cout << __FUNCTION__ << "error creating training thread" << endl;
			return -1;
		}

		if ( pthread_join ( tUIThread, NULL ) || pthread_join( tTrainingThread, NULL ) )
		{
			cout << __FUNCTION__ << "error joining thread" << endl;
			MUTEXOFF();
			gExit = true;
			return -1;
		}
	#endif
	
	return 0;
}



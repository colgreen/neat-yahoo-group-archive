#include "CController.h"
#include "Cga.h"

//---------------------------------------constructor---------------------
//
//	initilaize the genomes, their brains and the GA factory
//
//-----------------------------------------------------------------------
CController::CController(const string& aPatternFile): 	m_RateChangeAvFitness(0),
							m_RateChangeBestFitness(0),
							m_RateChangeNumSpecies(0),
							m_iPatternsPresented(0)
							
{
	m_PatternManager= new PatternManager(aPatternFile.c_str(), CParams::iNumInputs);

	m_pPop = new Cga(	CParams::iPopSize,
				CParams::iNumInputs,
				CParams::iNumOutputs,
				CParams::iNumBestGenomes,
				CParams::iMaxPermittedNeurons);

	//let's create the Population
	for (unsigned int i=0; i< m_pPop->getPopSize(); ++i)
	{
		m_vecPredictors.push_back(Predictor());
	}
  
	//and the vector of best performers
	for (unsigned int i=0; i < m_pPop->getNumBestGenomes(); ++i)
	{
		m_vecBestPredictors.push_back(Predictor());
	}

  	//create the phenotypes
	vector<CNeuralNet*> pBrains = m_pPop->CreatePhenotypes();
   
	//assign the phenotypes
	for (unsigned int i=0; i < m_pPop->getPopSize(); i++)
		m_vecPredictors[i].InsertNewBrain(pBrains[i]);
}

//--------------------------------------destructor-------------------------------------
//
//--------------------------------------------------------------------------------------
CController::~CController()
{
	if(m_PatternManager)
		delete m_PatternManager;
	m_PatternManager = NULL;
}

const Cga* CController::getPopulation() const { return m_pPop;}

//-------------------------------------Update---------------------------------------
//
//	This is the main workhorse. The entire simulation is controlled from here.
//
//--------------------------------------------------------------------------------------
void CController::Update(bool& aDone, bool& aEpochCompleted)
{
	//run the population through each of the patterns. During this loop each
	//NN is constantly updated. The output from the NN is obtained. 
	if (m_iPatternsPresented++ < CParams::iNumPatterns)
	{
		const Pattern& tPattern = m_PatternManager->getNextPattern();
		for (unsigned int i=0; i < m_pPop->getPopSize(); ++i)
		{
			//update the NN and position
			if (!m_vecPredictors[i].Update(tPattern))
			{
				//error in processing the neural net
				const string tExceptionString = "Wrong amount of NN inputs!";
				throw tExceptionString;
			}
		}

		//update the NNs of the last generations best performers
		if (getCurrentGeneration() > 0)
		{
			for (unsigned int i=0; i<m_vecBestPredictors.size(); ++i)
			{
				//update the NN and position
				if (!m_vecBestPredictors[i].Update(tPattern))
				{
					//error in processing the neural net
					const string tExceptionString = "Wrong amount of NN inputs!";
					throw tExceptionString;
				}
			}
		}

		aDone = false;
		aEpochCompleted = false;
		return;
	}
	//We have completed another generation so now we need to run the GA
	else
	{
		//printPopInfo();

		//first add up each genomes fitness scores. (remember for this task
		//there are many different sorts of penalties the genomes may incur
		//and each one has a coefficient)
		for (unsigned int swp=0; swp < m_vecPredictors.size(); ++swp)
		{
			m_vecPredictors[swp].EndOfRunCalculations();
		}

		//reset Pattern counter
		m_iPatternsPresented = 0;
		
		//perform an epoch and grab the new brains
		vector<CNeuralNet*> pBrains;
		pBrains = m_pPop->Epoch(getFitnessScores());

		//Update the vectors containing stats for each generation
		updateMetrics(*m_pPop);

		adjustMutationRate();
				
		//insert the new  brains back into the genomes and reset their
		//positions
		for (unsigned int i=0; i < m_pPop->getPopSize(); ++i)
		{
			m_vecPredictors[i].InsertNewBrain(pBrains[i]);
			m_vecPredictors[i].Reset();
		}

		//grab the NNs of the best performers from the last generation
		vector<CNeuralNet*> pBestBrains;
		pBestBrains = m_pPop->GetBestPhenotypesFromLastGeneration();

		//put them into our record of the best genomes
		for (unsigned int i=0; i < m_vecBestPredictors.size(); ++i)
		{
			m_vecBestPredictors[i].InsertNewBrain(pBestBrains[i]);
			m_vecBestPredictors[i].Reset();
		}

		const bool tFitnessStoppingCriteriaMet = 
			(m_pPop->BestEverFitness() >= CParams::iStoppingCriteria && !RC::isClear(CParams::iStoppingCriteria));
		if( tFitnessStoppingCriteriaMet || (getCurrentGeneration() >= CParams::iStoppingGeneration && !RC::isClear(CParams::iStoppingGeneration)))
		{
			//We are suppossed to stop so if we reached criteria then dump network to a file
			if(/*tFitnessStoppingCriteriaMet && */CParams::iDumpNetworkWhenDone)
				//Dump best networks to file
				m_pPop->writeBestToDisk("Best");
			
			//The stopping criteria has been reached. So end app.
			aDone = true;
			aEpochCompleted = true;
			return;
		}
		aDone = false;
		aEpochCompleted = true;
		return;
	}
}

void CController::adjustMutationRate()
{
	const float tUpperRateChangeThreshold = 1e-3;
	const float tLowerRateChangeThreshold = 1e-6;
	const float tMaxAdjustment = 1e-2;
	const float tMaxMutationRate = 10;
 	const float tMinMutationRate = 1e-3;
 

	const float tCurrentMutationRate = m_pPop->getMutationRate();
	const float tRateChangeBestFitness = m_RateChangeBestFitness;
	float tNewMutationRate = tCurrentMutationRate;
	if(tRateChangeBestFitness > tUpperRateChangeThreshold)
	{
		tNewMutationRate -= RandFloat()*tMaxAdjustment;
 		if(tNewMutationRate < tMinMutationRate)
 			tNewMutationRate = tMinMutationRate;

	} else if (tRateChangeBestFitness < tLowerRateChangeThreshold)
	{
		tNewMutationRate += RandFloat()*tMaxAdjustment;
 		if(tNewMutationRate > tMaxMutationRate)
 			tNewMutationRate = tMaxMutationRate;
	}
	m_pPop->setMutationRate(tNewMutationRate);
	cout << "MutationRate: " << tNewMutationRate << endl;


// 	const float tUpperRateChangeThreshold = 0.001;
// 	const float tLowerRateChangeThreshold = 0.0000001;
// 	const float tMaxAdjustment = 0.1;
// 	const float tMaxMutationRate = 10;
// 	const float tMinMutationRate = 0.001;
// 
// 	const float tCurrentMutationRate = m_pPop->getMutationRate();
// 	const float tRateChangeBestFitness = m_RateChangeBestFitness;
// 	float tNewMutationRate = tCurrentMutationRate;
// 	if(tRateChangeBestFitness > tUpperRateChangeThreshold)
// 	{
// 		tNewMutationRate -= RandFloat()*tMaxAdjustment;
// 		//tNewMutationRate -= tMaxAdjustment;
// 		if(tNewMutationRate < tMinMutationRate)
// 			tNewMutationRate = tMinMutationRate;
// 
// 	} else if (tRateChangeBestFitness < tLowerRateChangeThreshold)
// 	{
// 		tNewMutationRate += RandFloat()*tMaxAdjustment;
// 		//tNewMutationRate += tMaxAdjustment;
// 		if(tNewMutationRate > tMaxMutationRate)
// 			tNewMutationRate = tMaxMutationRate;
// 	}
// 	m_pPop->setMutationRate(tNewMutationRate);
}

void CController::updateMetrics(const Cga& aPop)
{

	if(getCurrentGeneration() < 1)
		return;

	const unsigned int tNumSpecies = aPop.getNumSpecies();
	const double tBestFitness = aPop.BestEverFitness();
	const double tAvgFitness = aPop.getAverageFitness();
	
	m_vecNumSpecies.push_back(tNumSpecies);
	m_vecBestFitness.push_back(tBestFitness);
	m_vecAvFitness.push_back(tAvgFitness);

	
	//Calculate the rate change over a window of generations
	//This is the Current Value minus the value a window of generations ago divided by the window size
	const unsigned int tWindowSize = 100;

	assert((m_vecNumSpecies.size() == m_vecBestFitness.size()) && (m_vecBestFitness.size() == m_vecAvFitness.size()));
	
	//Determine the size of the window
	//This will vary until tWindowSize generations have passed then it will remain fixed
	const unsigned int tCurrentGeneration = aPop.getCurrentGeneration();
	unsigned int tWindowSizeCurrentGeneration = 0;
	if(tCurrentGeneration >= tWindowSize)
		tWindowSizeCurrentGeneration = tWindowSize;
	else
		tWindowSizeCurrentGeneration = tCurrentGeneration;

	assert(tWindowSizeCurrentGeneration > 0);

	//Move the iterator to the start of the window
	const vector<unsigned int>::const_iterator itNumSpecies = m_vecNumSpecies.end() - tWindowSizeCurrentGeneration;
	const vector<double>::const_iterator itBestFitness = m_vecBestFitness.end() - tWindowSizeCurrentGeneration;
	const vector<double>::const_iterator itAvFitness = m_vecAvFitness.end() - tWindowSizeCurrentGeneration;

	const double tNumSpeciesDifferential = (*(m_vecNumSpecies.end() - 1)) - (*itNumSpecies);
	m_RateChangeNumSpecies = tNumSpeciesDifferential/tWindowSizeCurrentGeneration;

	const double tBestFitnessDifferential = (*(m_vecBestFitness.end() - 1)) - (*itBestFitness);
	m_RateChangeBestFitness = tBestFitnessDifferential/tWindowSizeCurrentGeneration;

	const double tAvFitnessDifferential = (*(m_vecAvFitness.end() - 1)) - (*itAvFitness);
	m_RateChangeAvFitness = tAvFitnessDifferential/tWindowSizeCurrentGeneration;

}

//------------------------------- GetFitnessScores -----------------------
//
//  returns a std::vector containing the genomes fitness scores
//------------------------------------------------------------------------
vector<double> CController::getFitnessScores() const
{
	vector<double> tScores;
	for( vector<Predictor>::const_iterator itPredictors = m_vecPredictors.begin(); itPredictors != m_vecPredictors.end(); ++itPredictors )
	{
		//scores.push_back(m_vecPredictors[i].Fitness());
		const double tScore = (*itPredictors).Fitness();
		assert(tScore <= 1);
		tScores.push_back(tScore);
	}
	return tScores;
}

void CController::printPopInfo() const
{
	assert(m_pPop);
	m_pPop->printPopInfo();
}


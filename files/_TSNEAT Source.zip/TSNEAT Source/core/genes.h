#ifndef RC_GENES_H
#define RC_GENES_H
//-----------------------------------------------------------------------
//
//  Name: Genes.h
//
//  Author: Mat Buckland 2002 (fup@btinternet.com)
//
//	Desc: neuron and link gene definitions used in the 
//        implementation of Kenneth Owen Stanley's and Risto 
//        Miikkulainen's NEAT idea.These structures are used to define
//        a genome.
//
//-----------------------------------------------------------------------

class CNeuron;

//------------------------------------------------------------------------
//
//  enumeration for all the available neuron types
//------------------------------------------------------------------------
enum neuron_type
{
  input,
  hidden,
  output,
  bias,
  none
};

//------------------------------------------------------------------------
//
//  this structure defines a neuron gene
//------------------------------------------------------------------------
struct SNeuronGene
{  
	//its identification
	int         iID;
	
	//its type
	neuron_type NeuronType;
	
	//is it recurrent
	bool        bRecurrent;
	
	//position in network grid
	double    dSplitY, dSplitX;
	
	//sets the curvature of the sigmoid function
	double    dActivationResponse;

	SNeuronGene(	neuron_type type,
			int         id,
			double      splitY,
			double      splitX,
			bool        r = false,
			double      act = 1):	iID(id),
						NeuronType(type),
						bRecurrent(r),
						dSplitY(splitY),
						dSplitX(splitX),
						dActivationResponse(act)
	{}

	//overload << for streaming
	friend ostream& operator <<(ostream &os, const SNeuronGene &rhs)
	{
		os << "\nNeuron: " << rhs.iID << "  Type: " << rhs.NeuronType
		<< "  Recurrent: " << rhs.bRecurrent << "  Activation: " << rhs.dActivationResponse
		<< "  SplitX: " << rhs.dSplitX << "  SplitY: " << rhs.dSplitY;
		
		return os;
	}
};

//------------------------------------------------------------------------
//
//  this structure defines a link gene
//------------------------------------------------------------------------
struct SLinkGene
{
	//flag to indicate if this link is currently enabled or not
	bool    bEnabled;

	int     InnovationID;

	//the IDs of the two neurons this link connects		
	int     FromNeuron,
		ToNeuron;

	float	dWeight;

	//flag to indicate if this link is recurrent or not
	bool    bRecurrent;

	SLinkGene(){}
	  
	SLinkGene(	const int	aIn,
			const int    aOut,
			const bool   aEnable,
			const int    aTag,
			const double aWeight,
			const bool   aRec = false):	bEnabled(aEnable),
							InnovationID(aTag),
							FromNeuron(aIn),
							ToNeuron(aOut),
							dWeight(aWeight),
							bRecurrent(aRec)
		{
		}

	//overload '<' used for sorting(we use the innovation ID as the criteria)
	friend bool operator<(const SLinkGene& lhs, const SLinkGene& rhs)
	{
		return (lhs.InnovationID < rhs.InnovationID);
	}

	//overload << for streaming
	friend ostream& operator <<(ostream &os, const SLinkGene &rhs)
	{
		os << "\nInnovID: " << rhs.InnovationID << "  From: " << rhs.FromNeuron
		<< "  To: " << rhs.ToNeuron << "  Enabled: " << rhs.bEnabled 
		<< "  Recurrent: " << rhs.bRecurrent << "  Weight: " << rhs.dWeight;

		return os;
	}
};
                                         
#endif 


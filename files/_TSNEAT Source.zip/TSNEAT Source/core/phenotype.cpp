#include "phenotype.h"

//------------------------------------Sigmoid function------------------------
//
//----------------------------------------------------------------------------

const float Sigmoid(const float aNetinput, const float aResponse)
{
	assert(aResponse != 0);
	if(aResponse ==0)
	{
		const string tExceptionString = (string) (__FUNCTION__) + " parameter 'aResponse' can not be equal to zero";
		throw tExceptionString;
	}

	const float tOutput = ( 1 / ( 1 + exp(-aNetinput / aResponse)));
	assert(tOutput >= 0);
	return tOutput;
}


//--------------------------------- ctor ---------------------------------
//
//------------------------------------------------------------------------
CNeuralNet::CNeuralNet(vector<SNeuron*> neurons, const int depth):	m_vecpNeurons(neurons),
                                              				m_iDepth(depth)
{}

CNeuralNet::CNeuralNet()
{

}

//--------------------------------- dtor ---------------------------------
//
//------------------------------------------------------------------------
CNeuralNet::~CNeuralNet()
{
	removeNeurons();
}

void CNeuralNet::removeNeurons()
{
	//delete any live neurons
	for (unsigned int i=0; i<m_vecpNeurons.size(); ++i)
	{
		if (m_vecpNeurons[i])
		{
			delete m_vecpNeurons[i];
			m_vecpNeurons[i] = NULL;
		}
	}
}

//----------------------------------Update--------------------------------
//	takes a list of doubles as inputs into the network then steps through 
//  the neurons calculating each neurons next output.
//
//	finally returns a std::vector of doubles as the output from the net.
//------------------------------------------------------------------------
vector<float> CNeuralNet::Update(	const vector<float> &inputs,
										const run_type type)
{
	//create a vector to put the outputs into
	vector<float>	outputs;

	//if the mode is snapshot then we require all the neurons to be
	//iterated through as many times as the network is deep. If the 
	//mode is set to active the method can return an output after
	//just one iteration
	int tFlushCount = 0;
  
	if (type == snapshot)
		tFlushCount = m_iDepth;
	else
		tFlushCount = 1;

	//iterate through the network FlushCount times
	for (int i=0; i<tFlushCount; ++i)
	{
		//clear the output vector
		outputs.clear();
   
		//this is an index into the current neuron
		unsigned int cNeuron = 0;

		//first set the outputs of the 'input' neurons to be equal
		//to the values passed into the function in inputs
		while (m_vecpNeurons[cNeuron]->NeuronType == input)
		{
			m_vecpNeurons[cNeuron]->dOutput = inputs[cNeuron];
			++cNeuron;
		}

		//set the output of the bias to 1
		m_vecpNeurons[cNeuron++]->dOutput = 1;

		//then we step through the network a neuron at a time
		while (cNeuron < m_vecpNeurons.size())
		{
			SNeuron* tCurrentNeuron = m_vecpNeurons[cNeuron];
			//this will hold the sum of all the inputs x weights 
			float tSum = 0;
		
			//sum this neuron's inputs by iterating through all the links into the neuron
			for( vector<SLink>::iterator it = tCurrentNeuron->vecLinksIn.begin(); it != tCurrentNeuron->vecLinksIn.end(); ++it )
			{
				const SLink& tLink = (*it);
				
				//get this link's weight
				const float tWeight = (const float) (tLink.dWeight);
		
				//get the output from the neuron this link is coming from
				const float tNeuronOutput = (const float) (tLink.pIn->dOutput);
		
				//add to sum
				tSum += tWeight * tNeuronOutput;
			}
		

			//now put the sum through the activation function and assign the value to this neuron's output
			tCurrentNeuron->dOutput = Sigmoid(tSum, (const float)(tCurrentNeuron->dActivationResponse));
				
			//add to our outputs
			if (tCurrentNeuron->NeuronType == output)
				outputs.push_back((const float) (tCurrentNeuron->dOutput));
	
			//next neuron
			++cNeuron;
		}

  	}//next iteration through the network

#if 1

	//the network needs to be flushed if this type of update is performed otherwise
	//it is possible for dependencies to be built on the order the training data is
	//presented
	if (type == snapshot)
	{
		for (unsigned int n=0; n<m_vecpNeurons.size(); ++n)
			m_vecpNeurons[n]->dOutput = 0;
	}

#endif

	//return the outputs
	return outputs;
}

SNeuron* CNeuralNet::getNeuronFromID(const int aNeuronID, const vector<SNeuron*>&  aNeurons)
{
	for( vector<SNeuron*>::const_iterator itNeurons = aNeurons.begin(); itNeurons != aNeurons.end(); ++itNeurons )
	{
		SNeuron* tNeuron = *itNeurons;
		if(tNeuron->iNeuronID == aNeuronID)
			return tNeuron;
	}
	return NULL;
}


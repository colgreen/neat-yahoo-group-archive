#ifndef RC_PHENOTYPE_H
#define RC_PHENOTYPE_H

//-----------------------------------------------------------------------
//
//  Name: phenotype.h
//
//  Author: Mat Buckland 2002 (fup@btinternet.com)
//
//	Desc: definitions required for the creation of a neural network. To be
//        used in the implementation of Kenneth Owen Stanley's NEAT idea.
//        
//-----------------------------------------------------------------------

#include <vector>
#include <math.h>
#include <algorithm>

#include "../common/utils.h"
#include "genes.h"

using namespace std;

struct SNeuron;

//------------------------------------------------------------------------
//
//  SLink structure 
//------------------------------------------------------------------------
struct SLink
{
	//the connection weight
	float  dWeight;

	//pointers to the neurons this link connects
	SNeuron*  pIn;
	SNeuron*  pOut;

	//is this link a recurrent link?
	bool    bRecurrent;

	SLink(const float aW, SNeuron* aIn, SNeuron* aOut, const bool aRec):	dWeight(aW),
										pIn(aIn),
										pOut(aOut),
										bRecurrent(aRec) 
								{}
};


//------------------------------------------------------------------------
//
//  SNeuron
//------------------------------------------------------------------------
struct SNeuron
{
	//all the links coming into this neuron
	vector<SLink> vecLinksIn;
	
	//and out
	vector<SLink> vecLinksOut;
	
	//sum of weights x inputs
	double        dSumActivation;
	
	//the output from this neuron
	double        dOutput;
	
	//what type of neuron is this?
	neuron_type   NeuronType;
	
	//its identification number
	int           iNeuronID;
	
	//sets the curvature of the sigmoid function
	double        dActivationResponse;
	
	//used in visualization of the phenotype
	int           iPosX,   iPosY;
	double        dSplitY, dSplitX;

	//--- ctors
	SNeuron(neuron_type type,
		int         id,
		double      y,
		double      x,
		double      ActResponse):	dSumActivation(0),
						dOutput(0),
						NeuronType(type),
						iNeuronID(id),
						dActivationResponse(ActResponse),
						iPosX(0),
						iPosY(0),
						dSplitY(y),
						dSplitX(x)
					
		{}
};

//------------------------------------------------------------------------
//
// CNeuralNet
//------------------------------------------------------------------------
class CNeuralNet
{
private:
 
	vector<SNeuron*>  m_vecpNeurons;
	//the depth of the network
	int               m_iDepth;

public:
 
	CNeuralNet(vector<SNeuron*> neurons, const int depth);
	CNeuralNet();
	~CNeuralNet();

	//you have to select one of these types when updating the network
	//If snapshot is chosen the network depth is used to completely
	//flush the inputs through the network. active just updates the
	//network each timestep
	enum run_type{snapshot, active};

	//update network for this clock cycle
	vector<float>  Update(const vector<float> &inputs, const run_type type=active);

	static SNeuron* getNeuronFromID(const int aNeuronID, const vector<SNeuron*>&  aNeurons);
	void removeNeurons();
		
	vector<SNeuron*> getNeurons() const { return m_vecpNeurons;}
};


#endif


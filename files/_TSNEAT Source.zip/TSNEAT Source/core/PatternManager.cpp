#include "PatternManager.h"

PatternManager::PatternManager(const string& aInputFilename, const unsigned int aNumInput)
{
	m_CurrentPatternIndex = -1;
	m_FileHandle.open(aInputFilename.c_str());
	const string tExceptinString = (string)(__FUNCTION__) + "Error opening Pattern file '" + aInputFilename + "'";
	if(!m_FileHandle)
		throw tExceptinString;

	m_NumInput = aNumInput;
}
PatternManager::~PatternManager()
{
	if(m_FileHandle)
		m_FileHandle.close();
}

const unsigned int PatternManager::getNumPatterns() const
{
	return m_Patterns.size();
}

const Pattern& PatternManager::getPattern(const unsigned int aPatternIndex) const
{
	if(aPatternIndex >= m_Patterns.size())
	{
		const string tExceptionString = "Array out of bounds exception";
		throw tExceptionString;
	}
	return m_Patterns[aPatternIndex];
}

void PatternManager::addPattern(const Pattern& aPattern)
{
	m_Patterns.push_back(aPattern);
}

const Pattern& PatternManager::getNextPattern()
{
	//Read patterns until there are no more in file then start iterating through list
	if(m_FileHandle)
	{
		Pattern tPattern;
		if(getPatternFromFile(tPattern))
		{
			m_Patterns.push_back(tPattern);
			return m_Patterns[m_Patterns.size() - 1];
		}
	}
	if(m_CurrentPatternIndex >= (int)(m_Patterns.size() - 1))
		m_CurrentPatternIndex = 0;
	else
		m_CurrentPatternIndex++;

	return m_Patterns[m_CurrentPatternIndex];
}

const unsigned int PatternManager::getCurrentPatternIndex() const
{	
	return m_CurrentPatternIndex;
}

void PatternManager::resetPatternIndex()
{
	m_CurrentPatternIndex = -1;
}

const bool PatternManager::getPatternFromFile(Pattern& aPattern)
{
	for(unsigned int i=0; i < m_NumInput; i++)
	{
		float tInput = (float)RC::CLEAR_FIELD_AMOUNT;
		m_FileHandle >> tInput;
		if(!m_FileHandle)
			return false;
		aPattern.addInput(tInput);
	}

	float tOutput = (float)RC::CLEAR_FIELD_AMOUNT;
	m_FileHandle >> tOutput;
	if(!m_FileHandle)
		return false;
	assert( tOutput <= 1 && tOutput >= -1);
	aPattern.setOutput(tOutput);
	return true;
}


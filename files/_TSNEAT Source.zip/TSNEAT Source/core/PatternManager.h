#ifndef RC_PATTERNMANAGER_H
#define RC_PATTERNMANAGER_H

//------------------------------------------------------------------------
//
//	Name: PatternManager.h
//
//  Author: Shane Ryan
//
//  Desc: Manages input patterns
//
//------------------------------------------------------------------------
#include <vector>
#include <fstream>
#include <exception>
#include "Pattern.h"
#include "../common/utils.h"

using namespace std;

class PatternManager
{

private:
	vector<Pattern> m_Patterns;
	int m_CurrentPatternIndex;
	ifstream m_FileHandle;
	unsigned int m_NumInput;

public:
	
	PatternManager(const string& aInputFilename, const unsigned int aNumInput);
	~PatternManager();

	const unsigned int getNumPatterns() const;
	const Pattern& getPattern(const unsigned int aPatternIndex) const;
	void addPattern(const Pattern& aPattern);

	const Pattern& getNextPattern();
	const unsigned int getCurrentPatternIndex() const;
	void resetPatternIndex();

	const bool getPatternFromFile(Pattern& aPattern);
 
};


#endif


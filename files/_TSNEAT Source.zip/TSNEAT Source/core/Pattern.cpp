#include "Pattern.h"

Pattern::Pattern()
{
	iOutput = (float)RC::CLEAR_FIELD_AMOUNT;
}
Pattern::Pattern(const vector<float>& aInputs, const float aOutput) : iInputs(aInputs), iOutput(aOutput)
{

	assert((aOutput <= 1.0) && (aOutput >= 0));
	if((aOutput > 1.0) || (aOutput < 0.0))
	{
		ostringstream tStringStream;
		tStringStream << __FUNCTION__ << ": Pattern has output greater than 1 this is not a possible output of the network.";
		tStringStream << " As outputs of the neurons are constrained to be between 1 and 0. The value was: " << aOutput << endl;
		const string tExceptionstring = tStringStream.str();
		throw tExceptionstring;
	}
}

const vector<float>& Pattern::getInputs() const
{
	return iInputs;
}

const unsigned int Pattern::getNumInputs() const
{
	return (const unsigned int) iInputs.size();
}

const float Pattern::getInput(const unsigned int aIndex) const
{
	return iInputs[aIndex];
}

const float Pattern::getOutput() const
{
	return iOutput;
}

void Pattern::addInput(const float aInput)
{
	iInputs.push_back(aInput);	
}

void Pattern::setOutput(const float aOutput)
{
	assert( aOutput <= 1 && aOutput >= 0);
	if((aOutput > 1.0) || (aOutput < 0))
	{
		ostringstream tStringStream;
		tStringStream << __FUNCTION__ << ": Pattern has output greater than 1 or less than 0.";
		tStringStream << " This is not a possible output of the network.";
		tStringStream << " As outputs of the neurons are constrained to be between 1 and 0. The value was: " << aOutput << endl;
		const string tExceptionstring = tStringStream.str();
		throw tExceptionstring;
	}		
	iOutput = aOutput;
}


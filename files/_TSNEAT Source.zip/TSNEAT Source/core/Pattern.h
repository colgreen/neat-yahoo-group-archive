#ifndef RC_PATTERN_H
#define RC_PATTERN_H

//------------------------------------------------------------------------
//
//	Name: Pattern.h
//
//  Author: Shane Ryan
//
//  Desc: Input pattern  
//
//------------------------------------------------------------------------
#include <vector>
#include "../common/utils.h"

using namespace std;

class Pattern
{

private:

	vector<float> iInputs;
	float iOutput;
	

public:
	
	Pattern();
	Pattern(const vector<float>& aInputs, const float aOutput);
	const vector<float>& getInputs() const;
	const unsigned int getNumInputs() const;
	const float getInput(const unsigned int aIndex) const;
	const float getOutput() const;
	void addInput(const float aInput);
	void setOutput(const float aOutput);
};
#endif
	

#include "CParams.h"

string CParams::iInputNet		= "";
string CParams::iInputFilename		= "";
string CParams::iOutputFilename		= "";
unsigned int CParams::iNumInput		= 0;
unsigned int CParams::iNumPatterns	= 0;

//this function loads in the parameters from a given file name. 
void CParams::LoadInParameters(const ConfigFile& aConfigFile)
{

	iInputNet = 			aConfigFile.read<string>("iInputNet");
	iInputFilename = 		aConfigFile.read<string>("iInputFilename");
	iOutputFilename = 		aConfigFile.read<string>("iOutputFilename");
	iNumInput = 			aConfigFile.read<unsigned int>("iNumInput");
	iNumPatterns = 			aConfigFile.read<unsigned int>("iNumPatterns");
}
 

  
  

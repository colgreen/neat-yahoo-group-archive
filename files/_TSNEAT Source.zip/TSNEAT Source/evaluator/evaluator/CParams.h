#ifndef RC_CPARAMS_H
#define RC_CPARAMS_H
//------------------------------------------------------------------------
//
//	Name: CParams.h
//
//
//  Desc: class to hold all the parameters used in this project. The values
//        are loaded in from an ini file
//       
//
//------------------------------------------------------------------------
#include "../common/Params.h"


using namespace std;	


class CParams: public Params
{

public:
  //-------------------------------------------------------------------
  //  general parameters
  //-------------------------------------------------------------------
	static string iInputNet;
 	static string iInputFilename;
	static string iOutputFilename;
	static unsigned int iNumInput;
	static unsigned int iNumPatterns;

  //---------------------------------------------

  //ctor
  CParams(){}

  void LoadInParameters(const ConfigFile& aConfigFile);
};

#endif




#include <fstream>
#include "../common/utils.h"
#include "../core/genotype.h"
#include "../core/PatternManager.h"
#include "CParams.h"

#ifdef _WIN32
	#include "windows.h"
#endif

#include <time.h>
#include <sys/timeb.h>

int main(int /*argc*/, char* /*argv[]*/)
{
	try {

		CParams tParams;
		tParams.Initialize("params.ini");
		//vector<float> tPredictedOutput;
		PatternManager tPatternManager(CParams::iInputFilename, CParams::iNumInput);
		
// 		CGenome tGenome;
// 		tGenome.CreateFromFile( CParams::iInputNet);
// 		CNeuralNet* tNeuralNet = tGenome.CreatePhenotype();

		CGenome tGenome0;
		tGenome0.CreateFromFile( "0.txt");
		CNeuralNet* tNeuralNet0 = tGenome0.CreatePhenotype();

// 		CGenome tGenome1;
// 		tGenome1.CreateFromFile( "1.txt");
// 		CNeuralNet* tNeuralNet1 = tGenome1.CreatePhenotype();
// 
// 		CGenome tGenome2;
// 		tGenome2.CreateFromFile( "2.txt");
// 		CNeuralNet* tNeuralNet2 = tGenome2.CreatePhenotype();
// 
// 
// 		CGenome tGenome3;
// 		tGenome3.CreateFromFile( "3.txt");
// 		CNeuralNet* tNeuralNet3 = tGenome3.CreatePhenotype();
		

		struct timeb tTempTime1, tStartOverallTime, tEndOverallTime; 
		ftime(&tStartOverallTime);
		ftime(&tTempTime1);

		ofstream tOutPutFile(CParams::iOutputFilename.c_str());
    		if (!tOutPutFile)
		{
			const string tExceptionString = (string)(__FUNCTION__) + "Error creating '" + CParams::iOutputFilename + "'";
			throw tExceptionString;
		}

		for(unsigned int i=0; i < CParams::iNumPatterns; i++)
		{
			const Pattern& tPattern = tPatternManager.getNextPattern();
			vector<float> tOutputs = tNeuralNet0->Update( tPattern.getInputs());
			const float tOutput = tOutputs[0];

// 			tOutputs = tNeuralNet1->Update( tPattern.getInputs());
// 			tOutput += tOutputs[0];
// 
// 			tOutputs = tNeuralNet2->Update( tPattern.getInputs());
// 			tOutput += tOutputs[0];
// 
// 			tOutputs = tNeuralNet3->Update( tPattern.getInputs());
// 			tOutput += tOutputs[0];
// 			
// 			tOutput /= 4;

			const float tActualOutput = tPattern.getOutput();
			tOutPutFile << tActualOutput << " " << tOutput << endl;
		}

		ftime(&tEndOverallTime);
		int tNumSeconds = (tEndOverallTime.time -  tStartOverallTime.time)*1000;
		int tNumSecondsMilli = (tEndOverallTime.millitm - tStartOverallTime.millitm);
		if(tNumSecondsMilli < 0)
			tNumSecondsMilli *= -1;
		tNumSeconds += tNumSecondsMilli;
		cout << "Overall time:\t" << tNumSeconds << endl;
		
	} catch(const string aException)
	{
		cout << "Exception:\t" << aException << endl;
	}
	
	return 0;
}


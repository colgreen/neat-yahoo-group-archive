
#include "pop_params.h"
#include "population.h"

#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

	const double PopParams::N_min = 0.1;
	const double PopParams::N_max = 0.9;


	const int PopParams::sc_num_trait_params = 8;


//	fitness buffer
	double PopParams::sc_fitness_buffer = 0.0;
	double PopParams::bsc_fitness_buffer = sc_fitness_buffer;
	const double PopParams::sc_fitness_buffer_max = 150.0;
	const double PopParams::sc_fitness_buffer_min = 0.0;
	const double PopParams::bsc_fitness_buffer_max = 1.5;
	const double PopParams::bsc_fitness_buffer_min = 0.0;


	int PopParams::sc_time_alive_minimum = 0;
	int PopParams::bsc_time_alive_minimum = sc_time_alive_minimum;

	double PopParams::sc_trait_param_mut_prob = 0.5;
	double PopParams::bsc_trait_param_mut_prob = sc_trait_param_mut_prob;
	const double PopParams::pop_trait_param_mut_prob_max = 1.0;
	const double PopParams::pop_trait_param_mut_prob_min = 0.0;

	double PopParams::sc_trait_mutation_power = 1.0;
	double PopParams::bsc_trait_mutation_power = sc_trait_mutation_power;
	const double PopParams::pop_trait_mutation_power_max = 3.0;
	const double PopParams::pop_trait_mutation_power_min = 0.0;

	double PopParams::sc_linktrait_mut_sig = 1.0;
	double PopParams::bsc_linktrait_mut_sig = sc_linktrait_mut_sig;
	const double PopParams::pop_linktrait_mut_sig_max = 10.0;
	const double PopParams::pop_linktrait_mut_sig_min = 0.0;

	double PopParams::sc_nodetrait_mut_sig = 0.5;
	double PopParams::bsc_nodetrait_mut_sig = sc_nodetrait_mut_sig;
	const double PopParams::pop_nodetrait_mut_sig_max = 10.0;
	const double PopParams::pop_nodetrait_mut_sig_min = 0.0;

	double PopParams::sc_weight_mut_power = 2.5;
	double PopParams::bsc_weight_mut_power = sc_weight_mut_power;
	const double PopParams::pop_weight_mut_power_max = 3.0;
	const double PopParams::pop_weight_mut_power_min = 0.0;

	double PopParams::sc_recur_prob = 0.0;
	double PopParams::bsc_recur_prob = sc_recur_prob;
	const double PopParams::pop_recur_prob_max = 1.0;
	const double PopParams::pop_recur_prob_min = 0.0;

	double PopParams::sc_disjoint_coeff = 1.0;
	double PopParams::bsc_disjoint_coeff = sc_disjoint_coeff;
	const double PopParams::pop_disjoint_coeff_max = 10.0;
	const double PopParams::pop_disjoint_coeff_min = 0.0;

	double PopParams::sc_excess_coeff = 1.0;
	double PopParams::bsc_excess_coeff = sc_excess_coeff;
	const double PopParams::pop_excess_coeff_max = 10.0;
	const double PopParams::pop_excess_coeff_min = 0.0;

	double PopParams::sc_mutdiff_coeff = 0.4;
	double PopParams::bsc_mutdiff_coeff = sc_mutdiff_coeff;
	const double PopParams::pop_mutdiff_coeff_max = 10.0;
	const double PopParams::pop_mutdiff_coeff_min = 0.0;

	double PopParams::sc_compat_threshold = 3.0;
	double PopParams::bsc_compat_threshold = sc_compat_threshold;
	const double PopParams::pop_compat_threshold_max = 10.0;
	const double PopParams::pop_compat_threshold_min = 0.0;

	double PopParams::sc_age_significance = 1.0;
	double PopParams::bsc_age_significance = sc_age_significance;
	const double PopParams::pop_age_significance_max = 10.0;
	const double PopParams::pop_age_significance_min = 0.0;

	double PopParams::sc_survival_thresh = 0.20;
	double PopParams::bsc_survival_thresh = sc_survival_thresh;
	const double PopParams::pop_survival_thresh_max = 1.0;
	const double PopParams::pop_survival_thresh_min = 0.0;

	double PopParams::sc_mutate_only_prob = 0.25;
	double PopParams::bsc_mutate_only_prob = sc_mutate_only_prob;
	const double PopParams::pop_mutate_only_prob_max = 1.0;
	const double PopParams::pop_mutate_only_prob_min = 0.0;

	double PopParams::sc_mutate_random_trait_prob = 0.1;
	double PopParams::bsc_mutate_random_trait_prob = sc_mutate_random_trait_prob;
	const double PopParams::pop_mutate_random_trait_prob_max = 1.0;
	const double PopParams::pop_mutate_random_trait_prob_min = 0.0;

	double PopParams::sc_mutate_link_trait_prob = 0.1;
	double PopParams::bsc_mutate_link_trait_prob = sc_mutate_link_trait_prob;
	const double PopParams::pop_mutate_link_trait_prob_max = 1.0;
	const double PopParams::pop_mutate_link_trait_prob_min = 0.0;

	double PopParams::sc_mutate_node_trait_prob = 0.1;
	double PopParams::bsc_mutate_node_trait_prob = sc_mutate_node_trait_prob;
	const double PopParams::pop_mutate_node_trait_prob_max = 1.0;
	const double PopParams::pop_mutate_node_trait_prob_min = 0.0;

	double PopParams::sc_mutate_link_weights_prob = 0.9;
	double PopParams::bsc_mutate_link_weights_prob = sc_mutate_link_weights_prob;
	const double PopParams::pop_mutate_link_weights_prob_max = 1.0;
	const double PopParams::pop_mutate_link_weights_prob_min = 0.0;

	double PopParams::sc_mutate_toggle_enable_prob = 0.00;
	double PopParams::bsc_mutate_toggle_enable_prob = sc_mutate_toggle_enable_prob;
	const double PopParams::pop_mutate_toggle_enable_prob_max = 1.0;
	const double PopParams::pop_mutate_toggle_enable_prob_min = 0.0;

	double PopParams::sc_mutate_gene_reenable_prob = 0.000;
	double PopParams::bsc_mutate_gene_reenable_prob = sc_mutate_gene_reenable_prob;
	const double PopParams::pop_mutate_gene_reenable_prob_max = 1.0;
	const double PopParams::pop_mutate_gene_reenable_prob_min = 0.0;

	double PopParams::sc_mutate_add_node_prob = 0.03;
	double PopParams::bsc_mutate_add_node_prob = sc_mutate_add_node_prob;
	const double PopParams::pop_mutate_add_node_prob_max = 1.0;
	const double PopParams::pop_mutate_add_node_prob_min = 0.0;

	double PopParams::sc_mutate_add_link_prob = 0.05;
	double PopParams::bsc_mutate_add_link_prob = sc_mutate_add_link_prob;
	const double PopParams::pop_mutate_add_link_prob_max = 1.0;
	const double PopParams::pop_mutate_add_link_prob_min = 0.0;

	double PopParams::sc_interspecies_mate_rate = 0.001;
	double PopParams::bsc_interspecies_mate_rate = sc_interspecies_mate_rate;
	const double PopParams::pop_interspecies_mate_rate_max = 1.0;
	const double PopParams::pop_interspecies_mate_rate_min = 0.0;

	double PopParams::sc_mate_multipoint_prob = 0.6;     
	double PopParams::bsc_mate_multipoint_prob = sc_mate_multipoint_prob;     
	const double PopParams::pop_mate_multipoint_prob_max = 1.0;
	const double PopParams::pop_mate_multipoint_prob_min = 0.0;

	double PopParams::sc_mate_multipoint_avg_prob = 0.4;
	double PopParams::bsc_mate_multipoint_avg_prob = sc_mate_multipoint_avg_prob;
	const double PopParams::pop_mate_multipoint_avg_prob_max = 1.0;
	const double PopParams::pop_mate_multipoint_avg_prob_min = 0.0;

	double PopParams::sc_mate_singlepoint_prob = 0.0;
	double PopParams::bsc_mate_singlepoint_prob = sc_mate_singlepoint_prob;
	const double PopParams::pop_mate_singlepoint_prob_max = 1.0;
	const double PopParams::pop_mate_singlepoint_prob_min = 0.0;

	double PopParams::sc_mate_only_prob = 0.2;
	double PopParams::bsc_mate_only_prob = sc_mate_only_prob;
	const double PopParams::pop_mate_only_prob_max = 1.0;
	const double PopParams::pop_mate_only_prob_min = 0.0;

	double PopParams::sc_recur_only_prob = 0.0;
	double PopParams::bsc_recur_only_prob = sc_recur_only_prob;
	const double PopParams::pop_recur_only_prob_max = 1.0;
	const double PopParams::pop_recur_only_prob_min = 0.0;

	int PopParams::sc_pop_size = 150;
	int PopParams::bsc_pop_size = sc_pop_size;
	const int PopParams::pop_pop_size_max = sc_pop_size;
	const int PopParams::pop_pop_size_min = sc_pop_size;

	int PopParams::sc_dropoff_age = 15;
	int PopParams::bsc_dropoff_age = sc_dropoff_age;
	const int PopParams::pop_dropoff_age_max = 100;
	const int PopParams::pop_dropoff_age_min = 1;

	int PopParams::sc_newlink_tries = 20;
	int PopParams::bsc_newlink_tries = sc_newlink_tries;
	const int PopParams::pop_newlink_tries_max = 100;
	const int PopParams::pop_newlink_tries_min = 1;

	int PopParams::sc_print_every = 5;
	int PopParams::bsc_print_every = sc_print_every;
	const int PopParams::pop_print_every_max = 10;
	const int PopParams::pop_print_every_min = 5;

	int PopParams::sc_babies_stolen = 0;
	int PopParams::bsc_babies_stolen = sc_babies_stolen;
	const int PopParams::pop_babies_stolen_max = sc_babies_stolen;
	const int PopParams::pop_babies_stolen_min = sc_babies_stolen;

	int PopParams::sc_num_runs = 1;
	int PopParams::bsc_num_runs = sc_num_runs;
	const int PopParams::pop_num_runs_max = sc_num_runs;
	const int PopParams::pop_num_runs_min = sc_num_runs;


	int PopParams::read_pop_time_alive_minimum(Population* pop) { return (pop->popparams).time_alive_minimum; }
	void PopParams::set_pop_time_alive_minimum(int i, Population* pop) { (pop->popparams).time_alive_minimum = i; }

	double PopParams::read_pop_trait_param_mut_prob(Population* pop) { return (pop->popparams).trait_param_mut_prob; }
	void PopParams::set_pop_trait_param_mut_prob(double d, Population* pop) { (pop->popparams).trait_param_mut_prob = d; }

	double PopParams::read_pop_trait_mutation_power(Population* pop) { return (pop->popparams).trait_mutation_power; }
	void PopParams::set_pop_trait_mutation_power(double d, Population* pop) { (pop->popparams).trait_mutation_power = d; }

	double PopParams::read_pop_linktrait_mut_sig(Population* pop) { return (pop->popparams).linktrait_mut_sig; }
	void PopParams::set_pop_linktrait_mut_sig(double d, Population* pop) { (pop->popparams).linktrait_mut_sig = d; }

	double PopParams::read_pop_nodetrait_mut_sig(Population* pop) { return (pop->popparams).nodetrait_mut_sig; }
	void PopParams::set_pop_nodetrait_mut_sig(double d, Population* pop) { (pop->popparams).nodetrait_mut_sig = d; }

	double PopParams::read_pop_weight_mut_power(Population* pop) { return (pop->popparams).weight_mut_power; }
	void PopParams::set_pop_weight_mut_power(double d, Population* pop) { (pop->popparams).weight_mut_power = d; }

	double PopParams::read_pop_recur_prob(Population* pop) { return (pop->popparams).recur_prob; }
	void PopParams::set_pop_recur_prob(double d, Population* pop) { (pop->popparams).recur_prob = d; }

	double PopParams::read_pop_disjoint_coeff(Population* pop) { return (pop->popparams).disjoint_coeff; }
	void PopParams::set_pop_disjoint_coeff(double d, Population* pop) { (pop->popparams).disjoint_coeff = d; }

	double PopParams::read_pop_excess_coeff(Population* pop) { return (pop->popparams).excess_coeff; }
	void PopParams::set_pop_excess_coeff(double d, Population* pop) { (pop->popparams).excess_coeff = d; }

	double PopParams::read_pop_mutdiff_coeff(Population* pop) { return (pop->popparams).mutdiff_coeff; }
	void PopParams::set_pop_mutdiff_coeff(double d, Population* pop) { (pop->popparams).mutdiff_coeff = d; }

	double PopParams::read_pop_compat_threshold(Population* pop) { return (pop->popparams).compat_threshold; }
	void PopParams::set_pop_compat_threshold(double d, Population* pop) { (pop->popparams).compat_threshold = d; }

	double PopParams::read_pop_age_significance(Population* pop) { return (pop->popparams).age_significance; }
	void PopParams::set_pop_age_significance(double d, Population* pop) { (pop->popparams).age_significance = d; }

	double PopParams::read_pop_survival_thresh(Population* pop) { return (pop->popparams).survival_thresh; }
	void PopParams::set_pop_survival_thresh(double d, Population* pop) { (pop->popparams).survival_thresh = d; }

	double PopParams::read_pop_mutate_only_prob(Population* pop) { return (pop->popparams).mutate_only_prob; }
	void PopParams::set_pop_mutate_only_prob(double d, Population* pop) { (pop->popparams).mutate_only_prob = d; }

	double PopParams::read_pop_mutate_random_trait_prob(Population* pop) { return (pop->popparams).mutate_random_trait_prob; }
	void PopParams::set_pop_mutate_random_trait_prob(double d, Population* pop) { (pop->popparams).mutate_random_trait_prob = d; }

	double PopParams::read_pop_mutate_link_trait_prob(Population* pop) { return (pop->popparams).mutate_link_trait_prob; }
	void PopParams::set_pop_mutate_link_trait_prob(double d, Population* pop) { (pop->popparams).mutate_link_trait_prob = d; }

	double PopParams::read_pop_mutate_node_trait_prob(Population* pop) { return (pop->popparams).mutate_node_trait_prob; }
	void PopParams::set_pop_mutate_node_trait_prob(double d, Population* pop) { (pop->popparams).mutate_node_trait_prob = d; }

	double PopParams::read_pop_mutate_link_weights_prob(Population* pop) { return (pop->popparams).mutate_link_weights_prob; }
	void PopParams::set_pop_mutate_link_weights_prob(double d, Population* pop) { (pop->popparams).mutate_link_weights_prob = d; }

	double PopParams::read_pop_mutate_toggle_enable_prob(Population* pop) { return (pop->popparams).mutate_toggle_enable_prob; }
	void PopParams::set_pop_mutate_toggle_enable_prob(double d, Population* pop) { (pop->popparams).mutate_toggle_enable_prob = d; }

	double PopParams::read_pop_mutate_gene_reenable_prob(Population* pop) { return (pop->popparams).mutate_gene_reenable_prob; }
	void PopParams::set_pop_mutate_gene_reenable_prob(double d, Population* pop) { (pop->popparams).mutate_gene_reenable_prob = d; }

	double PopParams::read_pop_mutate_add_node_prob(Population* pop) { return (pop->popparams).mutate_add_node_prob; }
	void PopParams::set_pop_mutate_add_node_prob(double d, Population* pop) { (pop->popparams).mutate_add_node_prob = d; }

	double PopParams::read_pop_mutate_add_link_prob(Population* pop) { return (pop->popparams).mutate_add_link_prob; }
	void PopParams::set_pop_mutate_add_link_prob(double d, Population* pop) { (pop->popparams).mutate_add_link_prob = d; }

	double PopParams::read_pop_interspecies_mate_rate(Population* pop) { return (pop->popparams).interspecies_mate_rate; }
	void PopParams::set_pop_interspecies_mate_rate(double d, Population* pop) { (pop->popparams).interspecies_mate_rate = d; }

	double PopParams::read_pop_mate_multipoint_prob(Population* pop) { return (pop->popparams).mate_multipoint_prob; }
	void PopParams::set_pop_mate_multipoint_prob(double d, Population* pop) { (pop->popparams).mate_multipoint_prob = d; }

	double PopParams::read_pop_mate_multipoint_avg_prob(Population* pop) { return (pop->popparams).mate_multipoint_avg_prob; }
	void PopParams::set_pop_mate_multipoint_avg_prob(double d, Population* pop) { (pop->popparams).mate_multipoint_avg_prob = d; }

	double PopParams::read_pop_mate_singlepoint_prob(Population* pop) { return (pop->popparams).mate_singlepoint_prob; }
	void PopParams::set_pop_mate_singlepoint_prob(double d, Population* pop) { (pop->popparams).mate_singlepoint_prob = d; }

	double PopParams::read_pop_mate_only_prob(Population* pop) { return (pop->popparams).mate_only_prob; }
	void PopParams::set_pop_mate_only_prob(double d, Population* pop) { (pop->popparams).mate_only_prob = d; }

	double PopParams::read_pop_recur_only_prob(Population* pop) { return (pop->popparams).recur_only_prob; }
	void PopParams::set_pop_recur_only_prob(double d, Population* pop) { (pop->popparams).recur_only_prob = d; }

	int PopParams::read_pop_pop_size(Population* pop) { return (pop->popparams).pop_size; }
	void PopParams::set_pop_pop_size(int i, Population* pop) { (pop->popparams).pop_size = i; }

	int PopParams::read_pop_dropoff_age(Population* pop) { return (pop->popparams).dropoff_age; }
	void PopParams::set_pop_dropoff_age(int i, Population* pop) { (pop->popparams).dropoff_age = i; }

	int PopParams::read_pop_newlink_tries(Population* pop) { return (pop->popparams).newlink_tries; }
	void PopParams::set_pop_newlink_tries(int i, Population* pop) { (pop->popparams).newlink_tries = i; }

	int PopParams::read_pop_print_every(Population* pop) { return (pop->popparams).print_every; }
	void PopParams::set_pop_print_every(int i, Population* pop) { (pop->popparams).print_every = i; }

	int PopParams::read_pop_babies_stolen(Population* pop) { return (pop->popparams).babies_stolen; }
	void PopParams::set_pop_babies_stolen(int i, Population* pop) { (pop->popparams).babies_stolen = i; }

	int PopParams::read_pop_num_runs(Population* pop) { return (pop->popparams).num_runs; }
	void PopParams::set_pop_num_runs(int i, Population* pop) { (pop->popparams).num_runs = i; }


//#################################################################################################
	double PopParams::normalize_input(double x,double x_min,double x_max,double N_min,double N_max,double N_prime, bool threshold) {

		if(threshold) {
			if(x >= x_max) {
				x = x_max;
				N_prime = N_max;
				return N_prime;
			}
			if(x <= x_min) {
				x = x_min;
				N_prime = N_min;
				return N_prime;
			}
		}

		if( x_max <= x_min ) {
			x = x_max;
			N_prime = N_max;
			return N_prime;
		}

		if( N_max <= N_min ) {
			N_prime = N_max;
			return N_prime;
		}

		double m = ( N_max - N_min ) / ( x_max - x_min );

		N_prime = N_min + ( m * x ) - ( m * x_min );

		if(threshold) {
			if(N_prime >= N_max) N_prime = N_max;
			if(N_prime <= N_min) N_prime = N_min;
		}
		return N_prime;
	}

//#################################################################################################


//#################################################################################################
	double PopParams::unnormalize_output(double x,double x_min,double x_max,double N_min,double N_max,double N_prime, bool threshold) {

		if(threshold) {
			if(N_prime >= N_max) {
				x = x_max;
				return x;
			}
			if(N_prime <= N_min) {
				x = x_min;
				return x;
			}
		}

		if( x_max <= x_min ) {
			x = x_max;
			return x;
		}

		if( N_max <= N_min ) {
			x = x_max;
			return x;
		}

		double m = ( N_max - N_min ) / ( x_max - x_min );

		x = ( N_prime - N_min + ( m * x_min ) ) / m;

		if(threshold) {
			if(x >= x_max) x = x_max;
			if(x <= x_min) x = x_min;
		}
		return x;
	}

//#################################################################################################


//#################################################################################################
	double PopParams::RoundNew(double val, int dp)
{
    int modifier = 1;
    for (int i = 0; i < dp; ++i)
        modifier *= 10;

    if(val < 0.0)
        return (ceil(val * modifier - 0.5) / modifier);
    return (floor(val * modifier + 0.5) / modifier);
}
//#################################################################################################




//#################################################################################################
	double PopParams::normalize_sc_fitness_buffer(double x, bool threshold) {
		
		double x_max = sc_fitness_buffer_max;
		double x_min = sc_fitness_buffer_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_bsc_fitness_buffer(double x, bool threshold) {
		
		double x_max = bsc_fitness_buffer_max;
		double x_min = bsc_fitness_buffer_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::unnormalize_sc_fitness_buffer(double N_prime, bool threshold) {
		
		double x_max = sc_fitness_buffer_max;
		double x_min = sc_fitness_buffer_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}

	double PopParams::unnormalize_bsc_fitness_buffer(double N_prime, bool threshold) {
		
		double x_max = bsc_fitness_buffer_max;
		double x_min = bsc_fitness_buffer_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################




//#################################################################################################
	double PopParams::normalize_read_pop_trait_param_mut_prob(Population* pop, bool threshold) {
		
		double x_max = pop_trait_param_mut_prob_max;
		double x_min = pop_trait_param_mut_prob_min;
		double x = PopParams::read_pop_trait_param_mut_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_trait_param_mut_prob(double x, bool threshold) {
		
		double x_max = pop_trait_param_mut_prob_max;
		double x_min = pop_trait_param_mut_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_trait_param_mut_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_trait_param_mut_prob_max;
		double x_min = pop_trait_param_mut_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_trait_param_mut_prob( x, pop );
	}

	double PopParams::unnormalize_pop_trait_param_mut_prob(double N_prime, bool threshold) {
		
		double x_max = pop_trait_param_mut_prob_max;
		double x_min = pop_trait_param_mut_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_trait_mutation_power(Population* pop, bool threshold) {
		
		double x_max = pop_trait_mutation_power_max;
		double x_min = pop_trait_mutation_power_min;
		double x = PopParams::read_pop_trait_mutation_power(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_trait_mutation_power(double x, bool threshold) {
		
		double x_max = pop_trait_mutation_power_max;
		double x_min = pop_trait_mutation_power_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_trait_mutation_power(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_trait_mutation_power_max;
		double x_min = pop_trait_mutation_power_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_trait_mutation_power( x, pop );
	}

	double PopParams::unnormalize_pop_trait_mutation_power(double N_prime, bool threshold) {
		
		double x_max = pop_trait_mutation_power_max;
		double x_min = pop_trait_mutation_power_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_linktrait_mut_sig(Population* pop, bool threshold) {
		
		double x_max = pop_linktrait_mut_sig_max;
		double x_min = pop_linktrait_mut_sig_min;
		double x = PopParams::read_pop_linktrait_mut_sig(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_linktrait_mut_sig(double x, bool threshold) {
		
		double x_max = pop_linktrait_mut_sig_max;
		double x_min = pop_linktrait_mut_sig_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_linktrait_mut_sig(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_linktrait_mut_sig_max;
		double x_min = pop_linktrait_mut_sig_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_linktrait_mut_sig( x, pop );
	}

	double PopParams::unnormalize_pop_linktrait_mut_sig(double N_prime, bool threshold) {
		
		double x_max = pop_linktrait_mut_sig_max;
		double x_min = pop_linktrait_mut_sig_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_nodetrait_mut_sig(Population* pop, bool threshold) {
		
		double x_max = pop_nodetrait_mut_sig_max;
		double x_min = pop_nodetrait_mut_sig_min;
		double x = PopParams::read_pop_nodetrait_mut_sig(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_nodetrait_mut_sig(double x, bool threshold) {
		
		double x_max = pop_nodetrait_mut_sig_max;
		double x_min = pop_nodetrait_mut_sig_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_nodetrait_mut_sig(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_nodetrait_mut_sig_max;
		double x_min = pop_nodetrait_mut_sig_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_nodetrait_mut_sig( x, pop );
	}

	double PopParams::unnormalize_pop_nodetrait_mut_sig(double N_prime, bool threshold) {
		
		double x_max = pop_nodetrait_mut_sig_max;
		double x_min = pop_nodetrait_mut_sig_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_weight_mut_power(Population* pop, bool threshold) {
		
		double x_max = pop_weight_mut_power_max;
		double x_min = pop_weight_mut_power_min;
		double x = PopParams::read_pop_weight_mut_power(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_weight_mut_power(double x, bool threshold) {
		
		double x_max = pop_weight_mut_power_max;
		double x_min = pop_weight_mut_power_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_weight_mut_power(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_weight_mut_power_max;
		double x_min = pop_weight_mut_power_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_weight_mut_power( x, pop );
	}

	double PopParams::unnormalize_pop_weight_mut_power(double N_prime, bool threshold) {
		
		double x_max = pop_weight_mut_power_max;
		double x_min = pop_weight_mut_power_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_recur_prob(Population* pop, bool threshold) {
		
		double x_max = pop_recur_prob_max;
		double x_min = pop_recur_prob_min;
		double x = PopParams::read_pop_recur_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_recur_prob(double x, bool threshold) {
		
		double x_max = pop_recur_prob_max;
		double x_min = pop_recur_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_recur_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_recur_prob_max;
		double x_min = pop_recur_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_recur_prob( x, pop );
	}

	double PopParams::unnormalize_pop_recur_prob(double N_prime, bool threshold) {
		
		double x_max = pop_recur_prob_max;
		double x_min = pop_recur_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_disjoint_coeff(Population* pop, bool threshold) {
		
		double x_max = pop_disjoint_coeff_max;
		double x_min = pop_disjoint_coeff_min;
		double x = PopParams::read_pop_disjoint_coeff(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_disjoint_coeff(double x, bool threshold) {
		
		double x_max = pop_disjoint_coeff_max;
		double x_min = pop_disjoint_coeff_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_disjoint_coeff(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_disjoint_coeff_max;
		double x_min = pop_disjoint_coeff_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_disjoint_coeff( x, pop );
	}

	double PopParams::unnormalize_pop_disjoint_coeff(double N_prime, bool threshold) {
		
		double x_max = pop_disjoint_coeff_max;
		double x_min = pop_disjoint_coeff_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_excess_coeff(Population* pop, bool threshold) {
		
		double x_max = pop_excess_coeff_max;
		double x_min = pop_excess_coeff_min;
		double x = PopParams::read_pop_excess_coeff(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_excess_coeff(double x, bool threshold) {
		
		double x_max = pop_excess_coeff_max;
		double x_min = pop_excess_coeff_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_excess_coeff(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_excess_coeff_max;
		double x_min = pop_excess_coeff_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_excess_coeff( x, pop );
	}

	double PopParams::unnormalize_pop_excess_coeff(double N_prime, bool threshold) {
		
		double x_max = pop_excess_coeff_max;
		double x_min = pop_excess_coeff_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mutdiff_coeff(Population* pop, bool threshold) {
		
		double x_max = pop_mutdiff_coeff_max;
		double x_min = pop_mutdiff_coeff_min;
		double x = PopParams::read_pop_mutdiff_coeff(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mutdiff_coeff(double x, bool threshold) {
		
		double x_max = pop_mutdiff_coeff_max;
		double x_min = pop_mutdiff_coeff_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mutdiff_coeff(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mutdiff_coeff_max;
		double x_min = pop_mutdiff_coeff_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mutdiff_coeff( x, pop );
	}

	double PopParams::unnormalize_pop_mutdiff_coeff(double N_prime, bool threshold) {
		
		double x_max = pop_mutdiff_coeff_max;
		double x_min = pop_mutdiff_coeff_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_compat_threshold(Population* pop, bool threshold) {
		
		double x_max = pop_compat_threshold_max;
		double x_min = pop_compat_threshold_min;
		double x = PopParams::read_pop_compat_threshold(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_compat_threshold(double x, bool threshold) {
		
		double x_max = pop_compat_threshold_max;
		double x_min = pop_compat_threshold_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_compat_threshold(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_compat_threshold_max;
		double x_min = pop_compat_threshold_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_compat_threshold( x, pop );
	}

	double PopParams::unnormalize_pop_compat_threshold(double N_prime, bool threshold) {
		
		double x_max = pop_compat_threshold_max;
		double x_min = pop_compat_threshold_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_age_significance(Population* pop, bool threshold) {
		
		double x_max = pop_age_significance_max;
		double x_min = pop_age_significance_min;
		double x = PopParams::read_pop_age_significance(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_age_significance(double x, bool threshold) {
		
		double x_max = pop_age_significance_max;
		double x_min = pop_age_significance_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_age_significance(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_age_significance_max;
		double x_min = pop_age_significance_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_age_significance( x, pop );
	}

	double PopParams::unnormalize_pop_age_significance(double N_prime, bool threshold) {
		
		double x_max = pop_age_significance_max;
		double x_min = pop_age_significance_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_survival_thresh(Population* pop, bool threshold) {
		
		double x_max = pop_survival_thresh_max;
		double x_min = pop_survival_thresh_min;
		double x = PopParams::read_pop_survival_thresh(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_survival_thresh(double x, bool threshold) {
		
		double x_max = pop_survival_thresh_max;
		double x_min = pop_survival_thresh_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_survival_thresh(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_survival_thresh_max;
		double x_min = pop_survival_thresh_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_survival_thresh( x, pop );
	}

	double PopParams::unnormalize_pop_survival_thresh(double N_prime, bool threshold) {
		
		double x_max = pop_survival_thresh_max;
		double x_min = pop_survival_thresh_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mutate_only_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mutate_only_prob_max;
		double x_min = pop_mutate_only_prob_min;
		double x = PopParams::read_pop_mutate_only_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mutate_only_prob(double x, bool threshold) {
		
		double x_max = pop_mutate_only_prob_max;
		double x_min = pop_mutate_only_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mutate_only_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mutate_only_prob_max;
		double x_min = pop_mutate_only_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mutate_only_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mutate_only_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mutate_only_prob_max;
		double x_min = pop_mutate_only_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mutate_random_trait_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mutate_random_trait_prob_max;
		double x_min = pop_mutate_random_trait_prob_min;
		double x = PopParams::read_pop_mutate_random_trait_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mutate_random_trait_prob(double x, bool threshold) {
		
		double x_max = pop_mutate_random_trait_prob_max;
		double x_min = pop_mutate_random_trait_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mutate_random_trait_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mutate_random_trait_prob_max;
		double x_min = pop_mutate_random_trait_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mutate_random_trait_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mutate_random_trait_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mutate_random_trait_prob_max;
		double x_min = pop_mutate_random_trait_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mutate_link_trait_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mutate_link_trait_prob_max;
		double x_min = pop_mutate_link_trait_prob_min;
		double x = PopParams::read_pop_mutate_link_trait_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mutate_link_trait_prob(double x, bool threshold) {
		
		double x_max = pop_mutate_link_trait_prob_max;
		double x_min = pop_mutate_link_trait_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mutate_link_trait_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mutate_link_trait_prob_max;
		double x_min = pop_mutate_link_trait_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mutate_link_trait_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mutate_link_trait_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mutate_link_trait_prob_max;
		double x_min = pop_mutate_link_trait_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mutate_node_trait_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mutate_node_trait_prob_max;
		double x_min = pop_mutate_node_trait_prob_min;
		double x = PopParams::read_pop_mutate_node_trait_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mutate_node_trait_prob(double x, bool threshold) {
		
		double x_max = pop_mutate_node_trait_prob_max;
		double x_min = pop_mutate_node_trait_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mutate_node_trait_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mutate_node_trait_prob_max;
		double x_min = pop_mutate_node_trait_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mutate_node_trait_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mutate_node_trait_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mutate_node_trait_prob_max;
		double x_min = pop_mutate_node_trait_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mutate_link_weights_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mutate_link_weights_prob_max;
		double x_min = pop_mutate_link_weights_prob_min;
		double x = PopParams::read_pop_mutate_link_weights_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mutate_link_weights_prob(double x, bool threshold) {
		
		double x_max = pop_mutate_link_weights_prob_max;
		double x_min = pop_mutate_link_weights_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mutate_link_weights_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mutate_link_weights_prob_max;
		double x_min = pop_mutate_link_weights_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mutate_link_weights_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mutate_link_weights_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mutate_link_weights_prob_max;
		double x_min = pop_mutate_link_weights_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mutate_toggle_enable_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mutate_toggle_enable_prob_max;
		double x_min = pop_mutate_toggle_enable_prob_min;
		double x = PopParams::read_pop_mutate_toggle_enable_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mutate_toggle_enable_prob(double x, bool threshold) {
		
		double x_max = pop_mutate_toggle_enable_prob_max;
		double x_min = pop_mutate_toggle_enable_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mutate_toggle_enable_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mutate_toggle_enable_prob_max;
		double x_min = pop_mutate_toggle_enable_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mutate_toggle_enable_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mutate_toggle_enable_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mutate_toggle_enable_prob_max;
		double x_min = pop_mutate_toggle_enable_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mutate_gene_reenable_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mutate_gene_reenable_prob_max;
		double x_min = pop_mutate_gene_reenable_prob_min;
		double x = PopParams::read_pop_mutate_gene_reenable_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mutate_gene_reenable_prob(double x, bool threshold) {
		
		double x_max = pop_mutate_gene_reenable_prob_max;
		double x_min = pop_mutate_gene_reenable_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mutate_gene_reenable_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mutate_gene_reenable_prob_max;
		double x_min = pop_mutate_gene_reenable_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mutate_gene_reenable_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mutate_gene_reenable_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mutate_gene_reenable_prob_max;
		double x_min = pop_mutate_gene_reenable_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mutate_add_node_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mutate_add_node_prob_max;
		double x_min = pop_mutate_add_node_prob_min;
		double x = PopParams::read_pop_mutate_add_node_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mutate_add_node_prob(double x, bool threshold) {
		
		double x_max = pop_mutate_add_node_prob_max;
		double x_min = pop_mutate_add_node_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mutate_add_node_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mutate_add_node_prob_max;
		double x_min = pop_mutate_add_node_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mutate_add_node_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mutate_add_node_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mutate_add_node_prob_max;
		double x_min = pop_mutate_add_node_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mutate_add_link_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mutate_add_link_prob_max;
		double x_min = pop_mutate_add_link_prob_min;
		double x = PopParams::read_pop_mutate_add_link_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mutate_add_link_prob(double x, bool threshold) {
		
		double x_max = pop_mutate_add_link_prob_max;
		double x_min = pop_mutate_add_link_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mutate_add_link_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mutate_add_link_prob_max;
		double x_min = pop_mutate_add_link_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mutate_add_link_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mutate_add_link_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mutate_add_link_prob_max;
		double x_min = pop_mutate_add_link_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_interspecies_mate_rate(Population* pop, bool threshold) {
		
		double x_max = pop_interspecies_mate_rate_max;
		double x_min = pop_interspecies_mate_rate_min;
		double x = PopParams::read_pop_interspecies_mate_rate(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_interspecies_mate_rate(double x, bool threshold) {
		
		double x_max = pop_interspecies_mate_rate_max;
		double x_min = pop_interspecies_mate_rate_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_interspecies_mate_rate(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_interspecies_mate_rate_max;
		double x_min = pop_interspecies_mate_rate_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_interspecies_mate_rate( x, pop );
	}

	double PopParams::unnormalize_pop_interspecies_mate_rate(double N_prime, bool threshold) {
		
		double x_max = pop_interspecies_mate_rate_max;
		double x_min = pop_interspecies_mate_rate_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mate_multipoint_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mate_multipoint_prob_max;
		double x_min = pop_mate_multipoint_prob_min;
		double x = PopParams::read_pop_mate_multipoint_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mate_multipoint_prob(double x, bool threshold) {
		
		double x_max = pop_mate_multipoint_prob_max;
		double x_min = pop_mate_multipoint_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mate_multipoint_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mate_multipoint_prob_max;
		double x_min = pop_mate_multipoint_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mate_multipoint_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mate_multipoint_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mate_multipoint_prob_max;
		double x_min = pop_mate_multipoint_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mate_multipoint_avg_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mate_multipoint_avg_prob_max;
		double x_min = pop_mate_multipoint_avg_prob_min;
		double x = PopParams::read_pop_mate_multipoint_avg_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mate_multipoint_avg_prob(double x, bool threshold) {
		
		double x_max = pop_mate_multipoint_avg_prob_max;
		double x_min = pop_mate_multipoint_avg_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mate_multipoint_avg_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mate_multipoint_avg_prob_max;
		double x_min = pop_mate_multipoint_avg_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mate_multipoint_avg_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mate_multipoint_avg_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mate_multipoint_avg_prob_max;
		double x_min = pop_mate_multipoint_avg_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mate_singlepoint_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mate_singlepoint_prob_max;
		double x_min = pop_mate_singlepoint_prob_min;
		double x = PopParams::read_pop_mate_singlepoint_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mate_singlepoint_prob(double x, bool threshold) {
		
		double x_max = pop_mate_singlepoint_prob_max;
		double x_min = pop_mate_singlepoint_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mate_singlepoint_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mate_singlepoint_prob_max;
		double x_min = pop_mate_singlepoint_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mate_singlepoint_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mate_singlepoint_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mate_singlepoint_prob_max;
		double x_min = pop_mate_singlepoint_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_mate_only_prob(Population* pop, bool threshold) {
		
		double x_max = pop_mate_only_prob_max;
		double x_min = pop_mate_only_prob_min;
		double x = PopParams::read_pop_mate_only_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_mate_only_prob(double x, bool threshold) {
		
		double x_max = pop_mate_only_prob_max;
		double x_min = pop_mate_only_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_mate_only_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_mate_only_prob_max;
		double x_min = pop_mate_only_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_mate_only_prob( x, pop );
	}

	double PopParams::unnormalize_pop_mate_only_prob(double N_prime, bool threshold) {
		
		double x_max = pop_mate_only_prob_max;
		double x_min = pop_mate_only_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_recur_only_prob(Population* pop, bool threshold) {
		
		double x_max = pop_recur_only_prob_max;
		double x_min = pop_recur_only_prob_min;
		double x = PopParams::read_pop_recur_only_prob(pop);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_recur_only_prob(double x, bool threshold) {
		
		double x_max = pop_recur_only_prob_max;
		double x_min = pop_recur_only_prob_min;

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);
		return N_prime;
	}

	void PopParams::unnormalize_set_pop_recur_only_prob(Population* pop, double N_prime, bool threshold) {
		
		double x_max = pop_recur_only_prob_max;
		double x_min = pop_recur_only_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		set_pop_recur_only_prob( x, pop );
	}

	double PopParams::unnormalize_pop_recur_only_prob(double N_prime, bool threshold) {
		
		double x_max = pop_recur_only_prob_max;
		double x_min = pop_recur_only_prob_min;

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return x;
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_pop_size(Population* pop, bool threshold) {
		
		double x_max = double(pop_pop_size_max);
		double x_min = double(pop_pop_size_min);
		double x = double(PopParams::read_pop_pop_size(pop));

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_pop_size(int x, bool threshold) {

		double x_d = double(x);
		
		double x_max = double(pop_pop_size_max);
		double x_min = double(pop_pop_size_min);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_pop_size(Population* pop, double N_prime, bool threshold) {
		
		double x_max = double(pop->popparams.pop_pop_size_max);
		double x_min = double(pop->popparams.pop_pop_size_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		set_pop_pop_size( int(x), pop );
	}

	int PopParams::unnormalize_pop_pop_size(double N_prime, bool threshold) {
		
		double x_max = double(pop_pop_size_max);
		double x_min = double(pop_pop_size_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		return int(x);
	}

//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_dropoff_age(Population* pop, bool threshold) {
		
		double x_max = double(pop_dropoff_age_max);
		double x_min = double(pop_dropoff_age_min);
		double x = double(PopParams::read_pop_dropoff_age(pop));

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_dropoff_age(int x, bool threshold) {
		
		double x_d = double(x);

		double x_max = double(pop_dropoff_age_max);
		double x_min = double(pop_dropoff_age_min);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_dropoff_age(Population* pop, double N_prime, bool threshold) {
		
		double x_max = double(pop_dropoff_age_max);
		double x_min = double(pop_dropoff_age_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		set_pop_dropoff_age( int(x), pop );
	}

	int PopParams::unnormalize_pop_dropoff_age(double N_prime, bool threshold) {
		
		double x_max = double(pop_dropoff_age_max);
		double x_min = double(pop_dropoff_age_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		return int(x);
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_newlink_tries(Population* pop, bool threshold) {
		
		double x_max = double(pop_newlink_tries_max);
		double x_min = double(pop_newlink_tries_min);
		double x = double(PopParams::read_pop_newlink_tries(pop));

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_newlink_tries(int x, bool threshold) {

		double x_d = double(x);
		
		double x_max = double(pop_newlink_tries_max);
		double x_min = double(pop_newlink_tries_min);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_newlink_tries(Population* pop, double N_prime, bool threshold) {
		
		double x_max = double(pop_newlink_tries_max);
		double x_min = double(pop_newlink_tries_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		set_pop_newlink_tries( int(x), pop );
	}

	int PopParams::unnormalize_pop_newlink_tries(double N_prime, bool threshold) {
		
		double x_max = double(pop_newlink_tries_max);
		double x_min = double(pop_newlink_tries_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		return int(x);
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_print_every(Population* pop, bool threshold) {
		
		double x_max = double(pop_print_every_max);
		double x_min = double(pop_print_every_min);
		double x = double(PopParams::read_pop_print_every(pop));

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_print_every(int x, bool threshold) {

		double x_d = double(x);

		double x_max = double(pop_print_every_max);
		double x_min = double(pop_print_every_min);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_print_every(Population* pop, double N_prime, bool threshold) {
		
		double x_max = double(pop_print_every_max);
		double x_min = double(pop_print_every_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		set_pop_print_every( int(x), pop );
	}

	int PopParams::unnormalize_pop_print_every(double N_prime, bool threshold) {
		
		double x_max = double(pop_print_every_max);
		double x_min = double(pop_print_every_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		return int(x);
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_babies_stolen(Population* pop, bool threshold) {
		
		double x_max = double(pop_babies_stolen_max);
		double x_min = double(pop_babies_stolen_min);
		double x = double(PopParams::read_pop_babies_stolen(pop));

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_babies_stolen(int x, bool threshold) {

		double x_d = double(x);
		
		double x_max = double(pop_babies_stolen_max);
		double x_min = double(pop_babies_stolen_min);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_babies_stolen(Population* pop, double N_prime, bool threshold) {
		
		double x_max = double(pop_babies_stolen_max);
		double x_min = double(pop_babies_stolen_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		set_pop_babies_stolen( int(x), pop );
	}

	int PopParams::unnormalize_pop_babies_stolen(double N_prime, bool threshold) {
		
		double x_max = double(pop_babies_stolen_max);
		double x_min = double(pop_babies_stolen_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		return int(x);
	}
//#################################################################################################


//#################################################################################################
	double PopParams::normalize_read_pop_num_runs(Population* pop, bool threshold) {
		
		double x_max = double(pop_num_runs_max);
		double x_min = double(pop_num_runs_min);
		double x = double(PopParams::read_pop_num_runs(pop));

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	double PopParams::normalize_pop_num_runs(int x, bool threshold) {

		double x_d = double(x);
		
		double x_max = double(pop_num_runs_max);
		double x_min = double(pop_num_runs_min);

		double N_prime = 0.0;

		N_prime = PopParams::normalize_input(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		return N_prime;
	}

	void PopParams::unnormalize_set_pop_num_runs(Population* pop, double N_prime, bool threshold) {
		
		double x_max = double(pop_num_runs_max);
		double x_min = double(pop_num_runs_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		set_pop_num_runs( int(x), pop );
	}

	int PopParams::unnormalize_pop_num_runs(double N_prime, bool threshold) {
		
		double x_max = double(pop_num_runs_max);
		double x_min = double(pop_num_runs_min);

		double x = 0.0;

		x = PopParams::unnormalize_output(x,x_min,x_max,N_min,N_max,N_prime,threshold);

		x = PopParams::RoundNew(x,0);

		return int(x);
	}
//#################################################################################################


//#################################################################################################
PopParams::PopParams() :
	
	time_alive_minimum(sc_time_alive_minimum),
	trait_param_mut_prob(sc_trait_param_mut_prob),
	trait_mutation_power(sc_trait_mutation_power),			// Power of mutation on a signle trait param 
	linktrait_mut_sig(sc_linktrait_mut_sig),				// Amount that mutation_num changes for a trait change inside a link
	nodetrait_mut_sig(sc_nodetrait_mut_sig),				// Amount a mutation_num changes on a link connecting a node that changed its trait 
	weight_mut_power(sc_weight_mut_power),					// The power of a linkweight mutation 
	recur_prob(sc_recur_prob),								// Prob. that a link mutation which doesn't have to be recurrent will be made recurrent 
	disjoint_coeff(sc_disjoint_coeff),
	excess_coeff(sc_excess_coeff),
	mutdiff_coeff(sc_mutdiff_coeff),
	compat_threshold(sc_compat_threshold),
	age_significance(sc_age_significance),					// How much does age matter? 
	survival_thresh(sc_survival_thresh),					// Percent of ave fitness for survival 
	mutate_only_prob(sc_mutate_only_prob),					// Prob. of a non-mating reproduction 
	mutate_random_trait_prob(sc_mutate_random_trait_prob),
	mutate_link_trait_prob(sc_mutate_link_trait_prob),
	mutate_node_trait_prob(sc_mutate_node_trait_prob),
	mutate_link_weights_prob(sc_mutate_link_weights_prob),
	mutate_toggle_enable_prob(sc_mutate_toggle_enable_prob),
	mutate_gene_reenable_prob(sc_mutate_gene_reenable_prob),
	mutate_add_node_prob(sc_mutate_add_node_prob),
	mutate_add_link_prob(sc_mutate_add_link_prob),
	interspecies_mate_rate(sc_interspecies_mate_rate),		// Prob. of a mate being outside species 
	mate_multipoint_prob(sc_mate_multipoint_prob),     
	mate_multipoint_avg_prob(sc_mate_multipoint_avg_prob),
	mate_singlepoint_prob(sc_mate_singlepoint_prob),
	mate_only_prob(sc_mate_only_prob),						// Prob. of mating without mutation 
	recur_only_prob(sc_recur_only_prob),					// Probability of forcing selection of ONLY links that are naturally recurrent 
	pop_size(sc_pop_size),									// Size of population 
	dropoff_age(sc_dropoff_age),							// Age where Species starts to be penalized 
	newlink_tries(sc_newlink_tries),						// Number of tries mutate_add_link will attempt to find an open link 
	print_every(sc_print_every),							// Tells to print population to file every n generations 
	babies_stolen(sc_babies_stolen),						// The number of babies to siphen off to the champions 
	num_runs(sc_num_runs)
	
	{}

//#################################################################################################


//#################################################################################################
void PopParams::initializer() {
	
	time_alive_minimum = read_sc_time_alive_minimum();
	trait_param_mut_prob = read_sc_trait_param_mut_prob();
	trait_mutation_power = read_sc_trait_mutation_power();			// Power of mutation on a signle trait param 
	linktrait_mut_sig = read_sc_linktrait_mut_sig();				// Amount that mutation_num changes for a trait change inside a link
	nodetrait_mut_sig = read_sc_nodetrait_mut_sig();				// Amount a mutation_num changes on a link connecting a node that changed its trait 
	weight_mut_power = read_sc_weight_mut_power();					// The power of a linkweight mutation 
	recur_prob = read_sc_recur_prob();								// Prob. that a link mutation which doesn't have to be recurrent will be made recurrent 
	disjoint_coeff = read_sc_disjoint_coeff();
	excess_coeff = read_sc_excess_coeff();
	mutdiff_coeff = read_sc_mutdiff_coeff();
	compat_threshold = read_sc_compat_threshold();
	age_significance = read_sc_age_significance();					// How much does age matter? 
	survival_thresh = read_sc_survival_thresh();					// Percent of ave fitness for survival 
	mutate_only_prob = read_sc_mutate_only_prob();					// Prob. of a non-mating reproduction 
	mutate_random_trait_prob = read_sc_mutate_random_trait_prob();
	mutate_link_trait_prob = read_sc_mutate_link_trait_prob();
	mutate_node_trait_prob = read_sc_mutate_node_trait_prob();
	mutate_link_weights_prob = read_sc_mutate_link_weights_prob();
	mutate_toggle_enable_prob = read_sc_mutate_toggle_enable_prob();
	mutate_gene_reenable_prob = read_sc_mutate_gene_reenable_prob();
	mutate_add_node_prob = read_sc_mutate_add_node_prob();
	mutate_add_link_prob = read_sc_mutate_add_link_prob();
	interspecies_mate_rate = read_sc_interspecies_mate_rate();		// Prob. of a mate being outside species 
	mate_multipoint_prob = read_sc_mate_multipoint_prob();     
	mate_multipoint_avg_prob = read_sc_mate_multipoint_avg_prob();
	mate_singlepoint_prob = read_sc_mate_singlepoint_prob();
	mate_only_prob = read_sc_mate_only_prob();						// Prob. of mating without mutation 
	recur_only_prob = read_sc_recur_only_prob();					// Probability of forcing selection of ONLY links that are naturally recurrent 
	pop_size = read_sc_pop_size();									// Size of population 
	dropoff_age = read_sc_dropoff_age();							// Age where Species starts to be penalized 
	newlink_tries = read_sc_newlink_tries();						// Number of tries mutate_add_link will attempt to find an open link 
	print_every = read_sc_print_every();							// Tells to print population to file every n generations 
	babies_stolen = read_sc_babies_stolen();						// The number of babies to siphen off to the champions 
	num_runs = read_sc_num_runs();
	
	}

//#################################################################################################


//#################################################################################################
void PopParams::initializer(Population* pop) {
	
	(pop->popparams).time_alive_minimum = read_sc_time_alive_minimum();
	(pop->popparams).trait_param_mut_prob = read_sc_trait_param_mut_prob();
	(pop->popparams).trait_mutation_power = read_sc_trait_mutation_power();			// Power of mutation on a signle trait param 
	(pop->popparams).linktrait_mut_sig = read_sc_linktrait_mut_sig();				// Amount that mutation_num changes for a trait change inside a link
	(pop->popparams).nodetrait_mut_sig = read_sc_nodetrait_mut_sig();				// Amount a mutation_num changes on a link connecting a node that changed its trait 
	(pop->popparams).weight_mut_power = read_sc_weight_mut_power();					// The power of a linkweight mutation 
	(pop->popparams).recur_prob = read_sc_recur_prob();								// Prob. that a link mutation which doesn't have to be recurrent will be made recurrent 
	(pop->popparams).disjoint_coeff = read_sc_disjoint_coeff();
	(pop->popparams).excess_coeff = read_sc_excess_coeff();
	(pop->popparams).mutdiff_coeff = read_sc_mutdiff_coeff();
	(pop->popparams).compat_threshold = read_sc_compat_threshold();
	(pop->popparams).age_significance = read_sc_age_significance();					// How much does age matter? 
	(pop->popparams).survival_thresh = read_sc_survival_thresh();					// Percent of ave fitness for survival 
	(pop->popparams).mutate_only_prob = read_sc_mutate_only_prob();					// Prob. of a non-mating reproduction 
	(pop->popparams).mutate_random_trait_prob = read_sc_mutate_random_trait_prob();
	(pop->popparams).mutate_link_trait_prob = read_sc_mutate_link_trait_prob();
	(pop->popparams).mutate_node_trait_prob = read_sc_mutate_node_trait_prob();
	(pop->popparams).mutate_link_weights_prob = read_sc_mutate_link_weights_prob();
	(pop->popparams).mutate_toggle_enable_prob = read_sc_mutate_toggle_enable_prob();
	(pop->popparams).mutate_gene_reenable_prob = read_sc_mutate_gene_reenable_prob();
	(pop->popparams).mutate_add_node_prob = read_sc_mutate_add_node_prob();
	(pop->popparams).mutate_add_link_prob = read_sc_mutate_add_link_prob();
	(pop->popparams).interspecies_mate_rate = read_sc_interspecies_mate_rate();		// Prob. of a mate being outside species 
	(pop->popparams).mate_multipoint_prob = read_sc_mate_multipoint_prob();     
	(pop->popparams).mate_multipoint_avg_prob = read_sc_mate_multipoint_avg_prob();
	(pop->popparams).mate_singlepoint_prob = read_sc_mate_singlepoint_prob();
	(pop->popparams).mate_only_prob = read_sc_mate_only_prob();						// Prob. of mating without mutation 
	(pop->popparams).recur_only_prob = read_sc_recur_only_prob();					// Probability of forcing selection of ONLY links that are naturally recurrent 
	(pop->popparams).pop_size = read_sc_pop_size();									// Size of population 
	(pop->popparams).dropoff_age = read_sc_dropoff_age();							// Age where Species starts to be penalized 
	(pop->popparams).newlink_tries = read_sc_newlink_tries();						// Number of tries mutate_add_link will attempt to find an open link 
	(pop->popparams).print_every = read_sc_print_every();							// Tells to print population to file every n generations 
	(pop->popparams).babies_stolen = read_sc_babies_stolen();						// The number of babies to siphen off to the champions 
	(pop->popparams).num_runs = read_sc_num_runs();

	}

//#################################################################################################


//#################################################################################################
void PopParams::initializer_bsc(Population* pop) {
	
	(pop->popparams).time_alive_minimum = read_bsc_time_alive_minimum();
	(pop->popparams).trait_param_mut_prob = read_bsc_trait_param_mut_prob();
	(pop->popparams).trait_mutation_power = read_bsc_trait_mutation_power();		// Power of mutation on a signle trait param 
	(pop->popparams).linktrait_mut_sig = read_bsc_linktrait_mut_sig();				// Amount that mutation_num changes for a trait change inside a link
	(pop->popparams).nodetrait_mut_sig = read_bsc_nodetrait_mut_sig();				// Amount a mutation_num changes on a link connecting a node that changed its trait 
	(pop->popparams).weight_mut_power = read_bsc_weight_mut_power();				// The power of a linkweight mutation 
	(pop->popparams).recur_prob = read_bsc_recur_prob();							// Prob. that a link mutation which doesn't have to be recurrent will be made recurrent 
	(pop->popparams).disjoint_coeff = read_bsc_disjoint_coeff();
	(pop->popparams).excess_coeff = read_bsc_excess_coeff();
	(pop->popparams).mutdiff_coeff = read_bsc_mutdiff_coeff();
	(pop->popparams).compat_threshold = read_bsc_compat_threshold();
	(pop->popparams).age_significance = read_bsc_age_significance();				// How much does age matter? 
	(pop->popparams).survival_thresh = read_bsc_survival_thresh();					// Percent of ave fitness for survival 
	(pop->popparams).mutate_only_prob = read_bsc_mutate_only_prob();				// Prob. of a non-mating reproduction 
	(pop->popparams).mutate_random_trait_prob = read_bsc_mutate_random_trait_prob();
	(pop->popparams).mutate_link_trait_prob = read_bsc_mutate_link_trait_prob();
	(pop->popparams).mutate_node_trait_prob = read_bsc_mutate_node_trait_prob();
	(pop->popparams).mutate_link_weights_prob = read_bsc_mutate_link_weights_prob();
	(pop->popparams).mutate_toggle_enable_prob = read_bsc_mutate_toggle_enable_prob();
	(pop->popparams).mutate_gene_reenable_prob = read_bsc_mutate_gene_reenable_prob();
	(pop->popparams).mutate_add_node_prob = read_bsc_mutate_add_node_prob();
	(pop->popparams).mutate_add_link_prob = read_bsc_mutate_add_link_prob();
	(pop->popparams).interspecies_mate_rate = read_bsc_interspecies_mate_rate();	// Prob. of a mate being outside species 
	(pop->popparams).mate_multipoint_prob = read_bsc_mate_multipoint_prob();     
	(pop->popparams).mate_multipoint_avg_prob = read_bsc_mate_multipoint_avg_prob();
	(pop->popparams).mate_singlepoint_prob = read_bsc_mate_singlepoint_prob();
	(pop->popparams).mate_only_prob = read_bsc_mate_only_prob();					// Prob. of mating without mutation 
	(pop->popparams).recur_only_prob = read_bsc_recur_only_prob();					// Probability of forcing selection of ONLY links that are naturally recurrent 
	(pop->popparams).pop_size = read_bsc_pop_size();								// Size of population 
	(pop->popparams).dropoff_age = read_bsc_dropoff_age();							// Age where Species starts to be penalized 
	(pop->popparams).newlink_tries = read_bsc_newlink_tries();						// Number of tries mutate_add_link will attempt to find an open link 
	(pop->popparams).print_every = read_bsc_print_every();							// Tells to print population to file every n generations 
	(pop->popparams).babies_stolen = read_bsc_babies_stolen();						// The number of babies to siphen off to the champions 
	(pop->popparams).num_runs = read_bsc_num_runs();

	}

//#################################################################################################


//#################################################################################################
void PopParams::initializer(Population* popfrom, Population* popto) {
	
	(popto->popparams).time_alive_minimum = (popfrom->popparams).time_alive_minimum;
	(popto->popparams).trait_param_mut_prob = (popfrom->popparams).trait_param_mut_prob;
	(popto->popparams).trait_mutation_power = (popfrom->popparams).trait_mutation_power;		// Power of mutation on a signle trait param 
	(popto->popparams).linktrait_mut_sig = (popfrom->popparams).linktrait_mut_sig;				// Amount that mutation_num changes for a trait change inside a link
	(popto->popparams).nodetrait_mut_sig = (popfrom->popparams).nodetrait_mut_sig;				// Amount a mutation_num changes on a link connecting a node that changed its trait 
	(popto->popparams).weight_mut_power = (popfrom->popparams).weight_mut_power;				// The power of a linkweight mutation 
	(popto->popparams).recur_prob = (popfrom->popparams).recur_prob;							// Prob. that a link mutation which doesn't have to be recurrent will be made recurrent 
	(popto->popparams).disjoint_coeff = (popfrom->popparams).disjoint_coeff;
	(popto->popparams).excess_coeff = (popfrom->popparams).excess_coeff;
	(popto->popparams).mutdiff_coeff = (popfrom->popparams).mutdiff_coeff;
	(popto->popparams).compat_threshold = (popfrom->popparams).compat_threshold;
	(popto->popparams).age_significance = (popfrom->popparams).age_significance;				// How much does age matter? 
	(popto->popparams).survival_thresh = (popfrom->popparams).survival_thresh;					// Percent of ave fitness for survival 
	(popto->popparams).mutate_only_prob = (popfrom->popparams).mutate_only_prob;				// Prob. of a non-mating reproduction 
	(popto->popparams).mutate_random_trait_prob = (popfrom->popparams).mutate_random_trait_prob;
	(popto->popparams).mutate_link_trait_prob = (popfrom->popparams).mutate_link_trait_prob;
	(popto->popparams).mutate_node_trait_prob = (popfrom->popparams).mutate_node_trait_prob;
	(popto->popparams).mutate_link_weights_prob = (popfrom->popparams).mutate_link_weights_prob;
	(popto->popparams).mutate_toggle_enable_prob = (popfrom->popparams).mutate_toggle_enable_prob;
	(popto->popparams).mutate_gene_reenable_prob = (popfrom->popparams).mutate_gene_reenable_prob;
	(popto->popparams).mutate_add_node_prob = (popfrom->popparams).mutate_add_node_prob;
	(popto->popparams).mutate_add_link_prob = (popfrom->popparams).mutate_add_link_prob;
	(popto->popparams).interspecies_mate_rate = (popfrom->popparams).interspecies_mate_rate;	// Prob. of a mate being outside species 
	(popto->popparams).mate_multipoint_prob = (popfrom->popparams).mate_multipoint_prob;     
	(popto->popparams).mate_multipoint_avg_prob = (popfrom->popparams).mate_multipoint_avg_prob;
	(popto->popparams).mate_singlepoint_prob = (popfrom->popparams).mate_singlepoint_prob;
	(popto->popparams).mate_only_prob = (popfrom->popparams).mate_only_prob;					// Prob. of mating without mutation 
	(popto->popparams).recur_only_prob = (popfrom->popparams).recur_only_prob;					// Probability of forcing selection of ONLY links that are naturally recurrent 
	(popto->popparams).pop_size = (popfrom->popparams).pop_size;								// Size of population 
	(popto->popparams).dropoff_age = (popfrom->popparams).dropoff_age;							// Age where Species starts to be penalized 
	(popto->popparams).newlink_tries = (popfrom->popparams).newlink_tries;						// Number of tries mutate_add_link will attempt to find an open link 
	(popto->popparams).print_every = (popfrom->popparams).print_every;							// Tells to print population to file every n generations 
	(popto->popparams).babies_stolen = (popfrom->popparams).babies_stolen;						// The number of babies to siphen off to the champions 
	(popto->popparams).num_runs = (popfrom->popparams).num_runs;

	}

//#################################################################################################


//#################################################################################################
void PopParams::initializer(const Population& popfrom, Population* popto) {
	
	(popto->popparams).time_alive_minimum = popfrom.popparams.time_alive_minimum;
	(popto->popparams).trait_param_mut_prob = popfrom.popparams.trait_param_mut_prob;
	(popto->popparams).trait_mutation_power = popfrom.popparams.trait_mutation_power;		// Power of mutation on a signle trait param 
	(popto->popparams).linktrait_mut_sig = popfrom.popparams.linktrait_mut_sig;				// Amount that mutation_num changes for a trait change inside a link
	(popto->popparams).nodetrait_mut_sig = popfrom.popparams.nodetrait_mut_sig;				// Amount a mutation_num changes on a link connecting a node that changed its trait 
	(popto->popparams).weight_mut_power = popfrom.popparams.weight_mut_power;				// The power of a linkweight mutation 
	(popto->popparams).recur_prob = popfrom.popparams.recur_prob;							// Prob. that a link mutation which doesn't have to be recurrent will be made recurrent 
	(popto->popparams).disjoint_coeff = popfrom.popparams.disjoint_coeff;
	(popto->popparams).excess_coeff = popfrom.popparams.excess_coeff;
	(popto->popparams).mutdiff_coeff = popfrom.popparams.mutdiff_coeff;
	(popto->popparams).compat_threshold = popfrom.popparams.compat_threshold;
	(popto->popparams).age_significance = popfrom.popparams.age_significance;				// How much does age matter? 
	(popto->popparams).survival_thresh = popfrom.popparams.survival_thresh;					// Percent of ave fitness for survival 
	(popto->popparams).mutate_only_prob = popfrom.popparams.mutate_only_prob;				// Prob. of a non-mating reproduction 
	(popto->popparams).mutate_random_trait_prob = popfrom.popparams.mutate_random_trait_prob;
	(popto->popparams).mutate_link_trait_prob = popfrom.popparams.mutate_link_trait_prob;
	(popto->popparams).mutate_node_trait_prob = popfrom.popparams.mutate_node_trait_prob;
	(popto->popparams).mutate_link_weights_prob = popfrom.popparams.mutate_link_weights_prob;
	(popto->popparams).mutate_toggle_enable_prob = popfrom.popparams.mutate_toggle_enable_prob;
	(popto->popparams).mutate_gene_reenable_prob = popfrom.popparams.mutate_gene_reenable_prob;
	(popto->popparams).mutate_add_node_prob = popfrom.popparams.mutate_add_node_prob;
	(popto->popparams).mutate_add_link_prob = popfrom.popparams.mutate_add_link_prob;
	(popto->popparams).interspecies_mate_rate = popfrom.popparams.interspecies_mate_rate;	// Prob. of a mate being outside species 
	(popto->popparams).mate_multipoint_prob = popfrom.popparams.mate_multipoint_prob;     
	(popto->popparams).mate_multipoint_avg_prob = popfrom.popparams.mate_multipoint_avg_prob;
	(popto->popparams).mate_singlepoint_prob = popfrom.popparams.mate_singlepoint_prob;
	(popto->popparams).mate_only_prob = popfrom.popparams.mate_only_prob;					// Prob. of mating without mutation 
	(popto->popparams).recur_only_prob = popfrom.popparams.recur_only_prob;					// Probability of forcing selection of ONLY links that are naturally recurrent 
	(popto->popparams).pop_size = popfrom.popparams.pop_size;								// Size of population 
	(popto->popparams).dropoff_age = popfrom.popparams.dropoff_age;							// Age where Species starts to be penalized 
	(popto->popparams).newlink_tries = popfrom.popparams.newlink_tries;						// Number of tries mutate_add_link will attempt to find an open link 
	(popto->popparams).print_every = popfrom.popparams.print_every;							// Tells to print population to file every n generations 
	(popto->popparams).babies_stolen = popfrom.popparams.babies_stolen;						// The number of babies to siphen off to the champions 
	(popto->popparams).num_runs = popfrom.popparams.num_runs;

	}

//#################################################################################################




//#################################################################################################
bool PopParams::load_neat_params(const char *filename, bool output) {

    std::ifstream paramFile(filename);

	if(!paramFile) {

		return false;

	}

	char curword[128];

	// **********LOAD IN PARAMETERS*************** //

	paramFile>>curword;
	paramFile>>PopParams::trait_param_mut_prob;
	set_sc_trait_param_mut_prob(PopParams::trait_param_mut_prob);


	paramFile>>curword;
	paramFile>>PopParams::trait_mutation_power;
	set_sc_trait_mutation_power(PopParams::trait_mutation_power);


	paramFile>>curword;
	paramFile>>PopParams::linktrait_mut_sig;
	set_sc_linktrait_mut_sig(PopParams::linktrait_mut_sig);


	paramFile>>curword;
	paramFile>>PopParams::nodetrait_mut_sig;
	set_sc_nodetrait_mut_sig(PopParams::nodetrait_mut_sig);

	
    paramFile>>curword;
	paramFile>>PopParams::weight_mut_power;
	set_sc_weight_mut_power(PopParams::weight_mut_power);

	
    paramFile>>curword;
	paramFile>>PopParams::recur_prob;
	set_sc_recur_prob(PopParams::recur_prob);


    paramFile>>curword;
	paramFile>>PopParams::disjoint_coeff;
	set_sc_disjoint_coeff(PopParams::disjoint_coeff);


    paramFile>>curword;
	paramFile>>PopParams::excess_coeff;
	set_sc_excess_coeff(PopParams::excess_coeff);


    paramFile>>curword;
	paramFile>>PopParams::mutdiff_coeff;
	set_sc_mutdiff_coeff(PopParams::mutdiff_coeff);


    paramFile>>curword;
	paramFile>>PopParams::compat_threshold;
	set_sc_compat_threshold(PopParams::compat_threshold);


    paramFile>>curword;
	paramFile>>PopParams::age_significance;
	set_sc_age_significance(PopParams::age_significance);


    paramFile>>curword;
	paramFile>>PopParams::survival_thresh;
	set_sc_survival_thresh(PopParams::survival_thresh);


    paramFile>>curword;
	paramFile>>PopParams::mutate_only_prob;
	set_sc_mutate_only_prob(PopParams::mutate_only_prob);


    paramFile>>curword;
	paramFile>>PopParams::mutate_random_trait_prob;
	set_sc_mutate_random_trait_prob(PopParams::mutate_random_trait_prob);


    paramFile>>curword;
	paramFile>>PopParams::mutate_link_trait_prob;
	set_sc_mutate_link_trait_prob(PopParams::mutate_link_trait_prob);


    paramFile>>curword;
	paramFile>>PopParams::mutate_node_trait_prob;
	set_sc_mutate_node_trait_prob(PopParams::mutate_node_trait_prob);


    paramFile>>curword;
	paramFile>>PopParams::mutate_link_weights_prob;
	set_sc_mutate_link_weights_prob(PopParams::mutate_link_weights_prob);


    paramFile>>curword;
	paramFile>>PopParams::mutate_toggle_enable_prob;
	set_sc_mutate_toggle_enable_prob(PopParams::mutate_toggle_enable_prob);


	paramFile>>curword;
	paramFile>>PopParams::mutate_gene_reenable_prob;
	set_sc_mutate_gene_reenable_prob(PopParams::mutate_gene_reenable_prob);


    paramFile>>curword;
	paramFile>>PopParams::mutate_add_node_prob;
	set_sc_mutate_add_node_prob(PopParams::mutate_add_node_prob);


    paramFile>>curword;
	paramFile>>PopParams::mutate_add_link_prob;
	set_sc_mutate_add_link_prob(PopParams::mutate_add_link_prob);


    paramFile>>curword;
	paramFile>>PopParams::interspecies_mate_rate;
	set_sc_interspecies_mate_rate(PopParams::interspecies_mate_rate);


    paramFile>>curword;
	paramFile>>PopParams::mate_multipoint_prob;
	set_sc_mate_multipoint_prob(PopParams::mate_multipoint_prob);


    paramFile>>curword;
	paramFile>>PopParams::mate_multipoint_avg_prob;
	set_sc_mate_multipoint_avg_prob(PopParams::mate_multipoint_avg_prob);


    paramFile>>curword;
	paramFile>>PopParams::mate_singlepoint_prob;
	set_sc_mate_singlepoint_prob(PopParams::mate_singlepoint_prob);


    paramFile>>curword;
	paramFile>>PopParams::mate_only_prob;
	set_sc_mate_only_prob(PopParams::mate_only_prob);


    paramFile>>curword;
	paramFile>>PopParams::recur_only_prob;
	set_sc_recur_only_prob(PopParams::recur_only_prob);


    paramFile>>curword;
	paramFile>>PopParams::pop_size;
	set_sc_pop_size(PopParams::pop_size);


    paramFile>>curword;
	paramFile>>PopParams::dropoff_age;
	set_sc_dropoff_age(PopParams::dropoff_age);


    paramFile>>curword;
	paramFile>>PopParams::newlink_tries;
	set_sc_newlink_tries(PopParams::newlink_tries);


    paramFile>>curword;
	paramFile>>PopParams::print_every;
	set_sc_print_every(PopParams::print_every);


    paramFile>>curword;
	paramFile>>PopParams::babies_stolen;
	set_sc_babies_stolen(PopParams::babies_stolen);


    paramFile>>curword;
	paramFile>>PopParams::num_runs;
	set_sc_num_runs(PopParams::num_runs);

	paramFile.close();
	return true;
}
//#################################################################################################




//#################################################################################################
bool PopParams::write_pop_neat_params_to_file(const char *filename, Population* pop)
{

    std::ofstream paramFile(filename);

	if(!paramFile) {

		return false;

	}

	paramFile << "trait_param_mut_prob " << pop->popparams.read_pop_trait_param_mut_prob(pop) << std::endl;

	paramFile << "trait_mutation_power " << pop->popparams.read_pop_trait_mutation_power(pop) << std::endl;

	paramFile << "linktrait_mut_sig " << pop->popparams.read_pop_linktrait_mut_sig(pop) << std::endl;

	paramFile << "nodetrait_mut_sig " << pop->popparams.read_pop_nodetrait_mut_sig(pop) << std::endl;

	paramFile << "weight_mut_power " << pop->popparams.read_pop_weight_mut_power(pop) << std::endl;

	paramFile << "recur_prob " << pop->popparams.read_pop_recur_prob(pop) << std::endl;

	paramFile << "disjoint_coeff " << pop->popparams.read_pop_disjoint_coeff(pop) << std::endl;

	paramFile << "excess_coeff " << pop->popparams.read_pop_excess_coeff(pop) << std::endl;

	paramFile << "mutdiff_coeff " << pop->popparams.read_pop_mutdiff_coeff(pop) << std::endl;

	paramFile << "compat_thresh " << pop->popparams.read_pop_compat_threshold(pop) << std::endl;

	paramFile << "age_significance " << pop->popparams.read_pop_age_significance(pop) << std::endl;

	paramFile << "survival_thresh " << pop->popparams.read_pop_survival_thresh(pop) << std::endl;

	paramFile << "mutate_only_prob " << pop->popparams.read_pop_mutate_only_prob(pop) << std::endl;

	paramFile << "mutate_random_trait_prob " << pop->popparams.read_pop_mutate_random_trait_prob(pop) << std::endl;

	paramFile << "mutate_link_trait_prob " << pop->popparams.read_pop_mutate_link_trait_prob(pop) << std::endl;

	paramFile << "mutate_node_trait_prob " << pop->popparams.read_pop_mutate_node_trait_prob(pop) << std::endl;

	paramFile << "mutate_link_weights_prob " << pop->popparams.read_pop_mutate_link_weights_prob(pop) << std::endl;

	paramFile << "mutate_toggle_enable_prob " << pop->popparams.read_pop_mutate_toggle_enable_prob(pop) << std::endl;

	paramFile << "mutate_gene_reenable_prob " << pop->popparams.read_pop_mutate_gene_reenable_prob(pop) << std::endl;

	paramFile << "mutate_add_node_prob " << pop->popparams.read_pop_mutate_add_node_prob(pop) << std::endl;

	paramFile << "mutate_add_link_prob " << pop->popparams.read_pop_mutate_add_link_prob(pop) << std::endl;

	paramFile << "interspecies_mate_rate " << pop->popparams.read_pop_interspecies_mate_rate(pop) << std::endl;

	paramFile << "mate_multipoint_prob " << pop->popparams.read_pop_mate_multipoint_prob(pop) << std::endl;

	paramFile << "mate_multipoint_avg_prob " << pop->popparams.read_pop_mate_multipoint_avg_prob(pop) << std::endl;

	paramFile << "mate_singlepoint_prob " << pop->popparams.read_pop_mate_singlepoint_prob(pop) << std::endl;

	paramFile << "mate_only_prob " << pop->popparams.read_pop_mate_only_prob(pop) << std::endl;

	paramFile << "recur_only_prob " << pop->popparams.read_pop_recur_only_prob(pop) << std::endl;

	paramFile << "pop_size " << pop->popparams.read_pop_pop_size(pop) << std::endl;

	paramFile << "dropoff_age " << pop->popparams.read_pop_dropoff_age(pop) << std::endl;

	paramFile << "newlink_tries " << pop->popparams.read_pop_newlink_tries(pop) << std::endl;

	paramFile << "print_every " << pop->popparams.read_pop_print_every(pop) << std::endl;

	paramFile << "babies_stolen " << pop->popparams.read_pop_babies_stolen(pop) << std::endl;

	paramFile << "num_runs " << pop->popparams.read_pop_num_runs(pop) << std::endl;

	paramFile.close();
	return true;
}
//#################################################################################################


//#################################################################################################
bool PopParams::read_pop_neat_params_from_file(const char *filename, Population* pop)
{

    std::ifstream paramFile(filename);

	if(!paramFile) {

		return false;

	}

	char curword[128];

	paramFile>>curword;
	paramFile>>PopParams::trait_param_mut_prob;
	pop->popparams.set_bsc_trait_param_mut_prob(PopParams::trait_param_mut_prob);

	paramFile>>curword;
	paramFile>>PopParams::trait_mutation_power;
	pop->popparams.set_bsc_trait_mutation_power(PopParams::trait_mutation_power);

	paramFile>>curword;
	paramFile>>PopParams::linktrait_mut_sig;
	pop->popparams.set_bsc_linktrait_mut_sig(PopParams::linktrait_mut_sig);

	paramFile>>curword;
	paramFile>>PopParams::nodetrait_mut_sig;
	pop->popparams.set_bsc_nodetrait_mut_sig(PopParams::nodetrait_mut_sig);
	
	paramFile>>curword;
	paramFile>>PopParams::weight_mut_power;
	pop->popparams.set_bsc_weight_mut_power(PopParams::weight_mut_power);
	
	paramFile>>curword;
	paramFile>>PopParams::recur_prob;
	pop->popparams.set_bsc_recur_prob(PopParams::recur_prob);

	paramFile>>curword;
	paramFile>>PopParams::disjoint_coeff;
	pop->popparams.set_bsc_disjoint_coeff(PopParams::disjoint_coeff);

	paramFile>>curword;
	paramFile>>PopParams::excess_coeff;
	pop->popparams.set_bsc_excess_coeff(PopParams::excess_coeff);

	paramFile>>curword;
	paramFile>>PopParams::mutdiff_coeff;
	pop->popparams.set_bsc_mutdiff_coeff(PopParams::mutdiff_coeff);

	paramFile>>curword;
	paramFile>>PopParams::compat_threshold;
	pop->popparams.set_bsc_compat_threshold(PopParams::compat_threshold);

	paramFile>>curword;
	paramFile>>PopParams::age_significance;
	pop->popparams.set_bsc_age_significance(PopParams::age_significance);

	paramFile>>curword;
	paramFile>>PopParams::survival_thresh;
	pop->popparams.set_bsc_survival_thresh(PopParams::survival_thresh);

	paramFile>>curword;
	paramFile>>PopParams::mutate_only_prob;
	pop->popparams.set_bsc_mutate_only_prob(PopParams::mutate_only_prob);

	paramFile>>curword;
	paramFile>>PopParams::mutate_random_trait_prob;
	pop->popparams.set_bsc_mutate_random_trait_prob(PopParams::mutate_random_trait_prob);

	paramFile>>curword;
	paramFile>>PopParams::mutate_link_trait_prob;
	pop->popparams.set_bsc_mutate_link_trait_prob(PopParams::mutate_link_trait_prob);

	paramFile>>curword;
	paramFile>>PopParams::mutate_node_trait_prob;
	pop->popparams.set_bsc_mutate_node_trait_prob(PopParams::mutate_node_trait_prob);

	paramFile>>curword;
	paramFile>>PopParams::mutate_link_weights_prob;
	pop->popparams.set_bsc_mutate_link_weights_prob(PopParams::mutate_link_weights_prob);

	paramFile>>curword;
	paramFile>>PopParams::mutate_toggle_enable_prob;
	pop->popparams.set_bsc_mutate_toggle_enable_prob(PopParams::mutate_toggle_enable_prob);

	paramFile>>curword;
	paramFile>>PopParams::mutate_gene_reenable_prob;
	pop->popparams.set_bsc_mutate_gene_reenable_prob(PopParams::mutate_gene_reenable_prob);

	paramFile>>curword;
	paramFile>>PopParams::mutate_add_node_prob;
	pop->popparams.set_bsc_mutate_add_node_prob(PopParams::mutate_add_node_prob);

	paramFile>>curword;
	paramFile>>PopParams::mutate_add_link_prob;
	pop->popparams.set_bsc_mutate_add_link_prob(PopParams::mutate_add_link_prob);

	paramFile>>curword;
	paramFile>>PopParams::interspecies_mate_rate;
	pop->popparams.set_bsc_interspecies_mate_rate(PopParams::interspecies_mate_rate);

	paramFile>>curword;
	paramFile>>PopParams::mate_multipoint_prob;
	pop->popparams.set_bsc_mate_multipoint_prob(PopParams::mate_multipoint_prob);

	paramFile>>curword;
	paramFile>>PopParams::mate_multipoint_avg_prob;
	pop->popparams.set_bsc_mate_multipoint_avg_prob(PopParams::mate_multipoint_avg_prob);

	paramFile>>curword;
	paramFile>>PopParams::mate_singlepoint_prob;
	pop->popparams.set_bsc_mate_singlepoint_prob(PopParams::mate_singlepoint_prob);

	paramFile>>curword;
	paramFile>>PopParams::mate_only_prob;
	pop->popparams.set_bsc_mate_only_prob(PopParams::mate_only_prob);

	paramFile>>curword;
	paramFile>>PopParams::recur_only_prob;
	pop->popparams.set_bsc_recur_only_prob(PopParams::recur_only_prob);

	paramFile>>curword;
	paramFile>>PopParams::pop_size;
	pop->popparams.set_bsc_pop_size(PopParams::pop_size);

	paramFile>>curword;
	paramFile>>PopParams::dropoff_age;
	pop->popparams.set_bsc_dropoff_age(PopParams::dropoff_age);

	paramFile>>curword;
	paramFile>>PopParams::newlink_tries;
	pop->popparams.set_bsc_newlink_tries(PopParams::newlink_tries);

	paramFile>>curword;
	paramFile>>PopParams::print_every;
	pop->popparams.set_bsc_print_every(PopParams::print_every);

	paramFile>>curword;
	paramFile>>PopParams::babies_stolen;
	pop->popparams.set_bsc_babies_stolen(PopParams::babies_stolen);

	paramFile>>curword;
	paramFile>>PopParams::num_runs;
	pop->popparams.set_bsc_num_runs(PopParams::num_runs);

	paramFile.close();
	return true;
}
//#################################################################################################




#include "experiments.h"

#include "population.h"

#include <cstring>
#include <stdlib.h>
#include  <io.h>

#include <ctime>

#define NO_SCREEN_OUT 

using namespace std; 

extern int i_accum_tmp;

extern int i_interactive_flag;			// 0 = not interactive, 1 = interactive

extern char* start_gene_spop_filename;

extern char* param_epop_filename;

int i_num_tries = 1;

//#################################################################################################
bool supervisor_evaluate(Population::Organism *org, Population *pop, int egens)
{
	Population eP, *epop = &eP;

	Population::Network *net;

	int i,j;

	stringstream ss;
	string s_print_output; 
	char* print_output;

	double out[33]; //The four outputs

	double this_out; //The current output
	int count;
	double errorsum;

	bool success;  //Check for successful activation
	int numnodes;  /* Used to figure out how many nodes should be visited during activation */

	int net_depth; //The max depth of the network to be activated
	int relax; //Activates until relaxation

	
	double r_highest_fitness = 0.0;
	double r_highest_fitness_accum = 0.0;
	double r_highest_fitness_overall = 0.0;

	double in[68]={0.0};

	//cout<<"pre-net"<<endl;
	net=org->net;
	//cout<<"post-net"<<endl;

	//cout<<"pre-numnodes"<<endl;
	numnodes=((org->gnome)->nodes).size();
	//cout<<"post-numnodes"<<endl;

	//cout<<"pre-net_depth"<<endl;
	net_depth=net->max_depth();
	//cout<<"post-net_depth"<<endl;

	//TEST CODE: REMOVE
	//cout<<"ACTIVATING: "<<org->gnome<<endl;
	//cout<<"DEPTH: "<<net_depth<<endl;

	bool threshold = 1;

	double d_tmp = 0.0;

	int i_tmp = 0;

	//*************************************************************************************
	//	double trait_param_mut_prob;
	d_tmp = pop->popparams.read_pop_trait_param_mut_prob(pop);
	in[0] = pop->popparams.normalize_pop_trait_param_mut_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_trait_param_mut_prob();
	in[33] = pop->popparams.normalize_pop_trait_param_mut_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double trait_mutation_power; // Power of mutation on a signle trait param 
	d_tmp = pop->popparams.read_pop_trait_mutation_power(pop);
	in[1] = pop->popparams.normalize_pop_trait_mutation_power(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_trait_mutation_power();
	in[34] = pop->popparams.normalize_pop_trait_mutation_power(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double linktrait_mut_sig;  // Amount that mutation_num changes for a trait change inside a link
	d_tmp = pop->popparams.read_pop_linktrait_mut_sig(pop);
	in[2] = pop->popparams.normalize_pop_linktrait_mut_sig(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_linktrait_mut_sig();
	in[35] = pop->popparams.normalize_pop_linktrait_mut_sig(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double nodetrait_mut_sig; // Amount a mutation_num changes on a link connecting a node that changed its trait 
	d_tmp = pop->popparams.read_pop_nodetrait_mut_sig(pop);
	in[3] = pop->popparams.normalize_pop_nodetrait_mut_sig(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_nodetrait_mut_sig();
	in[36] = pop->popparams.normalize_pop_nodetrait_mut_sig(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double weight_mut_power;  // The power of a linkweight mutation 
	d_tmp = pop->popparams.read_pop_weight_mut_power(pop);
	in[4] = pop->popparams.normalize_pop_weight_mut_power(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_weight_mut_power();
	in[37] = pop->popparams.normalize_pop_weight_mut_power(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double recur_prob;        // Prob. that a link mutation which doesn't have to be recurrent will be made recurrent 
	d_tmp = pop->popparams.read_pop_recur_prob(pop);
	in[5] = pop->popparams.normalize_pop_recur_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_recur_prob();
	in[38] = pop->popparams.normalize_pop_recur_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double disjoint_coeff;
	d_tmp = pop->popparams.read_pop_disjoint_coeff(pop);
	in[6] = pop->popparams.normalize_pop_disjoint_coeff(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_disjoint_coeff();
	in[39] = pop->popparams.normalize_pop_disjoint_coeff(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double excess_coeff;
	d_tmp = pop->popparams.read_pop_excess_coeff(pop);
	in[7] = pop->popparams.normalize_pop_excess_coeff(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_excess_coeff();
	in[40] = pop->popparams.normalize_pop_excess_coeff(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mutdiff_coeff;
	d_tmp = pop->popparams.read_pop_mutdiff_coeff(pop);
	in[8] = pop->popparams.normalize_pop_mutdiff_coeff(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mutdiff_coeff();
	in[41] = pop->popparams.normalize_pop_mutdiff_coeff(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double compat_threshold;	// This global tells compatibility threshold under which two Genomes are considered the same species
	d_tmp = pop->popparams.read_pop_compat_threshold(pop);
	in[9] = pop->popparams.normalize_pop_compat_threshold(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_compat_threshold();
	in[42] = pop->popparams.normalize_pop_compat_threshold(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double age_significance;          // How much does age matter? 
	d_tmp = pop->popparams.read_pop_age_significance(pop);
	in[10] = pop->popparams.normalize_pop_age_significance(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_age_significance();
	in[43] = pop->popparams.normalize_pop_age_significance(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double survival_thresh;           // Percent of ave fitness for survival 
	d_tmp = pop->popparams.read_pop_survival_thresh(pop);
	in[11] = pop->popparams.normalize_pop_survival_thresh(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_survival_thresh();
	in[44] = pop->popparams.normalize_pop_survival_thresh(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mutate_only_prob;          // Prob. of a non-mating reproduction 
	d_tmp = pop->popparams.read_pop_mutate_only_prob(pop);
	in[12] = pop->popparams.normalize_pop_mutate_only_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mutate_only_prob();
	in[45] = pop->popparams.normalize_pop_mutate_only_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mutate_random_trait_prob;
	d_tmp = pop->popparams.read_pop_mutate_random_trait_prob(pop);
	in[13] = pop->popparams.normalize_pop_mutate_random_trait_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mutate_random_trait_prob();
	in[46] = pop->popparams.normalize_pop_mutate_random_trait_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mutate_link_trait_prob;
	d_tmp = pop->popparams.read_pop_mutate_link_trait_prob(pop);
	in[14] = pop->popparams.normalize_pop_mutate_link_trait_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mutate_link_trait_prob();
	in[47] = pop->popparams.normalize_pop_mutate_link_trait_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mutate_node_trait_prob;
	d_tmp = pop->popparams.read_pop_mutate_node_trait_prob(pop);
	in[15] = pop->popparams.normalize_pop_mutate_node_trait_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mutate_node_trait_prob();
	in[48] = pop->popparams.normalize_pop_mutate_node_trait_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mutate_link_weights_prob;
	d_tmp = pop->popparams.read_pop_mutate_link_weights_prob(pop);
	in[16] = pop->popparams.normalize_pop_mutate_link_weights_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mutate_link_weights_prob();
	in[49] = pop->popparams.normalize_pop_mutate_link_weights_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mutate_toggle_enable_prob;
	d_tmp = pop->popparams.read_pop_mutate_toggle_enable_prob(pop);
	in[17] = pop->popparams.normalize_pop_mutate_toggle_enable_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mutate_toggle_enable_prob();
	in[50] = pop->popparams.normalize_pop_mutate_toggle_enable_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mutate_gene_reenable_prob;
	d_tmp = pop->popparams.read_pop_mutate_gene_reenable_prob(pop);
	in[18] = pop->popparams.normalize_pop_mutate_gene_reenable_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mutate_gene_reenable_prob();
	in[51] = pop->popparams.normalize_pop_mutate_gene_reenable_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mutate_add_node_prob;
	d_tmp = pop->popparams.read_pop_mutate_add_node_prob(pop);
	in[19] = pop->popparams.normalize_pop_mutate_add_node_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mutate_add_node_prob();
	in[52] = pop->popparams.normalize_pop_mutate_add_node_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mutate_add_link_prob;
	d_tmp = pop->popparams.read_pop_mutate_add_link_prob(pop);
	in[20] = pop->popparams.normalize_pop_mutate_add_link_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mutate_add_link_prob();
	in[53] = pop->popparams.normalize_pop_mutate_add_link_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double interspecies_mate_rate;    // Prob. of a mate being outside species 
	d_tmp = pop->popparams.read_pop_interspecies_mate_rate(pop);
	in[21] = pop->popparams.normalize_pop_interspecies_mate_rate(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_interspecies_mate_rate();
	in[54] = pop->popparams.normalize_pop_interspecies_mate_rate(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mate_multipoint_prob;     
	d_tmp = pop->popparams.read_pop_mate_multipoint_prob(pop);
	in[22] = pop->popparams.normalize_pop_mate_multipoint_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mate_multipoint_prob();
	in[55] = pop->popparams.normalize_pop_mate_multipoint_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mate_multipoint_avg_prob;
	d_tmp = pop->popparams.read_pop_mate_multipoint_avg_prob(pop);
	in[23] = pop->popparams.normalize_pop_mate_multipoint_avg_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mate_multipoint_avg_prob();
	in[56] = pop->popparams.normalize_pop_mate_multipoint_avg_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mate_singlepoint_prob;
	d_tmp = pop->popparams.read_pop_mate_singlepoint_prob(pop);
	in[24] = pop->popparams.normalize_pop_mate_singlepoint_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mate_singlepoint_prob();
	in[57] = pop->popparams.normalize_pop_mate_singlepoint_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double mate_only_prob;            // Prob. of mating without mutation 
	d_tmp = pop->popparams.read_pop_mate_only_prob(pop);
	in[25] = pop->popparams.normalize_pop_mate_only_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_mate_only_prob();
	in[58] = pop->popparams.normalize_pop_mate_only_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	double recur_only_prob;  // Probability of forcing selection of ONLY links that are naturally recurrent 
	d_tmp = pop->popparams.read_pop_recur_only_prob(pop);
	in[26] = pop->popparams.normalize_pop_recur_only_prob(d_tmp, threshold);

	d_tmp = pop->popparams.read_bsc_recur_only_prob();
	in[59] = pop->popparams.normalize_pop_recur_only_prob(d_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	int pop_size;  // Size of population 
	i_tmp = pop->popparams.read_pop_pop_size(pop);
	in[27] = pop->popparams.normalize_pop_pop_size(i_tmp, threshold);

	i_tmp = pop->popparams.read_bsc_pop_size();
	in[60] = pop->popparams.normalize_pop_pop_size(i_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	int dropoff_age;  // Age where Species starts to be penalized 
	i_tmp = pop->popparams.read_pop_dropoff_age(pop);
	in[28] = pop->popparams.normalize_pop_dropoff_age(i_tmp, threshold);

	i_tmp = pop->popparams.read_bsc_dropoff_age();
	in[61] = pop->popparams.normalize_pop_dropoff_age(i_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	int newlink_tries;  // Number of tries mutate_add_link will attempt to find an open link 
	i_tmp = pop->popparams.read_pop_newlink_tries(pop);
	in[29] = pop->popparams.normalize_pop_newlink_tries(i_tmp, threshold);

	i_tmp = pop->popparams.read_bsc_newlink_tries();
	in[62] = pop->popparams.normalize_pop_newlink_tries(i_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	int print_every; // Tells to print population to file every n generations 
	i_tmp = pop->popparams.read_pop_print_every(pop);
	in[30] = pop->popparams.normalize_pop_print_every(i_tmp, threshold);

	i_tmp = pop->popparams.read_bsc_print_every();
	in[63] = pop->popparams.normalize_pop_print_every(i_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	int babies_stolen; // The number of babies to siphon off to the champions 
	i_tmp = pop->popparams.read_pop_babies_stolen(pop);
	in[31] = pop->popparams.normalize_pop_babies_stolen(i_tmp, threshold);

	i_tmp = pop->popparams.read_bsc_babies_stolen();
	in[64] = pop->popparams.normalize_pop_babies_stolen(i_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//	int num_runs; //number of times to run experiment
	i_tmp = pop->popparams.read_pop_num_runs(pop);
	in[32] = pop->popparams.normalize_pop_num_runs(i_tmp, threshold);

	i_tmp = pop->popparams.read_bsc_num_runs();
	in[65] = pop->popparams.normalize_pop_num_runs(i_tmp, threshold);
	//*************************************************************************************

	//*************************************************************************************
	//fitness from last run of experiment
	d_tmp = pop->popparams.read_bsc_fitness_buffer();
	in[66] = pop->popparams.normalize_bsc_fitness_buffer(d_tmp, threshold);
	//*************************************************************************************

	in[67] = 1.0;	// bias input

	//Load and activate the network on each input
	//cout<<"pre-Load and activate"<<endl;
	for(count=0;count<33;count++) {

		net->load_sensors(in);

		//Relax net and get output
		success=net->activate();

		//use depth to ensure relaxation
		//cout<<"pre-ensure relaxation"<<endl;
		for (relax=0;relax<=net_depth;relax++) {

			success=net->activate();
			this_out=(*(net->outputs.begin()))->activation;

		}
		//cout<<"post-ensure relaxation"<<endl;

		// output array set to outputs nodes activation
		out[count]=(*(net->outputs.begin()))->activation;

		net->flush();

	}
	//cout<<"post-Load and activate"<<endl;

	
	if (success)
	{

		errorsum = 0.0;

		double N_prime = 0.0;

		//*************************************************************************************
		//		double trait_param_mut_prob;
		N_prime = out[0];
		epop->popparams.set_bsc_trait_param_mut_prob( epop->popparams.unnormalize_pop_trait_param_mut_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double trait_mutation_power; // Power of mutation on a signle trait param 
		N_prime = out[1];
		epop->popparams.set_bsc_trait_mutation_power( epop->popparams.unnormalize_pop_trait_mutation_power(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double linktrait_mut_sig;  // Amount that mutation_num changes for a trait change inside a link
		N_prime = out[2];
		epop->popparams.set_bsc_linktrait_mut_sig( epop->popparams.unnormalize_pop_linktrait_mut_sig(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double nodetrait_mut_sig; // Amount a mutation_num changes on a link connecting a node that changed its trait 
		N_prime = out[3];
		epop->popparams.set_bsc_nodetrait_mut_sig( epop->popparams.unnormalize_pop_nodetrait_mut_sig(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double weight_mut_power;  // The power of a linkweight mutation 
		N_prime = out[4];
		epop->popparams.set_bsc_weight_mut_power( epop->popparams.unnormalize_pop_weight_mut_power(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double recur_prob;        // Prob. that a link mutation which doesn't have to be recurrent will be made recurrent 
		N_prime = out[5];
		epop->popparams.set_bsc_recur_prob( epop->popparams.unnormalize_pop_recur_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double disjoint_coeff;
		N_prime = out[6];
		epop->popparams.set_bsc_disjoint_coeff( epop->popparams.unnormalize_pop_disjoint_coeff(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double excess_coeff;
		N_prime = out[7];
		epop->popparams.set_bsc_excess_coeff( epop->popparams.unnormalize_pop_excess_coeff(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mutdiff_coeff;
		N_prime = out[8];
		epop->popparams.set_bsc_mutdiff_coeff( epop->popparams.unnormalize_pop_mutdiff_coeff(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double compat_threshold;	// This global tells compatibility threshold under which two Genomes are considered the same species
		N_prime = out[9];
		epop->popparams.set_bsc_compat_threshold( epop->popparams.unnormalize_pop_compat_threshold(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double age_significance;          // How much does age matter? 
		N_prime = out[10];
		epop->popparams.set_bsc_age_significance( epop->popparams.unnormalize_pop_age_significance(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double survival_thresh;           // Percent of ave fitness for survival 
		N_prime = out[11];
		epop->popparams.set_bsc_survival_thresh( epop->popparams.unnormalize_pop_survival_thresh(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mutate_only_prob;          // Prob. of a non-mating reproduction 
		N_prime = out[12];
		epop->popparams.set_bsc_mutate_only_prob( epop->popparams.unnormalize_pop_mutate_only_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mutate_random_trait_prob;
		N_prime = out[13];
		epop->popparams.set_bsc_mutate_random_trait_prob( epop->popparams.unnormalize_pop_mutate_random_trait_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mutate_link_trait_prob;
		N_prime = out[14];
		epop->popparams.set_bsc_mutate_link_trait_prob( epop->popparams.unnormalize_pop_mutate_link_trait_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mutate_node_trait_prob;
		N_prime = out[15];
		epop->popparams.set_bsc_mutate_node_trait_prob( epop->popparams.unnormalize_pop_mutate_node_trait_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mutate_link_weights_prob;
		N_prime = out[16];
		epop->popparams.set_bsc_mutate_link_weights_prob( epop->popparams.unnormalize_pop_mutate_link_weights_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mutate_toggle_enable_prob;
		N_prime = out[17];
		epop->popparams.set_bsc_mutate_toggle_enable_prob( epop->popparams.unnormalize_pop_mutate_toggle_enable_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mutate_gene_reenable_prob;
		N_prime = out[18];
		epop->popparams.set_bsc_mutate_gene_reenable_prob( epop->popparams.unnormalize_pop_mutate_gene_reenable_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mutate_add_node_prob;
		N_prime = out[19];
		epop->popparams.set_bsc_mutate_add_node_prob( epop->popparams.unnormalize_pop_mutate_add_node_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mutate_add_link_prob;
		N_prime = out[20];
		epop->popparams.set_bsc_mutate_add_link_prob( epop->popparams.unnormalize_pop_mutate_add_link_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double interspecies_mate_rate;    // Prob. of a mate being outside species 
		N_prime = out[21];
		epop->popparams.set_bsc_interspecies_mate_rate( epop->popparams.unnormalize_pop_interspecies_mate_rate(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mate_multipoint_prob;     
		N_prime = out[22];
		epop->popparams.set_bsc_mate_multipoint_prob( epop->popparams.unnormalize_pop_mate_multipoint_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mate_multipoint_avg_prob;
		N_prime = out[23];
		epop->popparams.set_bsc_mate_multipoint_avg_prob( epop->popparams.unnormalize_pop_mate_multipoint_avg_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mate_singlepoint_prob;
		N_prime = out[24];
		epop->popparams.set_bsc_mate_singlepoint_prob( epop->popparams.unnormalize_pop_mate_singlepoint_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double mate_only_prob;            // Prob. of mating without mutation 
		N_prime = out[25];
		epop->popparams.set_bsc_mate_only_prob( epop->popparams.unnormalize_pop_mate_only_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		double recur_only_prob;  // Probability of forcing selection of ONLY links that are naturally recurrent 
		N_prime = out[26];
		epop->popparams.set_bsc_recur_only_prob( epop->popparams.unnormalize_pop_recur_only_prob(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		int pop_size;  // Size of population 
		N_prime = out[27];
		epop->popparams.set_bsc_pop_size( epop->popparams.unnormalize_pop_pop_size(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		int dropoff_age;  // Age where Species starts to be penalized 
		N_prime = out[28];
		epop->popparams.set_bsc_dropoff_age( epop->popparams.unnormalize_pop_dropoff_age(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		int newlink_tries;  // Number of tries mutate_add_link will attempt to find an open link 
		N_prime = out[29];
		epop->popparams.set_bsc_newlink_tries( epop->popparams.unnormalize_pop_newlink_tries(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		int print_every; // Tells to print population to file every n generations 
		N_prime = out[30];
		epop->popparams.set_bsc_print_every( epop->popparams.unnormalize_pop_print_every(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		int babies_stolen; // The number of babies to siphon off to the champions 
		N_prime = out[31];
		epop->popparams.set_bsc_babies_stolen( epop->popparams.unnormalize_pop_babies_stolen(N_prime, threshold));
		//*************************************************************************************

		//*************************************************************************************
		//		int num_runs; //number of times to run experiment
		N_prime = out[32];
		epop->popparams.set_bsc_num_runs( epop->popparams.unnormalize_pop_num_runs(N_prime, threshold));
		//*************************************************************************************
      
		epop->popparams.initializer_bsc(epop);

		i_accum_tmp = i_accum_tmp + 1;

		// Check for existence of parameter file: 0 = file does not exist, 1 = file exists
		if( ((_access( param_epop_filename, 0 )) != -1) && (i_interactive_flag != 1) )
		{
			epop->popparams.read_pop_neat_params_from_file(param_epop_filename, epop);
      
			epop->popparams.initializer_bsc(epop);
		}

		ss.clear();
		ss <<"Experiment Population Size: "<< (epop->popparams).pop_size << std::endl;
		getline(ss,s_print_output);
		print_output = (char*)(s_print_output.c_str());
		DBUG_PRINT("supervisor_evaluate", (print_output))

		    i_num_tries = 1;

GetSomeMore:	;

		if( i_interactive_flag == 1 )
		{
			cout << "call to experiment #:" << i_accum_tmp << "    i_num_tries #:"<< i_num_tries <<endl;
		}

		ss.clear();
		ss << "call to experiment #:" << i_accum_tmp << "    i_num_tries #:"<< i_num_tries <<endl;
		getline(ss,s_print_output);
		print_output = (char*)(s_print_output.c_str());
		DBUG_PRINT("supervisor_evaluate", (print_output))

		epop->highest_fitness_buf = 0.0;
		epop->highest_fitness_accum_buf = 0.0;

		epop = data_test(egens, epop);

		double r_highest_fitness=epop->highest_fitness_buf;

		double r_highest_fitness_accum=epop->highest_fitness_accum_buf;

		org->fitness = epop->highest_fitness_accum_buf;

		i_num_tries = i_num_tries - 1;

//		keep track of highest fitness of experiment & output associated population
		if ( r_highest_fitness > NEAT::highest_fitness_overall_buf )
		{
			if( i_num_tries == 0 )
			{
				i_num_tries = 10;
			}
			else
			{

				if( i_num_tries <= 3 )
				{
					i_num_tries = 10 * i_num_tries;	// multiply current value of i_num_tries for new high-water-mark fitness
				}
				else
				{
					if( i_num_tries > 10 )
					{
						i_num_tries = i_num_tries + 1;
					}
					else
					{
						i_num_tries = i_num_tries * 2;
					}
				}
			}
            
			NEAT::highest_fitness_overall_buf = r_highest_fitness;

			pop->highest_fitness_buf = r_highest_fitness;

			r_highest_fitness_overall = pop->highest_fitness_buf;

			if( i_interactive_flag == 1 )
			{
				cout<<"Pop OVERALL HIGHEST POPULATION FITNESS: "<< i_accum_tmp << "   " << r_highest_fitness_overall<<endl;
			}

			ss.clear();
			ss <<"Pop OVERALL HIGHEST POPULATION FITNESS: "<< i_accum_tmp << "   " << r_highest_fitness_overall<<endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("supervisor_evaluate", (print_output))

			epop->print_to_file_by_species("best_epop_by_species.out");

			if( i_interactive_flag == 1 )
			{
				cout << "An epop which sets a new high-watermark gets another try!!!" << endl;
			}

			DBUG_PRINT("supervisor_evaluate", ("An epop which sets a new high-watermark gets another try!!!"))

			goto GetSomeMore;	// an epop which sets a new high-watermark gets another try!!!
    
		}

		if( i_num_tries > 0 )
		{
			goto GetSomeMore;
		}

	}
	else 
	{

		//The network is flawed (shouldnt happen)
		errorsum = 1.0E15;

		org->fitness = 1.0E-15;

		if( i_interactive_flag == 1 )
		{
			cout<<"experiment network flawed"<<endl;
		}
		ss.clear();
		ss <<"experiment network flawed"<<endl;
		getline(ss,s_print_output);
		print_output = (char*)(s_print_output.c_str());
		DBUG_PRINT("supervisor_evaluate", (print_output))

	}

	delete epop;

	if ((org->fitness>100000.0)) {

		org->winner=true;
		return true;

	}
	else {

		org->winner=false;
		return false;

	}

}
//#################################################################################################


//#################################################################################################
int supervisor_epoch(Population *pop,int generation,char *filename,int &winnernum,int &winnergenes,int &winnernodes, int egens) {

	vector<Population::Organism*>::iterator curorg;
	vector<Population::Species*>::iterator curspecies;

	stringstream ss;
	string s_print_output; 
	char* print_output;

	bool win=false;

	double r_tmp = 0;

	double r_highest_fitness = 0;
	double r_highest_fitness_accum = 0;

	int i_flag = 0;

	Population::Genome C;

	//Evaluate each organism on a test
	for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {

		if (supervisor_evaluate(*curorg,pop,egens)) {

			win=true;
			winnernum=(*curorg)->gnome->genome_id;
			winnergenes=(*curorg)->gnome->extrons();
			winnernodes=((*curorg)->gnome->nodes).size();

			if (winnernodes==5) {

				//You could dump out optimal genomes here if desired
				//(*curorg)->gnome->print_to_filename("data_optimal");
				//cout<<"DUMPED OPTIMAL"<<endl;

			}

		}

		r_tmp = (*curorg)->fitness;

		r_highest_fitness=pop->highest_fitness;

//		keep track of highest fitness of supervisor & output associated population
		if ( r_tmp > NEAT::highest_fitness_overall ) {

			i_flag = 1;

			NEAT::highest_fitness_overall = r_tmp;

			if( i_interactive_flag == 1 )
			{
				cout<<"Supervisor OVERALL HIGHEST POPULATION FITNESS: "<< NEAT::highest_fitness_overall <<endl;
			}

			ss.clear();
			ss <<"Supervisor OVERALL HIGHEST POPULATION FITNESS: "<< NEAT::highest_fitness_overall <<endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("supervisor_epoch", (print_output))

			C.print_Genome_tofile((*curorg)->gnome,"best_sup_genome.out");

		    ofstream oFile("best_sup_genome_results.out");

			oFile << "best_sup_genome.out NEAT::highest_fitness_overall: " << NEAT::highest_fitness_overall << "    " << (*curorg)->fitness << std::endl;
			oFile << std::endl;

			oFile.close();

		}

	}

	//Average and max their fitnesses for dumping to file and snapshot
	for(curspecies=(pop->species).begin();curspecies!=(pop->species).end();++curspecies) {

		//This experiment control routine issues commands to collect ave
		//and max fitness, as opposed to having the snapshot do it, 
		//because this allows flexibility in terms of what time
		//to observe fitnesses at

		(*curspecies)->compute_average_fitness();
		(*curspecies)->compute_max_fitness();

	}

	if( i_flag == 1 )
	{
		i_flag = 0;

		pop->print_to_file_by_species("best_spop_by_species.out");

	}

	//Take a snapshot of the population, so that it can be
	//visualized later on
	//if ((generation%1)==0)
	//  pop->snapshot();

	//Only print to file every print_every generations
	if  (win) {

		pop->print_to_file_by_species("data_winner_pop_by_species.dat");

	}

	if (win) {

		for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {

			if ((*curorg)->winner) {

				//Prints the winner to file
				//IMPORTANT: This causes generational file output!
				C.print_Genome_tofile((*curorg)->gnome,"data_winner_genome.dat");

			}
		}
    
	}

	pop->epoch(generation,pop);

	if (win) return 1;
	else return 0;

}
//#################################################################################################


//#################################################################################################
//Perform evolution on data, for gens generations
Population *supervisor_test(int gens, Population* pop, int egens) {

	Population::Genome *start_genome;
    char curword[20];
    int id;

	int i,j;

	stringstream ss;
	string s_print_output; 
	char* print_output;

    ostringstream *fnamebuf;
    int gen;
 
    int* evals;  //Hold records for each run

    int* genes;

    int* nodes;

    int winnernum;
    int winnergenes;
    int winnernodes;

    //For averaging
    int totalevals=0;
    int totalgenes=0;
    int totalnodes=0;
    int expcount;

	evals = new int[(pop->popparams).num_runs];

	genes = new int[(pop->popparams).num_runs];

	nodes = new int[(pop->popparams).num_runs];

	/* Check for existence of supervisor start gene file */
	if( (_access( start_gene_spop_filename, 0 )) != -1 )
	{
		ifstream iFile(start_gene_spop_filename,ios::in);

		//Read in the start Genome
		iFile>>curword;
		iFile>>id;
		start_genome=new Population::Genome(id,iFile);
		iFile.close();
	}
	else
	{
		DBUG_PRINT("supervisor_test", ("Abort: start_gene_spop_filename file does not exist!"))
		abort();
	}

    for(expcount=0;expcount<(pop->popparams).num_runs;expcount++) {

		//Spawn the Population
		pop=new Population(start_genome,(pop->popparams).pop_size);
      
		pop->verify(pop);

		for (gen=1;gen<=gens;gen++) {

			//This is how to make a custom filename
			fnamebuf=new ostringstream();
			(*fnamebuf)<<"gen_"<<gen<<ends;  //needs end marker

			#ifndef NO_SCREEN_OUT
//			cout<<"name of fname: "<<fnamebuf->str()<<endl;
			#endif

			char temp[50];
			sprintf (temp, "gen_%d", gen);

			ss.clear();
			ss <<"%%% Highest Intermediate Supervisor Fitness: "<< NEAT::highest_fitness_overall << "     Gen #: " << (gen-1) << endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("supervisor_test", (print_output))

			ss.clear();
			ss <<"%%% Highest Intermediate Experiment Fitness: "<< NEAT::highest_fitness_overall_buf << "     Gen #: " << (gen-1) << endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("supervisor_test", (print_output))

			if( i_interactive_flag == 1 )
			{
				//Check for success
				cout<<"pre-supervisor_epoch "<< gen << "   " << gens <<endl;
			}

			ss.clear();
			ss <<"pre-supervisor_epoch "<< gen << "   " << gens <<endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("supervisor_test", (print_output))

			if (supervisor_epoch(pop,gen,temp,winnernum,winnergenes,winnernodes,egens))
			{

				//Collect Stats on end of experiment
				evals[expcount]=(pop->popparams).pop_size*(gen-1)+winnernum;

				genes[expcount]=winnergenes;
				nodes[expcount]=winnernodes;
				gen=gens;

			}

			//Clear output filename
			fnamebuf->clear();
			delete fnamebuf;

		}

		if (expcount<(pop->popparams).num_runs-1) delete pop;
      
	}

	float power = 0.0;

    //Average and print stats
	for(expcount=0;expcount<(pop->popparams).num_runs;expcount++)
	{

		totalnodes+=nodes[expcount];

    }
    
    for(expcount=0;expcount<(pop->popparams).num_runs;expcount++)
	{

		totalgenes+=genes[expcount];

    }
    
    for(expcount=0;expcount<(pop->popparams).num_runs;expcount++)
	{

		totalevals+=evals[expcount];

    }

	delete [] evals;
	evals = NULL;

	delete [] genes;
	genes = NULL;

	delete [] nodes;
	nodes = NULL;

	delete start_genome;
	start_genome = NULL;

    return pop;

}
//#################################################################################################



#include "neat.h"
#include "population.h"

#include <ctime>
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#include  <io.h>


#include <time.h>
 
void sleep(unsigned int mseconds)
{
    clock_t goal = mseconds + clock();
    while (goal > clock());
}
 



using namespace std;


extern void call_neat(int i1, int i, int igen, NEAT &A, int egen);

extern void load_test_input_output_data();


int i_accum_tmp = 0;

int i_interactive_flag = 0;			// 0 = not interactive, 1 = interactive

int i_param_file_flag = 0;			// 0 = file does not exist, 1 = file exists

int i_run_control_file_flag = 0;	// 0 = file does not exist, 1 = file exists

string s_param_epop_filename = "param_epop.inp";
char* param_epop_filename = (char*)(s_param_epop_filename.c_str());

string s_param_spop_filename = "param_spop.inp";
char* param_spop_filename = (char*)(s_param_spop_filename.c_str());

string s_start_gene_epop_filename;
char* start_gene_epop_filename = (char*)(s_start_gene_epop_filename.c_str());

string s_start_gene_spop_filename;
char* start_gene_spop_filename = (char*)(s_start_gene_spop_filename.c_str());


int main() {

	int	i, i1;

	int	ipop, igen, egen, irun;

	NEAT A;

	stringstream ss;
	string s_print_output; 
	char* print_output;

	//Set the file to log to
	DBUG_SETFILE("output.dat");

	load_test_input_output_data();


	//***********RANDOM SETUP***************//
	/* Seed the random-number generator with current time so that
	the numbers will be different every time we run.    */
	srand( (unsigned)time( NULL ) );

	string s_run_control_filename = "param_run_control.inp";
	char* run_control_filename = (char*)(s_run_control_filename.c_str());

	// set default supervisor start gene filename
	s_start_gene_spop_filename = "startgene_spop.inp";
	start_gene_spop_filename = (char*)(s_start_gene_spop_filename.c_str());

	// set default experiment start gene filename
	s_start_gene_epop_filename = "startgene_epop.inp";
	start_gene_epop_filename = (char*)(s_start_gene_epop_filename.c_str());

	/* Check for existence of parameter file */
	if( (_access( param_epop_filename, 0 )) != -1 )
	{
		i_param_file_flag = 1;

		/* Check for existence of run control file */
		if( (_access( run_control_filename, 0 )) != -1 )
		{
			i_run_control_file_flag = 1;

			std::ifstream iFile(run_control_filename,std::ios::in);
			string s;

			getline(iFile, s);

			ss.clear();
			ss << s;
			ss >> irun >> ipop >> igen >> egen;

			getline(iFile, s);
			s_start_gene_spop_filename = s;
			start_gene_spop_filename = (char*)(s_start_gene_spop_filename.c_str());

			getline(iFile, s);
			s_start_gene_epop_filename = s;
			start_gene_epop_filename = (char*)(s_start_gene_epop_filename.c_str());

			iFile.close();

			irun = 1;	// overwrite value for # runs when a param file exists
			ipop = 1;	// overwrite value for supervisor population size when a param file exists
			igen = 1;	// overwrite value for # supervisor generations when a param file exists
//			egen = 1;	// when a param file exists, only interested in # of experiment generations
		}
		else
		{
			irun = 1;	// default value
			ipop = 1;	// default value
			igen = 1;	// default value
			egen = 1;	// default value
		}
	}
	else
	{
		/* Check for existence of run control file */
		if( (_access( run_control_filename, 0 )) != -1 )
		{

			i_run_control_file_flag = 1;

			std::ifstream iFile(run_control_filename,std::ios::in);
			string s;

			getline(iFile, s);

			ss.clear();
			ss << s;
			ss >> irun >> ipop >> igen >> egen;

			getline(iFile, s);

			s_start_gene_spop_filename = s;
			start_gene_spop_filename = (char*)(s_start_gene_spop_filename.c_str());

			getline(iFile, s);
			s_start_gene_epop_filename = s;
			start_gene_epop_filename = (char*)(s_start_gene_epop_filename.c_str());

			iFile.close();
		}
		else
		{
			i_interactive_flag = 1;

			cout << "Enter # runs: ";
			cin >> irun;

			cout << "Enter # supervisor population: ";
			cin >> ipop;

			cout << "Enter # supervisor generations: ";
			cin >> igen;

			cout << "Enter # experiment generations: ";
			cin >> egen;

		}
	}

	ss.clear();
	ss << "Initial Values irun,ipop,igen,egen: " << irun << "   " << ipop << "   " << igen << "   " << egen << std::endl;
	getline(ss,s_print_output);
	print_output = (char*)(s_print_output.c_str());
	DBUG_PRINT("main", (print_output))

	DBUG_PRINT("main", (start_gene_spop_filename))

	DBUG_PRINT("main", (param_spop_filename))

	DBUG_PRINT("main", (start_gene_epop_filename))

	DBUG_PRINT("main", (param_epop_filename))



	for(i1=0;i1<irun;i1++) 
	{
		
		A.highest_fitness_overall = 0.0;
		A.highest_fitness_overall_buf = 0.0;
		i_accum_tmp = 0;


		call_neat( (i1 + 1), ipop, igen, A, egen);

		ss.clear();
		ss <<"*** Highest Final Supervisor Fitness: "<< NEAT::highest_fitness_overall << "     Run#: " << (i1+1) << endl;
		getline(ss,s_print_output);
		print_output = (char*)(s_print_output.c_str());
		DBUG_PRINT("main", (print_output))

		ss.clear();
		ss <<"*** Highest Final Experiment Fitness: "<< NEAT::highest_fitness_overall_buf << "   Run#: " << (i1+1) << endl;
		getline(ss,s_print_output);
		print_output = (char*)(s_print_output.c_str());
		DBUG_PRINT("main", (print_output))

	}

	ss.clear();
	ss <<"Final Values irun,ipop,igen,egen: "<< irun << "   " << ipop << "   " << igen << "   " << egen << endl;
	getline(ss,s_print_output);
	print_output = (char*)(s_print_output.c_str());
	DBUG_PRINT("main", (print_output))

	cout << "Pre-sleep call" << endl;
	sleep(1000000);
	cout << "Post-sleep call" << endl;

	return(0);
 
}






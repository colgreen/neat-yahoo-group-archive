
#include "experiments.h"
#include "population.h"

#include <cstring>
#include <stdlib.h>
#include <ctime>
#include  <io.h>

#define NO_SCREEN_OUT 

using namespace std; 

extern vector<double> Input_1;
extern vector<double> Input_2;
extern vector<double> Input_3;
extern vector<double> Input_4;
extern vector<double> Input_5;

extern int i_interactive_flag;

extern char* start_gene_epop_filename;

extern int i_num_tries;



//#################################################################################################
bool data_evaluate(Population::Organism *org) {

	Population::Network *net;

	int i,j;

	double out[8]; //The outputs

	double this_out; //The current output
	int count;
	double errorsum;

	bool success;  //Check for successful activation
	int numnodes;  /* Used to figure out how many nodes should be visited during activation */

	int net_depth; //The max depth of the network to be activated
	int relax; //Activates until relaxation

//	double in[8] = {0.17928,0.17928,0.17928,0.17928,0.17928,0.17928,0.17928,0.17928};
	double in[1] = {0.17928};


	net=org->net;

	numnodes=((org->gnome)->nodes).size();

	net_depth=net->max_depth();

	std::vector<Population::NNode*>::iterator curoutnode;

	//Load and activate the network on each input
	for(count=0;count<=1;count++) {

		net->load_sensors(&in[count]);

		//Relax net and get output
		success=net->activate();

		//use depth to ensure relaxation
		for (relax=0;relax<=net_depth;relax++) {

			success=net->activate();
			this_out=(*(net->outputs.begin()))->activation;

		}

		int i_tmp = 0;

		for(curoutnode = net->outputs.begin(); curoutnode != net->outputs.end(); ++curoutnode) 
		{
			out[i_tmp]=(*curoutnode)->activation;

			i_tmp++;
		}

		net->flush();

	}

	double Param_1 = 0.0;
	double Param_2 = 0.0;
	double Param_3 = 0.0; 
	double Param_4 = 0.0;
	double Param_5 = 0.0;
	double Param_6 = 0.0;
	double Param_7 = 0.0;
	double Param_8 = 0.0;

	double Param_1_norm = 0.0;
	double Param_2_norm = 0.0;
	double Param_3_norm = 0.0; 
	double Param_4_norm = 0.0;
	double Param_5_norm = 0.0;
	double Param_6_norm = 0.0;
	double Param_7_norm = 0.0;
	double Param_8_norm = 0.0;

	double Param_1_max			= 378.00;
	double Param_2_max			= 28.000;
	double Param_3_max		= 600.00; 
	double Param_4_max		= 0.7200;
	double Param_5_max			= 281.00;
	double Param_6_max			= 794.40;
	double Param_7_max		= 523.30;
	double Param_8_max	= 523.30;

	double Param_1_min			= 0.37800;
	double Param_2_min			= 0.28000E-01;
	double Param_3_min		= 0.60000; 
	double Param_4_min		= 0.72000E-03;
	double Param_5_min			= 0.28100;
	double Param_6_min			= 0.79440;
	double Param_7_min		= 0.52330;
	double Param_8_min	= 0.52330;

	double N_min = 0.1;
	double N_max = 0.9;
	bool threshold = true;
	double N_prime;
	
	PopParams B;

	if (success) {

		errorsum = 0.0;

		for (i=0;i<1;i++) 
		{
			//Param_1 Max/Min/Norm:		37.800          378.00         0.37800         0.17928    
			//Param_2 Max/Min/Norm:		2.8000          28.000         0.28000E-01     0.17928    
			//Param_3 Max/Min/Norm:		60.000          600.00         0.60000         0.17928    
			//Param_4 Max/Min/Norm:     0.72000E-01     0.72000        0.72000E-03     0.17928    
			//Param_5 Max/Min/Norm:			28.100          281.00         0.28100         0.17928    
			//Param_6 Max/Min/Norm:			79.440          794.40         0.79440         0.17928    
			//Param_7 Max/Min/Norm:      52.330          523.30         0.52330         0.17928    
			//Param_8 Max/Min/Norm:  52.330          523.30         0.52330         0.17928    

			//out[0] = 0.17928;
			//out[1] = 0.17928;
			//out[2] = 0.17928;
			//out[3] = 0.17928;
			//out[4] = 0.17928;
			//out[5] = 0.17928;
			//out[6] = 0.17928;
			//out[7] = 0.17928;

			N_prime = out[0];	// Param_1
			Param_1 = B.unnormalize_output( Param_1, Param_1_min, Param_1_max, N_min, N_max, N_prime, threshold);

			N_prime = out[1];	// Param_2
			Param_2 = B.unnormalize_output( Param_2, Param_2_min, Param_2_max, N_min, N_max, N_prime, threshold);

			N_prime = out[2];	// Param_3
			Param_3 = B.unnormalize_output( Param_3, Param_3_min, Param_3_max, N_min, N_max, N_prime, threshold);

			N_prime = out[3];	// Param_4
			Param_4 = B.unnormalize_output( Param_4, Param_4_min, Param_4_max, N_min, N_max, N_prime, threshold);

			N_prime = out[4];	// Param_5
			Param_5 = B.unnormalize_output( Param_5, Param_5_min, Param_5_max, N_min, N_max, N_prime, threshold);

			N_prime = out[5];	// Param_6
			Param_6 = B.unnormalize_output( Param_6, Param_6_min, Param_6_max, N_min, N_max, N_prime, threshold);

			N_prime = out[6];	// Param_7
			Param_7 = B.unnormalize_output( Param_7, Param_7_min, Param_7_max, N_min, N_max, N_prime, threshold);

			N_prime = out[7];	// Param_8
			Param_8 = B.unnormalize_output( Param_8, Param_8_min, Param_8_max, N_min, N_max, N_prime, threshold);

			int ii = 0;

			//% This .m file simulates the control law algorithms presented in xxx

			//%% xxx Constants
			//Param_1 = 37.8;
			//Param_2 = 2.8;
			//Param_3 = 60;
			//Param_4 = 0.072;
			//Param_5 = 28.1;
			//Param_6 = 79.44;
			//Param_7 = 52.33;
			//Param_8 = 52.33;

			for( j = 0; j < Input_1.size(); j++ )
			{
				//%% Inputs From xx

				double Var_1 = Input_1.at(j);

				int Var_2 = 1;

				double Var_3 = Input_2.at(j);

				int Var_4 = 1;

				double Var_5 = Input_3.at(j);

				int Var_6 = 1;

				double Var_7 = Input_4.at(j);

				double Var_8;

				double Var_9;

				double Var_10;

				if( Var_4 == 1 )
				{
    				Var_9 = Var_3;
				}
				else
				{
    				Var_9 = Param_1;
				}

				if( Var_5 < (Var_9 + Param_2) )
				{
    				Var_10 = Param_2;
				}
				else
				{
    				Var_10 = (Var_5 - Var_9);
				}

				if( Var_2 == 1 )
				{
    				Var_8 = Var_1;
				}
				else
				{
    				Var_8 = Param_3;
				}

				double Var_11 = Param_4*(Var_8/Var_10);

				double Var_12 = Param_5*Var_11*(Var_5 - Param_6);

				double Var_13;

				if( Var_12 >= Param_7 )
				{
    				Var_13 = 0;
				}
				else
				{
					if( Var_12 < 0 )
					{
        				Var_13 = 10;
					}
					else
					{
    					Var_13 = (1-(Var_12/Param_7))*10;
					}
				}

				if( Var_7 < (Var_9 + Param_2) )
				{
    				Var_10 = Param_2;
				}
				else
				{
    				Var_10 = (Var_7 - Var_9);
				}

				Var_11 = Param_4*(Var_8/Var_10);

				double Var_14 = Param_5*Var_11*(Var_7 - Param_6);

				double Var_15;

				if( Var_14 >= Param_8 )
				{
    				Var_15 = 0;
				}
				else
				{
					if( Var_14 < 0 )
					{
        				Var_15 = 10;
					}
					else
					{
    					Var_15 = (1-(Var_14/Param_8))*10;
					}
				}

				double Var_16;

				if( Var_15 > Var_13 )
				{
    				Var_16 = Var_13;
				}
				else
				{
    				Var_16 = Var_15;
				}

				errorsum = errorsum + ( fabs( Var_16 - Input_5.at(j) ) );

				int iii = 0;

			}

		}

		org->fitness=pow((1.0/errorsum),2);

		org->error=errorsum;

		org->experimentresultsptr->Fitness = org->fitness;
		org->experimentresultsptr->Param_7 = Param_7;
		org->experimentresultsptr->Param_8 = Param_8;
		org->experimentresultsptr->Param_5 = Param_5;
		org->experimentresultsptr->Param_6 = Param_6;
		org->experimentresultsptr->Param_4 = Param_4;
		org->experimentresultsptr->Param_3 = Param_3;
		org->experimentresultsptr->Param_1 = Param_1;
		org->experimentresultsptr->Param_2 = Param_2;

	}
	else 
	{
		//The network is flawed (shouldnt happen)
//		errorsum=999999.0;
		errorsum = 1.0E15;

//		org->fitness=0.0000001;
		org->fitness = 1.0E-15;
	}

//	delete []in;
//	delete []out;

//	#ifndef NO_SCREEN_OUT
//	cout<<"Org "<<(org->gnome)->genome_id<<"                                     error: "<<errorsum<<"  ["<<out[0]<<" "<<out[1]<<" "<<out[2]<<" "<<out[3]<<"]"<<endl;
//	cout<<"Org "<<(org->gnome)->genome_id<<"                                     fitness: "<<org->fitness<<endl;
//	#endif

	if ((org->fitness>1.5)) {

		org->winner=true;
		return true;

	}
	else {

		org->winner=false;
		return false;

	}

}
//#################################################################################################



//#################################################################################################
int data_epoch(Population *pop,int generation,char *filename,int &winnernum,int &winnergenes,int &winnernodes)
{

	vector<Population::Organism*>::iterator curorg;
	vector<Population::Species*>::iterator curspecies;

	bool win=false;

	double r_tmp = 0;

	double r_highest_fitness = 0;
	double r_highest_fitness_accum = 0;

	int i_flag = 0;

	stringstream ss;
	string s_print_output; 
	char* print_output;

	//Evaluate each organism on a test
	for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {

		if (data_evaluate(*curorg)) {

			win=true;
			winnernum=(*curorg)->gnome->genome_id;
			winnergenes=(*curorg)->gnome->extrons();
			winnernodes=((*curorg)->gnome->nodes).size();

			if (winnernodes==5) {

				//You could dump out optimal genomes here if desired
				//(*curorg)->gnome->print_to_filename("data_optimal");

			}
		}

		r_tmp = (*curorg)->fitness;

		r_highest_fitness=pop->highest_fitness;

		pop->highest_fitness_accum_buf = pop->highest_fitness_accum_buf + r_tmp;

		if ( r_tmp > pop->highest_fitness_buf ) {

			pop->highest_fitness_buf = r_tmp;

		}

//		keep track of highest fitness of experiment & output associated population
		if ( r_tmp > NEAT::highest_fitness_overall_2ndbuf ) {

			i_num_tries = i_num_tries + 1;	// increase current value of i_num_tries for new high-water-mark fitness

			NEAT::highest_fitness_overall_2ndbuf = r_tmp;

			(*curorg)->gnome->print_to_filename("best_exp_genome.out");

			if( i_interactive_flag == 1 )
			{
				cout << "best_exp_genome.out " << NEAT::highest_fitness_overall_2ndbuf << std::endl;
			}

			ss.clear();
			ss << "best_exp_genome.out " << NEAT::highest_fitness_overall_2ndbuf << std::endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("data_epoch", (print_output))

		    ofstream oFile("best_exp_genome_results.out");

			oFile << "best_exp_genome.out NEAT::highest_fitness_overall_2ndbuf: " << NEAT::highest_fitness_overall_2ndbuf << "    " << (*curorg)->experimentresultsptr->Fitness << std::endl;
			oFile << std::endl;

			oFile << "Param_7 :     " << (*curorg)->experimentresultsptr->Param_7 << std::endl;
			oFile << "Param_8 : " << (*curorg)->experimentresultsptr->Param_8 << std::endl;
			oFile << "Param_5 :          " << (*curorg)->experimentresultsptr->Param_5 << std::endl;
			oFile << "Param_6 :          " << (*curorg)->experimentresultsptr->Param_6 << std::endl;
			oFile << "Param_4 :    " << (*curorg)->experimentresultsptr->Param_4 << std::endl;
			oFile << "Param_3 :      " << (*curorg)->experimentresultsptr->Param_3 << std::endl;
			oFile << "Param_1 :       " << (*curorg)->experimentresultsptr->Param_1 << std::endl;
			oFile << "Param_2 :       " << (*curorg)->experimentresultsptr->Param_2 << std::endl;

			oFile.close();

		}

	}

	//Average and max their fitnesses for dumping to file and snapshot
	for(curspecies=(pop->species).begin();curspecies!=(pop->species).end();++curspecies) {

		//This experiment control routine issues commands to collect ave
		//and max fitness, as opposed to having the snapshot do it, 
		//because this allows flexibility in terms of what time
		//to observe fitnesses at

		(*curspecies)->compute_average_fitness();
		(*curspecies)->compute_max_fitness();

	}

	
	//Take a snapshot of the population, so that it can be
	//visualized later on
	//if ((generation%1)==0)
	//  pop->snapshot();

	//Only print to file every print_every generations
	if  (win) {

		pop->print_to_file_by_species("exp_winner_pop_by_species.dat");

	}

	Population::Genome C;

	if (win) {

		for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {

			if ((*curorg)->winner) {

				//Prints the winner to file
				//IMPORTANT: This causes generational file output!
				C.print_Genome_tofile((*curorg)->gnome,"exp_winner_genome.dat");

			}
		}
   	}

	pop->epoch(generation,pop);

	if (win) return 1;
	else return 0;

}
//#################################################################################################





//#################################################################################################
//Perform evolution on data, for gens generations
Population *data_test(int gens, Population* pop) {

	pop->popparams.initializer_bsc(pop);

	Population::Genome *start_genome;
	char curword[20];
	int id;

	int i,j;

	ostringstream *fnamebuf;
	int gen;
 
	int* evals;  //Hold records for each run

	int* genes;

	int* nodes;

	int winnernum;
	int winnergenes;
	int winnernodes;

	//For averaging
	int totalevals=0;
	int totalgenes=0;
	int totalnodes=0;
	int expcount;

	evals = new int[(pop->popparams).num_runs];

	genes = new int[(pop->popparams).num_runs];

	nodes = new int[(pop->popparams).num_runs];

	/* Check for existence of experiment start gene file */
	if( (_access( start_gene_epop_filename, 0 )) != -1 )
	{
		ifstream iFile(start_gene_epop_filename,ios::in);

		//Read in the start Genome
		iFile>>curword;
		iFile>>id;
		start_genome=new Population::Genome(id,iFile);
		iFile.close();
	}
	else
	{
		DBUG_PRINT("data_test", ("Abort: start_gene_epop_filename file does not exist!"))
		abort();
	}

	for(expcount=0;expcount<(pop->popparams).num_runs;expcount++) {

		//Spawn the Population
		pop=new Population(start_genome,(pop->popparams).pop_size);
      
		pop->popparams.initializer_bsc(pop);

		pop->verify(pop);

		for (gen=1;gen<=gens;gen++) {

			//This is how to make a custom filename
			fnamebuf=new ostringstream();
			(*fnamebuf)<<"gen_"<<gen<<ends;  //needs end marker

			#ifndef NO_SCREEN_OUT
//			cout<<"name of fname: "<<fnamebuf->str()<<endl;
			#endif

			char temp[50];
			sprintf (temp, "gen_%d", gen);

			//Check for success
			if (data_epoch(pop,gen,temp,winnernum,winnergenes,winnernodes)) {

				//Collect Stats on end of experiment
				evals[expcount]=(pop->popparams).pop_size*(gen-1)+winnernum;

				genes[expcount]=winnergenes;
				nodes[expcount]=winnernodes;
				gen=gens;

			}

			//Clear output filename
			fnamebuf->clear();
			delete fnamebuf;

		}

		if (expcount<(pop->popparams).num_runs-1) delete pop;
      
	}

	float power = 0.0;

    //Average and print stats
	for(expcount=0;expcount<(pop->popparams).num_runs;expcount++) {

		totalnodes+=nodes[expcount];

    }
    
    for(expcount=0;expcount<(pop->popparams).num_runs;expcount++) {

		totalgenes+=genes[expcount];

    }
    
    for(expcount=0;expcount<(pop->popparams).num_runs;expcount++) {

		totalevals+=evals[expcount];

    }

	delete [] evals;
	evals = NULL;

	delete [] genes;
	genes = NULL;

	delete [] nodes;
	nodes = NULL;

	delete start_genome;
	start_genome = NULL;

    return pop;

}
//#################################################################################################


#include "population.h"

#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

extern int i_interactive_flag;			// 0 = not interactive, 1 = interactive

//#################################################################################################
Population::NNode::NNode(nodetype ntype,int nodeid) {

	active_flag=false;
	activesum=0;
	activation=0;
	output=0;
	last_activation=0;
	last_activation2=0;
	type=ntype; //NEURON or SENSOR type
	activation_count=0; //Inactive upon creation
	node_id=nodeid;
	ftype=SIGMOID;
	nodetrait=0;
	gen_node_label=HIDDEN;
	dup=0;
	analogue=0;
	frozen=false;
	trait_id=1;
	override=false;

	embeddednetwork_num_inputs = 1;
	embeddednetwork_num_outputs = 1;

			if((( embeddednetwork_num_outputs > 1) || 
				( embeddednetwork_num_inputs > 1)) &&
				( ftype != EMBEDDEDNETWORK ))
			{
				int i = 0;
			}

}
//#################################################################################################


//#################################################################################################
Population::NNode::NNode(nodetype ntype,int nodeid,int iftype,char* filenameptr,nodeplace igen_node_label) {

	active_flag=false;
	activesum=0;
	activation=0;
	output=0;
	last_activation=0;
	last_activation2=0;
	type=ntype; //NEURON or SENSOR type
	activation_count=0; //Inactive upon creation
	node_id=nodeid;

	embeddednetwork_num_inputs = 1;
	embeddednetwork_num_outputs = 1;

	//	ftype=SIGMOID;
	if( iftype == 0 ) 
	{
		this->ftype=SIGMOID;

		this->gen_node_label=HIDDEN;
	}
	else
	{
		if( iftype == 1 )
		{
			this->ftype=EMBEDDEDNETWORK;

			this->gen_node_label = igen_node_label;

			for(int i = 0; i < 20; i++) this->EmbeddedNetworkFile[i] = filenameptr[i];	// afc, 12/07/06

			this->EmbeddedNetworkFileptr = &(this->EmbeddedNetworkFile[0]);

			int id;

			char curword[20];  //max word size of 20 characters

			std::ifstream iFile(this->EmbeddedNetworkFileptr);

			iFile>>curword;

			//Bypass initial comment
			if (strcmp(curword,"/*")==0)
			{
				iFile>>curword;

				while (strcmp(curword,"*/")!=0)
				{

					printf("%s ",curword);
					iFile>>curword;
				}

				iFile>>curword;
			}

			iFile>>id;

			this->genomeptr = new Population::Genome(id,iFile,iftype,this);

			iFile.close();

			this->networkptr = (this->genomeptr)->genesis(id,iftype);

			this->embeddednetwork = *(this->networkptr);
			this->embeddednetworkptr = (this->networkptr);

			this->embeddednetwork_num_inputs = (this->networkptr)->inputs.size();		// afc, 01/18/07
			this->embeddednetwork_num_outputs = (this->networkptr)->outputs.size();		// afc, 01/18/07

			char* nfilename1 = "node_network_links_1.out";
			this->embeddednetwork.print_links_tofile(nfilename1);

			gen_node_label = HIDDEN;	// afc, 01/19/07

			*(this->networkptr) = (this->embeddednetwork);

		}
		else
		{
			if( iftype == 2 )
			{
				this->ftype=EMBEDDEDPOPULATION;

				this->gen_node_label = igen_node_label;

				for(int i = 0; i < 20; i++) this->EmbeddedPopulationFile[i] = filenameptr[i];	// afc, 12/07/06
			}
		}
	}
	nodetrait=0;
	dup=0;
	analogue=0;
	frozen=false;
	trait_id=1;
	override=false;

			if((( embeddednetwork_num_outputs > 1) || 
				( embeddednetwork_num_inputs > 1)) &&
				( ftype != EMBEDDEDNETWORK ))
			{
				int i = 0;
			}

}
//#################################################################################################


//#################################################################################################
Population::NNode::NNode(nodetype ntype,int nodeid,int iftype,Population::Network* netptr,nodeplace igen_node_label) {

	active_flag=false;
	activesum=0;
	activation=0;
	output=0;
	last_activation=0;
	last_activation2=0;
	type=ntype; //NEURON or SENSOR type
	activation_count=0; //Inactive upon creation
	node_id=nodeid;

	embeddednetwork_num_inputs = 1;
	embeddednetwork_num_outputs = 1;

	//	ftype=SIGMOID;
	if( iftype == 0 ) 
	{
		this->ftype=SIGMOID;

		this->gen_node_label=HIDDEN;
	}
	else
	{
		if( iftype == 1 )
		{
			this->ftype=EMBEDDEDNETWORK;

			this->gen_node_label = igen_node_label;

			this->embeddednetworkptr = netptr;

			this->embeddednetwork_num_inputs = netptr->inputs.size();		// afc, 01/18/07
			this->embeddednetwork_num_outputs = netptr->outputs.size();		// afc, 01/18/07

			int i=0;
		}
		else
		{
			if( iftype == 2 )
			{
				this->ftype=EMBEDDEDPOPULATION;

				this->gen_node_label = igen_node_label;

			}
		}
	}
	nodetrait=0;
	dup=0;
	analogue=0;
	frozen=false;
	trait_id=1;
	override=false;

			if((( embeddednetwork_num_outputs > 1) || 
				( embeddednetwork_num_inputs > 1)) &&
				( ftype != EMBEDDEDNETWORK ))
			{
				int i = 0;
			}

}
//#################################################################################################


//#################################################################################################
Population::NNode::NNode(nodetype ntype,int nodeid, nodeplace placement) {

	active_flag=false;
	activesum=0;
	activation=0;
	output=0;
	last_activation=0;
	last_activation2=0;
	type=ntype; //NEURON or SENSOR type
	activation_count=0; //Inactive upon creation
	node_id=nodeid;
	ftype=SIGMOID;
	nodetrait=0;
	gen_node_label=placement;
	dup=0;
	analogue=0;
	frozen=false;
	trait_id=1;
	override=false;

	embeddednetwork_num_inputs = 1;
	embeddednetwork_num_outputs = 1;

			if((( embeddednetwork_num_outputs > 1) || 
				( embeddednetwork_num_inputs > 1)) &&
				( ftype != EMBEDDEDNETWORK ))
			{
				int i = 0;
			}

}
//#################################################################################################


//#################################################################################################
Population::NNode::NNode(Population::NNode *n,Population::Trait *t) {

	active_flag=false;
	activation=0;
	output=0;
	last_activation=0;
	last_activation2=0;
	type=n->type; //NEURON or SENSOR type
	activation_count=0; //Inactive upon creation
	node_id=n->node_id;
	ftype=SIGMOID;
	nodetrait=0;
	gen_node_label=n->gen_node_label;
	dup=0;
	analogue=0;
	nodetrait=t;
	frozen=false;
	if (t!=0)
		trait_id=t->trait_id;
	else trait_id=1;
	override=false;

	embeddednetwork_num_inputs = 1;
	embeddednetwork_num_outputs = 1;

	if( n->ftype == EMBEDDEDNETWORK )
	{
		ftype = n->ftype;

		embeddednetwork_num_inputs = n->embeddednetwork_num_inputs;		// afc, 01/18/07

		embeddednetwork_num_outputs = n->embeddednetwork_num_outputs;	// afc, 01/18/07

		embeddednetworkptr = n->embeddednetworkptr;						// afc, 01/16/07

		for(int i = 0; i < 20; i++) this->EmbeddedNetworkFile[i] = n->EmbeddedNetworkFile[i];

		EmbeddedNetworkFileptr = n->EmbeddedNetworkFileptr;

	}

			if((( embeddednetwork_num_outputs > 1) || 
				( embeddednetwork_num_inputs > 1)) &&
				( ftype != EMBEDDEDNETWORK ))
			{
				int i = 0;
			}

}
//#################################################################################################


//#################################################################################################
Population::NNode::NNode (const char *argline, std::vector<Population::Trait*> &traits) {

	int traitnum;
	std::vector<Population::Trait*>::iterator curtrait;

	embeddednetwork_num_inputs = 1;
	embeddednetwork_num_outputs = 1;

	activesum=0;

    std::stringstream ss(argline);

    int nodety, nodepl;

	int iftype;
	char genomefilename[20];  //max word size of 20 characters

    ss >> node_id >> traitnum >> nodety >> nodepl >> iftype >> genomefilename;

	// check for non-sigmoid neuron
	if( iftype > 0 )
	{

		if( iftype == 1 )	// check for embedded network
		{
			this->ftype = EMBEDDEDNETWORK;

			for(int i = 0; i < 20; i++) this->EmbeddedNetworkFile[i] = genomefilename[i];	// afc, 12/07/06

			this->EmbeddedNetworkFileptr = &(this->EmbeddedNetworkFile[0]);

			int id;

			char curword[20];  //max word size of 20 characters

			std::ifstream iFile(this->EmbeddedNetworkFileptr);

			iFile>>curword;

			//Bypass initial comment
			if (strcmp(curword,"/*")==0)
			{
				//strcpy(curword, NEAT::getUnit(curline, curwordnum++, delimiters));
				iFile>>curword;

				while (strcmp(curword,"*/")!=0)
				{

					printf("%s ",curword);
					//strcpy(curword, NEAT::getUnit(curline, curwordnum++, delimiters));
					iFile>>curword;
				}

				//cout<<endl;
				iFile>>curword;
				//strcpy(curword, NEAT::getUnit(curline, curwordnum++, delimiters));
			}

			//strcpy(curword, NEAT::getUnit(curline, curwordnum++, delimiters));
			//id = atoi(curword);
			iFile>>id;

			this->genomeptr = new Population::Genome(id,iFile,iftype,this);

			iFile.close();

			this->networkptr = (this->genomeptr)->genesis(id,iftype);

			this->embeddednetwork = *(this->networkptr);
			this->embeddednetworkptr = (this->networkptr);

			this->embeddednetwork_num_inputs = (this->networkptr)->inputs.size();		// afc, 01/18/07
			this->embeddednetwork_num_outputs = (this->networkptr)->outputs.size();		// afc, 01/18/07

			char* nfilename1 = "node_network_links_1.out";
			this->embeddednetwork.print_links_tofile(nfilename1);

			gen_node_label = HIDDEN;	// afc, 01/19/07

			*(this->networkptr) = (this->embeddednetwork);

		}//End check for embedded network
		else
		{

			if( iftype == 2 )	// check for embedded population (not complete!!!)
			{
				this->ftype = EMBEDDEDPOPULATION;

				for(int i = 0; i < 20; i++) this->EmbeddedPopulationFile[i] = genomefilename[i];	// afc, 12/07/06

				this->EmbeddedPopulationFileptr = &(this->EmbeddedPopulationFile[0]);				// afc, 12/07/06

				int id;

				char curword[20];  //max word size of 20 characters

				std::ifstream iFile(this->EmbeddedPopulationFileptr);

				iFile>>curword;

				//Bypass initial comment
				if (strcmp(curword,"/*")==0)
				{
					iFile>>curword;

					while (strcmp(curword,"*/")!=0)
					{

						printf("%s ",curword);
						iFile>>curword;
					}

					//cout<<endl;
					iFile>>curword;

				}//End Bypass initial comment

				iFile>>id;

				this->genomeptr = new Population::Genome(id,iFile);	// afc, need to change

				iFile.close();

				this->networkptr = (this->genomeptr)->genesis(id);	// afc, need to change

			}//End check for embedded population (not complete!!!)

		}//End check for embedded network

	}//End check for non-sigmoid neuron
	else
	{
        
		// check for non-defined neuron ftype
		if( iftype < 0 ) this->ftype = SIGMOID;

	}//End check for non-sigmoid neuron

    type = (nodetype)nodety;
    gen_node_label = (nodeplace)nodepl;

	// Get the Sensor Identifier and Parameter String
	// mySensor = SensorRegistry::getSensor(id, param);
	frozen=false;  //TODO: Maybe change

	//Get a pointer to the trait this node points to
	if (traitnum==0) nodetrait=0;
	else {

		curtrait=traits.begin();
		while(((*curtrait)->trait_id)!=traitnum)
			++curtrait;
		nodetrait=(*curtrait);
		trait_id=nodetrait->trait_id;

	}

	override=false;

			if((( embeddednetwork_num_outputs > 1) || 
				( embeddednetwork_num_inputs > 1)) &&
				( ftype != EMBEDDEDNETWORK ))
			{
				int i = 0;
			}

}
//#################################################################################################


//#################################################################################################
// This one might be incomplete
Population::NNode::NNode (const Population::NNode& nnode)
{
	active_flag = nnode.active_flag;
	activesum = nnode.activesum;
	activation = nnode.activation;
	output = nnode.output;
	last_activation = nnode.last_activation;
	last_activation2 = nnode.last_activation2;
	type = nnode.type; //NEURON or SENSOR type
	activation_count = nnode.activation_count; //Inactive upon creation
	node_id = nnode.node_id;
	ftype = nnode.ftype;
	nodetrait = nnode.nodetrait;
	gen_node_label = nnode.gen_node_label;
	dup = nnode.dup;
	analogue = nnode.dup;
	frozen = nnode.frozen;
	trait_id = nnode.trait_id;
	override = nnode.override;

	embeddednetwork_num_inputs = 1;
	embeddednetwork_num_outputs = 1;

	if( ftype == EMBEDDEDNETWORK )
	{
		embeddednetwork_num_inputs = nnode.analogue->embeddednetwork_num_inputs;

		embeddednetwork_num_outputs = nnode.analogue->embeddednetwork_num_outputs;

		embeddednetworkptr = nnode.analogue->embeddednetworkptr;

		gen_node_label = nnode.analogue->gen_node_label;

		for(int i = 0; i < 20; i++) EmbeddedNetworkFile[i] = nnode.analogue->EmbeddedNetworkFile[i];

		EmbeddedNetworkFileptr = nnode.analogue->EmbeddedNetworkFileptr;

	}

			if((( embeddednetwork_num_outputs > 1) || 
				( embeddednetwork_num_inputs > 1)) &&
				( ftype != EMBEDDEDNETWORK ))
			{
				int i = 0;
			}

}
//#################################################################################################


//#################################################################################################
Population::NNode::~NNode() {

	std::vector<Population::Link*>::iterator curlink;

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;
	std::vector<Population::NNode::NodeUniqueOutput*>::iterator curuniqueoutput;

	// loop over current unique inputs
	for(curuniqueinput = this->nodeuniqueinput.begin(); curuniqueinput != this->nodeuniqueinput.end(); ++curuniqueinput)
	{
		delete (*curuniqueinput);
	}


	// loop over current unique outputs
	for(curuniqueoutput = this->nodeuniqueoutput.begin(); curuniqueoutput != this->nodeuniqueoutput.end(); ++curuniqueoutput)
	{
		delete (*curuniqueoutput);
	}

}
//#################################################################################################


//#################################################################################################
//Returns the type of the node, NEURON or SENSOR
const nodetype Population::NNode::get_type() {

	return type;

}
//#################################################################################################


//#################################################################################################
//Allows alteration between NEURON and SENSOR.  Returns its argument
nodetype Population::NNode::set_type(nodetype newtype) {

	type=newtype;
	return newtype;

}
//#################################################################################################


//#################################################################################################
//If the node is a SENSOR, returns true and loads the value
bool Population::NNode::sensor_load(double value) {

	std::vector<Population::NNode::NodeUniqueOutput*>::iterator curuniqueoutput;

	std::vector<Population::Link*>::iterator  curoutgoinglink2;

	if (type==SENSOR) {

		//Time delay memory
		last_activation2=last_activation;
		last_activation=activation;

		activation_count++;  //Puts sensor into next time-step
		activation=value;

		int i_tmp = 0;

		int i_tmp2 = this->nodeuniqueoutput.size();

		// loop over current unique outputs
		for(curuniqueoutput = this->nodeuniqueoutput.begin(); curuniqueoutput != this->nodeuniqueoutput.end(); ++curuniqueoutput)
		{

			this->activation_count2 = activation_count;

			int t_tmp1 = (*curuniqueoutput)->outgoinglink2.size();

			// loop over current links
			for(curoutgoinglink2 = (*curuniqueoutput)->outgoinglink2.begin(); curoutgoinglink2 != (*curuniqueoutput)->outgoinglink2.end(); ++curoutgoinglink2)
			{

				(*curoutgoinglink2)->in_node_last_activation2 = last_activation;
				(*curoutgoinglink2)->in_node_last_activation = activation;
				(*curoutgoinglink2)->in_node_activation = value;
			}

			i_tmp++;

		}

		return true;

	}
	else return false;
}
//#################################################################################################


//#################################################################################################
// Note: NEAT keeps track of which links are recurrent and which
// are not even though this is unnecessary for activation.
// It is useful to do so for 2 other reasons: 
// 1. It makes networks visualization of recurrent networks possible
// 2. It allows genetic control of the proportion of connections
//    that may become recurrent
//#################################################################################################


//#################################################################################################
// Add an incoming connection a node
void Population::NNode::add_incoming(Population::NNode *feednode,double weight,bool recur) {

	int in_node_outnum = 1;		// afc, 12/19/06
	int out_node_innum = 1;
	Population::Link *newlink=new Population::Link(weight,feednode,in_node_outnum,this,out_node_innum,recur);

	this->pushbackincominglink(this,newlink);

}
//#################################################################################################


//#################################################################################################
// Nonrecurrent version
void Population::NNode::add_incoming(Population::NNode *feednode,double weight) {

	int in_node_outnum = 1;		// afc, 12/19/06
	int out_node_innum = 1;
	Population::Link *newlink=new Population::Link(weight,feednode,in_node_outnum,this,out_node_innum,false);

	this->pushbackincominglink(this,newlink);

}
//#################################################################################################


//#################################################################################################
// Return activation currently in node, if it has been activated
double Population::NNode::get_active_out() {

	if (activation_count>0)
		return activation;
	else return 0.0;

}
//#################################################################################################


//#################################################################################################
// Return activation currently in node from PREVIOUS (time-delayed) time step, if there is one
double Population::NNode::get_active_out_td() {

	if (activation_count>1)
		return last_activation;
	else return 0.0;

}
//#################################################################################################


//#################################################################################################
// This recursively flushes everything leading into and including this NNode, including recurrencies
void Population::NNode::flushback() {

	std::vector<Population::Link*>::iterator curlink;

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;

	//A sensor should not flush black
	if (type!=SENSOR) 
	{

		if (activation_count>0) {

			activation_count=0;
			activation=0;
			last_activation=0;
			last_activation2=0;

		}

		// loop over current unique inputs
		for(curuniqueinput = nodeuniqueinput.begin(); curuniqueinput != nodeuniqueinput.end(); ++curuniqueinput)
		{
			//loop over all incoming links
			for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
			{

			//Flush the link itself (For future learning parameters possibility) 
			(*curlink)->added_weight=0;

			if ((((*curlink)->in_node)->activation_count>0)) ((*curlink)->in_node)->flushback();

			}
		}

	}
	else 
	{

		//Flush the SENSOR
		activation_count=0;
		activation=0;
		last_activation=0;
		last_activation2=0;

	}

}
//#################################################################################################


//#################################################################################################
// This recursively checks everything leading into and including this NNode, 
// including recurrencies
// Useful for debugging
void Population::NNode::flushback_check(std::vector<Population::NNode*> &seenlist) {

	std::vector<Population::Link*>::iterator curlink;

	std::vector<Population::NNode*>::iterator location;

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;

	stringstream ss;
	string s_print_output; 
	char* print_output;

	if (!(type==SENSOR)) {

		//std::cout<<"ALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
		//std::cout<<"ALERT: "<<this<<" has activation  "<<activation<<std::endl;
		//std::cout<<"ALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
		//std::cout<<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;

		if (activation_count>0) {

			if( i_interactive_flag == 1 )
			{
				std::cout<<"ALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
			}
			ss.clear();
			ss <<"ALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("flushback_check", (print_output))

		}

		if (activation>0) {

			if( i_interactive_flag == 1 )
			{
				std::cout<<"ALERT: "<<this<<" has activation  "<<activation<<std::endl;
			}
			ss.clear();
			ss <<"ALERT: "<<this<<" has activation  "<<activation<<std::endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("flushback_check", (print_output))

		}

		if (last_activation>0) {

			if( i_interactive_flag == 1 )
			{
				std::cout<<"ALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
			}
			ss.clear();
			ss <<"ALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("flushback_check", (print_output))

		}

		if (last_activation2>0) {

			if( i_interactive_flag == 1 )
			{
				std::cout<<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;
			}
			ss.clear();
			ss <<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("flushback_check", (print_output))

		}

		// loop over current unique inputs
		for(curuniqueinput = nodeuniqueinput.begin(); curuniqueinput != nodeuniqueinput.end(); ++curuniqueinput)
		{
			//loop over all incoming links
			for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
			{

				location = std::find(seenlist.begin(),seenlist.end(),((*curlink)->in_node));

				if (location==seenlist.end()) 
				{

					seenlist.push_back((*curlink)->in_node);
					((*curlink)->in_node)->flushback_check(seenlist);

				}

			}// End loop over all incoming links
		}// End loop over current unique inputs

		//}

	}
	else {
		//Flush_check the SENSOR


		if( i_interactive_flag == 1 )
		{
			std::cout<<"sALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
			std::cout<<"sALERT: "<<this<<" has activation  "<<activation<<std::endl;
			std::cout<<"sALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
			std::cout<<"sALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;
		}
		ss.clear();
		ss <<"sALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
		getline(ss,s_print_output);
		print_output = (char*)(s_print_output.c_str());
		DBUG_PRINT("flushback_check", (print_output))

		ss.clear();
		ss <<"sALERT: "<<this<<" has activation  "<<activation<<std::endl;
		getline(ss,s_print_output);
		print_output = (char*)(s_print_output.c_str());
		DBUG_PRINT("flushback_check", (print_output))

		ss.clear();
		ss <<"sALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
		getline(ss,s_print_output);
		print_output = (char*)(s_print_output.c_str());
		DBUG_PRINT("flushback_check", (print_output))

		ss.clear();
		ss <<"sALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;
		getline(ss,s_print_output);
		print_output = (char*)(s_print_output.c_str());
		DBUG_PRINT("flushback_check", (print_output))

		if (activation_count>0)
		{
			if( i_interactive_flag == 1 )
			{
				std::cout<<"ALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
			}
			ss.clear();
			ss <<"ALERT: "<<this<<" has activation count "<<activation_count<<std::endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("flushback_check", (print_output))

		}

		if (activation>0)
		{
			if( i_interactive_flag == 1 )
			{
				std::cout<<"ALERT: "<<this<<" has activation  "<<activation<<std::endl;
			}
			ss.clear();
			ss <<"ALERT: "<<this<<" has activation  "<<activation<<std::endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("flushback_check", (print_output))

		}

		if (last_activation>0)
		{
			if( i_interactive_flag == 1 )
			{
				std::cout<<"ALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
			}
			ss.clear();
			ss <<"ALERT: "<<this<<" has last_activation  "<<last_activation<<std::endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("flushback_check", (print_output))

		}

		if (last_activation2>0)
		{
			if( i_interactive_flag == 1 )
			{
				std::cout<<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;
			}
			ss.clear();
			ss <<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<std::endl;
			getline(ss,s_print_output);
			print_output = (char*)(s_print_output.c_str());
			DBUG_PRINT("flushback_check", (print_output))

		}

	}

}
//#################################################################################################


//#################################################################################################
// Reserved for future system expansion
void Population::NNode::derive_trait(Population::Trait *curtrait) {

	if (curtrait!=0) {

		for (int count=0;count<PopParams::num_trait_params;count++)

			params[count]=(curtrait->params)[count];

	}
	else {

		for (int count=0;count<PopParams::num_trait_params;count++)

			params[count]=0;

	}

	if (curtrait!=0)
		trait_id=curtrait->trait_id;
	else trait_id=1;

}
//#################################################################################################


//#################################################################################################
// Returns the gene that created the node
Population::NNode *Population::NNode::get_analogue() {

	return analogue;

}
//#################################################################################################


//#################################################################################################
// Force an output value on the node
void Population::NNode::override_output(double new_output) {

	override_value=new_output;
	override=true;

}
//#################################################################################################


//#################################################################################################
// Tell whether node has been overridden
bool Population::NNode::overridden() {

	return override;

}
//#################################################################################################


//#################################################################################################
// Set activation to the override value and turn off override
void Population::NNode::activate_override() {

	activation=override_value;
	override=false;

}
//#################################################################################################


//#################################################################################################
// Set activation to the override value and turn off override
void Population::NNode::activate_override(Population::Link* curlink) {

	curlink->in_node_activation = curlink->in_node_override_value;

	curlink->in_node_override = false;

}
//#################################################################################################


//#################################################################################################
void Population::NNode::print_to_file(std::ofstream &outFile) {

  outFile<<"node "<<node_id<<" ";

  if (nodetrait!=0) outFile<<nodetrait->trait_id<<" ";
  else outFile<<"0 ";

  outFile<<type<<" ";

  if (ftype>0)	// check for non sigmoid neuron
  {
	  if( ftype == 1 )	// check for embedded network
	  {
		outFile<<gen_node_label<<" ";
		outFile<<ftype<<" ";
		outFile<<EmbeddedNetworkFile<<std::endl;

	  }//End check for embedded network
	  else
	  {
		  if( ftype == 2 )	// check for embedded population
		  {
			outFile<<gen_node_label<<" ";
			outFile<<ftype<<" ";
			outFile<<EmbeddedPopulationFile<<std::endl;

		  }//End check for embedded population
	  }

  }//End check for non sigmoid neuron

  else
  {
	outFile<<gen_node_label<<" ";
	outFile<<ftype<<std::endl;

  }


}
//#################################################################################################


//#################################################################################################
void Population::NNode::print_to_file(std::ostream &outFile) {

	char tempbuf[128];
	sprintf(tempbuf, "node %d ", node_id);
	outFile << tempbuf;

	if (nodetrait != 0) {

		char tempbuf2[128];
		sprintf(tempbuf2, "%d ", nodetrait->trait_id);
		outFile << tempbuf2;

	}
	else outFile << "0 ";

	char tempbuf2[128];
	sprintf(tempbuf2, "%d %d\n", type, gen_node_label);
	outFile << tempbuf2;

}
//#################################################################################################


//#################################################################################################
//Find the greatest depth starting from this neuron at depth d
int Population::NNode::depth(int d, Population::Network *mynet) {

	std::vector<Population::Link*>::iterator curlink;
	int cur_depth; //The depth of the current node
	int max=d; //The max depth

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;

	//cout<<"depth (1) pre-d:   "<<d<<endl;
	if (d>100) {

		//cout<<"depth (2) pre-d return"<<endl;

		//std::cout<<mynet->genotype<<std::endl;
		//std::cout<<"** DEPTH NOT DETERMINED FOR NETWORK WITH LOOP"<<std::endl;
		return 10;

	}


	//Base Case
	//cout<<"depth (3) pre-Base Case"<<endl;
	if ((this->type)==SENSOR) {

		//cout<<"depth (4) return d:   "<<d<<endl;
		return d;

	//Recursion
	} else {

		//cout<<"depth (5a) pre-curlink begin:  "<<innodes.begin()<<endl;
		//cout<<"depth (5b) pre-curlink end:    "<<innodes.end()<<endl;

		//for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {

		// loop over current unique inputs
		for(curuniqueinput = nodeuniqueinput.begin(); curuniqueinput != nodeuniqueinput.end(); ++curuniqueinput)
		{
			//loop over all incoming links
			for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
			{

				//cout<<"depth (6) curlink:   "<<curlink<<endl;

				cur_depth=((*curlink)->in_node)->depth(d+1,mynet);
				if (cur_depth>d) max=cur_depth;
				//cout<<"depth (7) post-max:   "<<max<<endl;

			}// End loop over all incoming links
		}// End loop over current unique inputs

		//}
  
		//cout<<"depth (8) return max:   "<<max<<endl;
		return max;

	} //end else

}
//#################################################################################################


//#################################################################################################
//Find the greatest depth starting from this neuron at depth d
int Population::NNode::depth(int d, Network *mynet, int i_num_tries_loop) {

	std::vector<Population::Link*>::iterator curlink;
	int cur_depth; //The depth of the current node
	int max=d; //The max depth

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;

	//cout<<"depth (1) pre-d:   "<<d<<endl;
	if (d>100) {

		//cout<<"depth (2) pre-d return"<<endl;

		//std::cout<<mynet->genotype<<std::endl;
		//std::cout<<"** DEPTH NOT DETERMINED FOR NETWORK WITH LOOP"<<std::endl;
		return 10;

	}


	i_num_tries_loop++;
	if (i_num_tries_loop>=10) {

		//cout<<"depth (2) pre-d return"<<endl;

		//std::cout<<mynet->genotype<<std::endl;
		//std::cout<<"** DEPTH NOT DETERMINED FOR NETWORK WITH LOOP"<<std::endl;
		return 10;

	}



	//Base Case
	//cout<<"depth (3) pre-Base Case"<<endl;
	if ((this->type)==SENSOR) {

		//cout<<"depth (4) return d:   "<<d<<endl;
		return d;

	//Recursion
	} else {



		//cout<<"depth (5a) pre-curlink begin:  "<<innodes.begin()<<endl;
		//cout<<"depth (5b) pre-curlink end:    "<<innodes.end()<<endl;
		//for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {

		// loop over current unique inputs
		for(curuniqueinput = nodeuniqueinput.begin(); curuniqueinput != nodeuniqueinput.end(); ++curuniqueinput)
		{
			//loop over all incoming links
			for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
			{

				//cout<<"depth (6) curlink:   "<<curlink<<endl;

				cur_depth=((*curlink)->in_node)->depth(d+1,mynet,i_num_tries_loop);
				if (cur_depth>d) max=cur_depth;
				//cout<<"depth (7) post-max:   "<<max<<endl;

			}// End loop over all incoming links
		}// End loop over current unique inputs
  
		//cout<<"depth (8) return max:   "<<max<<endl;
		return max;

	} //end else

}
//#################################################################################################


//#################################################################################################
Population::Genome *Population::NNode::new_Genome_load_file_to_node(char *filename) {

	Genome *newgenome;

	int id;

	char curword[20];  //max word size of 20 characters

	std::ifstream iFile(filename);

	iFile>>curword;

	//Bypass initial comment
	if (strcmp(curword,"/*")==0) {

		iFile>>curword;

		while (strcmp(curword,"*/")!=0) {

			printf("%s ",curword);
			iFile>>curword;

		}

		iFile>>curword;

	}

	iFile>>id;

	newgenome=new Population::Genome(id,iFile);

	iFile.close();

	return newgenome;
}
//#################################################################################################


//#################################################################################################
// trap for implementing push_back on incoming vector, afc, 12/14/06
void Population::NNode::pushbackincominglink(Population::NNode* inode, Population::Link* newlink) {

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;
	std::vector<Population::NNode::NodeUniqueOutput*>::iterator curuniqueoutput;
	std::vector<Population::Link*>::iterator curlink;

	int curinput = -1;
	int curoutput = -1;

	if( newlink->in_node->type == SENSOR )
	{
		int i=0;
	}

	if( newlink->out_node->type == SENSOR )
	{
		int i=0;
	}

	int i_i = newlink->out_node->nodeuniqueinput.size();
	int i_o = newlink->out_node->nodeuniqueoutput.size();

	// loop over current unique inputs to see if there is a match
	for(curuniqueinput = newlink->out_node->nodeuniqueinput.begin(); curuniqueinput != newlink->out_node->nodeuniqueinput.end(); ++curuniqueinput)
	{

		//loop over all incoming links
		for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
		{

			if( (newlink->in_node_outnum) == (*curlink)->in_node_outnum )
			{

				(*curuniqueinput)->incominglink2.push_back(newlink);	// A list of pointers to incoming weighted signals from other nodes

				goto label1;	// jump after finding match
			}
		}
	}

	Population::NNode::NodeUniqueInput* nodeuniqueinput1 = new Population::NNode::NodeUniqueInput(newlink);

	newlink->out_node->nodeuniqueinput.push_back(nodeuniqueinput1);		// link to new unique input for this node

	i_i = newlink->out_node->nodeuniqueinput.size();
	i_o = newlink->out_node->nodeuniqueoutput.size();

	label1: ;

	i_i = newlink->out_node->nodeuniqueinput.size();
	i_o = newlink->out_node->nodeuniqueoutput.size();

	// loop over current unique outputs to see if there is a match
	for(curuniqueoutput = newlink->in_node->nodeuniqueoutput.begin(); curuniqueoutput != newlink->in_node->nodeuniqueoutput.end(); ++curuniqueoutput)
	{

		//loop over all outgoing links
		for(curlink = (*curuniqueoutput)->outgoinglink2.begin(); curlink != (*curuniqueoutput)->outgoinglink2.end(); ++curlink)
		{

			if( (newlink->out_node_innum) == (*curlink)->out_node_innum )
			{

				(*curuniqueoutput)->outgoinglink2.push_back(newlink);	// A list of pointers to incoming weighted signals from other nodes

				goto label2;	// jump after finding match
			}
		}
	}

	Population::NNode::NodeUniqueOutput* nodeuniqueoutput1 = new Population::NNode::NodeUniqueOutput(newlink);

	newlink->in_node->nodeuniqueoutput.push_back(nodeuniqueoutput1);	// link to new unique output for this node

	i_i = newlink->out_node->nodeuniqueinput.size();
	i_o = newlink->out_node->nodeuniqueoutput.size();

	label2: ;

	i_i = newlink->out_node->nodeuniqueinput.size();
	i_o = newlink->out_node->nodeuniqueoutput.size();

}
//#################################################################################################


//#################################################################################################
Population::NNode::NodeUniqueInput::NodeUniqueInput(Population::Link* newlink) {

	this->incominglink2.push_back(newlink);				// A list of pointers to incoming weighted signals from other nodes

	this->incominglink2_innum = newlink->out_node_innum;			// output # of in_node (i.e. each node may have multiple unique outputs), afc, 12/11/06

	this->activesum_input = 0.0;								// The incoming activity before being processed 
	this->active_flag_input = true;

}
//#################################################################################################


//#################################################################################################
Population::NNode::NodeUniqueInput::~NodeUniqueInput() {

	std::vector<Population::Link*>::iterator curuniqueinput;

	if( this->incominglink2_innum > 0 )
	{
		//Kill off all incoming links
		for(curuniqueinput = this->incominglink2.begin(); curuniqueinput != this->incominglink2.end(); ++curuniqueinput)
		{
			delete (*curuniqueinput);
		}
	}

}
//#################################################################################################


//#################################################################################################
Population::NNode::NodeUniqueOutput::NodeUniqueOutput(Population::Link* newlink) {

	this->outgoinglink2.push_back(newlink);			// A list of pointers to incoming weighted signals from other nodes

	this->outgoinglink2_outnum = newlink->in_node_outnum;	// output # of in_node (i.e. each node may have multiple unique outputs), afc, 12/11/06

}
//#################################################################################################


#ifndef _dbug_h
#define _dbug_h

#ifndef DBUG_OFF  //if DBUG_OFF is defined, no debug prints are produced

void _db_setfile(char *name);
void _db_setkey(char *keyword);
void _db_print (const char *format,...);
void _db_closefile();

#define DBUG_SETSTDERR() \
        { _db_setfile(stderr); }
#define DBUG_SETFILE(name) \
        { _db_setfile(name); }
#define DBUG_CLOSEFILE() \
        { _db_closefile(); }

#define DBUG_PRINT(keyword,arglist) \
	{ _db_setkey(keyword); _db_print arglist; }

#define DBUG_ENTER(a1)
#define DBUG_LEAVE 
#define DBUG_RETURN(a1) return(a1)
#define DBUG_PUSH(a1) {}
#define DBUG_POP() {}
#define DBUG_PROCESS(a1) {}

#else //DBUG_OFF

#define DBUG_SETSTDERR() 
#define DBUG_SETFILE(name) 
#define DBUG_CLOSEFILE() 
#define DBUG_PRINT(keyword,arglist) {}
#define DBUG_ENTER(a1)
#define DBUG_LEAVE 
#define DBUG_RETURN(a1) return(a1)
#define DBUG_PUSH(a1) {}
#define DBUG_POP() {}
#define DBUG_PROCESS(a1) {}

#endif  //DBUG_OFF

#endif

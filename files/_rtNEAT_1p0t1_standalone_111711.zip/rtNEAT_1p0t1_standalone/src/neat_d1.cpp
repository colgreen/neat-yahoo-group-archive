
#include "neat.h"

#include "population.h"

#include <fstream>
#include <cmath>
#include <cstring>

using namespace std;

double NEAT::highest_fitness_overall = 0.0;			//afc, 11/16/06

double NEAT::highest_fitness_overall_buf = 0.0;		//afc, 11/28/06

double NEAT::highest_fitness_overall_2ndbuf = 0.0;	//afc, 01/18/07

//#################################################################################################
	int NEAT::getUnitCount(const char *string, const char *set)
{
	int count = 0;
	short last = 0;

	while(*string)
	{
		last = *string++;

		for(int i =0; set[i]; i++)
		{
			if(last == set[i])
			{
				count++;
				last = 0;
				break;
			}   
		}
	}

	if(last)
		count++;
	return count;
}   
//#################################################################################################


//#################################################################################################
double NEAT::gaussrand() {

	static int iset=0;
	static double gset;
	double fac,rsq,v1,v2;

	if (iset==0) {

		do {

			v1=2.0*(randfloat())-1.0;
			v2=2.0*(randfloat())-1.0;
			rsq=v1*v1+v2*v2;

		} while (rsq>=1.0 || rsq==0.0);
		fac=sqrt(-2.0*log(rsq)/rsq);
		gset=v1*fac;

		iset=1;
		return v2*fac;

	}
	else {

		iset=0;
		return gset;

	}
}
//#################################################################################################


//#################################################################################################
double NEAT::fsigmoid(double activesum,double slope,double constant) {

	//RIGHT SHIFTED ---------------------------------------------------------
	//return (1/(1+(exp(-(slope*activesum-constant))))); //ave 3213 clean on 40 runs of p2m and 3468 on another 40 
	//41394 with 1 failure on 8 runs

	//LEFT SHIFTED ----------------------------------------------------------
	//return (1/(1+(exp(-(slope*activesum+constant))))); //original setting ave 3423 on 40 runs of p2m, 3729 and 1 failure also

	//PLAIN SIGMOID ---------------------------------------------------------
	//return (1/(1+(exp(-activesum)))); //3511 and 1 failure

	//LEFT SHIFTED NON-STEEPENED---------------------------------------------
	//return (1/(1+(exp(-activesum-constant)))); //simple left shifted

	//NON-SHIFTED STEEPENED
	return (1/(1+(exp(-(slope*activesum))))); //Compressed

}
//#################################################################################################


//#################################################################################################
double NEAT::oldhebbian(double weight, double maxweight, double active_in, double active_out, double hebb_rate, double pre_rate, double post_rate) {

	bool neg=false;
	double delta;

	if (maxweight<5.0) maxweight=5.0;

	if (weight>maxweight) weight=maxweight;

	if (weight<-maxweight) weight=-maxweight;

	if (weight<0) {

		neg=true;
		weight=-weight;

	}

	if (!(neg)) {

		delta=
			hebb_rate*(maxweight-weight)*active_in*active_out+
			pre_rate*(weight)*active_in*(active_out-1.0)+
			post_rate*(weight)*(active_in-1.0)*active_out;

		if (weight+delta>0)
			return weight+delta;

	}
	else {

		//In the inhibatory case, we strengthen the synapse when output is low and
		//input is high
		delta=
			hebb_rate*(maxweight-weight)*active_in*(1.0-active_out)+ //"unhebb"
			-5*hebb_rate*(weight)*active_in*active_out+ //anti-hebbian
			0;

		if (-(weight+delta)<0)
			return -(weight+delta);
		else return -0.01;

		return -(weight+delta);

	}

	return 0;

}
//#################################################################################################


//#################################################################################################
double NEAT::hebbian(double weight, double maxweight, double active_in, double active_out, double hebb_rate, double pre_rate, double post_rate) {

	bool neg=false;
	double delta;

	double topweight;

	if (maxweight<5.0) maxweight=5.0;

	if (weight>maxweight) weight=maxweight;

	if (weight<-maxweight) weight=-maxweight;

	if (weight<0) {

		neg=true;
		weight=-weight;

	}

	topweight=weight+2.0;
	if (topweight>maxweight) topweight=maxweight;

	if (!(neg)) {

		delta=
			hebb_rate*(maxweight-weight)*active_in*active_out+
			pre_rate*(topweight)*active_in*(active_out-1.0);

		return weight+delta;

	}
	else {

		//In the inhibatory case, we strengthen the synapse when output is low and
		//input is high
		delta=
			pre_rate*(maxweight-weight)*active_in*(1.0-active_out)+ //"unhebb"
			-hebb_rate*(topweight+2.0)*active_in*active_out+ //anti-hebbian
			0;

		return -(weight+delta);

	}

}
//#################################################################################################


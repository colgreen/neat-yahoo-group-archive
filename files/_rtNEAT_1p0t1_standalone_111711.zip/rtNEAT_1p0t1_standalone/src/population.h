#ifndef _POPULATION_H_
#define _POPULATION_H_

#include <cmath>
#include <algorithm>
#include <vector>

#include "pop_params.h"

#include "neat.h"

// if we use or not debug functions
#include "dbug.h"

#include <fstream>

using namespace std;

	enum innovtype {
		NEWNODE = 0,
		NEWLINK = 1
	};

	enum mutator {
		GAUSSIAN = 0,
		COLDGAUSSIAN = 1
	};

	enum nodetype {
		NEURON = 0,
		SENSOR = 1
	};

	enum nodeplace {
		HIDDEN = 0,
		INPUT = 1,
		OUTPUT = 2,
		BIAS = 3
	};

	enum functype {
		SIGMOID = 0,
		EMBEDDEDNETWORK = 1,
		EMBEDDEDPOPULATION = 2
	};

	// ---------------------------------------------  
	// POPULATION CLASS:
	//   A Population is a group of Organisms   
	//   including their species                        
	// ---------------------------------------------  
	class Population {

	public:

		
		PopParams popparams;

		int population_id;


	//#################################################################################################
		// ------------------------------------------------------------------ 
		// TRAIT: A Trait is a group of parameters that can be expressed     
		//        as a group more than one time.  Traits save a genetic      
		//        algorithm from having to search vast parameter landscapes  
		//        on every node.  Instead, each node can simply point to a trait 
		//        and those traits can evolve on their own 
		class Trait;
		friend class Population::Trait;
		class Trait {

			// ************ LEARNING PARAMETERS *********** 
			// The following parameters are for use in    
			//   neurons that learn through habituation,
			//   sensitization, or Hebbian-type processes  

		public:

			int trait_id; // Used in file saving and loading
		
			double params[PopParams::num_trait_params]; // Keep traits in an array

			Trait ();

			Trait(int id,double p1,double p2,double p3,double p4,double p5,double p6,double p7,double p8,double p9);

			// Copy Constructor
			Trait(const Population::Trait& t);

			// Create a trait exactly like another trait
			Trait(Population::Trait *t);

			// Special constructor off a file assume word "trait" has been read in
			Trait(const char *argline);

			// Special Constructor creates a new Trait which is the average of 2 existing traits passed in
			Trait(Population::Trait *t1,Population::Trait *t2);

			// Dump trait to a stream
			void print_to_file(std::ostream &outFile);

			void print_to_file(std::ofstream &outFile);

			// Perturb the trait parameters slightly
			void mutate(Population* pop);

};		// end class Trait
	//#################################################################################################


	//#################################################################################################
		class NNode;
		// ----------------------------------------------------------------------- 
		// A LINK is a connection from one node to another with an associated weight 
		// It can be marked as recurrent 
		// Its parameters are made public for efficiency 
		class Link;
		friend class Population::Link;
		class Link {

		public: 
			double weight; // Weight of connection
			Population::NNode *in_node; // NNode inputting into the link

			int in_node_outnum;	// output # from in_node (i.e. each node may have multiple unique outputs), afc, 12/11/06

//			these next nine were shifted from NNode::NodeUniqueOutput to allow multi-outputs per NNode
			bool in_node_override;								// The NNode cannot compute its own output- something is overriding it
			double in_node_override_value;						// Contains the activation value that will override this node's activation
			bool in_node_active_flag;							// To make sure outputs are active
			double in_node_activation;							// The total activation entering the unique NNode input
			int in_node_max_num_delay_steps;					// keeps track of max # of elements in activation_timedelay
			double in_node_last_activation;						// Holds the previous step's activation for recurrency
			double in_node_last_activation2;					// Holds the activation BEFORE the prevous step's

			Population::NNode *out_node; // NNode that the link affects

			int out_node_innum;	// input # to out_node (i.e. each node may have multiple unique inputs), afc, 12/11/06

			bool is_recurrent;
			bool time_delay;

			Population::Trait *linktrait; // Points to a trait of parameters for genetic creation

			int trait_id;  // identify the trait derived by this link

			// ************ LEARNING PARAMETERS *********** 
			// These are link-related parameters that change during Hebbian type learning

			double added_weight;  // The amount of weight adjustment 

			double params[PopParams::num_trait_params];

			Link(double w,Population::NNode *inode,int inode_outnum,Population::NNode *onode,int onode_innum,bool recur);

			// Including a trait pointer in the Link creation
			Link(Trait *lt,double w,Population::NNode *inode,int inode_outnum,Population::NNode *onode,int onode_innum,bool recur);

			// For when you don't know the connections yet
			Link(double w);

			// Copy Constructor
			Link(const Population::Link& link);

			// Derive a trait into link params
			void derive_trait(Population::Trait *curtrait);

			Link();

		};	// end class Link
	//#################################################################################################


	//#################################################################################################
		// ----------------------------------------------------------------------- 
		// A NETWORK is a LIST of input NODEs and a LIST of output NODEs           
		//   The point of the network is to define a single entity which can evolve
		//   or learn on its own, even though it may be part of a larger framework 
		class Genome;
		class Network;
		friend class Population::Network;
		class Network {

			friend class Genome;
			friend class Population::Genome;

		protected:

			int numnodes; // The number of nodes in the net (-1 means not yet counted)
			int numlinks; //The number of links in the net (-1 means not yet counted)

			std::vector<Population::NNode*> all_nodes;  // A list of all the nodes

			std::vector<Population::NNode*>::iterator input_iter;  // For GUILE network inputting  

			void destroy();  // Kills all nodes and links within
			void destroy_helper(Population::NNode *curnode,std::vector<Population::NNode*> &seenlist); // helper for above

			void nodecounthelper(Population::NNode *curnode,int &counter,std::vector<Population::NNode*> &seenlist);
			void linkcounthelper(Population::NNode *curnode,int &counter,std::vector<Population::NNode*> &seenlist);

		public:

			Population::Genome *genotype;  // Allows Network to be matched with its Genome

			char *name; // Every Network or subNetwork can have a name

			std::vector<Population::NNode*> inputs;  // NNodes that input into the network
				//	Population::Genome::Genome
				//	Population::Network::Network
				//	Population::Network::show_input
				//	Population::Network::add_input
				//	Population::Network::load_sensors: called from: data_evaluate & supervisor_evaluate
				//	Population::Network::input_start
				//	Population::Network::load_in

			std::vector<Population::NNode*> outputs; // Values output by the network
				//	data_evaluate
				//	Population::Genome::Genome
				//	Population::Genome::mutate_add_sensor
				//	Population::Network::Network
				//	Population::Network::flush
				//	Population::Network::flush_check
				//	Population::Network::outputsoff
				//	Population::Network::show_activation
				//	Population::Network::add_output
				//	Population::Network::override_outputs
				//	Population::Network::nodecount
				//	Population::Network::linkcount
				//	Population::Network::max_depth
				//	supervisor_evaluate

			int net_id; // Allow for a network id

			double maxweight; // Maximum weight in network for adaptation purposes

			bool adaptable; // Tells whether network can adapt or not

			Network();

			// This constructor allows the input and output lists to be supplied
			// Defaults to not using adaptation
			Network(std::vector<Population::NNode*> in,std::vector<Population::NNode*> out,std::vector<Population::NNode*> all,int netid);

			//Same as previous constructor except the adaptibility can be set true or false with adaptval
			Network::Network(std::vector<Population::NNode*> in,std::vector<Population::NNode*> out,std::vector<Population::NNode*> all,int netid, bool adaptval);

			// This constructs a net with empty input and output lists
			Network(int netid);

			//Same as previous constructor except the adaptibility can be set true or false with adaptval
			Network::Network(int netid, bool adaptval);

			// Copy Constructor
			Network::Network(const Population::Network& network);

			~Network();

			// Puts the network back into an inactive state
			void flush();
		
			// Verify flushedness for debugging
			void flush_check();

			// Activates the net such that all outputs are active
			bool activate();

			void gen_incoming_activation_sigmoid(std::vector<Population::NNode*>::iterator curnode);
			void gen_incoming_activation_embeddednetwork(std::vector<Population::NNode*>::iterator curnode);

			void activate_incoming_activation_sigmoid(std::vector<Population::NNode*>::iterator curnode);
			void activate_incoming_activation_embeddednetwork(std::vector<Population::NNode*>::iterator curnode);
			void adapt_weights_based_on_activations(std::vector<Population::NNode*>::iterator curnode);

			// Prints the values of its outputs
			void show_activation();

			void show_input();

			// Add a new input node
			void add_input(Population::NNode*);

			// Add a new output node
			void add_output(Population::NNode*);

			// Takes an array of sensor values and loads it into SENSOR inputs ONLY
			void load_sensors(double*);
			void load_sensors(const std::vector<float> &sensvals);

			// Takes and array of output activations and OVERRIDES the outputs' actual 
			// activations with these values (for adaptation)
			void override_outputs(double*);

			// Name the network
			void give_name(char*);

			// Counts the number of nodes in the net if not yet counted
			int nodecount();

			// Counts the number of links in the net if not yet counted
			int linkcount();

			// This checks a POTENTIAL link between a potential in_node
			// and potential out_node to see if it must be recurrent 
			// Use count and thresh to jump out in the case of an infinite loop 
			bool is_recur(Population::NNode *potin_node,Population::NNode *potout_node,int &count,int thresh); 

			// Some functions to help GUILE input into Networks   
			int input_start();
			int load_in(double d);

			// If all output are not active then return true
			bool outputsoff();

			// Just print connections weights with carriage returns
			void print_links_tofile(char *filename);

			int max_depth();

		};	// end class Network
	//#################################################################################################




	//#################################################################################################
		// ----------------------------------------------------------------------- 
		// A NODE is either a NEURON or a SENSOR.  
		//   - If it's a sensor, it can be loaded with a value for output
		//   - If it's a neuron, it has a list of its incoming input signals (List<Link> is used) 
		// Use an activation count to avoid flushing
		friend class Population::NNode;
		class NNode {

			friend class Population::Network;

			friend class Population::Genome;

		protected:

			int activation_count;	// keeps track of which activation the node is currently in
			int activation_count2;	// keeps track of which activation the node is currently in, afc, 01/10/07

			double last_activation; // Holds the previous step's activation for recurrency
			double last_activation2; // Holds the activation BEFORE the prevous step's
			// This is necessary for a special recurrent case when the innode
			// of a recurrent link is one time step ahead of the outnode.
			// The innode then needs to send from TWO time steps ago

			Population::Trait *nodetrait; // Points to a trait of parameters

			int trait_id;  // identify the trait derived by this node

			Population::NNode *dup;       // Used for Genome duplication

			Population::NNode *analogue;  // Used for Gene decoding

			bool override; // The NNode cannot compute its own output- something is overriding it

			double override_value; // Contains the activation value that will override this node's activation

		public:

			//############################################################################################
			class NodeUniqueInput {

			public:

				Population::Link* newlink2;						// A pointer to incoming weighted signals from other nodes

				std::vector<Population::Link*> incominglink2;	// A list of pointers to incoming weighted signals from other nodes

				int incominglink2_innum;						// input # of current node (i.e. each node may have multiple unique inputs), afc, 01/03/07

				bool active_flag_input;							// To make sure some input came in

				double activesum_input;							// The incoming activity before being processed 

				NodeUniqueInput(Population::NNode* inode, Population::Link* newlink);
				NodeUniqueInput(Population::Link* newlink);

				~NodeUniqueInput();

			};//end class NodeUniqueInput
			//############################################################################################


			//############################################################################################
			class NodeUniqueOutput {

			public:

				Population::Link* newlink2;							// A pointer to incoming weighted signals from other nodes

				std::vector<Population::Link*> outgoinglink2;		// A list of pointers to links carrying this node's signal

				int outgoinglink2_outnum;							// output # of current node (i.e. each node may have multiple unique outputs), afc, 01/03/07

				bool active_flag_output;							// To make sure outputs are active
				double activation_output;							// The total activation entering the unique NNode input

				std::vector<double> activation_timedelay_output;	// Holds the prior step's activation for recurrency

				NodeUniqueOutput(Population::NNode* inode, Population::Link* newlink);
				NodeUniqueOutput(Population::Link* newlink);

			};//end class NodeUniqueOutput
			//############################################################################################


			std::vector<Population::NNode::NodeUniqueInput*> nodeuniqueinput;	// A list of pointers to unique inputs for this node

			std::vector<Population::NNode::NodeUniqueOutput*> nodeuniqueoutput;	// A list of pointers to unique outputs for this node

			Network embeddednetwork;

			Population::Network *embeddednetworkptr;

			int embeddednetwork_num_inputs;
			int embeddednetwork_num_outputs;
		
			Population *populationptr;

			Population::Genome *genomeptr;

			Population::Network *networkptr;

			Population::Genome *new_Genome_load_file_to_node(char *filename);

			char EmbeddedNetworkFile[20];
			char *EmbeddedNetworkFileptr;

			char EmbeddedPopulationFile[20];
			char *EmbeddedPopulationFileptr;

			bool frozen; // When frozen, cannot be mutated (meaning its trait pointer is fixed)

			functype ftype; // type is either SIGMOID ..or others that can be added
			nodetype type; // type is either NEURON or SENSOR 

			double activesum;  // The incoming activity before being processed 

			double activation; // The total activation entering the NNode 

			bool active_flag;  // To make sure outputs are active

			// NOT USED IN NEAT - covered by "activation" above
			double output;  // Output of the NNode- the value in the NNode 

			// ************ LEARNING PARAMETERS *********** 
			// The following parameters are for use in    
			//   neurons that learn through habituation,
			//   sensitization, or Hebbian-type processes  

			double params[PopParams::num_trait_params];

			void pushbackincominglink(Population::NNode* inode, Population::Link* newlink);	// trap for implementing push_back on incoming vector, afc, 12/14/06

			// These members are used for graphing with GTK+/GDK
			std::vector<double> rowlevels;  // Depths from output where this node appears
			int row;  // Final row decided upon for drawing this NNode in
			int ypos;
			int xpos;

			int node_id;  // A node can be given an identification number for saving in files

			nodeplace gen_node_label;  // Used for genetic marking of nodes

		
			NNode();

			NNode(nodetype ntype,int nodeid);
			NNode(nodetype ntype,int nodeid,int iftype,char* filenameptr,nodeplace igen_node_label);
			NNode(nodetype ntype,int nodeid,int iftype,Population::Network* embeddednetworkptr,nodeplace igen_node_label);

			NNode(nodetype ntype,int nodeid, nodeplace placement);

			// Construct a NNode off another NNode for genome purposes
			NNode(Population::NNode *n,Population::Trait *t);

			// Construct the node out of a file specification using given list of traits
			NNode (const char *argline, std::vector<Population::Trait*> &traits);

			// Copy Constructor
			NNode (const Population::NNode& nnode);

			~NNode();

			// Just return activation for step
			double get_active_out();

			// Return activation from PREVIOUS time step
			double get_active_out_td();

			// Returns the type of the node, NEURON or SENSOR
			const nodetype get_type();

			// Allows alteration between NEURON and SENSOR.  Returns its argument
			nodetype set_type(nodetype);

			// If the node is a SENSOR, returns true and loads the value
			bool sensor_load(double);

			// Adds a NONRECURRENT Link to a new NNode in the incoming List
			void add_incoming(Population::NNode*,double);

			// Adds a Link to a new NNode in the incoming List
			void add_incoming(Population::NNode*,double,bool);

			// Recursively deactivate backwards through the network
			void flushback();

			// Verify flushing for debugging
			void flushback_check(std::vector<Population::NNode*> &seenlist);

			// Print the node to a file
			void print_to_file(std::ostream &outFile);
			void print_to_file(std::ofstream &outFile);

			// Have NNode gain its properties from the trait
			void derive_trait(Population::Trait *curtrait);

			// Returns the gene that created the node
			Population::NNode *get_analogue();

			// Force an output value on the node
			void override_output(double new_output);

			// Tell whether node has been overridden
			bool overridden();

			// Set activation to the override value and turn off override
			void activate_override();  
			void activate_override(Population::Link* curlink);  

			// Writes back changes weight values into the genome
			// (Lamarckian trasnfer of characteristics)
			void Lamarck();

			//Find the greatest depth starting from this neuron at depth d
			int depth(int d,Population::Network *mynet); 

			//Find the greatest depth starting from this neuron at depth d
			int depth(int d,Population::Network *mynet, int i_num_tries_loop); 

		};	// end class NNode
	//#################################################################################################






	//#################################################################################################
		class Gene;
		friend class Population::Gene;
		class Gene {

		public:

			Population::Link *lnk;
			double innovation_num;
			double mutation_num;  //Used to see how much mutation has changed the link
			bool enable;  //When this is off the Gene is disabled
			bool frozen;  //When frozen, the linkweight cannot be mutated

			//Construct a gene with no trait
			Gene(double w,Population::NNode *inode,int inode_outnum,Population::NNode *onode,int onode_innum,bool recur,double innov,double mnum);

			//Construct a gene with a trait
			Gene(Population::Trait *tp,double w,Population::NNode *inode,int inode_outnum,Population::NNode *onode,int onode_innum,bool recur,double innov,double mnum);

			//Construct a gene off of another gene as a duplicate
			Gene(Population::Gene *g,Population::Trait *tp,Population::NNode *inode,int inode_outnum,Population::NNode *onode,int onode_innum);

			//Construct a gene from a file spec given traits and nodes
			Gene(const char *argline, std::vector<Population::Trait*> &traits, std::vector<Population::NNode*> &nodes);

			// Copy Constructor
			Gene(const Population::Gene& gene);

			Gene();

			~Gene();

			//Print gene to a file- called from Genome
			void print_to_file(std::ostream &outFile);
			void print_to_file(std::ofstream &outFile);

		};	// end class Gene
	//#################################################################################################



	//#################################################################################################
		// ------------------------------------------------------------
		// This Innovation class serves as a way to record innovations
		//   specifically, so that an innovation in one genome can be 
		//   compared with other innovations in the same epoch, and if they
		//   are the same innovation, they can both be assigned the same
		//   innovation number.
		//
		//  This class can encode innovations that represent a new link
		//  forming, or a new node being added.  In each case, two 
		//  nodes fully specify the innovation and where it must have
		//  occured.  (Between them)                                     
		// ------------------------------------------------------------ 
		class Innovation;
		friend class Population::Innovation;
		class Innovation {
		private:
			enum innovtype {
				NEWNODE = 0,
				NEWLINK = 1
			};

		public:
			innovtype innovation_type;  //Either NEWNODE or NEWLINK

			int node_in_id;     //Two nodes specify where the innovation took place
			int node_in_outnum;	// afc, 12/19/06

			int node_out_id;
			int node_out_innum;	// afc, 12/19/06

			double innovation_num1;  //The number assigned to the innovation
			double innovation_num2;  // If this is a new node innovation, then there are 2 innovations (links) added for the new node 

			double new_weight;   //  If a link is added, this is its weight 
			int new_traitnum; // If a link is added, this is its connected trait 

			int newnode_id;  // If a new node was created, this is its node_id 

			double old_innov_num;  // If a new node was created, this is the innovnum of the gene's link it is being stuck inside 

			bool recur_flag;

			//Constructor for the new node case
			Innovation(int nin,int in_node_outnum,int nout,int out_node_innum,double num1,double num2,int newid,double oldinnov);

			//Constructor for new link case
			Innovation(int nin,int in_node_outnum,int nout,int out_node_innum,double num1,double w,int t);

			//Constructor for a recur link
			Innovation(int nin,int in_node_outnum,int nout,int out_node_innum,double num1,double w,int t,bool recur);

			Innovation();

		};	// end class Innovation
	//#################################################################################################




	//#################################################################################################
		//----------------------------------------------------------------------- 
		//A Genome is the primary source of genotype information used to create   
		//a phenotype.  It contains 3 major constituents:                         
		//  1) A list of Traits                                                 
		//  2) A list of NNodes pointing to a Trait from (1)                      
		//  3) A list of Genes with Links that point to Traits from (1)           
		//(1) Reserved parameter space for future use
		//(2) NNode specifications                                                
		//(3) Is the primary source of innovation in the evolutionary Genome.     
		//    Each Gene in (3) has a marker telling when it arose historically.   
		//    Thus, these Genes can be used to speciate the population, and the   
		//    list of Genes provide an evolutionary history of innovation and     
		//    link-building.
		friend class Population::Genome;
		class Genome {

		public:

			int genome_id;

			std::vector<Population::Trait*> traits; //parameter conglomerations

			std::vector<Population::NNode*> nodes; //List of NNodes for the Network

			std::vector<Population::Gene*> genes; //List of innovation-tracking genes

			Population::Network *phenotype; //Allows Genome to be matched with its Network

			int get_last_node_id(); //Return id of final NNode in Genome
			double get_last_gene_innovnum(); //Return last innovation number in Genome

			void print_genome(); //Displays Genome on screen

			Genome(){}

			//Constructor which takes full genome specs and puts them into the new one
			Genome(int id, std::vector<Population::Trait*> t, std::vector<Population::NNode*> n, std::vector<Population::Gene*> g);

			//Constructor which takes in links (not genes) and creates a Genome
			Genome(int id, std::vector<Population::Trait*> t, std::vector<Population::NNode*> n, std::vector<Population::Link*> links);

			// Copy constructor
			Genome::Genome(const Population::Genome& genome);

			//Special constructor which spawns off an input file
			//This constructor assumes that some routine has already read in GENOMESTART
			Genome(int id, std::ifstream &iFile);
			Genome(int id, std::ifstream &iFile, int iftype);
			Genome(int id, std::ifstream &iFile, int iftype,Population::NNode* inode);

			// This special constructor creates a Genome
			// with i inputs, o outputs, n out of nmax hidden units, and random
			// connectivity.  If r is true then recurrent connections will
			// be included. 
			// The last input is a bias
			// Linkprob is the probability of a link  
			Genome(int new_id,int i, int o, int n,int nmax, bool r, double linkprob);

			//Special constructor that creates a Genome of 3 possible types:
			//0 - Fully linked, no hidden nodes
			//1 - Fully linked, one hidden node splitting each link
			//2 - Fully connected with a hidden layer, recurrent 
			//num_hidden is only used in type 2
			Genome(int num_in,int num_out,int num_hidden,int type);

			// Loads a new Genome from a file (doesn't require knowledge of Genome's id)
			static Population::Genome *new_Genome_load(char *filename);

			//Destructor kills off all lists (including the trait vector)
			~Genome();

			//Generate a network phenotype from this Genome with specified id
			Population::Network *genesis(int);
			Population::Network *genesis(int,int);	// afc, 12/07/06

			// Dump this genome to specified file
			void print_to_file(std::ostream &outFile);
			void print_to_file(std::ofstream &outFile);

			// Wrapper for print_to_file above
			void print_to_filename(char *filename);

			// Duplicate this Genome to create a new one with the specified id 
			Population::Genome *duplicate(int new_id);

			// For debugging: A number of tests can be run on a genome to check its
			// integrity
			// Note: Some of these tests do not indicate a bug, but rather are meant
			// to be used to detect specific system states
			bool verify();

			// ******* MUTATORS *******

			// Perturb params in one trait
			void mutate_random_trait(Population* pop);

			// Change random link's trait. Repeat times times
			void mutate_link_trait(int times);

			// Change random node's trait times times 
			void mutate_node_trait(int times);

			// Add Gaussian noise to linkweights either GAUSSIAN or COLDGAUSSIAN (from zero)
			void mutate_link_weights(double power,double rate,mutator mut_type);

			// toggle genes on or off 
			void mutate_toggle_enable(int times);

			// Find first disabled gene and enable it 
			void mutate_gene_reenable();

			// These last kinds of mutations return false if they fail
			//   They can fail under certain conditions,  being unable
			//   to find a suitable place to make the mutation.
			//   Generally, if they fail, they can be called again if desired. 

			// Mutate genome by adding a node respresentation 
			bool mutate_add_node(std::vector<Population::Innovation*> &innovs,int &curnode_id,double &curinnov);

			// Mutate the genome by adding a new link between 2 random NNodes 
			bool mutate_add_link(std::vector<Population::Innovation*> &innovs,double &curinnov,int tries,Population* pop); 

			void mutate_add_sensor(std::vector<Population::Innovation*> &innovs, double &curinnov);

			// ****** MATING METHODS ***** 

			// This method mates this Genome with another Genome g.  
			//   For every point in each Genome, where each Genome shares
			//   the innovation number, the Gene is chosen randomly from 
			//   either parent.  If one parent has an innovation absent in 
			//   the other, the baby will inherit the innovation 
			//   Interspecies mating leads to all genes being inherited.
			//   Otherwise, excess genes come from most fit parent.
			Population::Genome *mate_multipoint(Population::Genome *g,int genomeid,double fitness1, double fitness2, bool interspec_flag);

			//This method mates like multipoint but instead of selecting one
			//   or the other when the innovation numbers match, it averages their
			//   weights 
			Population::Genome *mate_multipoint_avg(Population::Genome *g,int genomeid,double fitness1,double fitness2, bool interspec_flag);

			// This method is similar to a standard single point CROSSOVER
			//   operator.  Traits are averaged as in the previous 2 mating
			//   methods.  A point is chosen in the smaller Genome for crossing
			//   with the bigger one.  
			Population::Genome *mate_singlepoint(Population::Genome *g,int genomeid);


			// ******** COMPATIBILITY CHECKING METHODS ********

			// This function gives a measure of compatibility between
			//   two Genomes by computing a linear combination of 3
			//   characterizing variables of their compatibilty.
			//   The 3 variables represent PERCENT DISJOINT GENES, 
			//   PERCENT EXCESS GENES, MUTATIONAL DIFFERENCE WITHIN
			//   MATCHING GENES.  So the formula for compatibility 
			//   is:  disjoint_coeff*pdg+excess_coeff*peg+mutdiff_coeff*mdmg.
			//   The 3 coefficients are global system parameters 
			double compatibility(Population::Genome *g,Population* pop);

			double trait_compare(Population::Trait *t1,Population::Trait *t2);

			// Return number of non-disabled genes 
			int extrons();

			// Randomize the trait pointers of all the node and connection genes 
			void randomize_traits();


			//Calls special constructor that creates a Genome of 3 possible types:
			//0 - Fully linked, no hidden nodes
			//1 - Fully linked, one hidden node splitting each link
			//2 - Fully connected with a hidden layer 
			//num_hidden is only used in type 2
			//Saves to file "auto_genome"
			Population::Genome *new_Genome_auto(int num_in,int num_out,int num_hidden,int type, const char *filename);

			void print_Genome_tofile(Population::Genome *g,const char *filename);

		protected:
			//Inserts a NNode into a given ordered list of NNodes in order
			void node_insert(std::vector<Population::NNode*> &nlist, Population::NNode *n);

			//Adds a new gene that has been created through a mutation in the
			//*correct order* into the list of genes in the genome
			void add_gene(std::vector<Population::Gene*> &glist,Population::Gene *g);

		};	// end class Genome
	//#################################################################################################



	//############################################################################################
	class ExperimentResults {

	public:

		double Fitness;

		double Param_1;
		double Param_2;
		double Param_3; 
		double Param_4;
		double Param_5;
		double Param_6;
		double Param_7;
		double Param_8;
		
		ExperimentResults();

		~ExperimentResults();

	};//end class ExperimentResults
	//############################################################################################


	//#################################################################################################
		class Species;
		// ---------------------------------------------  
		// ORGANISM CLASS:
		//   Organisms are Genomes and Networks with fitness
		//   information 
		//   i.e. The genotype and phenotype together
		// ---------------------------------------------  
		class Organism;
		friend class Population::Organism;
		class Organism {

		public:

			Population::ExperimentResults experimentresults;	// results associated w/ organism/genome, afc, 01/30/07

			Population::ExperimentResults* experimentresultsptr;	// results associated w/ organism/genome, afc, 01/30/07

			double fitness;  //A measure of fitness for the Organism
			double orig_fitness;  //A fitness measure that won't change during adjustments
			double error;  //Used just for reporting purposes
			bool winner;  //Win marker (if needed for a particular task)
			Population::Network *net;  //The Organism's phenotype
			Population::Genome *gnome; //The Organism's genotype 
			Population::Species *species;  //The Organism's Species 
			double expected_offspring; //Number of children this Organism may have
			int generation;  //Tells which generation this Organism is from
			bool eliminate;  //Marker for destruction of inferior Organisms
			bool champion; //Marks the species champ
			int super_champ_offspring;  //Number of reserved offspring for a population leader
			bool pop_champ;  //Marks the best in population
			bool pop_champ_child; //Marks the duplicate child of a champion (for tracking purposes)
			double high_fit; //DEBUG variable- high fitness of champ
			int time_alive; //When playing in real-time allows knowing the maturity of an individual

			// Track its origin- for debugging or analysis- we can tell how the organism was born
			bool mut_struct_baby;
			bool mate_baby;

			// MetaData for the object
			char metadata[128];
			bool modified;

			// Regenerate the network based on a change in the genotype 
			void update_phenotype();

			// Print the Organism's genome to a file preceded by a comment detailing the organism's species, number, and fitness 
			bool print_to_file(char *filename);   
			bool write_to_file(std::ostream &outFile);

			Organism(double fit, Population::Genome *g, int gen, const char* md = 0);

			Organism::Organism(const Population::Organism& org);	// Copy Constructor
		
			Organism();

			~Organism();

			// This is used for list sorting of Organisms by fitness..highest fitness first
			bool order_orgs(Population::Organism *x, Population::Organism *y);

			bool order_orgs_by_adjusted_fit(Population::Organism *x, Population::Organism *y);

		}; // end class Organism
	//#################################################################################################




	//#################################################################################################
		// ---------------------------------------------  
		// SPECIES CLASS:
		//   A Species is a group of similar Organisms      
		//   Reproduction takes place mostly within a
		//   single species, so that compatible organisms
		//   can mate.                                      
		// ---------------------------------------------  
		friend class Population::Species;
		class Species {

		public:

			int id;
			int age; //The age of the Species 
			double ave_fitness; //The average fitness of the Species
			double max_fitness; //Max fitness of the Species
			double max_fitness_ever; //The max it ever had
			int expected_offspring;
			bool novel;
			bool checked;
			bool obliterate;  //Allows killing off in competitive coevolution stagnation
			std::vector<Population::Organism*> organisms; //The organisms in the Species
			int age_of_last_improvement;  //If this is too long ago, the Species will goes extinct
			double average_est; //When playing real-time allows estimating average fitness

			bool add_Organism(Population::Organism *o);

			Population::Organism *first();

			bool print_to_file(std::ostream &outFile);
			bool Species::print_to_file(std::ofstream &outFile);

			//Change the fitness of all the organisms in the species to possibly depend slightly on the age of the species
			//and then divide it by the size of the species so that the organisms in the species "share" the fitness
			void adjust_fitness(Population* pop);

			double compute_average_fitness(); 

			double compute_max_fitness();

			//Counts the number of offspring expected from all its members skim is for keeping track of remaining 
			// fractional parts of offspring and distributing them among species
			double count_offspring(double skim);

			//Compute generations since last improvement
			int last_improved() {
				return age-age_of_last_improvement;
			}

			//Remove an organism from Species
			bool remove_org(Population::Organism *org);

			double size() {
				return organisms.size();
			}

			Population::Organism *get_champ();

			//Perform mating and mutation to form next generation
			bool reproduce(int generation, Population *pop,std::vector<Population::Species*> &sorted_species);

			// *** Real-time methods *** 

			//Place organisms in this species in order by their fitness
			bool Species::rank();

			//Compute an estimate of the average fitness of the species
			//The result is left in variable average_est and returned
			//New variable: average_est, NEAT::time_alive_minimum (const) 
			//Note: Initialization requires calling estimate_average() on all species
			//      Later it should be called only when a species changes 
			double estimate_average(Population* pop);

			//Like the usual reproduce() method except only one offspring is produced
			//Note that "generation" will be used to just count which offspring # this is over all evolution
			//Here is how to get sorted species:
			//    Sort the Species by max fitness (Use an extra list to do this)
			//    These need to use ORIGINAL fitness
			//      sorted_species.sort(order_species);
			Population::Organism *Species::reproduce_one(int generation, Population *pop,std::vector<Population::Species*> &sorted_species);

			Species();

			Species(int i);

			//Allows the creation of a Species that won't age (a novel one)
			//This protects new Species from aging inside their first generation
			Species(int i,bool n);

			~Species();

			// This is used for list sorting of Species by fitness of best organism highest fitness first 
			bool order_species(Population::Species *x, Population::Species *y);

			bool order_new_species(Population::Species *x, Population::Species *y);

		};	// end class Species
	//#################################################################################################



		// A Population can be spawned off of a single Genome 
		// There will be size Genomes added to the Population 
		// The Population does not have to be empty to add Genomes 
		bool spawn(Genome *g,int size,Population* pop);

		std::vector<Population::Organism*> organisms; //The organisms in the Population

        std::vector<Species*> species;  // Species in the Population. Note that the species should comprise all the genomes 

		// ******* Member variables used during reproduction *******
        std::vector<Innovation*> innovations;  // For holding the genetic innovations of the newest generation
		
		int cur_node_id;  //Current label number available
		double cur_innov_num;

		int last_species;  //The highest species number

		// ******* Fitness Statistics *******
		double mean_fitness;
		double variance;
		double standard_deviation;

		bool paramstatus;	// afc, 10/12/06, param load status flag


		int winnergen; //An integer that when above zero tells when the first winner appeared

		// ******* When do we need to delta code? *******
		double highest_fitness;  //Stagnation detector
		double highest_fitness_buf;  //Stagnation detector

		double highest_fitness_overall;  //afc, 10/10/06
		double highest_fitness_overall_buf;  //afc, 10/10/06

		double highest_fitness_accum;  //afc, 09/12/06
		double highest_fitness_accum_buf;  //afc, 09/12/06

		int highest_last_changed; //If too high, leads to delta coding
		int highest_last_changed_buf; //If too high, leads to delta coding

		// Separate the Organisms into species
		bool speciate(Population* pop);

		// Print Population to a file specified by a string 
		bool print_to_file(std::ostream& outFile);

		// Print Population to a file in speciated order with comments separating each species
		bool print_to_file_by_species(std::ostream& outFile);
		bool Population::print_to_file_by_species(char *filename);

		// Prints the champions of each species to files starting with directory_prefix
		// The file name are as follows: [prefix]g[generation_num]cs[species_num]
		// Thus, they can be indexed by generation or species
		bool print_species_champs_tofiles(char *directory_prefix,int generation);

		// Run verify on all Genomes in this Population (Debugging)
		bool verify(Population* pop);

		// Turnover the population to a new generation using fitness 
		// The generation argument is the next generation
		bool epoch(int generation,Population* pop);

		// *** Real-time methods *** 

		// Places the organisms in species in order from best to worst fitness 
		bool rank_within_species();

		// Estimates average fitness for all existing species
		void estimate_all_averages(Population* pop);

		//Reproduce only out of the pop champ
		Population::Organism* reproduce_champ(int generation,Population* pop);

		// Probabilistically choose a species to reproduce
		// Note that this method is effectively real-time fitness sharing in that the 
		// species will tend to produce offspring in an amount proportional
		// to their average fitness, which approximates the generational
		// method of producing the next generation of the species en masse
		// based on its average (shared) fitness.  
		Species *choose_parent_species();

		//Remove a species from the species list (sometimes called by remove_worst when a species becomes empty)
		bool remove_species(Species *spec);

		// Removes worst member of population that has been around for a minimum amount of time and returns
		// a pointer to the Organism that was removed (note that the pointer will not point to anything at all,
		// since the Organism it was pointing to has been deleted from memory)
		Population::Organism* remove_worst(Population* pop);

		//Warning: rtNEAT does not behave like regular NEAT if you remove the worst probabilistically   
		//You really should just use "remove_worst," which removes the org with worst adjusted fitness. 
		Population::Organism* remove_worst_probabilistic(Population* pop);

		//KEN: New 2/17/04
		//This method takes an Organism and reassigns what Species it belongs to
		//It is meant to be used so that we can reasses where Organisms should belong
		//as the speciation threshold changes.
        void reassign_species(Organism *org,Population* pop);

		//Move an Organism from one Species to another (called by reassign_species)
		void switch_species(Organism *org, Species *orig_species, Species *new_species,Population* pop);

		// Construct off of a single spawning Genome 
		Population(Genome *g,int size);

		// Construct off of a single spawning Genome without mutation
		Population(Genome *g,int size, float power);
		
		//MSC Addition
		// Construct off of a vector of genomes with a mutation rate of "power"
		Population(std::vector<Genome*> genomeList, float power);

		bool clone(Genome *g,int size, float power,Population* pop);

		// Construct off of a file of Genomes 
		Population(const char *filename);
		
		// Copy constructor
		Population(const Population& population);

		Population(Population* popfrom, Population* popto);


		Population();

		// It can delete a Population in two ways:
		//    -delete by killing off the species
		//    -delete by killing off the organisms themselves (if not speciated)
		// It does the latter if it sees the species list is empty
		~Population();

	};	// end class population

#endif

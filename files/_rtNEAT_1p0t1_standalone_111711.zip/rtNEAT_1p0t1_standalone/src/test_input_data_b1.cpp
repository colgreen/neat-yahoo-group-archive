
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

vector<double> Input_1;
vector<double> Input_2;
vector<double> Input_3;
vector<double> Input_4;
vector<double> Input_5;

void load_test_input_output_data()
{

	double Var_1;
	double Var_2;		// 
	double Var_3;		// 
	double Var_4;		// 
	double out;

    ifstream iFile("test_input_data.dat");

	string s;
	while(getline(iFile, s))
	{
		std::stringstream ss(s);

	    ss >> Var_1 >> Var_2 >> Var_3 >> Var_4;

		Input_1.push_back(Var_1);
		Input_2.push_back(Var_2);
		Input_3.push_back(Var_3);
		Input_4.push_back(Var_4);
	}

    iFile.close();

    ifstream iFile1("test_output_data.dat");

	double Var_5;

	while(getline(iFile1, s))
	{
		std::stringstream ss(s);

	    ss >> Var_5;

		Input_5.push_back(Var_5);
	}

    iFile1.close();

}
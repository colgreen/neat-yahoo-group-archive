
#ifndef TRUE
#define TRUE            (1)     /* Logical true */
#define FALSE           (0)     /* Logical false */
#endif

#include "dbug.h"
#include <errno.h>     // errno
#include <stdio.h>     // fprintf()
#include <stdarg.h>
#include <string.h>


#ifndef DBUG_OFF            //when DBUG_OFF is defined, no debug prints are made

static FILE *_db_file = 0;
char *_db_key;

void _db_setfile(FILE *file)
{
  _db_file = file;
}


void _db_setfile(char *name)
{

  if (! name)

	return;

  if (strlen (name) == 0)
    return;



  _db_file = fopen (name, "w+");
}

void _db_closefile()
{
  if (_db_file) fclose(_db_file);
}

void _db_setkey(char *keyword)
{
  _db_key = keyword;
}


void _db_print (const char *format,...)
{
  va_list args;
  va_start(args,format);

  if (! _db_file) 
    return;

  (void) fprintf (_db_file, "%s: ", _db_key);
  (void) vfprintf (_db_file, format, args);
  va_end(args);
  (void) fputc('\n',_db_file);
  fflush(_db_file);

  va_end(args);
}

#endif //DBUG_OFF

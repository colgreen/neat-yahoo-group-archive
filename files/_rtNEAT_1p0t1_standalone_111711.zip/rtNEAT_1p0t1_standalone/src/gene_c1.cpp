
#include "population.h"

#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

//#################################################################################################
Population::Gene::Gene(double w, NNode *inode,int inode_outnum, NNode *onode,int onode_innum, bool recur, double innov, double mnum) {

	lnk = new Population::Link(w, inode, inode_outnum, onode, onode_innum, recur);

	innovation_num = innov;
	mutation_num = mnum;

	enable = true;

	frozen = false;

	if( inode != 0 )
	{
		inode->pushbackincominglink( inode, lnk);	// afc, 01/22/07
	}

}
//#################################################################################################


//#################################################################################################
Population::Gene::Gene(Trait *tp,double w,NNode *inode,int inode_outnum,NNode *onode,int onode_innum,bool recur,double innov,double mnum) {

	lnk=new Population::Link(tp,w,inode,inode_outnum,onode,onode_innum,recur);

	innovation_num=innov;
	mutation_num=mnum;

	enable=true;

	frozen=false;

	if( inode != 0 )
	{
		inode->pushbackincominglink( inode, lnk);	// afc, 01/22/07
	}

}
//#################################################################################################


//#################################################################################################
Population::Gene::Gene(Gene *g,Trait *tp,NNode *inode,int inode_outnum,NNode *onode,int onode_innum) {

	lnk=new Population::Link(tp,(g->lnk)->weight,inode,inode_outnum,onode,onode_innum,(g->lnk)->is_recurrent);

	innovation_num=g->innovation_num;
	mutation_num=g->mutation_num;
	enable=g->enable;

	frozen=g->frozen;

	if( inode != 0 )
	{
		inode->pushbackincominglink( inode, lnk);	// afc, 01/22/07
	}

}
//#################################################################################################


//#################################################################################################
Population::Gene::Gene(const char *argline, std::vector<Population::Trait*> &traits, std::vector<Population::NNode*> &nodes) {

	//Gene parameter holders
	int traitnum;
	int inodenum;
	int onodenum;
	Population::NNode *inode;
	int inode_outnum = 0;

	Population::NNode *onode;
	int onode_innum = 0;

	double weight;
	int recur;
	Population::Trait *traitptr;

	std::vector<Population::Trait*>::iterator curtrait;

	std::vector<Population::NNode*>::iterator curnode;

	//Get the gene parameters
    std::stringstream ss(argline);

    ss >> traitnum >> inodenum >> inode_outnum >> onodenum >> onode_innum >> weight >> recur >> innovation_num >> mutation_num >> enable;

	frozen=false; //TODO: MAYBE CHANGE

	//Get a pointer to the linktrait
	if (traitnum==0) traitptr=0;
	else {
		curtrait=traits.begin();
		while(((*curtrait)->trait_id)!=traitnum)
			++curtrait;
		traitptr=(*curtrait);
	}

	//Get a pointer to the input node
	curnode=nodes.begin();
	while(((*curnode)->node_id)!=inodenum)
		++curnode;
	inode=(*curnode);

	//Get a pointer to the output node
	curnode=nodes.begin();
	while(((*curnode)->node_id)!=onodenum)
		++curnode;
	onode=(*curnode);

	lnk=new Population::Link(traitptr,weight,inode,inode_outnum,onode,onode_innum,recur);

	if( inode != 0 )
	{
		inode->pushbackincominglink( inode, lnk);	// afc, 01/22/07
	}

}
//#################################################################################################


//#################################################################################################
Population::Gene::Gene(const Population::Gene& gene)
{
	innovation_num = gene.innovation_num;
	mutation_num = gene.mutation_num;
	enable = gene.enable;
	frozen = gene.frozen;

	lnk = new Population::Link(*gene.lnk);

	if( lnk->in_node != 0 )
	{
		lnk->in_node->pushbackincominglink( lnk->in_node, lnk);	// afc, 01/22/07
	}
}
//#################################################################################################


//#################################################################################################
Population::Gene::~Gene() {

//	delete lnk;

//	if( lnk->in_node != NULL ) delete lnk;

}
//#################################################################################################


//#################################################################################################
void Population::Gene::print_to_file(std::ofstream &outFile) {

	outFile<<"gene ";
	//Start off with the trait number for this gene
	if ((lnk->linktrait)==0) outFile<<"0 ";
	else outFile<<((lnk->linktrait)->trait_id)<<" ";

	outFile<<(lnk->in_node)->node_id<<" ";
	outFile<<lnk->in_node_outnum<<" ";	// afc, 12/18/06

	outFile<<(lnk->out_node)->node_id<<" ";
	outFile<<lnk->out_node_innum<<" ";	// afc, 12/18/06

	outFile<<(lnk->weight)<<" ";
	outFile<<(lnk->is_recurrent)<<" ";
	outFile<<innovation_num<<" ";
	outFile<<mutation_num<<" ";
	outFile<<enable<<std::endl;

}
//#################################################################################################


//#################################################################################################
void Population::Gene::print_to_file(std::ostream &outFile) {

	outFile<<"gene ";

	//Start off with the trait number for this gene
	if ((lnk->linktrait)==0) {

		outFile<<"0 ";

	}
	else {

		outFile<<((lnk->linktrait)->trait_id)<<" ";

	}

	outFile<<(lnk->in_node)->node_id<<" ";
	outFile<<lnk->in_node_outnum<<" ";	// afc, 12/18/06

	outFile<<(lnk->out_node)->node_id<<" ";
	outFile<<lnk->out_node_innum<<" ";	// afc, 12/18/06

	outFile<<(lnk->weight)<<" ";
	outFile<<(lnk->is_recurrent)<<" ";
	outFile<<innovation_num<<" ";
	outFile<<mutation_num<<" ";
    outFile<<enable<<std::endl;

}
//#################################################################################################

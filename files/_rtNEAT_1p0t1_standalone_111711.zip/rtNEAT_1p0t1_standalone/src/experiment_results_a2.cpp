
#include "population.h"

#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;


//#################################################################################################
Population::ExperimentResults::ExperimentResults() {

	Fitness = 0.0;

	Param_1 = 0.0;
	Param_2 = 0.0;
	Param_3 = 0.0; 
	Param_4 = 0.0;
	Param_5 = 0.0;
	Param_6 = 0.0;
	Param_7 = 0.0;
	Param_8 = 0.0;


}
//#################################################################################################


//#################################################################################################
Population::ExperimentResults::~ExperimentResults() {


}
//#################################################################################################



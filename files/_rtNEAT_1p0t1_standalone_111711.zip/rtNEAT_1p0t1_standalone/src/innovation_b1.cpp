
#include "population.h"

//#################################################################################################
Population::Innovation::Innovation(int nin,int in_node_outnum,int nout,int out_node_innum,double num1,double num2,int newid,double oldinnov) {

	innovation_type=NEWNODE;

	node_in_id=nin;
	node_in_outnum = in_node_outnum;	// afc, 12/19/06

	node_out_id=nout;
	node_out_innum = out_node_innum;	// afc, 12/19/06

	innovation_num1=num1;
	innovation_num2=num2;
	newnode_id=newid;
	old_innov_num=oldinnov;

	//Unused parameters set to zero
	new_weight=0;
	new_traitnum=0;
	recur_flag=false;

}
//#################################################################################################


//#################################################################################################
Population::Innovation::Innovation(int nin,int in_node_outnum,int nout,int out_node_innum,double num1,double w,int t) {

	innovation_type=NEWLINK;

	node_in_id=nin;
	node_in_outnum = in_node_outnum;	// afc, 12/19/06

	node_out_id=nout;
	node_out_innum = out_node_innum;	// afc, 12/19/06

	innovation_num1=num1;
	new_weight=w;
	new_traitnum=t;

	//Unused parameters set to zero
	innovation_num2=0;
	newnode_id=0;
	recur_flag=false;

}
//#################################################################################################


//#################################################################################################
Population::Innovation::Innovation(int nin,int in_node_outnum,int nout,int out_node_innum,double num1,double w,int t,bool recur) {

	innovation_type=NEWLINK;

	node_in_id=nin;
	node_in_outnum = in_node_outnum;	// afc, 12/19/06

	node_out_id=nout;
	node_out_innum = out_node_innum;	// afc, 12/19/06

	innovation_num1=num1;
	new_weight=w;
	new_traitnum=t;

	//Unused parameters set to zero
	innovation_num2=0;
	newnode_id=0;
	recur_flag=recur;

}
//#################################################################################################

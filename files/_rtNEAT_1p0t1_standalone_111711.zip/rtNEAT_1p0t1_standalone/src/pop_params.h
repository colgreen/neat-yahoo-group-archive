#ifndef _POP_PARAMS_H_
#define _POP_PARAMS_H_

	class Population;

class PopParams {

	public:

	static const double N_min;
	static const double N_max;

	static const int sc_num_trait_params;

//	fitness buffer
	static double sc_fitness_buffer;
	static double bsc_fitness_buffer;

	static int sc_time_alive_minimum;
	static int bsc_time_alive_minimum;

	static double sc_trait_param_mut_prob;
	static double bsc_trait_param_mut_prob;

	static double sc_trait_mutation_power;
	static double bsc_trait_mutation_power;

	static double sc_linktrait_mut_sig;
	static double bsc_linktrait_mut_sig;

	static double sc_nodetrait_mut_sig;
	static double bsc_nodetrait_mut_sig;

	static double sc_weight_mut_power;
	static double bsc_weight_mut_power;

	static double sc_recur_prob;
	static double bsc_recur_prob;

	static double sc_disjoint_coeff;
	static double bsc_disjoint_coeff;

	static double sc_excess_coeff;
	static double bsc_excess_coeff;

	static double sc_mutdiff_coeff;
	static double bsc_mutdiff_coeff;

	static double sc_compat_threshold;
	static double bsc_compat_threshold;

	static double sc_age_significance;
	static double bsc_age_significance;

	static double sc_survival_thresh;
	static double bsc_survival_thresh;

	static double sc_mutate_only_prob;
	static double bsc_mutate_only_prob;

	static double sc_mutate_random_trait_prob;
	static double bsc_mutate_random_trait_prob;

	static double sc_mutate_link_trait_prob;
	static double bsc_mutate_link_trait_prob;

	static double sc_mutate_node_trait_prob;
	static double bsc_mutate_node_trait_prob;

	static double sc_mutate_link_weights_prob;
	static double bsc_mutate_link_weights_prob;

	static double sc_mutate_toggle_enable_prob;
	static double bsc_mutate_toggle_enable_prob;

	static double sc_mutate_gene_reenable_prob;
	static double bsc_mutate_gene_reenable_prob;

	static double sc_mutate_add_node_prob;
	static double bsc_mutate_add_node_prob;

	static double sc_mutate_add_link_prob;
	static double bsc_mutate_add_link_prob;

	static double sc_interspecies_mate_rate;
	static double bsc_interspecies_mate_rate;

	static double sc_mate_multipoint_prob;     
	static double bsc_mate_multipoint_prob;     

	static double sc_mate_multipoint_avg_prob;
	static double bsc_mate_multipoint_avg_prob;

	static double sc_mate_singlepoint_prob;
	static double bsc_mate_singlepoint_prob;

	static double sc_mate_only_prob;
	static double bsc_mate_only_prob;

	static double sc_recur_only_prob;
	static double bsc_recur_only_prob;

	static int sc_pop_size;
	static int bsc_pop_size;

	static int sc_dropoff_age;
	static int bsc_dropoff_age;

	static int sc_newlink_tries;
	static int bsc_newlink_tries;

	static int sc_print_every;
	static int bsc_print_every;

	static int sc_babies_stolen;
	static int bsc_babies_stolen;

	static int sc_num_runs;
	static int bsc_num_runs;


	public:

		PopParams();

		void initializer();

		void initializer(Population* pop);
		void initializer_bsc(Population* pop);

		void initializer(Population* popfrom, Population* popto);

		void initializer(const Population& popfrom, Population* popto);

		bool load_neat_params(const char *filename, bool output);

		bool write_pop_neat_params_to_file(const char *filename, Population* popfrom);

		bool read_pop_neat_params_from_file(const char *filename, Population* popto);

		static const int num_trait_params = 8;


		//*************************************************************************************
		//fitness buffer

		static const double sc_fitness_buffer_max;
		static const double sc_fitness_buffer_min;

		static const double bsc_fitness_buffer_max;
		static const double bsc_fitness_buffer_min;

		static double read_sc_fitness_buffer() { return sc_fitness_buffer; }
		void set_sc_fitness_buffer(double fitness_buffer) { sc_fitness_buffer = fitness_buffer; }

		static double read_bsc_fitness_buffer() { return bsc_fitness_buffer; }
		void set_bsc_fitness_buffer(double fitness_buffer) { bsc_fitness_buffer = fitness_buffer; }

		double normalize_sc_fitness_buffer(double x, bool threshold);
		double unnormalize_sc_fitness_buffer(double N_prime, bool threshold);

		double normalize_bsc_fitness_buffer(double x, bool threshold);
		double unnormalize_bsc_fitness_buffer(double N_prime, bool threshold);
		//*************************************************************************************



		//*************************************************************************************
		int time_alive_minimum; // Minimum time alive to be considered for selection or death in real-time evolution 

		static int read_sc_time_alive_minimum() { return sc_time_alive_minimum; }
		void set_sc_time_alive_minimum(int time_alive_minimum) { sc_time_alive_minimum = time_alive_minimum; }

		static int read_bsc_time_alive_minimum() { return bsc_time_alive_minimum; }
		void set_bsc_time_alive_minimum(int time_alive_minimum) { bsc_time_alive_minimum = time_alive_minimum; }

		int read_time_alive_minimum() const { return time_alive_minimum; }
		void set_time_alive_minimum(int i) { time_alive_minimum = i; }

		int read_pop_time_alive_minimum(Population* pop);
		void set_pop_time_alive_minimum(int i, Population* pop);
		//*************************************************************************************

		//*************************************************************************************
		double trait_param_mut_prob;

		static const double pop_trait_param_mut_prob_max;
		static const double pop_trait_param_mut_prob_min;

		static double read_sc_trait_param_mut_prob() { return sc_trait_param_mut_prob; }
		void set_sc_trait_param_mut_prob(double trait_param_mut_prob) { sc_trait_param_mut_prob = trait_param_mut_prob; }

		static double read_bsc_trait_param_mut_prob() { return bsc_trait_param_mut_prob; }
		void set_bsc_trait_param_mut_prob(double trait_param_mut_prob) { bsc_trait_param_mut_prob = trait_param_mut_prob; }

		double read_trait_param_mut_prob() const { return trait_param_mut_prob; }
		void set_trait_param_mut_prob(double d) { trait_param_mut_prob = d; }

		double read_pop_trait_param_mut_prob(Population* pop);
		void set_pop_trait_param_mut_prob(double d, Population* pop);

		double normalize_read_pop_trait_param_mut_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_trait_param_mut_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_trait_param_mut_prob(double x, bool threshold);
		double unnormalize_pop_trait_param_mut_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double trait_mutation_power; // Power of mutation on a signle trait param 

		static const double pop_trait_mutation_power_max;
		static const double pop_trait_mutation_power_min;

		static double read_sc_trait_mutation_power() { return sc_trait_mutation_power; }
		void set_sc_trait_mutation_power(double trait_mutation_power) { sc_trait_mutation_power = trait_mutation_power; }

		static double read_bsc_trait_mutation_power() { return bsc_trait_mutation_power; }
		void set_bsc_trait_mutation_power(double trait_mutation_power) { bsc_trait_mutation_power = trait_mutation_power; }

		double read_trait_mutation_power() const { return trait_mutation_power; }
		void set_trait_mutation_power(double d) { trait_mutation_power = d; }

		double read_pop_trait_mutation_power(Population* pop);
		void set_pop_trait_mutation_power(double d, Population* pop);

		double normalize_read_pop_trait_mutation_power(Population* pop, bool threshold);
		void unnormalize_set_pop_trait_mutation_power(Population* pop, double N_prime, bool threshold);

		double normalize_pop_trait_mutation_power(double x, bool threshold);
		double unnormalize_pop_trait_mutation_power(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double linktrait_mut_sig;  // Amount that mutation_num changes for a trait change inside a link

		static const double pop_linktrait_mut_sig_max;
		static const double pop_linktrait_mut_sig_min;

		static double read_sc_linktrait_mut_sig() { return sc_linktrait_mut_sig; }
		void set_sc_linktrait_mut_sig(double linktrait_mut_sig) { sc_linktrait_mut_sig = linktrait_mut_sig; }

		static double read_bsc_linktrait_mut_sig() { return bsc_linktrait_mut_sig; }
		void set_bsc_linktrait_mut_sig(double linktrait_mut_sig) { bsc_linktrait_mut_sig = linktrait_mut_sig; }

		double read_linktrait_mut_sig() const { return linktrait_mut_sig; }
		void set_linktrait_mut_sig(double d) { linktrait_mut_sig = d; }

		double read_pop_linktrait_mut_sig(Population* pop);
		void set_pop_linktrait_mut_sig(double d, Population* pop);

		double normalize_read_pop_linktrait_mut_sig(Population* pop, bool threshold);
		void unnormalize_set_pop_linktrait_mut_sig(Population* pop, double N_prime, bool threshold);

		double normalize_pop_linktrait_mut_sig(double x, bool threshold);
		double unnormalize_pop_linktrait_mut_sig(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double nodetrait_mut_sig; // Amount a mutation_num changes on a link connecting a node that changed its trait 

		static const double pop_nodetrait_mut_sig_max;
		static const double pop_nodetrait_mut_sig_min;

		static double read_sc_nodetrait_mut_sig() { return sc_nodetrait_mut_sig; }
		void set_sc_nodetrait_mut_sig(double nodetrait_mut_sig) { sc_nodetrait_mut_sig = nodetrait_mut_sig; }

		static double read_bsc_nodetrait_mut_sig() { return bsc_nodetrait_mut_sig; }
		void set_bsc_nodetrait_mut_sig(double nodetrait_mut_sig) { bsc_nodetrait_mut_sig = nodetrait_mut_sig; }

		double read_nodetrait_mut_sig() const { return nodetrait_mut_sig; }
		void set_nodetrait_mut_sig(double d) { nodetrait_mut_sig = d; }

		double read_pop_nodetrait_mut_sig(Population* pop);
		void set_pop_nodetrait_mut_sig(double d, Population* pop);

		double normalize_read_pop_nodetrait_mut_sig(Population* pop, bool threshold);
		void unnormalize_set_pop_nodetrait_mut_sig(Population* pop, double N_prime, bool threshold);

		double normalize_pop_nodetrait_mut_sig(double x, bool threshold);
		double unnormalize_pop_nodetrait_mut_sig(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double weight_mut_power;  // The power of a linkweight mutation 

		static const double pop_weight_mut_power_max;
		static const double pop_weight_mut_power_min;

		static double read_sc_weight_mut_power() { return sc_weight_mut_power; }
		void set_sc_weight_mut_power(double weight_mut_power) { sc_weight_mut_power = weight_mut_power; }

		static double read_bsc_weight_mut_power() { return bsc_weight_mut_power; }
		void set_bsc_weight_mut_power(double weight_mut_power) { bsc_weight_mut_power = weight_mut_power; }

		double read_weight_mut_power() const { return weight_mut_power; }
		void set_weight_mut_power(double d) { weight_mut_power = d; }

		double read_pop_weight_mut_power(Population* pop);
		void set_pop_weight_mut_power(double d, Population* pop);

		double normalize_read_pop_weight_mut_power(Population* pop, bool threshold);
		void unnormalize_set_pop_weight_mut_power(Population* pop, double N_prime, bool threshold);

		double normalize_pop_weight_mut_power(double x, bool threshold);
		double unnormalize_pop_weight_mut_power(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double recur_prob;        // Prob. that a link mutation which doesn't have to be recurrent will be made recurrent 

		static const double pop_recur_prob_max;
		static const double pop_recur_prob_min;

		static double read_sc_recur_prob() { return sc_recur_prob; }
		void set_sc_recur_prob(double recur_prob) { sc_recur_prob = recur_prob; }

		static double read_bsc_recur_prob() { return bsc_recur_prob; }
		void set_bsc_recur_prob(double recur_prob) { bsc_recur_prob = recur_prob; }

		double read_recur_prob() const { return recur_prob; }
		void set_recur_prob(double d) { recur_prob = d; }

		double read_pop_recur_prob(Population* pop);
		void set_pop_recur_prob(double d, Population* pop);

		double normalize_read_pop_recur_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_recur_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_recur_prob(double x, bool threshold);
		double unnormalize_pop_recur_prob(double N_prime, bool threshold);
		//*************************************************************************************


		// These 3 global coefficients are used to determine the formula for
		// computating the compatibility between 2 genomes.  The formula is:
		// disjoint_coeff*pdg+excess_coeff*peg+mutdiff_coeff*mdmg.
		// See the compatibility method in the Genome class for more info
		// They can be thought of as the importance of disjoint Genes,
		// excess Genes, and parametric difference between Genes of the
		// same function, respectively. 
		//*************************************************************************************
		double disjoint_coeff;

		static const double pop_disjoint_coeff_max;
		static const double pop_disjoint_coeff_min;

		static double read_sc_disjoint_coeff() { return sc_disjoint_coeff; }
		void set_sc_disjoint_coeff(double disjoint_coeff) { sc_disjoint_coeff = disjoint_coeff; }

		static double read_bsc_disjoint_coeff() { return bsc_disjoint_coeff; }
		void set_bsc_disjoint_coeff(double disjoint_coeff) { bsc_disjoint_coeff = disjoint_coeff; }

		double read_disjoint_coeff() const { return disjoint_coeff; }
		void set_disjoint_coeff(double d) { disjoint_coeff = d; }

		double read_pop_disjoint_coeff(Population* pop);
		void set_pop_disjoint_coeff(double d, Population* pop);

		double normalize_read_pop_disjoint_coeff(Population* pop, bool threshold);
		void unnormalize_set_pop_disjoint_coeff(Population* pop, double N_prime, bool threshold);

		double normalize_pop_disjoint_coeff(double x, bool threshold);
		double unnormalize_pop_disjoint_coeff(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double excess_coeff;

		static const double pop_excess_coeff_max;
		static const double pop_excess_coeff_min;

		static double read_sc_excess_coeff() { return sc_excess_coeff; }
		void set_sc_excess_coeff(double excess_coeff) { sc_excess_coeff = excess_coeff; }

		static double read_bsc_excess_coeff() { return bsc_excess_coeff; }
		void set_bsc_excess_coeff(double excess_coeff) { bsc_excess_coeff = excess_coeff; }

		double read_excess_coeff() const { return excess_coeff; }
		void set_excess_coeff(double d) { excess_coeff = d; }

		double read_pop_excess_coeff(Population* pop);
		void set_pop_excess_coeff(double d, Population* pop);

		double normalize_read_pop_excess_coeff(Population* pop, bool threshold);
		void unnormalize_set_pop_excess_coeff(Population* pop, double N_prime, bool threshold);

		double normalize_pop_excess_coeff(double x, bool threshold);
		double unnormalize_pop_excess_coeff(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mutdiff_coeff;

		static const double pop_mutdiff_coeff_max;
		static const double pop_mutdiff_coeff_min;

		static double read_sc_mutdiff_coeff() { return sc_mutdiff_coeff; }
		void set_sc_mutdiff_coeff(double mutdiff_coeff) { sc_mutdiff_coeff = mutdiff_coeff; }

		static double read_bsc_mutdiff_coeff() { return bsc_mutdiff_coeff; }
		void set_bsc_mutdiff_coeff(double mutdiff_coeff) { bsc_mutdiff_coeff = mutdiff_coeff; }

		double read_mutdiff_coeff() const { return mutdiff_coeff; }
		void set_mutdiff_coeff(double d) { mutdiff_coeff = d; }

		double read_pop_mutdiff_coeff(Population* pop);
		void set_pop_mutdiff_coeff(double d, Population* pop);

		double normalize_read_pop_mutdiff_coeff(Population* pop, bool threshold);
		void unnormalize_set_pop_mutdiff_coeff(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mutdiff_coeff(double x, bool threshold);
		double unnormalize_pop_mutdiff_coeff(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		// This global tells compatibility threshold under which two Genomes are considered the same species 
		double compat_threshold;

		static const double pop_compat_threshold_max;
		static const double pop_compat_threshold_min;

		static double read_sc_compat_threshold() { return sc_compat_threshold; }
		void set_sc_compat_threshold(double compat_threshold) { sc_compat_threshold = compat_threshold; }

		static double read_bsc_compat_threshold() { return bsc_compat_threshold; }
		void set_bsc_compat_threshold(double compat_threshold) { bsc_compat_threshold = compat_threshold; }

		double read_compat_threshold() const { return compat_threshold; }
		void set_compat_threshold(double d) { compat_threshold = d; }

		double read_pop_compat_threshold(Population* pop);
		void set_pop_compat_threshold(double d, Population* pop);

		double normalize_read_pop_compat_threshold(Population* pop, bool threshold);
		void unnormalize_set_pop_compat_threshold(Population* pop, double N_prime, bool threshold);

		double normalize_pop_compat_threshold(double x, bool threshold);
		double unnormalize_pop_compat_threshold(double N_prime, bool threshold);
		//*************************************************************************************


		// Globals involved in the epoch cycle - mating, reproduction, etc.. 

		//*************************************************************************************
		double age_significance;          // How much does age matter? 

		static const double pop_age_significance_max;
		static const double pop_age_significance_min;

		static double read_sc_age_significance() { return sc_age_significance; }
		void set_sc_age_significance(double age_significance) { sc_age_significance = age_significance; }

		static double read_bsc_age_significance() { return bsc_age_significance; }
		void set_bsc_age_significance(double age_significance) { bsc_age_significance = age_significance; }

		double read_age_significance() const { return age_significance; }
		void set_age_significance(double d) { age_significance = d; }

		double read_pop_age_significance(Population* pop);
		void set_pop_age_significance(double d, Population* pop);

		double normalize_read_pop_age_significance(Population* pop, bool threshold);
		void unnormalize_set_pop_age_significance(Population* pop, double N_prime, bool threshold);

		double normalize_pop_age_significance(double x, bool threshold);
		double unnormalize_pop_age_significance(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double survival_thresh;           // Percent of ave fitness for survival 

		static const double pop_survival_thresh_max;
		static const double pop_survival_thresh_min;

		static double read_sc_survival_thresh() { return sc_survival_thresh; }
		void set_sc_survival_thresh(double survival_thresh) { sc_survival_thresh = survival_thresh; }

		static double read_bsc_survival_thresh() { return bsc_survival_thresh; }
		void set_bsc_survival_thresh(double survival_thresh) { bsc_survival_thresh = survival_thresh; }

		double read_survival_thresh() const { return survival_thresh; }
		void set_survival_thresh(double d) { survival_thresh = d; }

		double read_pop_survival_thresh(Population* pop);
		void set_pop_survival_thresh(double d, Population* pop);

		double normalize_read_pop_survival_thresh(Population* pop, bool threshold);
		void unnormalize_set_pop_survival_thresh(Population* pop, double N_prime, bool threshold);

		double normalize_pop_survival_thresh(double x, bool threshold);
		double unnormalize_pop_survival_thresh(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mutate_only_prob;          // Prob. of a non-mating reproduction 

		static const double pop_mutate_only_prob_max;
		static const double pop_mutate_only_prob_min;

		static double read_sc_mutate_only_prob() { return sc_mutate_only_prob; }
		void set_sc_mutate_only_prob(double mutate_only_prob) { sc_mutate_only_prob = mutate_only_prob; }

		static double read_bsc_mutate_only_prob() { return bsc_mutate_only_prob; }
		void set_bsc_mutate_only_prob(double mutate_only_prob) { bsc_mutate_only_prob = mutate_only_prob; }

		double read_mutate_only_prob() const { return mutate_only_prob; }
		void set_mutate_only_prob(double d) { mutate_only_prob = d; }

		double read_pop_mutate_only_prob(Population* pop);
		void set_pop_mutate_only_prob(double d, Population* pop);

		double normalize_read_pop_mutate_only_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mutate_only_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mutate_only_prob(double x, bool threshold);
		double unnormalize_pop_mutate_only_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mutate_random_trait_prob;

		static const double pop_mutate_random_trait_prob_max;
		static const double pop_mutate_random_trait_prob_min;

		static double read_sc_mutate_random_trait_prob() { return sc_mutate_random_trait_prob; }
		void set_sc_mutate_random_trait_prob(double mutate_random_trait_prob) { sc_mutate_random_trait_prob = mutate_random_trait_prob; }

		static double read_bsc_mutate_random_trait_prob() { return bsc_mutate_random_trait_prob; }
		void set_bsc_mutate_random_trait_prob(double mutate_random_trait_prob) { bsc_mutate_random_trait_prob = mutate_random_trait_prob; }

		double read_mutate_random_trait_prob() const { return mutate_random_trait_prob; }
		void set_mutate_random_trait_prob(double d) { mutate_random_trait_prob = d; }

		double read_pop_mutate_random_trait_prob(Population* pop);
		void set_pop_mutate_random_trait_prob(double d, Population* pop);

		double normalize_read_pop_mutate_random_trait_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mutate_random_trait_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mutate_random_trait_prob(double x, bool threshold);
		double unnormalize_pop_mutate_random_trait_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mutate_link_trait_prob;

		static const double pop_mutate_link_trait_prob_max;
		static const double pop_mutate_link_trait_prob_min;

		static double read_sc_mutate_link_trait_prob() { return sc_mutate_link_trait_prob; }
		void set_sc_mutate_link_trait_prob(double mutate_link_trait_prob) { sc_mutate_link_trait_prob = mutate_link_trait_prob; }

		static double read_bsc_mutate_link_trait_prob() { return bsc_mutate_link_trait_prob; }
		void set_bsc_mutate_link_trait_prob(double mutate_link_trait_prob) { bsc_mutate_link_trait_prob = mutate_link_trait_prob; }

		double read_mutate_link_trait_prob() const { return mutate_link_trait_prob; }
		void set_mutate_link_trait_prob(double d) { mutate_link_trait_prob = d; }

		double read_pop_mutate_link_trait_prob(Population* pop);
		void set_pop_mutate_link_trait_prob(double d, Population* pop);

		double normalize_read_pop_mutate_link_trait_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mutate_link_trait_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mutate_link_trait_prob(double x, bool threshold);
		double unnormalize_pop_mutate_link_trait_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mutate_node_trait_prob;

		static const double pop_mutate_node_trait_prob_max;
		static const double pop_mutate_node_trait_prob_min;

		static double read_sc_mutate_node_trait_prob() { return sc_mutate_node_trait_prob; }
		void set_sc_mutate_node_trait_prob(double mutate_node_trait_prob) { sc_mutate_node_trait_prob = mutate_node_trait_prob; }

		static double read_bsc_mutate_node_trait_prob() { return bsc_mutate_node_trait_prob; }
		void set_bsc_mutate_node_trait_prob(double mutate_node_trait_prob) { bsc_mutate_node_trait_prob = mutate_node_trait_prob; }

		double read_mutate_node_trait_prob() const { return mutate_node_trait_prob; }
		void set_mutate_node_trait_prob(double d) { mutate_node_trait_prob = d; }

		double read_pop_mutate_node_trait_prob(Population* pop);
		void set_pop_mutate_node_trait_prob(double d, Population* pop);

		double normalize_read_pop_mutate_node_trait_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mutate_node_trait_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mutate_node_trait_prob(double x, bool threshold);
		double unnormalize_pop_mutate_node_trait_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mutate_link_weights_prob;

		static const double pop_mutate_link_weights_prob_max;
		static const double pop_mutate_link_weights_prob_min;

		static double read_sc_mutate_link_weights_prob() { return sc_mutate_link_weights_prob; }
		void set_sc_mutate_link_weights_prob(double mutate_link_weights_prob) { sc_mutate_link_weights_prob = mutate_link_weights_prob; }

		static double read_bsc_mutate_link_weights_prob() { return bsc_mutate_link_weights_prob; }
		void set_bsc_mutate_link_weights_prob(double mutate_link_weights_prob) { bsc_mutate_link_weights_prob = mutate_link_weights_prob; }

		double read_mutate_link_weights_prob() const { return mutate_link_weights_prob; }
		void set_mutate_link_weights_prob(double d) { mutate_link_weights_prob = d; }

		double read_pop_mutate_link_weights_prob(Population* pop);
		void set_pop_mutate_link_weights_prob(double d, Population* pop);

		double normalize_read_pop_mutate_link_weights_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mutate_link_weights_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mutate_link_weights_prob(double x, bool threshold);
		double unnormalize_pop_mutate_link_weights_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mutate_toggle_enable_prob;

		static const double pop_mutate_toggle_enable_prob_max;
		static const double pop_mutate_toggle_enable_prob_min;

		static double read_sc_mutate_toggle_enable_prob() { return sc_mutate_toggle_enable_prob; }
		void set_sc_mutate_toggle_enable_prob(double mutate_toggle_enable_prob) { sc_mutate_toggle_enable_prob = mutate_toggle_enable_prob; }

		static double read_bsc_mutate_toggle_enable_prob() { return bsc_mutate_toggle_enable_prob; }
		void set_bsc_mutate_toggle_enable_prob(double mutate_toggle_enable_prob) { bsc_mutate_toggle_enable_prob = mutate_toggle_enable_prob; }

		double read_mutate_toggle_enable_prob() const { return mutate_toggle_enable_prob; }
		void set_mutate_toggle_enable_prob(double d) { mutate_toggle_enable_prob = d; }

		double read_pop_mutate_toggle_enable_prob(Population* pop);
		void set_pop_mutate_toggle_enable_prob(double d, Population* pop);

		double normalize_read_pop_mutate_toggle_enable_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mutate_toggle_enable_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mutate_toggle_enable_prob(double x, bool threshold);
		double unnormalize_pop_mutate_toggle_enable_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mutate_gene_reenable_prob;

		static const double pop_mutate_gene_reenable_prob_max;
		static const double pop_mutate_gene_reenable_prob_min;

		static double read_sc_mutate_gene_reenable_prob() { return sc_mutate_gene_reenable_prob; }
		void set_sc_mutate_gene_reenable_prob(double mutate_gene_reenable_prob) { sc_mutate_gene_reenable_prob = mutate_gene_reenable_prob; }

		static double read_bsc_mutate_gene_reenable_prob() { return bsc_mutate_gene_reenable_prob; }
		void set_bsc_mutate_gene_reenable_prob(double mutate_gene_reenable_prob) { bsc_mutate_gene_reenable_prob = mutate_gene_reenable_prob; }

		double read_mutate_gene_reenable_prob() const { return mutate_gene_reenable_prob; }
		void set_mutate_gene_reenable_prob(double d) { mutate_gene_reenable_prob = d; }

		double read_pop_mutate_gene_reenable_prob(Population* pop);
		void set_pop_mutate_gene_reenable_prob(double d, Population* pop);

		double normalize_read_pop_mutate_gene_reenable_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mutate_gene_reenable_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mutate_gene_reenable_prob(double x, bool threshold);
		double unnormalize_pop_mutate_gene_reenable_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mutate_add_node_prob;

		static const double pop_mutate_add_node_prob_max;
		static const double pop_mutate_add_node_prob_min;

		static double read_sc_mutate_add_node_prob() { return sc_mutate_add_node_prob; }
		void set_sc_mutate_add_node_prob(double mutate_add_node_prob) { sc_mutate_add_node_prob = mutate_add_node_prob; }

		static double read_bsc_mutate_add_node_prob() { return bsc_mutate_add_node_prob; }
		void set_bsc_mutate_add_node_prob(double mutate_add_node_prob) { bsc_mutate_add_node_prob = mutate_add_node_prob; }

		double read_mutate_add_node_prob() const { return mutate_add_node_prob; }
		void set_mutate_add_node_prob(double d) { mutate_add_node_prob = d; }

		double read_pop_mutate_add_node_prob(Population* pop);
		void set_pop_mutate_add_node_prob(double d, Population* pop);

		double normalize_read_pop_mutate_add_node_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mutate_add_node_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mutate_add_node_prob(double x, bool threshold);
		double unnormalize_pop_mutate_add_node_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mutate_add_link_prob;

		static const double pop_mutate_add_link_prob_max;
		static const double pop_mutate_add_link_prob_min;

		static double read_sc_mutate_add_link_prob() { return sc_mutate_add_link_prob; }
		void set_sc_mutate_add_link_prob(double mutate_add_link_prob) { sc_mutate_add_link_prob = mutate_add_link_prob; }

		static double read_bsc_mutate_add_link_prob() { return bsc_mutate_add_link_prob; }
		void set_bsc_mutate_add_link_prob(double mutate_add_link_prob) { bsc_mutate_add_link_prob = mutate_add_link_prob; }

		double read_mutate_add_link_prob() const { return mutate_add_link_prob; }
		void set_mutate_add_link_prob(double d) { mutate_add_link_prob = d; }

		double read_pop_mutate_add_link_prob(Population* pop);
		void set_pop_mutate_add_link_prob(double d, Population* pop);

		double normalize_read_pop_mutate_add_link_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mutate_add_link_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mutate_add_link_prob(double x, bool threshold);
		double unnormalize_pop_mutate_add_link_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double interspecies_mate_rate;    // Prob. of a mate being outside species 

		static const double pop_interspecies_mate_rate_max;
		static const double pop_interspecies_mate_rate_min;

		static double read_sc_interspecies_mate_rate() { return sc_interspecies_mate_rate; }
		void set_sc_interspecies_mate_rate(double interspecies_mate_rate) { sc_interspecies_mate_rate = interspecies_mate_rate; }

		static double read_bsc_interspecies_mate_rate() { return bsc_interspecies_mate_rate; }
		void set_bsc_interspecies_mate_rate(double interspecies_mate_rate) { bsc_interspecies_mate_rate = interspecies_mate_rate; }

		double read_interspecies_mate_rate() const { return interspecies_mate_rate; }
		void set_interspecies_mate_rate(double d) { interspecies_mate_rate = d; }

		double read_pop_interspecies_mate_rate(Population* pop);
		void set_pop_interspecies_mate_rate(double d, Population* pop);

		double normalize_read_pop_interspecies_mate_rate(Population* pop, bool threshold);
		void unnormalize_set_pop_interspecies_mate_rate(Population* pop, double N_prime, bool threshold);

		double normalize_pop_interspecies_mate_rate(double x, bool threshold);
		double unnormalize_pop_interspecies_mate_rate(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mate_multipoint_prob;     

		static const double pop_mate_multipoint_prob_max;
		static const double pop_mate_multipoint_prob_min;

		static double read_sc_mate_multipoint_prob() { return sc_mate_multipoint_prob; }
		void set_sc_mate_multipoint_prob(double mate_multipoint_prob) { sc_mate_multipoint_prob = mate_multipoint_prob; }

		static double read_bsc_mate_multipoint_prob() { return bsc_mate_multipoint_prob; }
		void set_bsc_mate_multipoint_prob(double mate_multipoint_prob) { bsc_mate_multipoint_prob = mate_multipoint_prob; }

		double read_mate_multipoint_prob() const { return mate_multipoint_prob; }
		void set_mate_multipoint_prob(double d) { mate_multipoint_prob = d; }

		double read_pop_mate_multipoint_prob(Population* pop);
		void set_pop_mate_multipoint_prob(double d, Population* pop);

		double normalize_read_pop_mate_multipoint_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mate_multipoint_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mate_multipoint_prob(double x, bool threshold);
		double unnormalize_pop_mate_multipoint_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mate_multipoint_avg_prob;

		static const double pop_mate_multipoint_avg_prob_max;
		static const double pop_mate_multipoint_avg_prob_min;

		static double read_sc_mate_multipoint_avg_prob() { return sc_mate_multipoint_avg_prob; }
		void set_sc_mate_multipoint_avg_prob(double mate_multipoint_avg_prob) { sc_mate_multipoint_avg_prob = mate_multipoint_avg_prob; }

		static double read_bsc_mate_multipoint_avg_prob() { return bsc_mate_multipoint_avg_prob; }
		void set_bsc_mate_multipoint_avg_prob(double mate_multipoint_avg_prob) { bsc_mate_multipoint_avg_prob = mate_multipoint_avg_prob; }

		double read_mate_multipoint_avg_prob() const { return mate_multipoint_avg_prob; }
		void set_mate_multipoint_avg_prob(double d) { mate_multipoint_avg_prob = d; }

		double read_pop_mate_multipoint_avg_prob(Population* pop);
		void set_pop_mate_multipoint_avg_prob(double d, Population* pop);

		double normalize_read_pop_mate_multipoint_avg_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mate_multipoint_avg_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mate_multipoint_avg_prob(double x, bool threshold);
		double unnormalize_pop_mate_multipoint_avg_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mate_singlepoint_prob;

		static const double pop_mate_singlepoint_prob_max;
		static const double pop_mate_singlepoint_prob_min;

		static double read_sc_mate_singlepoint_prob() { return sc_mate_singlepoint_prob; }
		void set_sc_mate_singlepoint_prob(double mate_singlepoint_prob) { sc_mate_singlepoint_prob = mate_singlepoint_prob; }

		static double read_bsc_mate_singlepoint_prob() { return bsc_mate_singlepoint_prob; }
		void set_bsc_mate_singlepoint_prob(double mate_singlepoint_prob) { bsc_mate_singlepoint_prob = mate_singlepoint_prob; }

		double read_mate_singlepoint_prob() const { return mate_singlepoint_prob; }
		void set_mate_singlepoint_prob(double d) { mate_singlepoint_prob = d; }

		double read_pop_mate_singlepoint_prob(Population* pop);
		void set_pop_mate_singlepoint_prob(double d, Population* pop);

		double normalize_read_pop_mate_singlepoint_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mate_singlepoint_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mate_singlepoint_prob(double x, bool threshold);
		double unnormalize_pop_mate_singlepoint_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double mate_only_prob;            // Prob. of mating without mutation 

		static const double pop_mate_only_prob_max;
		static const double pop_mate_only_prob_min;

		static double read_sc_mate_only_prob() { return sc_mate_only_prob; }
		void set_sc_mate_only_prob(double mate_only_prob) { sc_mate_only_prob = mate_only_prob; }

		static double read_bsc_mate_only_prob() { return bsc_mate_only_prob; }
		void set_bsc_mate_only_prob(double mate_only_prob) { bsc_mate_only_prob = mate_only_prob; }

		double read_mate_only_prob() const { return mate_only_prob; }
		void set_mate_only_prob(double d) { mate_only_prob = d; }

		double read_pop_mate_only_prob(Population* pop);
		void set_pop_mate_only_prob(double d, Population* pop);

		double normalize_read_pop_mate_only_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_mate_only_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_mate_only_prob(double x, bool threshold);
		double unnormalize_pop_mate_only_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		double recur_only_prob;  // Probability of forcing selection of ONLY links that are naturally recurrent 

		static const double pop_recur_only_prob_max;
		static const double pop_recur_only_prob_min;

		static double read_sc_recur_only_prob() { return sc_recur_only_prob; }
		void set_sc_recur_only_prob(double recur_only_prob) { sc_recur_only_prob = recur_only_prob; }

		static double read_bsc_recur_only_prob() { return bsc_recur_only_prob; }
		void set_bsc_recur_only_prob(double recur_only_prob) { bsc_recur_only_prob = recur_only_prob; }

		double read_recur_only_prob() const { return recur_only_prob; }
		void set_recur_only_prob(double d) { recur_only_prob = d; }

		double read_pop_recur_only_prob(Population* pop);
		void set_pop_recur_only_prob(double d, Population* pop);

		double normalize_read_pop_recur_only_prob(Population* pop, bool threshold);
		void unnormalize_set_pop_recur_only_prob(Population* pop, double N_prime, bool threshold);

		double normalize_pop_recur_only_prob(double x, bool threshold);
		double unnormalize_pop_recur_only_prob(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		int pop_size;  // Size of population 

		static const int pop_pop_size_max;
		static const int pop_pop_size_min;

		static int read_sc_pop_size() { return sc_pop_size; }
		void set_sc_pop_size(int pop_size) { sc_pop_size = pop_size; }

		static int read_bsc_pop_size() { return bsc_pop_size; }
		void set_bsc_pop_size(int pop_size) { bsc_pop_size = pop_size; }

		int read_pop_size() const { return pop_size; }
		void set_pop_size(int i) { pop_size = i; }

		int read_pop_pop_size(Population* pop);
		void set_pop_pop_size(int i, Population* pop);

		double normalize_read_pop_pop_size(Population* pop, bool threshold);
		void unnormalize_set_pop_pop_size(Population* pop, double N_prime, bool threshold);

		double normalize_pop_pop_size(int x, bool threshold);
		int unnormalize_pop_pop_size(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		int dropoff_age;  // Age where Species starts to be penalized 

		static const int pop_dropoff_age_max;
		static const int pop_dropoff_age_min;

		static int read_sc_dropoff_age() { return sc_dropoff_age; }
		void set_sc_dropoff_age(int dropoff_age) { sc_dropoff_age = dropoff_age; }

		static int read_bsc_dropoff_age() { return bsc_dropoff_age; }
		void set_bsc_dropoff_age(int dropoff_age) { bsc_dropoff_age = dropoff_age; }

		int read_dropoff_age() const { return dropoff_age; }
		void set_dropoff_age(int i) { dropoff_age = i; }

		int read_pop_dropoff_age(Population* pop);
		void set_pop_dropoff_age(int i, Population* pop);

		double normalize_read_pop_dropoff_age(Population* pop, bool threshold);
		void unnormalize_set_pop_dropoff_age(Population* pop, double N_prime, bool threshold);

		double normalize_pop_dropoff_age(int x, bool threshold);
		int unnormalize_pop_dropoff_age(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		int newlink_tries;  // Number of tries mutate_add_link will attempt to find an open link 

		static const int pop_newlink_tries_max;
		static const int pop_newlink_tries_min;

		static int read_sc_newlink_tries() { return sc_newlink_tries; }
		void set_sc_newlink_tries(int newlink_tries) { sc_newlink_tries = newlink_tries; }

		static int read_bsc_newlink_tries() { return bsc_newlink_tries; }
		void set_bsc_newlink_tries(int newlink_tries) { bsc_newlink_tries = newlink_tries; }

		int read_newlink_tries() const { return newlink_tries; }
		void set_newlink_tries(int i) { newlink_tries = i; }

		int read_pop_newlink_tries(Population* pop);
		void set_pop_newlink_tries(int i, Population* pop);

		double normalize_read_pop_newlink_tries(Population* pop, bool threshold);
		void unnormalize_set_pop_newlink_tries(Population* pop, double N_prime, bool threshold);

		double normalize_pop_newlink_tries(int x, bool threshold);
		int unnormalize_pop_newlink_tries(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		int print_every; // Tells to print population to file every n generations 

		static const int pop_print_every_max;
		static const int pop_print_every_min;

		static int read_sc_print_every() { return sc_print_every; }
		void set_sc_print_every(int print_every) { sc_print_every = print_every; }

		static int read_bsc_print_every() { return bsc_print_every; }
		void set_bsc_print_every(int print_every) { bsc_print_every = print_every; }

		int read_print_every() const { return print_every; }
		void set_print_every(int i) { print_every = i; }

		int read_pop_print_every(Population* pop);
		void set_pop_print_every(int i, Population* pop);

		double normalize_read_pop_print_every(Population* pop, bool threshold);
		void unnormalize_set_pop_print_every(Population* pop, double N_prime, bool threshold);

		double normalize_pop_print_every(int x, bool threshold);
		int unnormalize_pop_print_every(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		int babies_stolen; // The number of babies to siphon off to the champions 

		static const int pop_babies_stolen_max;
		static const int pop_babies_stolen_min;

		static int read_sc_babies_stolen() { return sc_babies_stolen; }
		void set_sc_babies_stolen(int babies_stolen) { sc_babies_stolen = babies_stolen; }

		static int read_bsc_babies_stolen() { return bsc_babies_stolen; }
		void set_bsc_babies_stolen(int babies_stolen) { bsc_babies_stolen = babies_stolen; }

		int read_babies_stolen() const { return babies_stolen; }
		void set_babies_stolen(int i) { babies_stolen = i; }

		int read_pop_babies_stolen(Population* pop);
		void set_pop_babies_stolen(int i, Population* pop);

		double normalize_read_pop_babies_stolen(Population* pop, bool threshold);
		void unnormalize_set_pop_babies_stolen(Population* pop, double N_prime, bool threshold);

		double normalize_pop_babies_stolen(int x, bool threshold);
		int unnormalize_pop_babies_stolen(double N_prime, bool threshold);
		//*************************************************************************************

		//*************************************************************************************
		int num_runs; //number of times to run experiment

		static const int pop_num_runs_max;
		static const int pop_num_runs_min;

		static int read_sc_num_runs() { return sc_num_runs; }
		void set_sc_num_runs(int num_runs) { sc_num_runs = num_runs; }

		static int read_bsc_num_runs() { return bsc_num_runs; }
		void set_bsc_num_runs(int num_runs) { bsc_num_runs = num_runs; }

		int read_num_runs() const { return num_runs; }
		void set_num_runs(int i) { num_runs = i; }

		int read_pop_num_runs(Population* pop);
		void set_pop_num_runs(int i, Population* pop);

		double normalize_read_pop_num_runs(Population* pop, bool threshold);
		void unnormalize_set_pop_num_runs(Population* pop, double N_prime, bool threshold);

		double normalize_pop_num_runs(int x, bool threshold);
		int unnormalize_pop_num_runs(double N_prime, bool threshold);
		//*************************************************************************************

		double normalize_input(double x,double x_min,double x_max,double N_min,double N_max,double N_prime, bool threshold);

		double unnormalize_output(double x,double x_min,double x_max,double N_min,double N_max,double N_prime, bool threshold);

		double RoundNew(double val, int dp);



	};	// end class PopParams


#endif	// _POP_PARAMS_H_

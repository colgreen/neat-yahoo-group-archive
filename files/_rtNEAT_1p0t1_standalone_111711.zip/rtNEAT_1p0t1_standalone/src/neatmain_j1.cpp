
#include <ctime>
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include  <io.h>

#include "population.h"
#include "experiments.h"

using namespace std;

extern int i_interactive_flag;			// 0 = not interactive, 1 = interactive

extern char* param_spop_filename;


//#################################################################################################
void call_neat(int irun, int ipop, int igen, NEAT &A, int egen)
{
	int pause;

	double r_highest_fitness = 0;
	double r_highest_fitness_accum = 0;
	double r_highest_fitness_overall = 0;

	int i;

	stringstream ss;
	string s_print_output; 
	char* print_output;

	//***********RANDOM SETUP***************//
	/* Seed the random-number generator with current time so that
	the numbers will be different every time we run.    */

	Population sP, *sPp = &sP;

	// Check for existence of supervisor parameter file: 0 = file does not exist, 1 = file exists
	if( ((_access( param_spop_filename, 0 )) != -1) && (i_interactive_flag != 1) )
	{
		sPp->popparams.read_pop_neat_params_from_file(param_spop_filename, sPp);
      
		sPp->popparams.initializer_bsc(sPp);
	}


	(sPp->popparams).set_pop_size(ipop);

	sPp = supervisor_test(igen, sPp, egen);

	r_highest_fitness=sPp->highest_fitness;

	r_highest_fitness_accum=sPp->highest_fitness_accum;

		if( i_interactive_flag == 1 )
		{
			cout<<"OVERALL HIGHEST POPULATION FITNESS: "<< irun << "   " << (ipop+1) << "   " << A.highest_fitness_overall << endl;
		}

		ss.clear();
		ss <<"OVERALL HIGHEST POPULATION FITNESS: "<< irun << "   " << (ipop+1) << "   " << A.highest_fitness_overall << endl;
		getline(ss,s_print_output);
		print_output = (char*)(s_print_output.c_str());
		DBUG_PRINT("neatmain", (print_output))
	
	delete sPp;
 
}
//#################################################################################################



#include "population.h"

#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

//#################################################################################################
Population::Link::Link(double w,Population::NNode *inode,int inode_outnum,Population::NNode *onode,int onode_innum,bool recur) {

	weight=w;
	in_node=inode;
	in_node_outnum = inode_outnum;	// output # of in_node (i.e. each node may have multiple unique outputs), afc, 12/11/06

	//	these next nine were shifted from NNode::NodeUniqueOutput to allow multi-outputs per NNode
	in_node_override = false;							// The NNode cannot compute its own output- something is overriding it
	in_node_override_value = 0.0;						// Contains the activation value that will override this node's activation
	in_node_active_flag = true;							// To make sure outputs are active

	in_node_activation = 0.0;							// The total activation entering the unique NNode input
	in_node_max_num_delay_steps = 10;					// keeps track of max # of elements in activation_timedelay
	in_node_last_activation = 0.0;						// Holds the previous step's activation for recurrency
	in_node_last_activation2 = 0.0;						// Holds the activation BEFORE the prevous step's

	out_node=onode;
	out_node_innum = onode_innum;	// input # of out_node (i.e. each node may have multiple unique inputs), afc, 12/11/06

	is_recurrent=recur;
	added_weight=0;
	linktrait=0;
	time_delay=false;
	trait_id=1;
}
//#################################################################################################


//#################################################################################################
Population::Link::Link(Population::Trait *lt,double w,Population::NNode *inode,int inode_outnum,Population::NNode *onode,int onode_innum,bool recur) {

	weight=w;
	in_node=inode;
	in_node_outnum = inode_outnum;	// output # of in_node (i.e. each node may have multiple unique outputs, afc, 12/11/06

	//	these next three were shifted from NNode::NodeUniqueOutput to allow multi-outputs per NNode
	in_node_override = false;		// The NNode cannot compute its own output- something is overriding it
	in_node_override_value = 0.0;	// Contains the activation value that will override this node's activation
	in_node_active_flag = true;		// To make sure outputs are active

	in_node_activation = 0.0;							// The total activation entering the unique NNode input
	in_node_max_num_delay_steps = 10;					// keeps track of max # of elements in activation_timedelay
	in_node_last_activation = 0.0;						// Holds the previous step's activation for recurrency
	in_node_last_activation2 = 0.0;						// Holds the activation BEFORE the prevous step's

	out_node=onode;
	out_node_innum = onode_innum;	// input # of out_node (i.e. each node may have multiple unique inputs, afc, 12/11/06

	is_recurrent=recur;
	added_weight=0;
	linktrait=lt;
	time_delay=false;
	if (lt!=0)
		trait_id=lt->trait_id;
	else trait_id=1;
}	
//#################################################################################################


//#################################################################################################
Population::Link::Link(double w) {

	weight=w;
	in_node=out_node=0;  

	in_node_outnum = 0;	// default, output # of in_node (i.e. each node may have multiple unique outputs, afc, 12/11/06
	out_node_innum = 0;	// default, input # of out_node (i.e. each node may have multiple unique inputs, afc, 12/11/06

	//	these next three were shifted from NNode::NodeUniqueOutput to allow multi-outputs per NNode
	in_node_override = false;		// The NNode cannot compute its own output- something is overriding it
	in_node_override_value = 0.0;	// Contains the activation value that will override this node's activation
	in_node_active_flag = true;		// To make sure outputs are active

	in_node_activation = 0.0;							// The total activation entering the unique NNode input
	in_node_max_num_delay_steps = 10;					// keeps track of max # of elements in activation_timedelay
	in_node_last_activation = 0.0;						// Holds the previous step's activation for recurrency
	in_node_last_activation2 = 0.0;						// Holds the activation BEFORE the prevous step's

	is_recurrent=false;
	linktrait=0;
	time_delay=false;
	trait_id=1;

}
//#################################################################################################


//#################################################################################################
Population::Link::Link(const Population::Link& link)
{
	weight = link.weight;

	in_node = link.in_node;
	in_node_outnum = link.in_node_outnum;	// output # of in_node (i.e. each node may have multiple unique outputs, afc, 12/11/06

	//	these next three were shifted from NNode::NodeUniqueOutput to allow multi-outputs per NNode
	in_node_override = false;		// The NNode cannot compute its own output- something is overriding it
	in_node_override_value = 0.0;	// Contains the activation value that will override this node's activation
	in_node_active_flag = true;		// To make sure outputs are active

	in_node_activation = 0.0;							// The total activation entering the unique NNode input
	in_node_max_num_delay_steps = 10;					// keeps track of max # of elements in activation_timedelay
	in_node_last_activation = 0.0;						// Holds the previous step's activation for recurrency
	in_node_last_activation2 = 0.0;						// Holds the activation BEFORE the prevous step's


	out_node = link.out_node;
	out_node_innum = link.out_node_innum;	// input # of out_node (i.e. each node may have multiple unique inputs, afc, 12/11/06

	is_recurrent = link.is_recurrent;
	added_weight = link.added_weight;
	linktrait = link.linktrait;
	time_delay = link.time_delay;
	trait_id = link.trait_id;
}
//#################################################################################################


//#################################################################################################
void Population::Link::derive_trait(Population::Trait *curtrait) {

	if (curtrait!=0) {

		for (int count=0;count<PopParams::num_trait_params;count++)

			params[count]=(curtrait->params)[count];
	}
	else {

		for (int count=0;count<PopParams::num_trait_params;count++)

			params[count]=0;
	}

	if (curtrait!=0)
		trait_id=curtrait->trait_id;
	else trait_id=1;

}
//#################################################################################################



#include "population.h"
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

//#################################################################################################
/* used on selection #1, #2, #3, #4 & #5 */
Population::Network::Network() {

  name=0;   //Defaults to no name  ..NOTE: TRYING TO PRINT AN EMPTY NAME CAN CAUSE A CRASH
  numnodes=-1;
  numlinks=-1;
  adaptable=false;

}
//#################################################################################################


//#################################################################################################
/* used on selection #1, #2, #3, #4 & #5 */
Population::Network::Network(std::vector<Population::NNode*> in,std::vector<Population::NNode*> out,std::vector<Population::NNode*> all,int netid) {

  inputs=in;
  outputs=out;
  all_nodes=all;
  name=0;   //Defaults to no name  ..NOTE: TRYING TO PRINT AN EMPTY NAME CAN CAUSE A CRASH
  numnodes=-1;
  numlinks=-1;
  net_id=netid;
  adaptable=false;

	std::vector<Population::NNode*>::const_iterator curnode;

	// set gen_node_label for all the inputs
	for(curnode = inputs.begin(); curnode != inputs.end(); ++curnode) 
	{
		(*curnode)->gen_node_label = INPUT;
	}

	// set gen_node_label for all the outputs
	for(curnode = outputs.begin(); curnode != outputs.end(); ++curnode) 
	{
		(*curnode)->gen_node_label = OUTPUT;
	}

}
//#################################################################################################


//#################################################################################################
/* not used on any of seletion 1 thru 5 (standard) */
Population::Network::Network(std::vector<Population::NNode*> in,std::vector<Population::NNode*> out,std::vector<Population::NNode*> all,int netid, bool adaptval) {

  inputs=in;
  outputs=out;
  all_nodes=all;
  name=0;   //Defaults to no name  ..NOTE: TRYING TO PRINT AN EMPTY NAME CAN CAUSE A CRASH                                    
  numnodes=-1;
  numlinks=-1;
  net_id=netid;
  adaptable=adaptval;

	std::vector<Population::NNode*>::const_iterator curnode;

	// set gen_node_label for all the inputs
	for(curnode = inputs.begin(); curnode != inputs.end(); ++curnode) 
	{
		(*curnode)->gen_node_label = INPUT;
	}

	// set gen_node_label for all the outputs
	for(curnode = outputs.begin(); curnode != outputs.end(); ++curnode) 
	{
		(*curnode)->gen_node_label = OUTPUT;
	}

}
//#################################################################################################


//#################################################################################################
/* not used on any of seletion 1 thru 5 (standard) */
Population::Network::Network(int netid) {

	name=0; //Defaults to no name
	numnodes=-1;
	numlinks=-1;
	net_id=netid;
	adaptable=false;

}
//#################################################################################################


//#################################################################################################
/* not used on any of seletion 1 thru 5 (standard) */
Population::Network::Network(int netid, bool adaptval) {

  name=0; //Defaults to no name                                                                                               
  numnodes=-1;
  numlinks=-1;
  net_id=netid;
  adaptable=adaptval;

}
//#################################################################################################


//#################################################################################################
Population::Network::Network(const Population::Network& network)
{

	std::vector<Population::NNode*>::const_iterator curnode;

	// Copy all the inputs
	for(curnode = network.inputs.begin(); curnode != network.inputs.end(); ++curnode) {

		Population::NNode* n = new Population::NNode(**curnode);
		inputs.push_back(n);
		all_nodes.push_back(n);

		(*curnode)->gen_node_label = INPUT;

	}

	// Copy all the outputs
	for(curnode = network.outputs.begin(); curnode != network.outputs.end(); ++curnode) {

		Population::NNode* n = new Population::NNode(**curnode);
		outputs.push_back(n);
		all_nodes.push_back(n);

		(*curnode)->gen_node_label = OUTPUT;

	}

	if(network.name)
		name = strdup(network.name);
	else
		name = 0;

	numnodes = network.numnodes;
	numlinks = network.numlinks;
	net_id = network.net_id;
	adaptable = network.adaptable;

}
//#################################################################################################


//#################################################################################################
Population::Network::~Network() {

	if (name!=0)
		delete [] name;

	destroy();  // Kill off all the nodes and links

}
//#################################################################################################


//#################################################################################################
// Puts the network back into an initial state
void Population::Network::flush() {

	std::vector<Population::NNode*>::iterator curnode;

	for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {

		(*curnode)->flushback();

	}
}
//#################################################################################################


//#################################################################################################
// Debugger: Checks network state
void Population::Network::flush_check() {

	std::vector<Population::NNode*>::iterator curnode;

	std::vector<Population::NNode*>::iterator location;

	std::vector<Population::NNode*> seenlist;  //List of nodes not to doublecount

	for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {    

        location= std::find(seenlist.begin(),seenlist.end(),(*curnode));

		if (location==seenlist.end()) {

			seenlist.push_back(*curnode);
			(*curnode)->flushback_check(seenlist);

		}
	}
}
//#################################################################################################


//#################################################################################################
// If all output are not active then return true
bool Population::Network::outputsoff() {

	std::vector<Population::NNode*>::iterator curnode;

	std::vector<Population::NNode::NodeUniqueOutput*>::iterator curuniqueoutput;

	for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {

		if( (*curnode)->nodeuniqueoutput.size() > 0 )
		{

			// loop over current unique inputs
			//for(curuniqueinput = (*curnode)->nodeuniqueinput.begin(); curuniqueinput != (*curnode)->nodeuniqueinput.end(); ++curuniqueinput)
			// loop over current unique outputs
			for(curuniqueoutput = (*curnode)->nodeuniqueoutput.begin(); curuniqueoutput != (*curnode)->nodeuniqueoutput.end(); ++curuniqueoutput)
			{

				if (((*curnode)->activation_count)==0) return true;
			}
		}
	}

	return false;
}
//#################################################################################################


//#################################################################################################
// Print the connections weights to a file separated by only carriage returns
void Population::Network::print_links_tofile(char *filename) {

	std::vector<Population::NNode*>::iterator curnode;
	std::vector<Population::Link*>::iterator curlink;

    std::ofstream oFile(filename);

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;
	std::vector<Population::Link*>::iterator curuniqueinputlink;

	//Make sure it worked
	//if (!oFile) {
	//	cerr<<"Can't open "<<filename<<" for output"<<endl;
		//return 0;
	//}

	for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode) {

		if (((*curnode)->type)!=SENSOR) {

			int inumlink = 0;

			int itmp1 = (*curnode)->nodeuniqueinput.size();

			if( (*curnode)->nodeuniqueinput.size() > 0 )
			{

				oFile << "New: " << ((*curnode)->nodeuniqueinput).size() << std::endl;

				// loop over current unique inputs
				for(curuniqueinput = (*curnode)->nodeuniqueinput.begin(); curuniqueinput != (*curnode)->nodeuniqueinput.end(); ++curuniqueinput)
				{

					int itmp2 = (*curuniqueinput)->incominglink2.size();

					//loop over all incoming links
					for(curuniqueinputlink = (*curuniqueinput)->incominglink2.begin(); curuniqueinputlink != (*curuniqueinput)->incominglink2.end(); ++curuniqueinputlink)
					{
						oFile << (*curuniqueinputlink)->in_node->node_id << "( "   << ( *curuniqueinputlink)->in_node_outnum << " ) -> " << ( *curuniqueinputlink)->out_node->node_id << "( " << ( *curuniqueinputlink)->out_node_innum << " ) : " << (*curuniqueinputlink)->weight << std::endl;
					}
				}
			}

		} //end if
	} //end for loop on nodes

	oFile.close();

} //print_links_tofile
//#################################################################################################


//#################################################################################################
// Activates the net such that all outputs are active
// Returns true on success;
bool Population::Network::activate() {

	std::vector<Population::NNode*>::iterator curnode;
	std::vector<Population::Link*>::iterator curlink;
	double add_amount = 0.0;  //For adding to the activesum
	bool onetime; //Make sure we at least activate once
	int abortcount=0;  //Used in case the output is somehow truncated from the network

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;
	std::vector<Population::NNode::NodeUniqueOutput*>::iterator curuniqueoutput;

	NEAT A;

	//cout<<"Activating network: "<<this->genotype<<endl;

	//Keep activating until all the outputs have become active 
	//(This only happens on the first activation, because after that they
	// are always active)

	onetime=false;

	while(outputsoff()||!onetime) 
	{

		++abortcount;

		if (abortcount==20) {

			return false;
			//cout<<"Inputs disconnected from output!"<<endl;

		}

		//std::cout<<"Outputs are off"<<std::endl;

		// For each node, compute the sum of its incoming activation 
		for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode) {

			if( ((*curnode)->ftype)==EMBEDDEDNETWORK )
			{
				int i = (*curnode)->nodeuniqueinput.size();
				int i1 = 0;
			}

			//Ignore SENSORS

			//cout<<"On node "<<(*curnode)->node_id<<endl;

			if (((*curnode)->type)!=SENSOR) {

				if( (*curnode)->nodeuniqueinput.size() > 0 )
				{

					//	for SIGMOID neurons
					if( ((*curnode)->ftype)==SIGMOID )
					{

						gen_incoming_activation_sigmoid(curnode);


					}// End ((*curnode)->ftype) == SIGMOID
					else
					{// Start ((*curnode)->ftype) != SIGMOID

						// for EMBEDDEDNETWORK neurons
						if( ((*curnode)->ftype) == EMBEDDEDNETWORK )
						{

							if(( (*curnode)->nodeuniqueoutput.size() >= 1) && 
								( (*curnode)->ftype == EMBEDDEDNETWORK ))
							{
								int i = 0;
							}

							if( (*curnode)->nodeuniqueoutput.size() > 0 ) 
							{
								gen_incoming_activation_embeddednetwork(curnode);
							}


						}// End ((*curnode)->ftype) == EMBEDDEDNETWORK 
						else
						{// Start ((*curnode)->ftype) != EMBEDDEDNETWORK

							// for EMBEDDEDPOPULATION neurons
							if( ((*curnode)->ftype)==EMBEDDEDPOPULATION )
							{

							}//End if( ((*curnode)->ftype)==EMBEDDEDPOPULATION )

						}//End ((*curnode)->ftype) != EMBEDDEDNETWORK

					}// End ((*curnode)->ftype) != SIGMOID

				}//End if( (*curnode)->nodeuniqueinput.size() > 0 )




			} //End if (((*curnode)->type)!=SENSOR) 

		} //End for over all nodes

		// Now activate all the non-sensor nodes off their incoming activation 
		for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode) 
		{

			if (((*curnode)->type)!=SENSOR) 
			{

				int itmp = (*curnode)->nodeuniqueinput.size();

				if( (*curnode)->nodeuniqueinput.size() > 0 )	// loop over inputs, and get activations from link in_nodes
				{

					//Now run the net activation through an activation function
					if ((*curnode)->ftype==SIGMOID)
					{

						activate_incoming_activation_sigmoid(curnode);


					}// End (*curnode)->ftype == SIGMOID
					else
					{// Start (*curnode)->ftype != SIGMOID

						//Now run the net activation through an activation function
						if ((*curnode)->ftype == EMBEDDEDNETWORK)
						{

//							activate_incoming_activation_embeddednetwork(curnode);
							if( (*curnode)->nodeuniqueoutput.size() > 0 )
							{
								activate_incoming_activation_embeddednetwork(curnode);
							}


						}// End ((*curnode)->ftype == EMBEDDEDNETWORK
						else
						{// Start (*curnode)->ftype != EMBEDDEDNETWORK

							//Now run the net activation through an activation function
							if ((*curnode)->ftype == EMBEDDEDPOPULATION)
							{


							}// End (*curnode)->ftype == EMBEDDEDPOPULATION


						}// End (*curnode)->ftype != EMBEDDEDNETWORK

					}// End (*curnode)->ftype != SIGMOID



				}// End if( (*curnode)->nodeuniqueinput.size() > 0 )

			}// End if (((*curnode)->type)!=SENSOR)
		}// End Now activate all the non-sensor nodes off their incoming activation

		onetime=true;
	}// End while(outputsoff()||!onetime)

	if (adaptable) 
	{

		//std::cout << "ADAPTING" << std:endl;

		// ADAPTATION:  Adapt weights based on activations 
		for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode) 
		{
	    
			//cout<<"On node "<<(*curnode)->node_id<<endl;
	    
			//Ignore SENSORS
			if (((*curnode)->type)!=SENSOR) 
			{

				adapt_weights_based_on_activations(curnode);

			}// End if (((*curnode)->type)!=SENSOR)
	    
		}// End for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode)
	  
	} // End if (adaptable)

	return true;  
}
//#################################################################################################


//#################################################################################################
void Population::Network::gen_incoming_activation_sigmoid(std::vector<Population::NNode*>::iterator curnode)
{
	std::vector<Population::Link*>::iterator curlink;
	double add_amount = 0.0;  //For adding to the activesum
	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;

	(*curnode)->activesum=0;
	(*curnode)->active_flag=false;  //This will tell us if it has any active inputs

	double add_amount_link = 0.0;  //For adding to the activesum associated w/ link


		// loop over current unique inputs
		for(curuniqueinput = (*curnode)->nodeuniqueinput.begin(); curuniqueinput != (*curnode)->nodeuniqueinput.end(); ++curuniqueinput)
		{

			// check for output nodes
			if( ( ((*curnode)->gen_node_label) == OUTPUT ) && ( ((*curnode)->type) == NEURON ) )
			{

				(*curuniqueinput)->activesum_input = 0;

				//loop over all incoming links
				for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
				{

					(*curlink)->in_node_active_flag = false;  //This will tell us if it has any active inputs

					//Handle possible time delays
					if (!((*curlink)->time_delay)) {

						add_amount=((*curlink)->weight)*(((*curlink)->in_node)->get_active_out());

						add_amount_link=((*curlink)->weight)*((*curlink)->in_node_activation);

						if ((((*curlink)->in_node)->active_flag) || (((*curlink)->in_node)->type==SENSOR))
						{
							(*curnode)->active_flag=true;
						}

						if (((*curlink)->in_node_active_flag) || (((*curlink)->in_node)->type==SENSOR))
						{
							(*curlink)->in_node_active_flag=true;
						}

						(*curnode)->activesum+=add_amount;

						(*curuniqueinput)->activesum_input+=add_amount_link;

						// set active_flag_input to true of some input received (i.e. activesum > 0)
						if( (*curnode)->activesum > 0.0 ) 
						{
							(*curnode)->active_flag = true;
						}

						// set active_flag_input to true of some input received (i.e. activesum > 0)
						if( (*curuniqueinput)->activesum_input > 0.0 ) 
						{
							(*curlink)->in_node_active_flag = true;
						}

						//std::cout<<"Node "<<(*curnode)->node_id<<" adding "<<add_amount<<" from node "<<((*curlink)->in_node)->node_id<<std::endl;
					}
					else
					{
						//Input over a time delayed connection
						add_amount=((*curlink)->weight)*(((*curlink)->in_node)->get_active_out_td());

						add_amount_link=((*curlink)->weight)*((*curlink)->in_node_last_activation);

						(*curnode)->activesum+=add_amount;

						(*curuniqueinput)->activesum_input+=add_amount_link;

						// set active_flag_input to true of some input received (i.e. activesum > 0)
						if( (*curnode)->activesum > 0.0 ) 
						{
							(*curnode)->active_flag = true;
						}

						// set active_flag_input to true of some input received (i.e. activesum > 0)
						if( (*curuniqueinput)->activesum_input > 0.0 ) 
						{
							(*curlink)->in_node_active_flag = true;
						}

					}

				}//End loop over all incoming links


			}// End check for output nodes
			else
			{// Start hidden nodes

				//loop over all incoming links
				for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
				{

					(*curlink)->in_node_active_flag = false;  //This will tell us if it has any active inputs

					//Handle possible time delays
					if (!((*curlink)->time_delay)) {

						add_amount_link=((*curlink)->weight)*((*curlink)->in_node_activation);

						if (((*curlink)->in_node_active_flag) || (((*curlink)->in_node)->type==SENSOR))
						{
							(*curlink)->in_node_active_flag=true;
						}

						(*curuniqueinput)->activesum_input+=add_amount_link;

						// set active_flag_input to true of some input received (i.e. activesum > 0)
						if( (*curuniqueinput)->activesum_input > 0.0 ) 
						{
							(*curlink)->in_node_active_flag = true;
						}

						//std::cout<<"Node "<<(*curnode)->node_id<<" adding "<<add_amount<<" from node "<<((*curlink)->in_node)->node_id<<std::endl;
					}
					else
					{
//						//Input over a time delayed connection
						add_amount_link=((*curlink)->weight)*((*curlink)->in_node_last_activation);

						(*curuniqueinput)->activesum_input+=add_amount_link;

						// set active_flag_input to true of some input received (i.e. activesum > 0)
						if( (*curuniqueinput)->activesum_input > 0.0 ) 
						{
							(*curlink)->in_node_active_flag = true;
						}

					}

				}//End loop over all incoming links

			}// End hidden nodes

		}//End loop over current unique inputs

}
//#################################################################################################


//#################################################################################################
void Population::Network::gen_incoming_activation_embeddednetwork(std::vector<Population::NNode*>::iterator curnode)
{

	Population::Network *net;

	int i,j;

	double in[100] = {0}; //The inputs
	double out[100]; //The outputs

	double this_out; //The current output
	int count;
	double errorsum;

	bool success;  //Check for successful activation
	int numnodes;  /* Used to figure out how many nodes
		    should be visited during activation */

	int net_depth; //The max depth of the network to be activated
	int relax; //Activates until relaxation

	std::vector<Population::NNode*>::iterator curnode2;
	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;
	std::vector<Population::NNode::NodeUniqueOutput*>::iterator curuniqueoutput;
	std::vector<Population::Link*>::iterator curlink;

	int end_count = 0;

	// loop over current unique inputs
	for(curuniqueinput = (*curnode)->nodeuniqueinput.begin(); curuniqueinput != (*curnode)->nodeuniqueinput.end(); ++curuniqueinput)
	{
		if( (*curuniqueinput)->active_flag_input )
		{
			in[end_count] = (*curuniqueinput)->activesum_input;
		}
		else
		{
			in[end_count] = 0.0;
		}

		end_count++;
	}

	net = (*curnode)->embeddednetworkptr;

	net_depth = net->max_depth();

	//Load and activate the network on each input
	for(count = 0; count <= end_count; count++)
	{

		net->load_sensors(&in[count]);

		//Relax net and get output
		success=net->activate();

		//use depth to ensure relaxation
		for(relax = 0; relax <= net_depth; relax++)
		{
			success = net->activate();
			this_out = (*(net->outputs.begin()))->activation;
		}
		
		out[count]=(*(net->outputs.begin()))->activation;

		net->flush();

	}

	int i_tmp = 0;
	
	// loop over current unique outputs
	for(curuniqueoutput = (*curnode)->nodeuniqueoutput.begin(); curuniqueoutput != (*curnode)->nodeuniqueoutput.end(); ++curuniqueoutput)
	{

		(*curuniqueoutput)->activation_output = out[i_tmp];

		//loop over all outgoing links
		for(curlink = (*curuniqueoutput)->outgoinglink2.begin(); curlink != (*curuniqueoutput)->outgoinglink2.end(); ++curlink)
		{
			(*curlink)->in_node_activation = out[i_tmp];
		}

		i_tmp++;

	}

}
//#################################################################################################


//#################################################################################################
void Population::Network::activate_incoming_activation_sigmoid(std::vector<Population::NNode*>::iterator curnode)
{
	std::vector<Population::Link*>::iterator curlink;
	double add_amount = 0.0;  //For adding to the activesum
	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;

	NEAT A;

		// loop over current unique inputs
		for(curuniqueinput = (*curnode)->nodeuniqueinput.begin(); curuniqueinput != (*curnode)->nodeuniqueinput.end(); ++curuniqueinput)
		{

			// check for output nodes
			if( ( ((*curnode)->gen_node_label) == OUTPUT ) && ( ((*curnode)->type) == NEURON ) )
			{

				//Only activate if some active input came in
				if ((*curnode)->active_flag) 
				{

					//cout<<"Activating "<<(*curnode)->node_id<<" with "<<(*curnode)->activesum<<": ";

					//Keep a memory of activations for potential time delayed connections
					(*curnode)->last_activation2=(*curnode)->last_activation;

					(*curnode)->last_activation=(*curnode)->activation;

					//If the node is being overrided from outside,
					//stick in the override value
					if ((*curnode)->overridden())
					{

						//Set activation to the override value and turn off override
						(*curnode)->activate_override();

					}
					else 
					{

						(*curnode)->activation = A.fsigmoid((*curnode)->activesum,4.924273,2.4621365);  //Sigmoidal activation- see comments under fsigmoid
					}

					(*curnode)->activation_count++;

				}// End //Only activate if some active input came in

			}// End check for output nodes

				//Only activate if some active input came in
				if ((*curuniqueinput)->active_flag_input) 
				{
					//loop over all incoming links
					for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
					{

						//cout<<"Activating "<<(*curnode)->node_id<<" with "<<(*curnode)->activesum<<": ";

						//Keep a memory of activations for potential time delayed connections
						(*curlink)->in_node_last_activation2 = (*curlink)->in_node_last_activation;

						(*curlink)->in_node_last_activation = (*curlink)->in_node_activation;

						//If the node is being overrided from outside,
						//stick in the override value
						if ((*curlink)->in_node_override)
						{
							//Set activation to the override value and turn off override
							(*curnode)->activate_override(*curlink);

						}
						else 
						{
							(*curlink)->in_node_activation = A.fsigmoid((*curuniqueinput)->activesum_input,4.924273,2.4621365);  //Sigmoidal activation- see comments under fsigmoid
						}

						(*curnode)->activation_count2++;

					}// End loop over all incoming links

				}// End //Only activate if some active input came in

		}// End loop over current unique inputs
}
//#################################################################################################


//#################################################################################################
void Population::Network::activate_incoming_activation_embeddednetwork(std::vector<Population::NNode*>::iterator curnode)
{
	std::vector<Population::Link*>::iterator curlink;
	double add_amount = 0.0;  //For adding to the activesum
	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;
	std::vector<Population::NNode::NodeUniqueOutput*>::iterator curuniqueoutput;

	std::vector<Population::NNode*>::iterator curoutputnode;

	NEAT A;

			// check for output nodes
			if( ( ((*curnode)->gen_node_label) == OUTPUT ) && ( ((*curnode)->type) == NEURON ) )
			{

				//Only activate if some active input came in
				if ((*curnode)->active_flag) 
				{

					//cout<<"Activating "<<(*curnode)->node_id<<" with "<<(*curnode)->activesum<<": ";

					//Keep a memory of activations for potential time delayed connections
					(*curnode)->last_activation2=(*curnode)->last_activation;

					(*curnode)->last_activation=(*curnode)->activation;

					//If the node is being overrided from outside,
					//stick in the override value
					if ((*curnode)->overridden())
					{
						//Set activation to the override value and turn off override
						(*curnode)->activate_override();
					}
					else 
					{

						(*curnode)->activation = (*curnode)->embeddednetworkptr->outputs.at(1)->activation;

					}

					(*curnode)->activation_count++;

				}// End //Only activate if some active input came in

			}// End check for output nodes
			else
			{// Start non-output nodes

				int i_tmp = 0;	// afc, 01/23/07

				// loop over current unique outputs
				for(curuniqueoutput = (*curnode)->nodeuniqueoutput.begin(); curuniqueoutput != (*curnode)->nodeuniqueoutput.end(); ++curuniqueoutput)
				{
					//Only activate if some active input came in
					if ((*curuniqueoutput)->active_flag_output) 
					{
						//loop over all outgoing links
						for(curlink = (*curuniqueoutput)->outgoinglink2.begin(); curlink != (*curuniqueoutput)->outgoinglink2.end(); ++curlink)
						{
							//Keep a memory of activations for potential time delayed connections
							(*curlink)->in_node_last_activation2 = (*curlink)->in_node_last_activation;

							(*curlink)->in_node_last_activation = (*curlink)->in_node_activation;

							//If the node is being overrided from outside,
							//stick in the override value
							if ((*curlink)->in_node_override)
							{
								//Set activation to the override value and turn off override
								(*curnode)->activate_override(*curlink);

							}
							else 
							{
								// loop over all the outputs
								for(curoutputnode = (*curnode)->embeddednetworkptr->outputs.begin(); curoutputnode != (*curnode)->embeddednetworkptr->outputs.end(); ++curoutputnode) 
								{

									(*curlink)->in_node_activation = (*curoutputnode)->activation;
								}

							}

						(*curnode)->activation_count2++;

					}// End loop over all outgoing links

				}// End //Only activate if some active input came in

				i_tmp++;

			}// End loop over current unique outputs

		}// End non-output nodes

}
//#################################################################################################


//#################################################################################################
void Population::Network::adapt_weights_based_on_activations(std::vector<Population::NNode*>::iterator curnode)
{
	std::vector<Population::Link*>::iterator curlink;
	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;
	NEAT A;

	if( (*curnode)->nodeuniqueinput.size() > 0 )
	{

		// loop over current unique inputs
		for(curuniqueinput = (*curnode)->nodeuniqueinput.begin(); curuniqueinput != (*curnode)->nodeuniqueinput.end(); ++curuniqueinput)
		{
			//loop over all incoming links
			for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
			{

				if (((*curlink)->trait_id==2)||
					((*curlink)->trait_id==3)||
					((*curlink)->trait_id==4)) 
				{
		  
					//In the recurrent case we must take the last activation of the input for calculating hebbian changes
					if ((*curlink)->is_recurrent) 
					{

						(*curlink)->weight=

						A.hebbian((*curlink)->weight,maxweight,

						(*curlink)->in_node_last_activation, 

						(*curlink)->out_node->get_active_out(),		// uses old NNode activation for out_nodes, for time being, afc, 01/04/07
						(*curlink)->params[0],(*curlink)->params[1],
						(*curlink)->params[2]);
		    		    
					}// End In the recurrent case we must take the last activation of the input for calculating hebbian changes
					else 
					{ //non-recurrent case

						(*curlink)->weight=

						A.hebbian((*curlink)->weight,maxweight,

						(*curlink)->in_node->get_active_out(), 

						(*curlink)->out_node->get_active_out(),		// uses old NNode activation for out_nodes, for time being, afc, 01/04/07
						(*curlink)->params[0],(*curlink)->params[1],
						(*curlink)->params[2]);

					}// End non-recurrent case
				}
			}// End loop over all incoming links
		}// End loop over current unique inputs
	}// End if( (*curnode)->nodeuniqueinput.size() > 0 )
}
//#################################################################################################


//#################################################################################################
// Prints the values of its outputs
void Population::Network::show_activation() {

	std::vector<Population::NNode*>::iterator curnode;
	int count;

	//if (name!=0)
	//  cout<<"Network "<<name<<" with id "<<net_id<<" outputs: (";
	//else cout<<"Network id "<<net_id<<" outputs: (";

	count=1;

	for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {

		//cout<<"[Output #"<<count<<": "<<(*curnode)<<"] ";
		count++;

	}

	//cout<<")"<<endl;
}
//#################################################################################################


//#################################################################################################
void Population::Network::show_input() {

	std::vector<Population::NNode*>::iterator curnode;
	int count;

	//if (name!=0)
	//  cout<<"Network "<<name<<" with id "<<net_id<<" inputs: (";
	//else cout<<"Network id "<<net_id<<" outputs: (";

	count=1;

	for(curnode=inputs.begin();curnode!=inputs.end();++curnode) {

		//cout<<"[Input #"<<count<<": "<<(*curnode)<<"] ";
		count++;

	}

	//cout<<")"<<endl;
}
//#################################################################################################


//#################################################################################################
// Add an input
void Population::Network::add_input(Population::NNode *in_node) {

	inputs.push_back(in_node);

}
//#################################################################################################


//#################################################################################################
// Add an output
void Population::Network::add_output(Population::NNode *out_node) {

	outputs.push_back(out_node);

}
//#################################################################################################


//#################################################################################################
// Takes an array of sensor values and loads it into SENSOR inputs ONLY
void Population::Network::load_sensors(double *sensvals) {

	std::vector<Population::NNode*>::iterator sensPtr;

	for(sensPtr=inputs.begin();sensPtr!=inputs.end();++sensPtr) {

		//only load values into SENSORS (not BIASes)
		if (((*sensPtr)->type)==SENSOR) {

			(*sensPtr)->sensor_load(*sensvals);
			sensvals++;

		}
	}
}
//#################################################################################################


//#################################################################################################
void Population::Network::load_sensors(const std::vector<float> &sensvals) {

	std::vector<Population::NNode*>::iterator sensPtr;
	std::vector<float>::const_iterator valPtr;

	for(valPtr = sensvals.begin(), sensPtr = inputs.begin(); sensPtr != inputs.end() && valPtr != sensvals.end(); ++sensPtr, ++valPtr) {

		//only load values into SENSORS (not BIASes)
		if (((*sensPtr)->type)==SENSOR) {

			(*sensPtr)->sensor_load(*valPtr);
			//sensvals++;

		}
	}
}
//#################################################################################################


//#################################################################################################
// Takes and array of output activations and OVERRIDES 
// the outputs' actual activations with these values (for adaptation)
void Population::Network::override_outputs(double* outvals) {

	std::vector<Population::NNode*>::iterator outPtr;

	for(outPtr=outputs.begin();outPtr!=outputs.end();++outPtr) {

		(*outPtr)->override_output(*outvals);
		outvals++;

	}

}
//#################################################################################################


//#################################################################################################
void Population::Network::give_name(char *newname) {

	char *temp;
	char *temp2;
	temp=new char[strlen(newname)+1];
	strcpy(temp,newname);

	if (name==0) name=temp;
	else {

		temp2=name;
		delete temp2;
		name=temp;

	}
}
//#################################################################################################


//#################################################################################################
// The following two methods recurse through a network from outputs
// down in order to count the number of nodes and links in the network.
// This can be useful for debugging genotype->phenotype spawning 
// (to make sure their counts correspond)
//#################################################################################################


//#################################################################################################
int Population::Network::nodecount() {

	int counter=0;
	std::vector<Population::NNode*>::iterator curnode;

	std::vector<Population::NNode*>::iterator location;

	std::vector<Population::NNode*> seenlist;  //List of nodes not to doublecount

	for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {

        location = std::find(seenlist.begin(),seenlist.end(),(*curnode));
		if (location==seenlist.end()) {

			counter++;
			seenlist.push_back(*curnode);
			nodecounthelper((*curnode),counter,seenlist);

		}
	}

	numnodes=counter;

	return counter;

}
//#################################################################################################


//#################################################################################################
void Population::Network::nodecounthelper(Population::NNode *curnode,int &counter,std::vector<Population::NNode*> &seenlist) {

	std::vector<Population::Link*>::iterator curlink;

	std::vector<Population::NNode*>::iterator location;

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;

	if (!((curnode->type)==SENSOR)) {

		//for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {

		// loop over current unique inputs
		for(curuniqueinput = curnode->nodeuniqueinput.begin(); curuniqueinput != curnode->nodeuniqueinput.end(); ++curuniqueinput)
		{
			//loop over all incoming links
			for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
			{

				location= std::find(seenlist.begin(),seenlist.end(),((*curlink)->in_node));

				if (location==seenlist.end()) 
				{

					counter++;
					seenlist.push_back((*curlink)->in_node);
					nodecounthelper((*curlink)->in_node,counter,seenlist);

				}

			}// End loop over all incoming links
		}// End loop over current unique inputs

		//}

	}

}
//#################################################################################################


//#################################################################################################
int Population::Network::linkcount() {

	int counter=0;
	std::vector<Population::NNode*>::iterator curnode;
	std::vector<Population::NNode*> seenlist;  //List of nodes not to doublecount

	for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
		linkcounthelper((*curnode),counter,seenlist);
	}

	numlinks=counter;

	return counter;

}
//#################################################################################################


//#################################################################################################
void Population::Network::linkcounthelper(Population::NNode *curnode,int &counter,std::vector<Population::NNode*> &seenlist) {

	std::vector<Population::Link*>::iterator curlink;

	std::vector<Population::NNode*>::iterator location;

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;

    location = std::find(seenlist.begin(),seenlist.end(),curnode);
	if ((!((curnode->type)==SENSOR))&&(location==seenlist.end())) {

		seenlist.push_back(curnode);

		// loop over current unique inputs
		for(curuniqueinput = curnode->nodeuniqueinput.begin(); curuniqueinput != curnode->nodeuniqueinput.end(); ++curuniqueinput)
		{
			//loop over all incoming links
			for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
			{

				counter++;
				linkcounthelper((*curlink)->in_node,counter,seenlist);

			}// End loop over all incoming links
		}// End loop over current unique inputs
	}

}
//#################################################################################################


//#################################################################################################
// Destroy will find every node in the network and subsequently
// delete them one by one.  Since deleting a node deletes its incoming
// links, all nodes and links associated with a network will be destructed
// Note: Traits are parts of genomes and not networks, so they are not
//       deleted here
void Population::Network::destroy() {

	std::vector<Population::NNode*>::iterator curnode;

	std::vector<Population::NNode*>::iterator location;

	std::vector<Population::NNode*> seenlist;  //List of nodes not to doublecount

	// Erase all nodes from all_nodes list 

	for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode) {

		delete (*curnode);

	}


	// ----------------------------------- 

	//  OLD WAY-the old way collected the nodes together and then deleted them

	//for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
	//cout<<seenstd::vector<<endl;
	//cout<<curnode<<endl;
	//cout<<curnode->node_id<<endl;

	//  location=find(seenlist.begin(),seenlist.end(),(*curnode));
	//  if (location==seenlist.end()) {
	//    seenlist.push_back(*curnode);
	//    destroy_helper((*curnode),seenlist);
	//  }
	//}

	//Now destroy the seenlist, which is all the NNodes in the network
	//for(curnode=seenlist.begin();curnode!=seenlist.end();++curnode) {
	//  delete (*curnode);
	//}
}
//#################################################################################################


//#################################################################################################
void Population::Network::destroy_helper(Population::NNode *curnode,std::vector<Population::NNode*> &seenlist) {

	std::vector<Population::Link*>::iterator curlink;

	std::vector<Population::NNode*>::iterator location;

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;

	if (!((curnode->type)==SENSOR)) {

		// loop over current unique inputs
		for(curuniqueinput = curnode->nodeuniqueinput.begin(); curuniqueinput != curnode->nodeuniqueinput.end(); ++curuniqueinput)
		{
			//loop over all incoming links
			for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
			{

				location = std::find(seenlist.begin(),seenlist.end(),((*curlink)->in_node));

				if (location==seenlist.end()) 
				{

					seenlist.push_back((*curlink)->in_node);
					destroy_helper((*curlink)->in_node,seenlist);

				}

			}// End loop over all incoming links
		}// End loop over current unique inputs

	}

}
//#################################################################################################


//#################################################################################################
// This checks a POTENTIAL link between a potential in_node and potential out_node to see if it must be recurrent 
bool Population::Network::is_recur(Population::NNode *potin_node,Population::NNode *potout_node,int &count,int thresh) {

	std::vector<Population::Link*>::iterator curlink;

	std::vector<Population::NNode::NodeUniqueInput*>::iterator curuniqueinput;

	++count;  //Count the node as visited

	if (count>thresh) {

		//cout<<"returning false"<<endl;
		return false;  //Short out the whole thing- loop detected

	}

	if (potin_node==potout_node) return true;
	else 
	{

		// loop over current unique inputs
		for(curuniqueinput = potin_node->nodeuniqueinput.begin(); curuniqueinput != potin_node->nodeuniqueinput.end(); ++curuniqueinput)
		{
			//loop over all incoming links
			for(curlink = (*curuniqueinput)->incominglink2.begin(); curlink != (*curuniqueinput)->incominglink2.end(); ++curlink)
			{

				//But skip links that are already recurrent
				//(We want to check back through the forward flow of signals only
				if (!((*curlink)->is_recurrent)) 
				{
					if (is_recur((*curlink)->in_node,potout_node,count,thresh)) return true;
				}

			}// End loop over all incoming links
		}// End loop over current unique inputs

		return false;
	}
}
//#################################################################################################


//#################################################################################################
int Population::Network::input_start() {

	input_iter=inputs.begin();
	return 1;

}
//#################################################################################################


//#################################################################################################
int Population::Network::load_in(double d) {

	(*input_iter)->sensor_load(d);
	input_iter++;
	if (input_iter==inputs.end()) return 0;
	else return 1;

}
//#################################################################################################


//#################################################################################################
//Find the maximum number of neurons between an ouput and an input
int Population::Network::max_depth() {

	std::vector<Population::NNode*>::iterator curoutput; //The current output we are looking at
	int cur_depth; //The depth of the current node
	int max=0; //The max depth

	int i_num_tries_loop;

	for(curoutput=outputs.begin();curoutput!=outputs.end();curoutput++) {

		i_num_tries_loop = 0;

		cur_depth=(*curoutput)->Population::NNode::depth(0,this,i_num_tries_loop);

		//cout<<"cur_depth:   "<<cur_depth<<endl;

		//cout<<"pre-cur_depth"<<endl;
		//cout<<"pre-max:   "<<max<<endl;
		if (cur_depth>max) {
			
			max=cur_depth;

		}
		//cout<<"post-cur_depth"<<endl;
		//cout<<"post-max:   "<<max<<endl;

		//cout<<"post max test curoutput:   "<<curoutput<<endl;

	}
	//cout<<"post-curoutput"<<endl;

	return max;

}
//#################################################################################################


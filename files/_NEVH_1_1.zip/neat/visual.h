#include <windows.h>
#include "utils.h"
#include "neat.h"
#include "gene.h"
#include "population.h"
#include "network.h"
#include "organism.h"
#include "math_vectors.h"
#include "math_matrix.h"
//#include "objects.h"

#define Pressed(x) ((GetAsyncKeyState(x) & 0x8000)!=0)

#define MAX_RADIUS_DEFAULT 15.0
#define MAX_RADIUS_INPUT  15.0
#define MAX_RADIUS_HIDDEN 15.0
#define MAX_RADIUS_OUTPUT 15.0

#define ARROW_ANGLE 0.02
#define ARROW_SPIKE_LENGTH 20.0

#define NN_DRAWING_NORMAL    0
#define NN_DRAWING_SUBSTRATE 1
#define NN_DRAWING_CTRNN     2
#define NN_DRAWING_CPPN      3

//#define MAX_WEIGHT 0.25

extern int mouse_x; extern int mouse_y;
extern bool choose_nn;
extern NEAT::Organism* chosen_nn;


int Init_GL_Window(HDC dc, int x, int y);
void Draw_NN_OpenGL(NEAT::Network* net, HDC dc, int flags);

void Draw_Species(NEAT::Population* pop, HDC& dc);

void Draw_NN(NEAT::Network* net, HDC &dc, int FIELD_X, int FIELD_Y, int drawing_type, int flags, int MAX_THICKNESS);




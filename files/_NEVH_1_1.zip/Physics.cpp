#include "headers.h"
#include "physics.h"


//////////////////////
// Physics engine data

//#define MAX_CONTACTS 128

dWorldID physics_world;
dSpaceID physics_space;
dGeomID plane;
dJointGroupID conts;


// this is called by dSpaceCollide when two objects in space are
// potentially colliding.
void nearCollisionCallback(void* data, dGeomID o1, dGeomID o2)
{
	int i=0;

	dBodyID b1=dGeomGetBody(o1);
	dBodyID b2=dGeomGetBody(o2);
	
	if (b1 && b2 && dAreConnectedExcluding(b1,b2,dJointTypeContact))
		return;

	dContact contact[MAX_CONTACTS];
	for(i=0;i<MAX_CONTACTS;i++)
	{
		contact[i].surface.mode = dContactBounce | dContactSoftERP;// | dContactSoftCFM;
		contact[i].surface.mu = dInfinity;
	    //contact[i].surface.slip1 = 0.1; // friction
		//contact[i].surface.slip2 = 0.1;
		contact[i].surface.bounce=-0.1f;
		contact[i].surface.soft_erp = 0.5f;
		contact[i].surface.soft_cfm = 0.01f;//0.3f;
	}

	int numc = dCollide(o1,o2,MAX_CONTACTS,&contact[0].geom,sizeof(dContact));

	if(numc > 0)
	{
		/*
		// do something usefull with the colliding objects
		*/

		for(i=0;i<numc;i++)
		{		
			dJointID c=dJointCreateContact(physics_world, conts, &contact[i]);
			dJointAttach(c,b1,b2);
		}
	}
}



void init_physics()
{
	physics_world = dWorldCreate();
	dWorldSetGravity(physics_world, 0, -9.81/1, 0);
//	dWorldSetGravity(physics_world, 0, 0, 0);
	physics_space = dSimpleSpaceCreate(0);
	plane = dCreateBox(physics_space, 10, 1.0, 10);
	dGeomSetPosition(plane, 0, -0.5, 0);
	conts = dJointGroupCreate(MAX_CONTACTS);

//	dWorldSetERP(physics_world, 1);
//	dWorldSetCFM(physics_world, 0.01);
}


double ElapsedTime()
{
  static double prev=0.0;
  double curr = timeGetTime()/1000.0;
  if (!prev)
    prev=curr;
  double retval = curr-prev;
  prev=curr;
//  if (retval>1.0) retval=1.0;
  if (retval<dEpsilon) retval=dEpsilon;
  return retval;
}
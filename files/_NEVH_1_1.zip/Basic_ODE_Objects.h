#ifndef BASIC_H
#define BASIC_H

#include "headers.h"
#include "ode\ode.h"

class Box
{
public:
	// physics data
	dBodyID body;
	dGeomID geom;
	dMass mass;

	dReal xd, yd, zd;
    
	// 3D engine data
    ISceneNode *node;

	Box(dWorldID world, dSpaceID space, dReal ms, dReal x, dReal y, dReal z);
	dBodyID GetBodyID();

	vector3df GetPosition();

	dReal GetXDimension();
	dReal GetYDimension();
	dReal GetZDimension();

	void UpdateNode();

	~Box();
};



class Sphere
{
public:

	// physics data
	dBodyID body;
	dGeomID geom;
	dMass mass;

	dReal rad;
    
	// 3D engine data
    ISceneNode *node;

	Sphere(dWorldID world, dSpaceID space, dReal ms, dReal radius);

	dBodyID GetBodyID();

	vector3df GetPosition();

	dReal GetRadius();

	void UpdateNode();

	~Sphere();
};


#endif
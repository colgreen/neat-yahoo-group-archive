#ifndef _HEADERS_H
#define _HEADERS_H

#include <windows.h>
#include "irrlicht\irrlicht.h"
#include "ode\ode.h"
#include "neat\utils.h"
#include "neat\neat.h"
#include "neat\gene.h"
#include "neat\population.h"
#include "neat\network.h"
#include "neat\organism.h"
#include "neat\math_vectors.h"
#include "neat\math_matrix.h"
#include "neat\visual.h"

#include "graphics.h"
#include "main.h"
#include "evolution.h"
#include "human.h"
#include "basic_ode_objects.h"

#endif
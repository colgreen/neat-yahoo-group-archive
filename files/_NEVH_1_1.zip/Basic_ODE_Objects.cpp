#include "headers.h"
#include "graphics.h"


///////////////////
// BOX


Box::Box(dWorldID world, dSpaceID space, dReal ms, dReal x, dReal y, dReal z)
{
	vector3df sc;

	// physics
	body = dBodyCreate(world);
	geom = dCreateBox(space, x, y, z);
	dMassSetBoxTotal(&mass, ms, x, y, z);
	dBodySetMass(body, &mass);
	dGeomSetBody(geom, body);

	// 3D
	node = smgr->addCubeSceneNode(1);
	node->setMaterialFlag(EMF_LIGHTING, true);
	node->setMaterialFlag(EMF_NORMALIZE_NORMALS, true);
//	node->setMaterialType(EMT_REFLECTION_2_LAYER);
	node->setMaterialTexture( 0, driver->getTexture("media\\green.jpg") );
	sc.X = x * GRAPHICS_SCALE;
	sc.Y = y * GRAPHICS_SCALE;
	sc.Z = z * GRAPHICS_SCALE;
	node->setScale(sc);

	xd=x; yd=y; zd=z;
}

dBodyID Box::GetBodyID()
{
	return body;
}

vector3df Box::GetPosition()
{
	vector3df tmp;
	const dReal* pos = dBodyGetPosition(body);

	tmp.X = pos[0];
	tmp.Y = pos[1];
	tmp.Z = pos[2];

	return tmp;
}

dReal Box::GetXDimension() { return xd;	}
dReal Box::GetYDimension() { return yd;	}
dReal Box::GetZDimension() { return zd;	}

void Box::UpdateNode()
{
	vector3df pos;
	vector3df rot;

	// get the new position of the ODE geometry
	dReal* ode_pos=(dReal*)dGeomGetPosition(geom);
	// set the position at the scenenode
	pos.set((irr::f32)ode_pos[0]*GRAPHICS_SCALE,(irr::f32)ode_pos[1]*GRAPHICS_SCALE,(irr::f32)ode_pos[2]*GRAPHICS_SCALE);
	node->setPosition(pos);
	// get the rotation quaternion
	dQuaternion result;
	dGeomGetQuaternion(geom, result);
	// convert it to eulerangles
	QuaternionToEuler(result,rot);
	// set the rotation 
	node->setRotation(rot);
}

Box::~Box()
{
	dBodyDestroy(body);
	dGeomDestroy(geom);
//	node->drop();
//	delete node;

	node->remove();
}



//////////////////////////
// SPHERE



Sphere::Sphere(dWorldID world, dSpaceID space, dReal ms, dReal radius)
{
	// physics
	body = dBodyCreate(world);
	geom = dCreateSphere(space, radius); 
	dMassSetSphereTotal(&mass, ms, radius);
	dBodySetMass(body, &mass);
	dGeomSetBody(geom, body);

	// 3D
	node = smgr->addSphereSceneNode(radius*GRAPHICS_SCALE);
	node->setMaterialFlag(EMF_LIGHTING, true);
	node->setMaterialFlag(EMF_NORMALIZE_NORMALS, true);
    node->setMaterialType(EMT_SOLID);
	node->setMaterialTexture( 0, driver->getTexture("media\\green.jpg") );

	rad = radius;
}

dBodyID Sphere::GetBodyID()
{
	return body;
}

vector3df Sphere::GetPosition()
{
	vector3df tmp;
	const dReal* pos = dBodyGetPosition(body);

	tmp.X = pos[0];
	tmp.Y = pos[1];
	tmp.Z = pos[2];

	return tmp;
}

dReal Sphere::GetRadius()
{
	return rad;
}

void Sphere::UpdateNode()
{
	vector3df pos;
	vector3df rot;

	// get the new position of the ODE geometry
	dReal* ode_pos=(dReal*)dGeomGetPosition(geom);
	// set the position at the scenenode
	pos.set((irr::f32)ode_pos[0]*GRAPHICS_SCALE,(irr::f32)ode_pos[1]*GRAPHICS_SCALE,(irr::f32)ode_pos[2]*GRAPHICS_SCALE);
	node->setPosition(pos);
	// get the rotation quaternion
	dQuaternion result;
	dGeomGetQuaternion(geom, result);
	// convert it to eulerangles
	QuaternionToEuler(result,rot);
	// set the rotation 
	node->setRotation(rot);
}


Sphere::~Sphere()
{
	dBodyDestroy(body);
	dGeomDestroy(geom);

//	node->drop();
//	delete node;

	node->remove();
}

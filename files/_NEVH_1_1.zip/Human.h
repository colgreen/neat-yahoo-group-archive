#ifndef HUMAN_H
#define HUMAN_H

#include "headers.h"
#include "basic_ode_objects.h"


class Human
{
public:
	//quaternion to store initial body part orientations
	dQuaternion initialQuaternion;
	dBodyID thisBodyID;

	int hip1_cycles;
	int previous_hip1_state; // 0 - (<0), 1 - (>0)
	int hip2_cycles;
	int previous_hip2_state; // 0 - (<0), 1 - (>0)
	int knee1_cycles;
	int previous_knee1_state; // 0 - (<0), 1 - (>0)
	int knee2_cycles;
	int previous_knee2_state; // 0 - (<0), 1 - (>0)

	dReal total_mass;
	double LEGS_ADJUST;

	double time;

	Sphere* head;
	Box* torso;
	Box* leftUpperArm;
	Box* rightUpperArm;
	Box* leftLowerArm;
	Box* rightLowerArm;
	Box* leftUpperLeg;
	Box* rightUpperLeg;
	Box* leftLowerLeg;
	Box* rightLowerLeg;
	Box* leftFoot;
	Box* rightFoot;

	dJointID leftElbow;
	dJointID rightElbow;
	dJointID leftShoulder;
	dJointID rightShoulder;
	dJointID neck;
	dJointID leftHip;
	dJointID rightHip;
	dJointID leftKnee;
	dJointID rightKnee;
	dJointID leftAnkle;
	dJointID rightAnkle;

	vector3df position;

	NEAT::Network* brain;

	void SetInitialPosition();

	Human(dWorldID world, dSpaceID space, dReal posx, dReal posy, dReal posz, dReal size, NEAT::Network* br);

	//The following functions are to help the evolution system.
	vector3df GetHeadPosition();
	dReal HeadHeightAboveFeet();
	dReal ForwardDistanceOfFeet();
	dReal AverageForwardDistanceOfFeet();
	dReal AverageForwardDistance();
	dReal ZDistanceBetweenFeet();
	dReal CombinedFeetHeight();
	dReal LeftFootHeight();
	dReal RightFootHeight();
	bool LeftFootMovingDownward();
	bool RightFootMovingDownward();

	void UseBrain(double step_size);
	void Update();

	~Human();
};

#endif
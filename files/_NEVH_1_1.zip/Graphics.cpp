#include "headers.h"

using namespace irr;
using namespace core;
using namespace scene;
using namespace video;
using namespace io;
using namespace gui;

//#define HELP_ME
#define HELPER_PLANE_Y 0.8

/////////////////////////
// 3D engine data
IrrlichtDevice *device;
IVideoDriver* driver;
ISceneManager* smgr;
IGUIEnvironment* guienv;

// objects
ISceneNode *ground;
ISceneNode *step_threshold_plane;
ICameraSceneNode* cam;


void QuaternionToEuler(const dQuaternion quaternion, vector3df &euler)
{
  dReal w,x,y,z;
  w=quaternion[0];
  x=quaternion[1];
  y=quaternion[2];
  z=quaternion[3];
  double sqw = w*w;    
  double sqx = x*x;    
  double sqy = y*y;    
  double sqz = z*z; 
  
  euler.Z = (irr::f32) (atan2(2.0 * (x*y + z*w),(sqx - sqy - sqz + sqw))
                        *irr::core::GRAD_PI);
  
  euler.X = (irr::f32) (atan2(2.0 * (y*z + x*w),(-sqx - sqy + sqz + sqw))
                        *irr::core::GRAD_PI);  
  
  euler.Y = (irr::f32) (asin(-2.0 * (x*z - y*w))
                        *irr::core::GRAD_PI);
}


void init_graphics()
{
	vector3df sc;

	device = createDevice( video::EDT_OPENGL, dimension2d<s32>(400, 300), 16, false, false, false, 0);
	device->setWindowCaption(L"NEAT Neuro-Evolving Humanoid");
	device->setResizeAble(true);

	driver = device->getVideoDriver();
	smgr = device->getSceneManager();
	guienv = device->getGUIEnvironment();

	ground = smgr->addCubeSceneNode(1);
	ground->setMaterialFlag(EMF_LIGHTING, false);
//	ground->setMaterialType(EMT_TRANSPARENT_ADD_COLOR);
	ground->setMaterialTexture( 0, driver->getTexture("media\\pitbull.jpg") );
	sc.X = 10*GRAPHICS_SCALE;
	sc.Y = 1*GRAPHICS_SCALE;
	sc.Z = 10*GRAPHICS_SCALE;
	ground->setScale(sc);
	ground->setPosition(vector3df(0, -0.5*GRAPHICS_SCALE, 0));


#ifdef HELP_ME
	step_threshold_plane = smgr->addCubeSceneNode(1);
	step_threshold_plane->setMaterialFlag(EMF_LIGHTING, false);
	step_threshold_plane->setMaterialType(EMT_TRANSPARENT_ADD_COLOR);
	step_threshold_plane->setMaterialTexture( 0, driver->getTexture("media\\kapki.jpg") );
	sc.X = 2*GRAPHICS_SCALE;
	sc.Y = 0.01*GRAPHICS_SCALE;
	sc.Z = 2*GRAPHICS_SCALE;
	step_threshold_plane->setScale(sc);
	step_threshold_plane->setPosition(vector3df(0, HELPER_PLANE_Y*GRAPHICS_SCALE, 0));
#endif

/*	cam = smgr->addCameraSceneNode(0, 
		vector3df(2.5f*GRAPHICS_SCALE,0.75f*GRAPHICS_SCALE,0.55*GRAPHICS_SCALE), 
		vector3df(0, 0.5f*GRAPHICS_SCALE,0.0*GRAPHICS_SCALE)); 
*/	
//	cam = smgr->addCameraSceneNodeFPS(0,100, 500); 

	cam = smgr->addCameraSceneNodeMaya(0, -500, 600, 500, -1);

	sc.X=2.5f*GRAPHICS_SCALE;
	sc.Y=0.75f*GRAPHICS_SCALE;
	sc.Z=0.55*GRAPHICS_SCALE;
	cam->setPosition(sc);



	sc.X = 0;
	sc.Y = 0.5f*GRAPHICS_SCALE;
	sc.Z = 0;
	cam->setTarget(sc);

	scene::ILightSceneNode* light1 = smgr->addLightSceneNode(0, core::vector3df(400,500,500), video::SColorf(1.0f, 1.0f, 1.0f, 1.0f), 20000.0f); 
}
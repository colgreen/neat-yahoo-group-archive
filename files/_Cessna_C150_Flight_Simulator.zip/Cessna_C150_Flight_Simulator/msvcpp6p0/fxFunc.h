long fxSqrt32( long v, int radix);
long fxSin32( long v);
long fxCos32( long v);

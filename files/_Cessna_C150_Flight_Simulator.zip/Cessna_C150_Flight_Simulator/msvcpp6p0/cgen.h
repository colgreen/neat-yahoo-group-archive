/*************************************************************************
 *              (C) Copyright 1989-2002 Visual Solutions                 *
 *                      All Rights Reserved                              *
 * This software may not be used, copied or made available to anyone,    *
 * except in accordance with the license under which it is furnished.    *
 *************************************************************************/

#ifndef CGEN_H
#define CGEN_H
#include <stdio.h>
#include "vsuser.h"

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif
#define MAX_FN 32
#define MAX_DATA_POINT_COUNT 8192
#define UNIT_DELAY(n,b) ((b)&&sim->delay[n].delayLatchTick != sim->tickCount?sim->delay[n].out = sim->delay[n].in:sim->delay[n].out)
#define LATCH_UNIT_DELAY(n,b,v) if (b&&!sim->integState && sim->delay[n].delayLatchTick != sim->tickCount)\
 {  sim->delay[n].in=(v);  sim->delay[n].delayLatchTick = sim->tickCount; }
#define IUNIT_DELAY(n,b) ((b) && sim->idelay[n].delayLatchTick != sim->tickCount?sim->idelay[n].out = sim->idelay[n].in: sim->idelay[n].out)
#define ILATCH_UNIT_DELAY(n,b,v) if ((b)&&!sim->integState && sim->idelay[n].delayLatchTick != sim->tickCount)\
 { sim->idelay[n].in=(v);  sim->idelay[n].delayLatchTick = sim->tickCount; }
#define VUNIT_DELAY(n,b, m) if ((b)&& sim->mdelay[n].delayLatchTick != sim->tickCount && sim->mdelay[n].in) \
 { matCopy(m, sim->mdelay[n].in); sim->mdelay[n].delayLatchTick = sim->tickCount; }
#define VLATCH_UNIT_DELAY(n,b,m) if ((b)&&!sim->integState && sim->mdelay[n].delayLatchTick != sim->tickCount)\
sim->mdelay[n].in = m 

#define SAMPLE_HOLD(n)  sim->SHBuf[n]
#define ISAMPLE_HOLD(n)  (*(int*)&sim->SHBuf[n])
#define LIMIT(n,h,l)  if (sim->n > sim->h) sim->n = sim->h;else if (sim->n < sim->l) sim->n = sim->l
#define M(a,b,c) *matRef(a,b,c)
#define CG_CAST_TO_INT(e) ((int)(e))
#define DIV_SHIFT(n,d,w,s) ((((long)(n))<<s)/(d))
#define MUL_SHIFT16(m1,m2,s) ((int)(((long)m1*m2)>>s))
#define CG_ALLOC(p, n) if (!p&&n) p = calloc(sizeof(*(p)),n) 

#if WIN32
// #include "windows.h"
#define MUL_SHIFT32(a,b,shift) (Int32x32To64(a,b)>>(shift))
#elif _F28XX_
#define MUL_SHIFT32(a,b,shift) _IQXMPY(a,b,shift)
#else
#define MUL_SHIFT32(a,b,shift) _mulShift32(a,b,shift)
#endif

long _mulShift32( long m1, long m2, int shift);
extern int noIntegrationUsed;

typedef int INT;
#ifdef _DSP
#ifndef CGDOUBLE
/* typedef float CGDOUBLE; */
#endif
#define winMsg(x)
#else
/* typedef double CGDOUBLE; */
#endif

#ifndef BITFIELD
#ifndef _MSC_VER         /* ANSI BITFIELD */
/*  typedef unsigned int BITFIELD; */
#else                           /* Microsoft C++ */
/*  typedef unsigned char BITFIELD; */
#endif
#endif

typedef void (*SIM_FUNC)();


typedef struct {
  CGDOUBLE minVal, maxVal, scaleFactor;
} BOUNDS;

typedef struct {
  CGDOUBLE high, low;
} INTEG_LIMIT;

#define MAX_PLOTS (4)
#define WAY_FAR 

typedef struct {
  long maxSize;
  long curSize;
  CGDOUBLE WAY_FAR*dlist;
} DLIST;

#define MAX_NAME_LEN 32
#define MAX_PATH_LEN 128

typedef struct {
  DLIST data;
} DATA_SET;

#define MAX_DATA_SETS (50)
typedef struct {
  unsigned step;  /* Data points to skip */
  unsigned stepCount; /* Current intermediate calc */
  unsigned long dataPointCount;  /* Max data points */
} DATA_STEP;


#if VERSION_10X > 20
#define MATRIX_DECL(n) struct {\
char res;\
  unsigned dim1;\
  unsigned dim2;\
  unsigned dim3;\
  CGDOUBLE d[n];  \
}
#define MATRIX_DECL_I(n) struct {\
char res;\
  unsigned dim1;\
  unsigned dim2;\
  unsigned dim3;\
  int d[n];  \
}
#else 
#define MATRIX_DECL(n) struct {\
char res;\
  unsigned dim1;\
  unsigned dim2;\
  CGDOUBLE d[n];  \
} 
#endif

#ifdef NOW_IN_VSUSER_H
typedef struct
{ 
  unsigned int isTemp:1;
  unsigned dim1;
  unsigned dim2;
  CGDOUBLE d[1];
}  MATRIX;
#endif

typedef struct {
  char *fileName;
  CGDOUBLE intervalStart;
  CGDOUBLE intervalStop;
  CGDOUBLE intervalStep;
  int itemCount;
  int precision;        /* # of digits of numeric precision to save */
  CGDOUBLE lastSampleTime;
  BITFIELD noWriteHeader:1;
  BITFIELD isMatrix:1;
  BITFIELD isBinary:1;
  BITFIELD hasTimeColumn:1;
  BITFIELD wantFlush:1;
  BITFIELD appendToFile:1;
  long flushInterval;
  MATRIX *mat;
  unsigned char timeColumn;
  BITFIELD wantNoInterpolation:1;  /* Should be up with other bitfields, but put here for 4.5 compatibility */
  BITFIELD wantNoExtrapolation:1;
  long nextFlushTime;
  unsigned lastPointWritten;
  unsigned char columnCount;
  long timeLastMod;
  unsigned pointCount;
  unsigned lastIndexX;
  unsigned lastIndexY;
  unsigned lastIndexZ;
  DATA_STEP ds;
  VECTOR interpGridX;
  VECTOR interpGridY;
  VECTOR interpGridZ;
  DATA_SET dataSet[MAX_DATA_SETS];
#ifdef _DSP
  long fh;
#else
  FILE *fh; 
#endif
  } DATA_FILE_INFO;

typedef struct {
  char fileName[MAX_NAME_LEN];
  CGDOUBLE intervalStep;
  BITFIELD noWriteHeader:1;
} EXPORT_INFO;

typedef struct {
  unsigned bufSize;
  unsigned bufMax;
  CGDOUBLE *buf;
  CGDOUBLE lastTime;
  BITFIELD bufBeenRealloced:1,latchInput:1,saveLatch:1;
  CGDOUBLE delayTime;
  CGDOUBLE step;
  unsigned bufPtr, bufLen;
} TIME_DELAY_INFO;

#if 0
typedef struct {
  int len;
  CGDOUBLE *vec;
} VECTOR;
#endif

#define CG_INIT_XFER(n,d,t,dt,g) {d,t,0,dt,g,(MATRIX*)&matPhi##n,(MATRIX*)&matPsi##n\
,(MATRIX*)&matC##n, (MATRIX*)&matD##n, 0, 0,0,-1e30}


typedef struct {
  BITFIELD isDiscrete:1;
  BITFIELD useTappedDelay:1;
  BITFIELD outputPosted:1;
  CGDOUBLE dT;
  CGDOUBLE gain;
  MATRIX *phi, *psi;
  MATRIX *c, *d;
  MATRIX *state;
  CGDOUBLE *u,*y;
  CGDOUBLE lastTime;
  MATRIX *deriv;
  MATRIX *lastState;
  CGDOUBLE lastResult;
  CGDOUBLE lastLatchTime;
  unsigned lastLatchTickCount;
  unsigned lastTickCount;
  unsigned ticksPerRun;
} XFERFUN_INFO;

typedef struct {
  unsigned ticksPerRun;
  unsigned stateCount;
  int *X;
  int *ic;
} XFERFUN_INFO_FX;

typedef enum {
  CGR_OK, CGR_MATH_ERR, CGR_FILE_OPEN_FAILED
} CG_RUNTIME_STATUS;

typedef struct {
  int type;
  char *name;
  int dim1;
  int dim2;
} ARG_DESCR;

typedef struct {
  unsigned long delayLatchTick;
  CGDOUBLE in;
  CGDOUBLE out;
} DELAY_ITEM;

typedef struct {
  unsigned long delayLatchTick;
  int in;
  int out;
} IDELAY_ITEM;

typedef struct {
  unsigned long delayLatchTick;
  MATRIX* in;
  MATRIX* out;
} MDELAY_ITEM;

typedef struct sim_state {
  CGDOUBLE timeStart, timePanel, timeEnd, T;
  CGDOUBLE timeStep;
  VECTOR *delayIC;
  IVECTOR *idelayIC;
  MVECTOR *mdelayIC;
  VECTOR *SHBufIC;
  XFERFUN_INFO *xferFunInfo;
  XFERFUN_INFO_FX *xferFunInfoFx;
  TIME_DELAY_INFO *timeDelayInfo;
  CGDOUBLE *integIC;
  ARG_DESCR *outArgInfo;
  ARG_DESCR *inArgInfo;
  int inArgCount;
  int outArgCount;
  int integCount;
  int xferCount;
  int xferCountFx;
  SIM_FUNC evalDerivFn;
  void (*limitIntegOutput)();
  void (*initSimFunc)(struct sim_state *pSim, long *runCount);
  void (*postSimFunc)(struct sim_state *pSim, long *runCount);
  DATA_FILE_INFO *importBuf;
  char integrationMethod;
#if VERSION_10X > 45
  int subsystemCount;         /* Count of enabled subsystems */
#endif
  BITFIELD isMatrix:1, SimStartUp:1, firstPass:1, reserved:1
    , usingVisSimIntegEngine:1, autoRestart:1, retainStates:1, isDLL:1
    , beenInitialized:1, doCompleteRunPerStep:1
    ;
#if VERSION_10X > 45
  struct sim_state **hSubsystem; /* subsystem handle vector for this instantiation */
#endif
  char integState;
  char stopRequested;
  char lastPass;
  long runCount;
  CGDOUBLE *derivIn;
  CGDOUBLE *integLastState;   /* State value from last step */
  CGDOUBLE *integOut0;        /* Euler/RK2 state vector */
  CGDOUBLE *integOut1;        /* Rk2 secondary state vector */
  CGDOUBLE *integOut2;        /* Rk4 secondary state vector */
  CGDOUBLE *integOut3;        /* Rk4 secondary state vector */
  CGDOUBLE *integOut;         /* Current integrator state vector */
  INTEG_LIMIT *integLimit;    /* Limited Integrator limits */
  DELAY_ITEM *delay;          /* double Unit delay buffer */
  IDELAY_ITEM *idelay;        /* int Unit delay buffer */
  MDELAY_ITEM *mdelay;        /* Matrix Unit delay buffer */
  CGDOUBLE *SHBuf;            /* Sample hold buffer */
  CGDOUBLE *inSig;            /* Input Vector */
  CGDOUBLE *outSig;           /* output Vector */
  SIGNAL **inSigS;             /* Input vec as signals */
  SIGNAL *outSigS;
  char *terminationCondition; /* "C" termination expression */
  struct sim_state *owner;    /* temp file owner, indentifies copied nodes */
  CG_RUNTIME_STATUS status;
  char *lastErrorText;
  unsigned long tickCount;         /* number of ticks since start of task (Low Word) */
  unsigned long tickCountHW;       /* number of ticks since start of task (High Word) */
  CGDOUBLE rolloverTime;      /* accumulated tickCount time due to tickCountHW */
} SIM_STATE;

#define UD_INFO_STR "F[5]I[15]bII"

extern SIM_STATE *sim;
static void limitIntegOutput(void);

#ifndef MAX
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#ifndef max
#define max(a,b) MAX(a,b)
#define min(a,b) MIN(a,b)
#endif
#endif


/* Integration methods */
#define IDG_INTEG_EULER   170
#define IDG_INTEG_TRAP         171
#define IDG_INTEG_RUNGKUT_2    172
#define IDG_INTEG_RUNGKUT_4    173
#define IDG_INTEG_RUNGKUT_AS4   174
#define IDG_INTEG_BULSTOER      175
#define IDG_INTEG_STIFF_EULER   176


#include "cg.h"
#include "xfer.h"
#include "fileio.h"
#include "mat.h"
#include "import.h"
#include "cginit.h"
#ifdef _DSP
#include "rtdsp.h"
#else
#include "cgio.h"
#include "rtdos.h"
#endif
#include "userdll.h"
#include "matdiv.h"
#include "crossdet.h"
#include "fxFunc.h"
#endif

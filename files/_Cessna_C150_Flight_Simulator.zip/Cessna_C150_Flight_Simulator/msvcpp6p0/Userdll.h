/* Put your DLL function prototypes here */

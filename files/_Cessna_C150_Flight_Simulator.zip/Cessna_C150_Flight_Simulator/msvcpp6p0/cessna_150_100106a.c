/*** VisSim Automatic C Code Generator Version 5.0e ***/
/*  Output for E:\Aerospace\cessna_150_100106a.vsm at Sun Oct 01 12:24:31 2006 */


#include "math.h"
#include "cgen.h"

static MATRIX_DECL(10) _mat365={0,2,5,0,{
2600,5.9,
2400,4.3,
2200,3.5,
1000,2,
0,0,
}};
static MATRIX_DECL(10) _mat52={0,2,5,0,{
0,1,
1,0.3,
3,0.2,
20,0,
10000,0,
}};
static MATRIX_DECL(8) _mat82={0,2,4,0,{
0,0,
1000,10,
1500,30,
2600,450,
}};
static MATRIX_DECL(20) _mat440={0,2,10,0,{
-5,3,
-2,1,
0,1,
1,1,
2,1.1,
4,2,
5,2.5,
6,3.5,
10,4,
17,5,
}};
static MATRIX_DECL(14) _mat516={0,2,7,0,{
0,0,
30,0.9,
40,0.91,
42,0.93,
43,0.95,
44,1,
200,1,
}};
static MATRIX_DECL(24) _mat190={0,2,12,0,{
-17,-5,
-16,-10,
-2,-2,
0,0,
2,2,
3,2.6,
4,3.3,
8,4,
12.4,2,
16,4.4,
16.5,4.6,
17,1.5,
}};
static DATA_FILE_INFO importBuf[]={{ "flight_sim.out", 0,3600,0.05,20,15,-1e30,0,1,0,0,0,0,0,0,1,1,1}
,{ "FUELCONS.MAP", 2600,0,0,1,15,-1e30,0,1,0,0,0,0,0,(MATRIX*)&_mat365,1,0,0}
,{ "CGEARWT.MAP", 0,10000,0,1,15,-1e30,0,1,0,0,0,0,0,(MATRIX*)&_mat52,1,0,0}
,{ "Cthrust.map", 0,2600,0,1,15,-1e30,0,1,0,0,0,0,0,(MATRIX*)&_mat82,1,0,0}
,{ "Drag_att.map", -5,17,0,1,15,-1e30,0,1,0,0,0,0,0,(MATRIX*)&_mat440,1,0,0}
,{ "Vel_Stall.map", 0,200,0,1,15,-1e30,0,1,0,0,0,0,0,(MATRIX*)&_mat516,1,0,0}
,{ "Cstall.map", -17,17,0,1,15,-1e30,0,1,0,0,0,0,0,(MATRIX*)&_mat190,1,0,0}
};
extern CGDOUBLE Zed;

static CGDOUBLE Ft_NMile;
static CGDOUBLE Kts_Ft_min;
static CGDOUBLE Deg_rad;
static CGDOUBLE _2_g;
static CGDOUBLE GL;
static CGDOUBLE V_Ft_min;
static CGDOUBLE Vvert_Ft_min;
static CGDOUBLE Angle_of_Attack;
static CGDOUBLE Glide_Path;
static CGDOUBLE AGL;
static CGDOUBLE A_C_Weight;
static CGDOUBLE Thrust;
static CGDOUBLE V_2;
static CGDOUBLE Pitch;
static CGDOUBLE Lift;
static CGDOUBLE AGL_Disp;
static CGDOUBLE Trim;
static CGDOUBLE Flap;
static CGDOUBLE Brakes;
static CGDOUBLE Roll;
static CGDOUBLE Hdg;
static CGDOUBLE Yaw;
static CGDOUBLE Slip;
static CGDOUBLE Ball;
static CGDOUBLE V_Kts;
static CGDOUBLE Heading;
static CGDOUBLE Side_Slip_Kts;
static CGDOUBLE N_S;
static CGDOUBLE E_W;
static CGDOUBLE Alt_Ft;
static CGDOUBLE Runway;
static CGDOUBLE Throttle;
static CGDOUBLE Fuel__;
static CGDOUBLE Fuel_Wt;
static CGDOUBLE Wing_Area;
static CGDOUBLE Rnw_33_Thrhld_N_S;
static CGDOUBLE Rnw_33_Thrhld_E_W;
static CGDOUBLE V_Init_Kts;
static int Init_flag;
static CGDOUBLE Vert_V_Init_ft_sec;
static CGDOUBLE Alt_Init_ft;
static CGDOUBLE Roll_Rate_Init;
static CGDOUBLE Kts_Ft_sec;
static CGDOUBLE Hdg_Init_def;
static CGDOUBLE Side_Slp_V_Init_ft_sec;
static CGDOUBLE N_S_Init_Nm;
static CGDOUBLE E_W_Init_Nm;
static CGDOUBLE Brakes_drag;
static CGDOUBLE Rudder;
static CGDOUBLE Yoke;
static CGDOUBLE Column;
static CGDOUBLE AC_ASI_Knots;
static CGDOUBLE AC_Pitch_Deg;
static CGDOUBLE AC_Vert_Vel_Ft_per_min;
static CGDOUBLE AC_Alt_K_Ft;
static CGDOUBLE AC_Roll_deg;
static CGDOUBLE AC_Heading;
static CGDOUBLE Glide_Path_deg;
static CGDOUBLE ILS_deg;
static CGDOUBLE Stall_Warning;
static CGDOUBLE Dist_from_Threshold;
static CGDOUBLE Net_Thrust;
static CGDOUBLE E_W_Position;
static CGDOUBLE N_S_Position;
static CGDOUBLE AC_Horizonal_Angle_Deg;
static CGDOUBLE Distance_NM;

static void cgMain();
static CGDOUBLE integIC0[]={
22.5,0,650,0,0,0,0,0,0,0,0.19408,-0.33615,0
};
static void limitIntegOutput0()
{
  LIMIT(integOut[0], integLimit[0].high, integLimit[0].low);
  LIMIT(integOut[1], integLimit[1].high, integLimit[1].low);
  LIMIT(integOut[2], integLimit[2].high, integLimit[2].low);
  LIMIT(integOut[3], integLimit[3].high, integLimit[3].low);
  LIMIT(integOut[4], integLimit[4].high, integLimit[4].low);
  LIMIT(integOut[6], integLimit[6].high, integLimit[6].low);
  LIMIT(integOut[7], integLimit[7].high, integLimit[7].low);
  LIMIT(integOut[8], integLimit[8].high, integLimit[8].low);
  LIMIT(integOut[9], integLimit[9].high, integLimit[9].low);
  LIMIT(integOut[10], integLimit[10].high, integLimit[10].low);
  LIMIT(integOut[11], integLimit[11].high, integLimit[11].low);

}

static SIM_STATE tSim={0, 0.05, 3600,0,0.05,0,0,0,0,0,0,0,integIC0
,0,0,0,0,13,0,0, cgMain,limitIntegOutput0,0,0,importBuf,2,0,0};
SIM_STATE *sim=&tSim;

void cgMain()
{
  CGDOUBLE _Throttle_645;
  CGDOUBLE t59;
  CGDOUBLE t54;
  CGDOUBLE _Flap_645;
  CGDOUBLE t104;
  CGDOUBLE t11;
  CGDOUBLE t107;
  CGDOUBLE t537;
  CGDOUBLE t184;
  CGDOUBLE t27;
  CGDOUBLE t30;
  CGDOUBLE t48;
  CGDOUBLE t187;
  CGDOUBLE t180;
  CGDOUBLE _Throttle_78;
  CGDOUBLE _Column_645;
  CGDOUBLE _Column_78;
  CGDOUBLE _Trim_645;
  CGDOUBLE _Brakes_645;
  CGDOUBLE t203;
  CGDOUBLE t507;
  CGDOUBLE _Tau_122;
  CGDOUBLE t193;
  CGDOUBLE t535;
  CGDOUBLE t439;
  CGDOUBLE t536;
  CGDOUBLE _Rudder_645;
  CGDOUBLE _Rudder_78;
  CGDOUBLE _Tau_266;
  CGDOUBLE _Yoke_645;
  CGDOUBLE _Yoke_78;
  CGDOUBLE t289;
  CGDOUBLE t247;
  CGDOUBLE t473;
  CGDOUBLE t234;
  CGDOUBLE t253;
  CGDOUBLE t317;
  CGDOUBLE t251;
  CGDOUBLE t340;
  CGDOUBLE t347;
  CGDOUBLE _Pitch_Deg_78;
  CGDOUBLE _ASI_Knots_78;
  CGDOUBLE _Roll_deg_78;
  CGDOUBLE _Heading_78;
  CGDOUBLE _Vert_Vel_Ft_per_min_78;
  CGDOUBLE _Alt_K_Ft_78;
  CGDOUBLE t395;
  CGDOUBLE t396;
  CGDOUBLE t400;
  /* Inputs */
  _Throttle_645 = 2600.00000000000;
  /* Flight Simulator */
  Throttle =  _Throttle_645 ;
  /* Flight Simulator.guts.A/C Dynamics.Constants */
  _2_g = 64.4000000000000;
  /* Flight Simulator.guts.A/C Dynamics.Altitude */
  t59 = ( sim->integOut[2] +(-650.000000000000));
  AGL =  t59 ;
  /* Flight Simulator.guts.A/C Dynamics.VertVel */
  t54 =  AGL ;
  if ( t54 > 10000) t54 = 10000;
  if ( t54 < 0) t54 = 0;
  /* Flight Simulator.guts.A/C Dynamics.Engine */
  Fuel_Wt = ( sim->integOut[0] *6.);
  /* Flight Simulator.guts.A/C Dynamics.Cessna 150 Data */
  A_C_Weight = (1103.10000000000+185.000000000000+175.000000000000+ Fuel_Wt );
  /* Inputs */
  _Flap_645 = 0.000000000000000;
  /* Flight Simulator */
  Flap =  _Flap_645 ;
  /* Flight Simulator.guts.A/C Dynamics.Roll Rate */
  Roll =  sim->integOut[6] ;
  /* Flight Simulator.guts.A/C Dynamics.Constants */
  Deg_rad = 57.2957795056010;
  /* Flight Simulator.guts.A/C Dynamics.Thrust.Velocity */
  t104 = ( sim->integOut[4] *60.);
  V_Ft_min =  t104 ;
  /* Flight Simulator.guts.A/C Dynamics.Constants */
  Ft_NMile = 6080.00000000000;
  t11 = (( Ft_NMile )/(60.0000000000000));
  Kts_Ft_min =  t11 ;
  /* Flight Simulator.guts.A/C Dynamics.Thrust.Velocity */
  t107 = (( t104 )/( Kts_Ft_min ));
  V_Kts =  t107 ;
  /* Flight Simulator.guts.A/C Dynamics.Lift.Stall */
  t537 =  V_Kts ;
  if ( t537 > 160) t537 = 160;
  if ( t537 < 30) t537 = 30;
  /* Flight Simulator.guts.A/C Dynamics.VertVel.Vert Velocity */
  t184 = ( sim->integOut[1] *60.);
  /* Flight Simulator.guts.A/C Dynamics.VertVel */
  Vvert_Ft_min =  t184 ;
  /* Flight Simulator.guts.A/C Dynamics.Lift.Glied Path */
  t27 =  V_Ft_min ;
  if ( t27 > 20000) t27 = 20000;
  if ( t27 < 10) t27 = 10;
  t30 = (( Vvert_Ft_min )/( t27 ));
  if ( t30 > 1) t30 = 1;
  if ( t30 < -1) t30 = -1;
  Glide_Path = ( asin( t30 )* Deg_rad );
  /* Flight Simulator.guts.A/C Dynamics.Lift.Angle of Attack */
  Angle_of_Attack = ( sim->integOut[3] +3.00000000000000+(- Glide_Path ));
  /* Flight Simulator.guts.A/C Dynamics.Lift */
  Lift = (((( Flap )/(40.0000000000000))+1.00000000000000)*((( cos((( Roll )/( Deg_rad )))*pow( V_Ft_min ,2)* map1d( 5, 1, t537 )*
	 map1d( 6, 1, Angle_of_Attack )))/(50000.0000000000)));
  /* Flight Simulator.guts.A/C Dynamics.VertVel */
  t48 = (( map1d( 2, 1, t54 )* A_C_Weight )+(- A_C_Weight )+ Lift );
  /* Flight Simulator.guts.A/C Dynamics.VertVel.Vert Velocity */
  t187 = ( t184 *0.05);
  t180 = ((( _2_g *( t48 +(- t187 ))))/( A_C_Weight ));
  /* Flight Simulator.guts.INIT.Init Flag */
  Init_flag = ((sim->T)<1.00000000000000);
  /* Flight Simulator.guts.INIT */
  Vert_V_Init_ft_sec = 0.000000000000000;
  Alt_Init_ft = 650.000000000000;
  /* Flight Simulator.guts.A/C Dynamics.Constants */
  GL = 650.000000000000;
  /* Flight Simulator.guts.A/C Dynamics */
  _Throttle_78 =  Throttle ;
  /* Flight Simulator.guts.A/C Dynamics.Thrust */
  Thrust =  map1d( 3, 1, _Throttle_78 );
  /* Flight Simulator.guts.A/C Dynamics.Thrust.Velocity.V^2 */
  V_2 = pow((( t107 )/(90.0000000000000)),2);
  /* Inputs */
  _Column_645 = -2.00000000000000;
  /* Flight Simulator */
  Column =  _Column_645 ;
  /* Flight Simulator.guts.A/C Dynamics */
  _Column_78 =  Column ;
  /* Inputs */
  _Trim_645 = 0.000000000000000;
  /* Flight Simulator */
  Trim =  _Trim_645 ;
  /* Inputs */
  _Brakes_645 = 0.000000000000000;
  /* Flight Simulator */
  Brakes =  _Brakes_645 ;
  /* Flight Simulator.guts.A/C Dynamics.Thrust.Brakes */
  t203 = (( Brakes *3.5)*( quantize( AGL , 1.)==0.000000000000000));
  Brakes_drag =  t203 ;
  /* Flight Simulator.guts.A/C Dynamics.Pitch */
  t507 =  Brakes_drag ;
  if ( t507 > 1) t507 = 1;
  if ( t507 < 0) t507 = 0;
  /* Flight Simulator.guts.A/C Dynamics.Pitch.FO_Lag */
  _Tau_122 = 1.00000000000000;
  /* Flight Simulator.guts.A/C Dynamics.Thrust.Glide Slope */
  t193 =  quantize( AGL , 1.);
  if ( t193 > 1) t193 = 1;
  if ( t193 < 0) t193 = 0;
  /* Flight Simulator.guts.A/C Dynamics.Thrust */
  t535 = ( Thrust +(- t203 )+(-(( sin((( Glide_Path )/( Deg_rad )))* A_C_Weight )* t193 )));
  if ( t535 > 2000) t535 = 2000;
  if ( t535 < -500) t535 = -500;
  /* Flight Simulator.guts.A/C Dynamics.Yaw */
  Yaw =  sim->integOut[5] ;
  /* Flight Simulator.guts.A/C Dynamics.Thrust.Velocity.Angle of Attack */
  t439 =  Angle_of_Attack ;
  if ( t439 > 17) t439 = 17;
  if ( t439 < -3) t439 = -3;
  /* Flight Simulator.guts.A/C Dynamics.Thrust.Velocity */
  t536 = ((( V_2 *240.)*(( Lift )/( A_C_Weight )))*((( Flap )/(40.0000000000000))+1.00000000000000)*(pow((( Yaw )/(5.00000000000000)),2)+1.00000000000000)*
	 map1d( 4, 1, t439 ));
  if ( t536 > 1e+006) t536 = 1e+006;
  if ( t536 < 0) t536 = 0;
  /* Flight Simulator.guts.INIT */
  V_Init_Kts = 0.000000000000000;
  /* Inputs */
  _Rudder_645 = 0.000000000000000;
  /* Flight Simulator */
  Rudder =  _Rudder_645 ;
  /* Flight Simulator.guts.A/C Dynamics */
  _Rudder_78 =  Rudder ;
  /* Flight Simulator.guts.A/C Dynamics.Yaw.FO_Lag */
  _Tau_266 = 0.500000000000000;
  /* Inputs */
  _Yoke_645 = 0.000000000000000;
  /* Flight Simulator */
  Yoke =  _Yoke_645 ;
  /* Flight Simulator.guts.A/C Dynamics */
  _Yoke_78 =  Yoke ;
  /* Flight Simulator.guts.INIT */
  Roll_Rate_Init = 0.000000000000000;
  /* Flight Simulator.guts.A/C Dynamics.Rate of Turn.Yaw Lat Force */
  t289 = ((( sin((( sim->integOut[5] )/( Deg_rad )))*pow( V_Ft_min ,2)))/(50000.0000000000));
  /* Flight Simulator.guts.A/C Dynamics.Rate of Turn.Lat Velocity */
  t247 = ( sim->integOut[7] *60.);
  /* Flight Simulator.guts.A/C Dynamics.Constants */
  Kts_Ft_sec = (( t11 )/(60.0000000000000));
  /* Flight Simulator.guts.A/C Dynamics.Rate of Turn.Lat Velocity.Init */
  t473 = ( Kts_Ft_sec * V_Init_Kts );
  /* Flight Simulator.guts.A/C Dynamics.Rate of Turn.Heading */
  t234 =  V_Ft_min ;
  if ( t234 > 10000) t234 = 10000;
  if ( t234 < 1) t234 = 1;
  t253 = (( t247 )/( t234 ));
  if ( t253 > 1) t253 = 1;
  if ( t253 < -1) t253 = -1;
  /* Flight Simulator.guts.INIT */
  Hdg_Init_def = 330.000000000000;
  /* Flight Simulator.guts.A/C Dynamics.Rate of Turn.Side Slip Velocity */
  t317 = ( sim->integOut[9] *60.);
  /* Flight Simulator.guts.INIT */
  Side_Slp_V_Init_ft_sec = 0.000000000000000;
  /* Flight Simulator.guts.A/C Dynamics.Rate of Turn.Side Slip Velocity */
  Side_Slip_Kts = (( t317 )/( Kts_Ft_min ));
  /* Flight Simulator.guts.A/C Dynamics.Rate of Turn.Heading */
  t251 = ( sim->integOut[8] +(- quantize( sim->integOut[8] , 360.)));
  /* Flight Simulator.guts.A/C Dynamics.Rate of Turn */
  Heading =  t251 ;
  /* Flight Simulator.guts.Position Calc */
  t340 = ((((( simAtan2( Side_Slip_Kts ,  V_Kts ))* Deg_rad )+ Heading ))/( Deg_rad ));
  t347 = (( V_Kts )/(3600.00000000000));
  /* Flight Simulator.guts.INIT */
  E_W_Init_Nm = 0.194080000000000;
  N_S_Init_Nm = -0.336150000000000;
  /* Flight Simulator.guts.A/C Dynamics.Altitude */
  AGL_Disp =  quantize( t59 , 1.);
  /* Flight Simulator.guts.A/C Dynamics */
  _Pitch_Deg_78 =  quantize( sim->integOut[3] , 0.1);
  /* Flight Simulator.guts */
  AC_Pitch_Deg =  _Pitch_Deg_78 ;
  /* Flight Simulator.guts.A/C Dynamics */
  _ASI_Knots_78 =  quantize( t107 , 1.);
  /* Flight Simulator.guts */
  AC_ASI_Knots =  _ASI_Knots_78 ;
  AC_Horizonal_Angle_Deg = ( AC_Pitch_Deg *-1);
  /* Flight Simulator.guts.A/C Dynamics */
  _Roll_deg_78 =  quantize( Roll , 0.1);
  /* Flight Simulator.guts */
  AC_Roll_deg =  _Roll_deg_78 ;
  /* Flight Simulator.guts.A/C Dynamics */
  _Heading_78 =  quantize((( t251 )/(10.0000000000000)), 0.1);
  /* Flight Simulator.guts */
  AC_Heading =  _Heading_78 ;
  /* Flight Simulator.guts.A/C Dynamics.Engine */
  Fuel__ = ((( sim->integOut[0] )/(22.5000000000000))*100.);
  /* Flight Simulator.guts.A/C Dynamics.Rate of Turn */
  Ball = ( t317 *-0.001);
  /* Flight Simulator.guts.A/C Dynamics */
  _Vert_Vel_Ft_per_min_78 =  quantize( t184 , 1.);
  /* Flight Simulator.guts */
  AC_Vert_Vel_Ft_per_min =  _Vert_Vel_Ft_per_min_78 ;
  /* Flight Simulator.guts.A/C Dynamics */
  _Alt_K_Ft_78 =  quantize((( sim->integOut[2] )/(1.00000000000000)), 1.);
  /* Flight Simulator.guts */
  AC_Alt_K_Ft =  _Alt_K_Ft_78 ;
  /* Flight Simulator.guts.Position Calc */
  E_W =  sim->integOut[10] ;
  /* Flight Simulator.guts.ILS Calc.E-W */
  t395 = ((- E_W )+0.194078947000000);
  /* Flight Simulator.guts.Position Calc */
  N_S =  sim->integOut[11] ;
  /* Flight Simulator.guts.ILS Calc.N-S */
  t396 = ((- N_S )+-0.336154598000000);
  /* Flight Simulator.guts.ILS Calc.Hdg to Threshold */
  t400 = ((( simAtan2( t395 ,  t396 ))* Deg_rad )+720.000000000000);
  /* Flight Simulator.guts.ATIS */
  Runway = 330.000000000000;
  /* Flight Simulator.guts */
  ILS_deg = ( t400 +(- quantize( t400 , 360.))+(- Runway ));
  Glide_Path_deg = ((( simAtan2( AGL , ( sqrt((pow( t395 ,2)+pow( t396 ,2)))*6080.)))* Deg_rad )+(-3.00000000000000));
  Stall_Warning =  CG_CAST_TO_INT(((int)((int)( V_Kts <=53.0000000000000)|(int)( Angle_of_Attack >16.0000000000000))&(int)( AGL >1.00000000000000)));
  /* Flight Simulator.guts.ILS Calc.E-W */
  Rnw_33_Thrhld_E_W = 0.194078947000000;
  /* Flight Simulator.guts.ILS Calc.N-S */
  Rnw_33_Thrhld_N_S = -0.336154598000000;
  /* Flight Simulator.guts */
  Dist_from_Threshold = pow((pow(( E_W +(- Rnw_33_Thrhld_E_W )),2)+pow(((- Rnw_33_Thrhld_N_S )+ N_S ),2)),0.5);
  E_W_Position =  E_W ;
  N_S_Position =  N_S ;
  Distance_NM = ( sim->integOut[12] *0.000165000000000000);
 export( 0,  AGL_Disp ,  AC_Pitch_Deg ,  AC_ASI_Knots ,  AC_Horizonal_Angle_Deg ,  AC_Roll_deg ,  AC_Heading ,  Fuel__ ,  Ball , 
	 AC_Vert_Vel_Ft_per_min ,  AC_Alt_K_Ft ,  ILS_deg ,  Glide_Path_deg ,  Stall_Warning ,  Dist_from_Threshold ,  Heading ,  V_Kts , 
	 Yaw ,  E_W_Position ,  N_S_Position ,  Distance_NM );
 display( AGL_Disp );
 display( AC_Pitch_Deg );
 display( AC_ASI_Knots );
 display( AC_Horizonal_Angle_Deg );
 display( Ball );
 display( Fuel__ );
 display( AC_Heading );
 display( AC_Roll_deg );
 display( Glide_Path_deg );
 display( ILS_deg );
 display( AC_Alt_K_Ft );
 display( AC_Vert_Vel_Ft_per_min );
 display( V_Kts );
 display( Heading );
 display( Dist_from_Threshold );
 display( Stall_Warning );
 display( Yaw );
 display( Distance_NM );
 display( E_W_Position );
 display( N_S_Position );

  sim->derivIn[0] = ( map1d( 1, 1, Throttle )*-0.0002778);
  sim->integLimit[0].high = 22.5000000000000;
  sim->integLimit[0].low = 0.000000000000000;
  sim->derivIn[1] =  t180 ;
  sim->integLimit[1].high = ( Init_flag ? Vert_V_Init_ft_sec :15.0000000000000);
  sim->integLimit[1].low = ( Init_flag ? Vert_V_Init_ft_sec :-33.0000000000000);
  sim->derivIn[2] = (( t184 )/(60.0000000000000));
  sim->integLimit[2].high = ( Init_flag ? Alt_Init_ft :10000.0000000000);
  sim->integLimit[2].low = ( Init_flag ? Alt_Init_ft : GL );
  sim->derivIn[3] = ((((( Thrust *0.005)+(( V_2 *(( _Column_78 *-6)+ Trim ))*0.2)+(-( Flap *0.1))+(-( t507 *( Thrust *0.02))))+(-
	 sim->integOut[3] )))/( _Tau_122 ));
  sim->integLimit[3].high = 17.0000000000000;
  sim->integLimit[3].low = -17.0000000000000;
  sim->derivIn[4] = ((( _2_g *( t535 +(- t536 )+(-( V_2 *60.)))))/( A_C_Weight ));
  sim->integLimit[4].high = ( Init_flag ? V_Init_Kts :180.000000000000);
  sim->integLimit[4].low = ( Init_flag ? V_Init_Kts :0.000000000000000);
  sim->derivIn[5] = (((((-( Thrust *0.006))+( _Rudder_78 *0.5)+( V_2 *1.92925))+(- sim->integOut[5] )))/( _Tau_266 ));
  sim->derivIn[6] = (( Yaw *0.05)+ _Yoke_78 +(- sim->integOut[6] ));
  sim->integLimit[6].high = ( Init_flag ? Roll_Rate_Init :60.0000000000000);
  sim->integLimit[6].low = ( Init_flag ? Roll_Rate_Init :-60.0000000000000);
  sim->derivIn[7] = ((( _2_g *((( sin((( Roll )/( Deg_rad )))* Lift )+ t289 )+(-( t247 *1.33)))))/( A_C_Weight ));
  sim->integLimit[7].high = ( Init_flag ? t473 :5000.00000000000);
  sim->integLimit[7].low = ( Init_flag ? t473 :-5000.00000000000);
  sim->derivIn[8] = ( asin( t253 )* Deg_rad );
  sim->integLimit[8].high = ( Init_flag ? Hdg_Init_def :10000.0000000000);
  sim->integLimit[8].low = ( Init_flag ? Hdg_Init_def :-10000.0000000000);
  sim->derivIn[9] = ((( _2_g *( t289 +(-( t317 *0.05)))))/( A_C_Weight ));
  sim->integLimit[9].high = ( Init_flag ? Side_Slp_V_Init_ft_sec :100.000000000000);
  sim->integLimit[9].low = ( Init_flag ? Side_Slp_V_Init_ft_sec :-100.000000000000);
  sim->derivIn[10] = ( sin( t340 )* t347 );
  sim->integLimit[10].high = ( Init_flag ? E_W_Init_Nm :500.000000000000);
  sim->integLimit[10].low = ( Init_flag ? E_W_Init_Nm :-500.000000000000);
  sim->derivIn[11] = ( cos( t340 )* t347 );
  sim->integLimit[11].high = ( Init_flag ? N_S_Init_Nm :100.000000000000);
  sim->integLimit[11].low = ( Init_flag ? N_S_Init_Nm :-100.000000000000);
  sim->derivIn[12] = ( Kts_Ft_sec *pow((pow( V_Kts ,2)+1.00000000000000),0.5));

}

main()
{
 simInit( &tSim );
  simExportInit( 0 );
  simInitMap( 1 );
  simInitMap( 2 );
  simInitMap( 3 );
  simInitMap( 4 );
  simInitMap( 5 );
  simInitMap( 6 );
  startSim();
  simExportClose( 0 );
  return 0;
}

Cessna C-150 Reg: C-FDRV based at Buttonville Ontario - Active Runway 33

INPUTS:

1) Throttle rpm: 1000 idle, 2400 cruise, 2600 full pwr ( 0 to 2600 )

2) Control Column: -ve  = Pull   = Nose Up, +ve = Push = Nose Down ( -100 to +100 )

3) Yoke: -ve  = Left, +ve = Right ( -45 to +45 )

4) Rudder: -ve  = Left, +ve = Right ( -10 to +10 )

5) Flaps degrees: 0 = 0 degrees, 10 = T/O, 20 = Land normal, 40 = Max ( 0 to 40 )

6) Trim: -ve  = Nose Up, +ve = Nose Down ( -20 to 20 )

7) Brakes: 100 = Full On, 0 = Off ( 0 to 100 )


OUTPUTS:

1) AGL Disp: Height Above Ground ft

2) AC_Pitch_Deg: Attitude, -ve  = Nose Down, +ve = Nose Up

3) AC_ASI_Knots: Air Speed in Knots (see table of Cessna C-150 Speeds)

4) AC_Horizonal_Angle_Deg: Horizon attempt to show horizon
	Note: Stall occurs at 17 angle of attack
	Bar Low  (-20)  = horizon below nose = Nose Up Attitude (+5 deg)
	Bar Level (0)    = Level Flight
	Bar High (+20)  = horizon above nose = Nose Down Attitude (-5 deg)

5) AC_Roll_deg: Bank Angle, -ve  = Left degrees, +ve = Right degrees

6) AC_Heading: Heading, Degrees magnetic

7) Fuel %: 26 US Gallons full load, 0 - 100%

8) Ball: Ball, -ve  = Left, +ve = Right

9) AC_Vert_Vel_Ft_per_min: Veritcal Velocity, Ft / min, -ve  = Down, +ve = Pu

10) AC_Alt_K_Ft: Altitude, ft x 1000

11) ILS_deg: ILS = Instument Landing System, The Angle is between the A/C Heading and the Threshold of Runway 33

12) Glide_Path_deg

13) Stall_Warning

14) Dist_from_Threshold

15) Heading

16) V Kts

17) Yaw

18) E_W_Position: (Nautical Miles)

19) N_S_Position: (Nautical Miles)

20) Distance_NM: Cummulative Distance Traveled, Nautical Miles



Derived from VISSIM Example Application. Further VISSIM information and demo version may be obtained at the following weblink: http://www.vissim.com/



Cessna C-150 Speeds

MPH	Knots	Category
			
48	42	Vso - Stall Landing Config 40 Deg Flap
55	48	Vs  -  Stall No Flap
65	56	Vx  - Best Angle - Sea Level
78	68	Vy  - Best  Rate - Sea Level
71	62	Vy  - Best Rate 10,000'
98	85	Vfe - Max with Flaps
112	97	Va  - Maneuver speed 1600#
107	93	Va  - Maneuver speed 1450#
101	88	Va  - Maneuver speed 1300#
123	107	Va  - Max Structural Cruising 
162	141	Vne- Never Exceed
69-80	60-70	      - Normal Take-off Climb
75-86	65-75	      - En-Route Climb
69	60 	      - Short Field Take-off Flaps Up
69-80	60-70	      - Landing Flaps Up
75	65	      - Landing 20 Deg Flaps
58-69	50-60	      - Landing 40 Deg Flaps
60	52	      - Landing Short Field, 40 Deg Flap
69	60	      - Max Glide (2300#)
63	55	      - Precautionary Landing w Pwr, 40 Deg Flap
15	35	      - Max Cross-Wind
60	52	        - Endurance
55	48	        - Slow Flight			


ADDITIONAL INFORMATION:

The simulation was checked against typical flight attitudes and speeds and appeared to be faithful to Bill's experiance. You can reach Bill at: bialkowski@entechcontrol.com

CESSNA 150, C-FRDV, TORONTO AIRWAYS FLIGHT SCHOOL, BUTTONVILLE, ONTARIO
Active Runway = 33

Getting the feel of it .....

First study the instruments and the controls.   Unfortunately in VisSim it is not possible to re-create a life-like cockpit with the familiar knobs and dials that looks anything like the real thing.  We had to use the "Meter" for indicators of all kinds, and the "Slider" for all controls -- not very satisfactory!  It also makes it hard to fly, because you have to keep on using all of those sliders - one at a time.  This is so very different from flying a real plane!  To make things a bit easier, there is a very small compound block next to each control or indicator to explain how each one works, or how to interpret the indication.  Study these before you seriously try to fly.  The real problem is that you cannot "see out the window" -- a real necessity for a VFR pilot!  So you are really going to fly on instruments all the way. 
 To help a bit we have added a few things which the real C-FRDV does not have - such as an ILS system for Rnw 33, as well as a "GPS" "Way Point" distance to the threshold of Runway 33.  The "NAV" box is also useful and looks very much like a GPS plot.

Scenario:  you are a student pilot, and your instructor has just sent you off for your first SOLO flight -- off you go!  You are going to take off from runway 33, fly one circuit (Canadian term for pattern in the US) and land.  Runway 33 is a Left-hand circuit, and is flown at 1000 ft AGL.  After you have mastered this, you can proceed to other lessons - how about some "Upper Air Work (stalls, slow flight, steep turns)".

It is best to run the simulator with the Control Panel or Tool Bar (need to be able to stop the simulator quickly  if things get away on you) because the control inputs are via sliders and in VisSim it was not possible to create realistic flight instruments.  As a result it is very hard to keep up with events and fly the A/C realistically.  However, the flight dynamics are realistic from the point of view of a student pilot.  It is recommended to move control inputs and see what happens.  If in doubt hit STOP.  Then make more moves and hit Cont.  Consult the checklist and fly by the speeds!

How do you know where you are in VisSim?  The NAV compound block is your position - just like GPS.  You should see yourself fly along 33 outbound, 15 downwind and hopefully you have lined up with the runway on final.  This is where the ILS and Glide Path indicators will help. (We are pretending that Runway 33 has ILS). 

THE FIRST SOLO FLIGHT
You have taxied out to Runway 33 and have backtracked to the end.  You are now looking down all 3900 ft of 33.  You have already put on 10 degrees of flap. Put on full power (2600 rpm -- the nose should dip down as you apply full power with brakes on).  Once you have full power, take off the brakes (the nose should lift as the brakes come off). At 50 kts rotate by pulling back on the column (-10). You are now flying - watch the height AGL build.  But watch that speed - FLY THE SPEEDS - climb at 65 Kts.  Adjust your attitude to get it.  You can put the flaps up now.

At about 500 ft AGL it is time to start the Left turn for the crosswind -- look for a heading of 240, but keep climbing.  The cross-wind turn is made at 500 ft AGL (Hdg 240), still keep climbing to 1000 ft (if you look at the NAV box, you should be about 0.7 miles out along a Hdg of 330 at this time.  

At 1000 ft it is OK to turn down wind (Hdg 150) and level off (you have flown about 0.5 miles on the crosswind leg - check the NAV).   Make your turn onto a heading of 150. We want to fly down wind at 75 kts, so throttle back (2200 rpm is good).  Make sure you stay at 1000 ft AGL.  Start doing your down wind checks - look at the Checklist.   

When the threshold of Runway 33 is 45 deg behind you're left shoulder (how do you know this in VisSim you ask? You should be on the down wind and about 1.5 miles S of the runway) you turn Base (Hdg 060), make your turn onto 060, put down 20 degrees of flap and establish 65 kts (reduce power to about 1500 rpm).  Use the NAV to get yourself lined up with the runway.  

You should be about 500 ft AGL at the point you make your turn onto final. Turn onto a heading of 330.   Keep 65 kts all the way into the threshold.

This is where the ILS and Glide Path indicators will help. (We are pretending that Runway 33 has ILS).  When you get on final keep the ILS reading on zero, and the glide slope at - 2 degrees and hopefully you should make the runway -- too bad you can't look out the window!

After you have mastered your solo flying in the circuit, it is time to go onto to some upper air work (stalls, slow flight, steep turns).  Toy can if you wish take off from CYKZ and fly northbound and eventually get to 3000 feet.  Alternatively, you could initialize the simulator at 3000 feet, 80 kts, flying straight and level on a course of 330.  To do that take a look at the INIT block.

Whichever way you choose to get to 3000 feet, you can now try out your skill at stalls, stall recovery, slow flight -- go uo the back-side of the speed-power curve in a nose-up attitude, or try steep turns (remember not more than 50 feet of altitude change).

HAVE FUN!

Bill Bialkowski


Initial Conditions:

The simulator is written with the first SOLO flight in mind, and the initial conditions put 
C-FDRV in position on Runway 33 with engine idling at 1000 rpm, the brakes on and 10 deg of flap.

For other flight profiles, you can start the flight at different starting points
 e.g. at 3000 feet flying straigt and level at 855 Kts

Initialization Flag Timer - set to 1 sec for SOLO flight. 
For flights starting at altitude you can set the time 10 seconds

For the initialization period the integrators are forced to the values you specify.  There may be a bit of a "wobble" as the A/C flies out of this, but this is where your great flying skills come in!



Airport:

APT:  CYKZ
Toronto
Buttonville Municple
Toronto, Ontario

Elev: 650 ft ASL
N  43 deg 51.734'
W 79 deg 22.202'

Runwy 15-33
3900 FT
Surfc Hard
LGHTS Full Time

Runwy 03-21
2693 FT
Surfc Hard
LGHTS Full Time

ATIS             C
Time              13Z
Wind              320 5G15
Visibility         15 M
Ceiling            3500 Brkn
Alt Setting       3016
Runway           33

Airport Layout (see cykz.bmp)

Map (see air5000.bmp)

CYKZ is located near CYYZ, Toronto Pearson International Airport

CYKZ control zone is topped at 2500 ' ASL and is located below the CYYZ Class F airspace floor at 2500' ASL

To the NW the CYKZ Class F floor is at 3500" ASL

Past the town of Ballentrae the airspace is uncontrolled.

Aircraft operating from CYKZ normally exit the control zone at 2400' ASL and return at 2100' ASL

Normal Exit procedure is to leave via an outer reporting point, and to tell the TWR (124.8 Mhz) that you are leaving.


Check List:

PRE TAKE-OFF
Pilots Seat..............Locked
Belts....................Fastened
Doors/Windows...Secure
Instruments............Check
Primer...................Locked
Switches............As Req'd
Carb Ht........Check for Ice
               .......Then Cold
Throttle Friction..........Set
Mixture...............Full Rich
Fuel....................On & Qty
Trim.................Set for T/O
Flaps.......................10 deg
Controls..............Full/Free
Strobes................As Req'd
XPDR/DME..................On
Flight Plan.................Open
Compass Dir.................Set

TAKE OFF
Power..Full Pwr 2500 rpm
Rotate..........................50 K

AFTER TAKE OFF
Climb Out.............65-75 K
Flaps...............................Up
Throttle......................2400

CRUISE
Throttle.......................2400
Mixture..........................Set

IN RANGE OF A/P
Atis,Descend 2100'
At Checkpoint........Report

PRE-LANDING CHECK
Belts.....................Fastened
Primer....................Locked
Speed.....................60-70 K
Switches .............As Req'd
Landing Lt..........As Req'd
Carb Ht........................Hot
Mixture.......................Rich
Fuel ...............................On
Brake Pressure........Check

BASE LEG
Flaps.......................20 deg
Approach.............60-70 K

TOUCH DOWN
Speed.....................50-60 K


Weight & Balance:

WEIGHT & BALANCE
Max Gross Weight.....1600
Std Empty ..................1125
Useful Load F+P+B.....475
Full Fuel (22.5 useble).135
Passengers+Bag...........340
Max Baggage Comp.....40
Empty C of G = 32..5"
Empty Wt Mom=36600

c.of g.=Tot Mom/Tot Wt

c of g env'pe=31.5"-37.5"

FUEL/ OIL
Fuel Capacity (Reg T's)...
22.5 Usable (+3.5 unus'b)
Fuel Grades........................
.....100 Green/100 LL Blue
Oil Capacity........6 Quarts
Min Safe Oil........4 Quarts


Radio Freq's:

BUTTONVILLE FREQ'S
Tower.........................124.8
Approach...................119.9
Ground.......................121.8
ATIS...........................127.1
Toronto Radio...........126.7
TAL Flt Ln/ Disp......123.5



One Norther outer reporting point is Preston Lake (look for V37-126 Airway - next to "216")

Normal Entry procedure is to get latest ATIS info (127.1 Mhz) and request TWR (124.8 Mhz) for permission to enter zone (with ATIS) over outer reporting point.






#include "NEAT_GeneticGeneration.h"

#include "NEAT_GeneticLinkGene.h"
#include "NEAT_Globals.h"

namespace NEAT
{

    GeneticGeneration::GeneticGeneration(TiXmlElement *generationElement)
            :
            userData(NULL)
    {
        generationNumber = atoi(generationElement->Attribute("GenNumber"));

        TiXmlElement *individualElement = generationElement->FirstChildElement();

        do
        {
            individuals.push_back(shared_ptr<GeneticIndividual>(new GeneticIndividual(individualElement)));
            individualElement = individualElement->NextSiblingElement();
        }
        while ( individualElement!=NULL );

    }

    GeneticGeneration::GeneticGeneration(const GeneticGeneration &other)
    {
        //cout << "Invoking copy constructor...";
        generationNumber = other.generationNumber;
        sortedByFitness = other.sortedByFitness;

        if(other.userData)
        {
            userData = other.userData->clone();
        }
        else
        {
            userData = NULL;
        }

        individuals = other.individuals;

        //cout << "done!\n";
    }

    GeneticGeneration& GeneticGeneration::operator=(const GeneticGeneration &other)
    {
        //cout << "Invoking assignment operator...";
        generationNumber = other.generationNumber;
        sortedByFitness = other.sortedByFitness;

        if(other.userData)
        {
            userData = other.userData->clone();
        }
        else
        {
            userData = NULL;
        }

        individuals = other.individuals;

        //cout << "done!\n";
        return *this;
    }

    GeneticGeneration::~GeneticGeneration()
    {
        //cout << "Starting delete\n";
        if (userData)
            delete userData;

        //cout << "Finished with delete!\n";
    }

    void GeneticGeneration::setAttributes(TiXmlElement *generationElement)
    {
        generationElement->SetAttribute("GenNumber",int(generationNumber));

        if (userData)
            generationElement->SetAttribute("UserData",userData->toString());

        double totalFitness=0;

        vector<int> speciesIDs;

        for (size_t a=0;a<individuals.size();a++)
        {
            totalFitness += individuals[a]->getFitness();

            for (size_t b=0;b<=speciesIDs.size();b++)
            {
                if (b==speciesIDs.size())
                {
                    speciesIDs.push_back(individuals[a]->getSpeciesID());
                    break;
                }
                else if (speciesIDs[b]==individuals[a]->getSpeciesID())
                {
                    break;
                }
            }
        }

        generationElement->SetDoubleAttribute("AverageFitness",totalFitness/individuals.size());
        generationElement->SetDoubleAttribute("SpeciesCount",speciesIDs.size());

    }

    void GeneticGeneration::dump(TiXmlElement *generationElement,bool includeGenes)
    {
        setAttributes(generationElement);

        for (size_t a=0;a<individuals.size();a++)
        {
            TiXmlElement *individualElement = new TiXmlElement("Individual");

            individuals[a]->dump(individualElement,includeGenes);

            generationElement->LinkEndChild(individualElement);
        }
    }

    void GeneticGeneration::dumpBest(TiXmlElement *generationElement,bool includeGenes)
    {
        setAttributes(generationElement);

        shared_ptr<GeneticIndividual> bestIndividual=individuals[0];

        for (size_t a=1;a<individuals.size();a++)
        {
            if (individuals[a]->getFitness()>bestIndividual->getFitness())
                bestIndividual = individuals[a];
        }

        TiXmlElement *individualElement = new TiXmlElement("Individual");

        bestIndividual->dump(individualElement,includeGenes);

        generationElement->LinkEndChild(individualElement);
    }

    shared_ptr<GeneticIndividual> GeneticGeneration::mateIndividuals(size_t i1,size_t i2)
    {
        shared_ptr<GeneticIndividual> ind1 = individuals[i1];
        shared_ptr<GeneticIndividual> ind2 = individuals[i2];

        return shared_ptr<GeneticIndividual>(new GeneticIndividual(ind1,ind2));
    }

    double GeneticGeneration::getCompatibility(size_t i1,size_t i2)
    {
        shared_ptr<GeneticIndividual> ind1 = individuals[i1];
        shared_ptr<GeneticIndividual> ind2 = individuals[i2];

        return ind1->getCompatibility(ind2);
    }

    void GeneticGeneration::sortByFitness()
    {
        for (size_t a=0;a<individuals.size();a++)
        {
            for (size_t b=0;b<(individuals.size()-(a+1));b++)
            {
                if (individuals[b]->getFitness()<individuals[b+1]->getFitness())
                {
                    shared_ptr<GeneticIndividual> ind = individuals[b];
                    individuals[b] = individuals[b+1];
                    individuals[b+1] = ind;
                }
            }
        }

        sortedByFitness=true;
    }

    //Gets the generation champion.  Based on unadjusted Fitness
    shared_ptr<GeneticIndividual> GeneticGeneration::getGenerationChampion()
    {
        shared_ptr<GeneticIndividual> bestIndividual;

        for (size_t b=0;b<individuals.size();b++)
        {
            if (!bestIndividual||individuals[b]->getFitness()>bestIndividual->getFitness())
            {
                bestIndividual = individuals[b];
            }
        }

        return bestIndividual;
    }

    void GeneticGeneration::cleanup()
    {
        if (!sortedByFitness)
        {
            throw string("You aren't supposed to acll this until you sort by fitness!");
        }

        while (individuals.size()>1)
        {
            cout << "CLEANING UP!\n";
            //Never delete the generation champion (remember that they are sorted by fitness at this point).

            individuals.erase(individuals.begin()+1);
        }
    }

}

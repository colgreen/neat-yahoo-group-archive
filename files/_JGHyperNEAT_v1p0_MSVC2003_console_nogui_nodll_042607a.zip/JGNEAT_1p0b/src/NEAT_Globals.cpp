#include "NEAT_Globals.h"

#include "NEAT_GeneticNodeGene.h"
#include "NEAT_GeneticLinkGene.h"

#define DEBUG_NEAT_GLOBALS (0)

const char* activationFunctionNames[ACTIVATION_FUNCTION_END] =
    {
        "SIGMOID",
        "SIN",
        "COS",
        "GAUSSIAN",
        "SQUARE",
        "ABS_ROOT",
        "LINEAR",
        "ONES_COMPLIMENT"
    };

namespace NEAT
{
    double signedSigmoidTable[6001];
    double unsignedSigmoidTable[6001];

    Globals *Globals::singleton = NULL;
    void Globals::assignNodeID(GeneticNodeGene *testNode)
    {
        if (testNode->getType()=="NetworkSensor")
        {
            for (size_t a=0;a<sensorNodeGenes.size();a++)
            {
                if (sensorNodeGenes[a]->getName()==testNode->getName())
                {
                    testNode->setID( sensorNodeGenes[a]->getID() );
                    return;
                }
            }
            testNode->setID(generateNodeID());
            sensorNodeGenes.push_back(new GeneticNodeGene(*testNode));
        }
        else if (testNode->getType()=="NetworkOutputNode")
        {
            for (size_t a=0;a<outputNodeGenes.size();a++)
            {
                if (outputNodeGenes[a]->getName()==testNode->getName())
                {
                    testNode->setID( outputNodeGenes[a]->getID() );
                    return;
                }
            }
            testNode->setID(generateNodeID());
            outputNodeGenes.push_back(new GeneticNodeGene(*testNode));
        }
        else
        {
            testNode->setID(generateNodeID());
        }
    }

    void Globals::assignLinkID(GeneticLinkGene *testLink,bool ignoreHistory)
    {
        if (ignoreHistory)
        {
            testLink->setID(generateLinkID());
        }
        for (size_t a=0;a<linkGenesThisGeneration.size();a++)
        {
            GeneticLinkGene *link = linkGenesThisGeneration[a];
            if (link->getFromNodeID()==testLink->getFromNodeID()&&link->getToNodeID()==testLink->getToNodeID())
            {
                testLink->setID( link->getID() );
                return;
            }
        }
        testLink->setID(generateLinkID());
        linkGenesThisGeneration.push_back(new GeneticLinkGene(*testLink));
    }

    void Globals::clearLinkHistory()
    {
        linkGenesThisGeneration.clear();
    }

    int Globals::generateSpeciesID()
    {
        return speciesCounter++;
    }

    int Globals::generateNodeID()
    {
        return nodeCounter++;
    }

    int Globals::generateLinkID()
    {
        return linkCounter++;
    }

    void Globals::addParameter(string name,double value)
    {
        parameters[name] = value;
    }

    void Globals::setParameterValue(string name,double value)
    {
        parameters[name] = value;
    }

    Globals::Globals(string fileName)
            :
            nodeCounter(0),
            linkCounter(0),
            speciesCounter(0)
    {
        cout << "Populating sigmoid table...";
        for (int a=0;a<6001;a++)
        {
            signedSigmoidTable[a] = ((1 / (1+exp(-((a-3000)/1000.0)))) - 0.5)*2.0;
            unsignedSigmoidTable[a] = 1 / (1+exp(-((a-3000)/1000.0)));
        }
        cout << "done!\n";

        cout << "Loading Parameter data from " << fileName << endl;

        if (fileName==string(""))
        {
            return;
        }

        ifstream infile;
        infile.open(fileName.c_str());
        string line="test";
        istringstream instream;
        while (getline(infile,line))
        {
#if DEBUG_NEAT_GLOBALS
            cout << "LINE: " << line << endl;
#endif
#ifdef linux
            if (int(line[line.size()-1])==13) //DOS line breaks
                line.erase(line.begin()+(int(line.size())-1));
#endif
            if (line[0]==';') //comment
            {
                cout << line << endl;
                continue;
            }
            if (line.size()==0)
            {
                continue;
            }
            istringstream input(line);
            string parameterName;
            double value;
            input >> parameterName >> value;
            parameters[parameterName] = value;
        }

    }

    Globals::~Globals()
    {}
}

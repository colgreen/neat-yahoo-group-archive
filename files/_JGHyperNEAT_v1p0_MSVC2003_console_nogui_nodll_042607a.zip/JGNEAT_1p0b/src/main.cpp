
#include <iostream>

using namespace std;

#include "NEAT_Globals.h"

#include "HCUBE_ExperimentRun.h"

#include "Experiments/HCUBE_Experiment.h"
#include "Experiments/HCUBE_FindClusterExperiment.h"


int main(int argc,char **argv)
{
//			NEAT::Globals::init(string(argv[1]));
			NEAT::Globals::init("param.inp");

            int experimentType = int(NEAT::Globals::getSingleton()->getParameterValue("ExperimentType")+0.001);

            cout << "Loading Experiment: " << experimentType << endl;

            HCUBE::ExperimentRun experimentRun;

//			experimentRun.setupExperiment(experimentType,string(argv[2]));
			experimentRun.setupExperiment(experimentType,"output.dat");

            cout << "Experiment set up\n";

            experimentRun.createPopulation();

            experimentRun.setCleanup(true);

            cout << "Population Created\n";

            experimentRun.start();

			return 0;
}
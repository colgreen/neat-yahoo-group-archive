#include "NEAT_GeneticLinkGene.h"

#include "NEAT_NetworkLink.h"
#include "NEAT_Random.h"
#include "NEAT_Globals.h"

#include "NEAT_GeneticNodeGene.h"

namespace NEAT
{

    GeneticLinkGene::GeneticLinkGene(int _fromNodeID,int _toNodeID,double _weight)
            :
            GeneticGene(),
            fromNodeID(_fromNodeID),
            toNodeID(_toNodeID),
            weight(_weight)
    {
        //legacyID = -1;

        //This means a link was created with the same input and output in the same generation, so it's the same ID.
        Globals::getSingleton()->assignLinkID(this);

        //DON'T WRITE CODE PAST THE ID ASSIGNMENT BECAUSE OF COPY ISSUES
    }

    GeneticLinkGene::GeneticLinkGene(int _fromNodeID,int _toNodeID)
            :
            GeneticGene(),
            fromNodeID(_fromNodeID),
            toNodeID(_toNodeID)
    {
        weight = Random::getInstance()->getRandomDouble(-3,3);
        //legacyID = -1;

        //This means a link was created with the same input and output in the same generation, so it's the same ID.
        Globals::getSingleton()->assignLinkID(this);

        //DON'T WRITE CODE PAST THE ID ASSIGNMENT BECAUSE OF COPY ISSUES
    }

    GeneticLinkGene::GeneticLinkGene(TiXmlElement *linkElementPtr)
            :
            GeneticGene(linkElementPtr)
    {
        fromNodeID = atoi(linkElementPtr->Attribute("fromNode"));
        toNodeID = atoi(linkElementPtr->Attribute("toNode"));
        weight = atof(linkElementPtr->Attribute("weight"));
    }

    GeneticLinkGene::~GeneticLinkGene()
    {
    }


    bool GeneticLinkGene::operator==(const GeneticLinkGene &other) const
    {
        return
        (
            GeneticGene::operator==(other) &&
            fromNodeID == other.fromNodeID &&
            toNodeID == other.toNodeID &&
            weight == other.weight
        );
    }

    void GeneticLinkGene::mutate()
    {
        int mod=1;
        //mod = max(20-age,2)/2;
        double mutationPower = mod*Globals::getSingleton()->getParameterValue("MutationPower");
        weight += mutationPower*(2.0*(Random::getInstance()->getRandomDouble()-0.5));

        if(weight>5)
            weight=5;
        else if(weight<-5)
            weight=-5;

    }

    void GeneticLinkGene::dump(TiXmlElement *XMLnode)
    {
        GeneticGene::dump(XMLnode);
        XMLnode->SetAttribute("fromNode",fromNodeID);
        XMLnode->SetAttribute("toNode",toNodeID);
        XMLnode->SetDoubleAttribute("weight",weight);
    }
}

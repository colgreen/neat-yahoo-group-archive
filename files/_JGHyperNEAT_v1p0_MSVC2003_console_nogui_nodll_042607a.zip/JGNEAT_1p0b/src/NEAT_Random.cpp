#include "NEAT_Random.h"

namespace NEAT
{

    Random *Random::singleton = NULL;

}

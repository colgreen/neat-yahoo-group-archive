#include "NEAT_GeneticGene.h"

namespace NEAT
{

    GeneticGene::GeneticGene()
            :
            enabled(true),
            age(0)
    {}

    GeneticGene::GeneticGene(TiXmlElement *elementPtr)
    {
        elementPtr->Attribute("ID",&ID);
        enabled = (atoi(elementPtr->Attribute("Enabled"))==1);
    }

    GeneticGene::~GeneticGene()
    {
    }

    bool GeneticGene::operator==(const GeneticGene &other) const
    {
        return
        (
            ID==other.ID &&
            enabled==other.enabled
        );
    }

    void GeneticGene::dump(TiXmlElement *XMLnode)
    {
        XMLnode->SetAttribute("ID",ID);
        XMLnode->SetAttribute("Enabled",enabled);
    }
}

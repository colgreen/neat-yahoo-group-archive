#include "NEAT_GeneticNodeGene.h"

#include "NEAT_Globals.h"

namespace NEAT
{

    GeneticNodeGene::GeneticNodeGene(
        const string &_name,
        const string &_type,
        double _drawingPosition,
        bool randomizeActivation,
        ActivationFunction _activationFunction
    )
            :
            name(_name),
            type(_type),
            drawingPosition(_drawingPosition),
            activationFunction(_activationFunction)
    {
        if (randomizeActivation)
        {
            if (Globals::getSingleton()->getParameterValue("OnlyGaussianHiddenNodes")>0.5)
            {
                do
                {
                    activationFunction = (ActivationFunction)Random::getInstance()->getRandomInt(ACTIVATION_FUNCTION_END);
                }
                while (
                    activationFunction==ACTIVATION_FUNCTION_ABS_ROOT||
                    activationFunction==ACTIVATION_FUNCTION_SQUARE||
                    activationFunction==ACTIVATION_FUNCTION_COS||
                    activationFunction==ACTIVATION_FUNCTION_SIGMOID||
                    activationFunction==ACTIVATION_FUNCTION_SIN||
                    activationFunction==ACTIVATION_FUNCTION_LINEAR||
                    activationFunction==ACTIVATION_FUNCTION_ONES_COMPLIMENT||
                    false);
            }
            else
            {
                do
                {
                    activationFunction = (ActivationFunction)Random::getInstance()->getRandomInt(ACTIVATION_FUNCTION_END);
                }
                while (
                    activationFunction==ACTIVATION_FUNCTION_ABS_ROOT||
                    activationFunction==ACTIVATION_FUNCTION_SQUARE||
                    activationFunction==ACTIVATION_FUNCTION_COS||
                    //activationFunction==ACTIVATION_FUNCTION_SIGMOID||
                    //activationFunction==ACTIVATION_FUNCTION_SIN||
                    //activationFunction==ACTIVATION_FUNCTION_LINEAR||
                    activationFunction==ACTIVATION_FUNCTION_ONES_COMPLIMENT||
                    false);
            }
        }

        Globals::getSingleton()->assignNodeID(this);
        //DON'T WRITE CODE PAST THE ID ASSIGNMENT BECAUSE OF COPY ISSUES
    }

    GeneticNodeGene::GeneticNodeGene(TiXmlElement *nodeElementPtr)
            :
            GeneticGene(nodeElementPtr),
            activationFunction(ACTIVATION_FUNCTION_SIGMOID)
    {
        name = nodeElementPtr->Attribute("Name");
        type = nodeElementPtr->Attribute("Type");

        nodeElementPtr->Attribute("DrawingPosition",&drawingPosition);

        int actVal = (int)activationFunction;

        nodeElementPtr->Attribute("ActivationFunction",&actVal);

        activationFunction = (ActivationFunction)actVal;
    }

    GeneticNodeGene::~GeneticNodeGene()
    {}

    bool GeneticNodeGene::operator==(const GeneticNodeGene &other) const
    {
        return
        (
        GeneticGene::operator==(other) &&
        activationFunction==other.activationFunction

        );
    }

    void GeneticNodeGene::dump(TiXmlElement *XMLnode)
    {
        GeneticGene::dump(XMLnode);
        XMLnode->SetAttribute("Name",name);
        XMLnode->SetAttribute("Type",type);
        XMLnode->SetDoubleAttribute("DrawingPosition",drawingPosition);
        XMLnode->SetAttribute("ActivationFunction",(int)activationFunction);
    }

    void GeneticNodeGene::mutate()
    {
        throw string("Don\'t try to mutate node genes!");
        //activationFunction = Random::getInstance()->getRandomInt(ACTIVATION_FUNCTION_END);
    }

}

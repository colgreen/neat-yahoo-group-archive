#ifndef __GLOBALS_H__
#define __GLOBALS_H__

#include "NEAT_Defines.h"
#include "NEAT_STL.h"
#include "NEAT_Random.h"
#include "tinyxmldll.h"

/* #defines */
#define LAST_GENERATION		(-1)

enum ActivationFunction
{
    ACTIVATION_FUNCTION_SIGMOID = 0,
    ACTIVATION_FUNCTION_SIN,
    ACTIVATION_FUNCTION_COS,
    ACTIVATION_FUNCTION_GAUSSIAN,
    ACTIVATION_FUNCTION_SQUARE,
    ACTIVATION_FUNCTION_ABS_ROOT,
    ACTIVATION_FUNCTION_LINEAR,
    ACTIVATION_FUNCTION_ONES_COMPLIMENT,
    ACTIVATION_FUNCTION_END
};

extern const char *activationFunctionNames[ACTIVATION_FUNCTION_END];

namespace NEAT
{
    typedef unsigned int uint;

    class GeneticLinkGene;
    class GeneticNodeGene;

    class Globals
    {
    protected:
        //NEAT_DLL_EXPORT static Globals *singleton;
        static Globals *singleton;

        int nodeCounter,linkCounter,speciesCounter;

        vector<GeneticLinkGene *> linkGenesThisGeneration;

        vector<GeneticNodeGene *> sensorNodeGenes;

        vector<GeneticNodeGene *> outputNodeGenes;

        map<string,double> parameters;
    public:
        static inline Globals *getSingleton()
        {
            if (!singleton)
                throw string("You didn't initialize Globals before using it!");

            return singleton;
        }

        static inline Globals *init(string filename="")
        {
            if (singleton)
                delete singleton;

            singleton = new Globals(filename);

            if (filename!=string(""))
            {
                double randomSeed = Globals::getSingleton()->getParameterValue("RandomSeed");
                if (randomSeed<0.0)
                    Random::init(); //use time as the seed
                else
                    Random::init(uint(randomSeed));
            }

            return singleton;
        }

        static inline void deinit()
        {
            delete singleton;
        }

        //NEAT_DLL_EXPORT void assignNodeID(GeneticNodeGene *testNode);
        void assignNodeID(GeneticNodeGene *testNode);

        //NEAT_DLL_EXPORT void assignLinkID(GeneticLinkGene *testLink,bool ignoreHistory=false);
        void assignLinkID(GeneticLinkGene *testLink,bool ignoreHistory=false);

        //NEAT_DLL_EXPORT void clearLinkHistory();
        void clearLinkHistory();

        //NEAT_DLL_EXPORT int generateSpeciesID();
        int generateSpeciesID();

        //NEAT_DLL_EXPORT void addParameter(string name,double value);
        void addParameter(string name,double value);

        inline double getParameterValue(string name)
        {
            if (parameters.count(name)==0)
            {
                cout << "\nParameter Lookup Failure: " << name << '\t' << parameters[name] << '\t' << int(parameters.count(name)) << endl;
                system("PAUSE");
                throw string("Parameter not found!");
            }

            return parameters[name];
        }

        //NEAT_DLL_EXPORT void setParameterValue(string name,double value);
        void setParameterValue(string name,double value);

        inline map<string,double>::iterator getMapBegin()
        {
            return parameters.begin();
        }

        inline map<string,double>::iterator getMapEnd()
        {
            return parameters.end();
        }

    protected:
        //NEAT_DLL_EXPORT Globals(string fileName);
        Globals(string fileName);

        //NEAT_DLL_EXPORT virtual ~Globals();
        virtual ~Globals();

        //NEAT_DLL_EXPORT int generateNodeID();
        int generateNodeID();

        //NEAT_DLL_EXPORT int generateLinkID();
        int generateLinkID();
    };

}

#endif

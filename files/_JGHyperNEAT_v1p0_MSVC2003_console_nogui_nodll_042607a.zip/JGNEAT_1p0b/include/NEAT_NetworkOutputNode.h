#ifndef __NETWORKOUTPUTNODE_H__
#define __NETWORKOUTPUTNODE_H__

#include "NetworkNode.h"

namespace NEAT
{
    static const string network_output_node("NetworkOutputNode");

	class NetworkOutputNode : public NetworkNode
	{
	public:
		NetworkOutputNode(const string &_name,ActivationFunction _activationFunction)
		:
		NetworkNode(_name,_activationFunction)
		{
		}

		virtual inline const string &getType()
		{
			return network_output_node;
		}
	};

}

#endif

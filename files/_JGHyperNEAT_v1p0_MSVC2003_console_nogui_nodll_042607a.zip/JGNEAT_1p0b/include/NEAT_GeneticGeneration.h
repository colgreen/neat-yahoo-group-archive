#ifndef __GENETICGENERATION_H__
#define __GENETICGENERATION_H__

#include "NEAT_GeneticIndividual.h"

#include "NEAT_Defines.h"

namespace NEAT
{

    /**
     * The GeneticGeneration class is responsible for containing and managing a single generation of indiviudals
     */
    class GeneticGeneration
    {
        vector<shared_ptr<GeneticIndividual> > individuals;

        size_t generationNumber;

        bool sortedByFitness;

        Stringable *userData;
    public:

        /**
         * Constructor: Creates a generation
         * \param _individuals Is a list of individuals for this generation
         * \param _generationNumber Is the number of this generation
         */
        GeneticGeneration(vector<shared_ptr<GeneticIndividual> > _individuals,size_t _generationNumber)
                :
                individuals(_individuals),
                generationNumber(_generationNumber),
                sortedByFitness(false),
                userData(NULL)
        {}

        /**
         * Constructor: Creates an empty generation
         * \param _generationNumber Is the number of this generation
         */
        GeneticGeneration(int _generationNumber)
                :
                generationNumber(_generationNumber),
                userData(NULL)
        {}

        //NEAT_DLL_EXPORT GeneticGeneration(const GeneticGeneration &other);
        GeneticGeneration(const GeneticGeneration &other);

        //NEAT_DLL_EXPORT GeneticGeneration &operator=(const GeneticGeneration &other);
        GeneticGeneration &operator=(const GeneticGeneration &other);

        //NEAT_DLL_EXPORT virtual ~GeneticGeneration();
        virtual ~GeneticGeneration();

        /**
         * Constructor: Creates a generation from it's serialized XML format
         * \param generationElement Is the root of the XML format
         */
        //NEAT_DLL_EXPORT GeneticGeneration(TiXmlElement *generationElement);
        GeneticGeneration(TiXmlElement *generationElement);

        inline void addIndividual(shared_ptr<GeneticIndividual> i)
        {
            individuals.push_back(i);
        }

        inline size_t getIndividualCount()
        {
            return individuals.size();
        }

        inline shared_ptr<GeneticIndividual> getIndividual(size_t a)
        {
            if(a>=individuals.size())
            {
                cout << string("GENETICGENERATION::GETINDIVIDUAL: Individual index out of range!\n");
                throw string("GENETICGENERATION::GETINDIVIDUAL: Individual index out of range!\n");
            }

            return individuals[a];
        }

        inline vector<shared_ptr<GeneticIndividual> >::iterator getIndividualIterator(size_t a)
        {
            return (individuals.begin()+a);
        }

        inline void setUserData(Stringable *_userData)
        {
            userData = _userData;
        }

        inline Stringable* getUserData()
        {
            return userData;
        }

        //NEAT_DLL_EXPORT void dump(TiXmlElement *generationElement,bool includeGenes=true);
        void dump(TiXmlElement *generationElement,bool includeGenes=true);

        //NEAT_DLL_EXPORT void dumpBest(TiXmlElement *generationElement,bool includeGenes=true);
        void dumpBest(TiXmlElement *generationElement,bool includeGenes=true);

        /**
         * mateIndividuals: mates two individuals
         */
        //NEAT_DLL_EXPORT shared_ptr<GeneticIndividual> mateIndividuals(size_t i1,size_t i2);
        shared_ptr<GeneticIndividual> mateIndividuals(size_t i1,size_t i2);

        /**
         * getCompatibility: Returns the compatiblity between two individuals
         */
        //NEAT_DLL_EXPORT double getCompatibility(size_t i1,size_t i2);
        double getCompatibility(size_t i1,size_t i2);

        //NEAT_DLL_EXPORT void sortByFitness();
        void sortByFitness();

        //NEAT_DLL_EXPORT shared_ptr<GeneticIndividual> getGenerationChampion();
        shared_ptr<GeneticIndividual> getGenerationChampion();

        /**
         * cleanup: Removes all individuals from this generation except the generation champion
         */
        //NEAT_DLL_EXPORT void cleanup();
        void cleanup();

    protected:
        void setAttributes(TiXmlElement *generationElement);
    };

}

#endif

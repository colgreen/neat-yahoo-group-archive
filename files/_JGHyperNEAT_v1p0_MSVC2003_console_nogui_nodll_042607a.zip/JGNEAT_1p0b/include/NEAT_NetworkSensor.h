#ifndef __NETWORKSENSOR_H__
#define __NETWORKSENSOR_H__

#include "STL.h"
#include "NetworkNode.h"

namespace NEAT
{
    static const string network_sensor_type("NetworkSensor");

	class NetworkSensor : public NetworkNode
	{
	protected:
	public:
		NetworkSensor(const string &_name,ActivationFunction _activationFunction)
			:	NetworkNode(_name,_activationFunction)
		{
		}

		virtual inline const string &getType()
		{
			return network_sensor_type;
		}

		/* There's no need to update the value when it's a sensor */
		virtual void updateValue()
		{
		}

		/* There's no need to compute a new value when it's a sensor */
		virtual void computeNewValue()
		{
		}

	};

}

#endif

#ifndef __RANDOM_H__
#define __RANDOM_H__

#include "NEAT_Defines.h"
#include "NEAT_STL.h"

namespace NEAT
{

    class Random
    {
    protected:
        unsigned int seed;

        //NEAT_DLL_EXPORT static Random *singleton;
       static Random *singleton;
    public:
        static inline Random *getInstance()
        {
            if(!singleton)
                cout << "Singleton class not defined!" << endl;

            return singleton;
        }

        static void init(unsigned int seed)
        {
            if(singleton)
                delete singleton;

            singleton = new Random(seed);
        }

        static void init()
        {
            singleton = new Random();
        }

        static void deinit()
        {
            delete singleton;
        }

        ///Gets a random int 0 <= x < limit;
        inline int getRandomInt(int limit)
        {
            int lowest=0, highest=limit;
            int range=(highest-lowest);
            return lowest+int(range*(rand()/1000)/((RAND_MAX/1000) + 1.0));
        }
        ///Gets a random int min <= x <= max;
        inline int getRandomWithinRange(int min,int max)
        {
            if(min==max)
                return min;
            int lowest=min, highest=max;
            int range=(highest-lowest)+1;
            int value = lowest+int(range*(rand()/1000)/((RAND_MAX/1000) + 1.0));
            return value;
        }
        ///Gets a random int min <= x <= max;
        /*int getRandomWithinRange(const Range r)
        {
        return getRandomWithinRange(r.low,r.high);
        }*/
        ///Gets a random floating point number low <= x <= high
        inline double getRandomDouble()
        {
            return double(rand())/RAND_MAX;
        }
        inline double getRandomDouble(int low,int high)
        {
            return (double(rand())/RAND_MAX*(high-low))+low;
        }
        inline double getRandomDouble(double low,double high)
        {
            return (double(rand())/RAND_MAX*(high-low))+low;
        }
        inline unsigned int getSeed()
        {
            return seed;
        }
    protected:
        Random(unsigned int _seed =
            (static_cast<unsigned int>(std::clock()%1000000))
            + (static_cast<unsigned int>(time(NULL)%1000000)))
                :
                seed(_seed)
        {
            srand(seed);
        }

        virtual ~Random()
        {}
    };

}

#endif

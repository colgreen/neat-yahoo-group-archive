#ifndef __GENETICPOPULATION_H__
#define __GENETICPOPULATION_H__

#include "tinyxmldll.h"
#include "NEAT_STL.h"

#include "NEAT_Globals.h"
#include "NEAT_GeneticGeneration.h"
#include "NEAT_GeneticSpecies.h"

namespace NEAT
{

	class GeneticIndividual;

    /**
     * The Genetic Population class is responsible for holding and managing a population of individuals
     * over multiple generations.
     */
	class GeneticPopulation
	{
		vector<GeneticGeneration> generations;

		vector<GeneticSpecies *> species;

		//we use a separate vector for extinct species to save CPU.
		vector<GeneticSpecies *> extinctSpecies;

		size_t onGeneration;
	public:
		//NEAT_DLL_EXPORT GeneticPopulation();
		GeneticPopulation();

		//NEAT_DLL_EXPORT GeneticPopulation(string fileName);
		GeneticPopulation(string fileName);

		//NEAT_DLL_EXPORT virtual ~GeneticPopulation();
		virtual ~GeneticPopulation();

		inline GeneticGeneration* getGeneration(int generationIndex=-1)
		{
			if(generationIndex==-1)
				generationIndex=int(onGeneration);

			return &generations[generationIndex];
		}

		//NEAT_DLL_EXPORT void addIndividual(shared_ptr<GeneticIndividual> individual);
		void addIndividual(shared_ptr<GeneticIndividual> individual);

		inline size_t getIndividualCount(int generation=-1)
		{
			if(generation==-1)
				generation=int(onGeneration);

			return generations[generation].getIndividualCount();
		}

		//NEAT_DLL_EXPORT shared_ptr<GeneticIndividual> getIndividual(size_t a,int generation=-1);
		shared_ptr<GeneticIndividual> getIndividual(size_t a,int generation=-1);

		//NEAT_DLL_EXPORT vector<shared_ptr<GeneticIndividual> >::iterator getIndividualIterator(size_t a,int generation=-1);
		vector<shared_ptr<GeneticIndividual> >::iterator getIndividualIterator(size_t a,int generation=-1);

		//NEAT_DLL_EXPORT shared_ptr<GeneticIndividual> getBestAllTimeIndividual();
		shared_ptr<GeneticIndividual> getBestAllTimeIndividual();

		//NEAT_DLL_EXPORT shared_ptr<GeneticIndividual> getBestIndividualOfGeneration(int generation=LAST_GENERATION);
		shared_ptr<GeneticIndividual> getBestIndividualOfGeneration(int generation=LAST_GENERATION);

		inline GeneticSpecies *getSpecies(int id)
		{

			int i_tmp = species.size();

			int id_tmp = species[0]->getID();

			for(size_t a=0;a<species.size();a++)
			{

				int id_tmp = species[a]->getID();

				if(species[a]->getID()==id)
					return species[a];
			}

			throw string("Tried to get a species which doesn't exist (Maybe it went extinct?)");
		}

		//NEAT_DLL_EXPORT void speciate();
		void speciate();

		//NEAT_DLL_EXPORT void setSpeciesMultipliers();
		void setSpeciesMultipliers();

		//NEAT_DLL_EXPORT void adjustFitness();
		void adjustFitness();

		//NEAT_DLL_EXPORT void produceNextGeneration();
		void produceNextGeneration();

		//NEAT_DLL_EXPORT void dump(string filename,bool includeGenes=true,bool append=false);
		void dump(string filename,bool includeGenes=true,bool append=false);

		//NEAT_DLL_EXPORT void dumpBest(string filename,bool includeGenes=true,bool append=false);
		void dumpBest(string filename,bool includeGenes=true,bool append=false);

		//NEAT_DLL_EXPORT void cleanupOld(int generationSkip);
		void cleanupOld(int generationSkip);

		inline size_t getGenerationCount()
		{
			return generations.size();
		}
	};

}

#endif

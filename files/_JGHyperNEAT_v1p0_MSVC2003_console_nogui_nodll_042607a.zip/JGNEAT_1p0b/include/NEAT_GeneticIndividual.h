#ifndef __GENETICINDIVIDUAL_H__
#define __GENETICINDIVIDUAL_H__

#include "NEAT_Defines.h"
#include "NEAT_STL.h"
#include "tinyxmldll.h"

namespace NEAT
{

    class GeneticNodeGene;
    class GeneticLinkGene;
    class Network;
    class FastNetwork;

    class GeneticIndividual
    {
        vector<GeneticNodeGene> nodes;
        vector<GeneticLinkGene> links;

        double fitness;

        int speciesID;

        bool canReproduce;

        Stringable* userData;

    public:
        /**
         * Constructor: Creates an individual with the inputed nodes.
         * \param createTopology Creates a set of links for the new individual
         * \param edgeDensity The probability that a link will exist
        */
        //NEAT_DLL_EXPORT GeneticIndividual(
        GeneticIndividual(
            const vector<GeneticNodeGene> &_nodes,
            bool createTopology=true,
            double edgeDensity=0.75
        );

        /**
         * Create an individual with the inputed nodes.
         * \param randomizeLinkWeights Randomizes all input link weights
         * \param createTopology Creates more links for the new individual
         * \param edgeDensity The probability that a link will exist
        */
        //NEAT_DLL_EXPORT GeneticIndividual(
        GeneticIndividual(
            const vector<GeneticNodeGene> &_nodes,
            const vector<GeneticLinkGene> &_links,
            bool randomizeLinkWeights=true,
            bool createTopology=false,
            double edgeDensity=0.75);

        /**
         * Create an individual from the XML description.
        */
        //NEAT_DLL_EXPORT GeneticIndividual(TiXmlElement *individualElement);
        GeneticIndividual(TiXmlElement *individualElement);

        /**
         * Create a baby individual from two parents
        */
        //NEAT_DLL_EXPORT GeneticIndividual(shared_ptr<GeneticIndividual> parent1,shared_ptr<GeneticIndividual> parent2,bool mate_multipoint_avg=false);
        GeneticIndividual(shared_ptr<GeneticIndividual> parent1,shared_ptr<GeneticIndividual> parent2,bool mate_multipoint_avg=false);

        /**
         * Create a baby individual from one parent
        */
        //NEAT_DLL_EXPORT GeneticIndividual(shared_ptr<GeneticIndividual> parent,bool tryMutation);
        GeneticIndividual(shared_ptr<GeneticIndividual> parent,bool tryMutation);

        /**
         * Copy an individual. THIS COPIES FITNESS TOO!  DO NOT USE THIS TO MAKE OFFSPRING!
        */
        //NEAT_DLL_EXPORT GeneticIndividual(GeneticIndividual &copy);
        GeneticIndividual(GeneticIndividual &copy);

        //NEAT_DLL_EXPORT virtual ~GeneticIndividual();
        virtual ~GeneticIndividual();

		//NEAT_DLL_EXPORT virtual bool operator==(const GeneticIndividual &other) const;
		virtual bool operator==(const GeneticIndividual &other) const;

        /**
         * testMutate: Attempts to mutate an individual.
        */
        //NEAT_DLL_EXPORT void testMutate();
        void testMutate();

        //NEAT_DLL_EXPORT size_t getNodesCount() const;
        size_t getNodesCount() const;

        //NEAT_DLL_EXPORT GeneticNodeGene *getNode(size_t index);
        GeneticNodeGene *getNode(size_t index);

        //NEAT_DLL_EXPORT const GeneticNodeGene *getNode(size_t index) const;
        const GeneticNodeGene *getNode(size_t index) const;

        //NEAT_DLL_EXPORT int getMaxNodePositionOccurance() const;
        int getMaxNodePositionOccurance() const;

        //NEAT_DLL_EXPORT size_t getLinksCount() const;
        size_t getLinksCount() const;

        //NEAT_DLL_EXPORT GeneticLinkGene *getLink(size_t index);
        GeneticLinkGene *getLink(size_t index);

        //NEAT_DLL_EXPORT const GeneticLinkGene *getLink(size_t index) const;
        const GeneticLinkGene *getLink(size_t index) const;

        //NEAT_DLL_EXPORT GeneticLinkGene *getLink(int fromNodeID,int toNodeID);
        GeneticLinkGene *getLink(int fromNodeID,int toNodeID);

        //NEAT_DLL_EXPORT const GeneticLinkGene *getLink(int fromNodeID,int toNodeID) const;
        const GeneticLinkGene *getLink(int fromNodeID,int toNodeID) const;

        //NEAT_DLL_EXPORT bool linkExists(int fromNode,int toNode) const;
        bool linkExists(int fromNode,int toNode) const;

        //NEAT_DLL_EXPORT void dump(TiXmlElement *root,bool dumpGenes=true);
        void dump(TiXmlElement *root,bool dumpGenes=true);

        inline void setFitness(double _fitness)
        {
            fitness = _fitness;
        }

        inline void reward(double _fitness)
        {
            fitness += _fitness;
        }

        inline double getFitness() const
        {
            return fitness;
        }

        inline int getSpeciesID() const
        {
            return speciesID;
        }

        inline void setSpeciesID(int _speciesID)
        {
            speciesID = _speciesID;
        }

        inline Stringable* getUserData()
        {
            return userData;
        }

        inline void setUserData(Stringable* data)
        {
            if (userData)
                delete userData;

            userData = data;
        }

        /**
         * getCompatibility: returns the compatibility between this individual and another
         */
        //NEAT_DLL_EXPORT double getCompatibility(shared_ptr<GeneticIndividual> other);
        double getCompatibility(shared_ptr<GeneticIndividual> other);

        inline void setCanReproduce(bool _canReproduce)
        {
            canReproduce = _canReproduce;
        }

        inline bool getCanReproduce()
        {
            return canReproduce;
        }

        //NEAT_DLL_EXPORT bool mutateAddLink();
        bool mutateAddLink();

        //NEAT_DLL_EXPORT bool mutateAddNode(int fromNodeID=-1,int toNodeID=-1);
        bool mutateAddNode(int fromNodeID=-1,int toNodeID=-1);

        //NEAT_DLL_EXPORT void incrementAge();
        void incrementAge();

        //NEAT_DLL_EXPORT Network *spawnPhenotype() const;
        Network *spawnPhenotype() const;

        //NEAT_DLL_EXPORT Network spawnPhenotypeStack() const;
        Network spawnPhenotypeStack() const;

        //NEAT_DLL_EXPORT FastNetwork spawnFastPhenotypeStack() const;
        FastNetwork spawnFastPhenotypeStack() const;

        //NEAT_DLL_EXPORT void addNode(GeneticNodeGene node);
        void addNode(GeneticNodeGene node);

        //NEAT_DLL_EXPORT void addLink(GeneticLinkGene link);
        void addLink(GeneticLinkGene link);
    protected:
    };

}

#endif

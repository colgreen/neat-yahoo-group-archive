#ifndef NEAT_NETWORKINDEXEDLINK_H_INCLUDED
#define NEAT_NETWORKINDEXEDLINK_H_INCLUDED

namespace NEAT
{
	struct NetworkIndexedLink
	{
	    int fromNode,toNode;
	    double weight;
	};
}


#endif // NEAT_NETWORKINDEXEDLINK_H_INCLUDED

#ifndef NEAT_DEFINES_H_INCLUDED
#define NEAT_DEFINES_H_INCLUDED

#include "tinyxmldll.h"

#include <boost/shared_ptr.hpp>

using namespace boost;

#if defined( __CYGWIN__ )
#  ifdef BUILD_NEAT_DLL
#    define NEAT_DLL_EXPORT
#  else
#    define NEAT_DLL_EXPORT
#  endif
#elif defined( _WIN32 )
#  ifdef BUILD_NEAT_DLL
#    define NEAT_DLL_EXPORT __declspec( dllexport )
#  else
#    define NEAT_DLL_EXPORT __declspec( dllimport )
#  endif
#else
#  ifdef BUILD_NEAT_DLL
#    define NEAT_DLL_EXPORT
#  else
#    define NEAT_DLL_EXPORT
#  endif
#endif

#endif // NEAT_DEFINES_H_INCLUDED

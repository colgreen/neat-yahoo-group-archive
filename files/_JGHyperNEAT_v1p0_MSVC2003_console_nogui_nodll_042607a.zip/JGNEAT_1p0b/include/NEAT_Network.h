#ifndef __NETWORK_H__
#define __NETWORK_H__

#include "NEAT_NetworkNode.h"
#include "NEAT_NetworkLink.h"

namespace NEAT
{

	class NetworkOutputNode;
	class GeneticIndividual;

    /**
     * Network: This class is responsible for creating a neural network phenotype.
     * While this isn't as fast as FastNetwork, it allows you to have more control
     * over the network topology without creating a new network.
     */
	class Network
	{
		vector<NetworkNode *> nodes;
		vector<NetworkLink *> links;

		bool activated;

	public:
		/**
		 *  (Constructor) Create a Network with the inputed toplogy
		 */
		//NEAT_DLL_EXPORT Network(vector<NetworkNode *> &_nodes,vector<NetworkLink *> &_links);
		Network(vector<NetworkNode *> &_nodes,vector<NetworkLink *> &_links);

		/**
		 *  (Constructor) Empty Constructor
		 */
		//NEAT_DLL_EXPORT Network();
		Network();

		/**
		 *  (Assignment) Copies the network
		 */
		//NEAT_DLL_EXPORT Network& operator=(const Network &other);
		Network& operator=(const Network &other);

		/**
		 *  (Copy Constructor) Copies the network
		 */
		//NEAT_DLL_EXPORT Network(const Network &other);
		Network(const Network &other);

		//NEAT_DLL_EXPORT void copyFrom(const Network &other);
		void copyFrom(const Network &other);

		//NEAT_DLL_EXPORT virtual ~Network();
		virtual ~Network();

		//NEAT_DLL_EXPORT NetworkNode *getNode(const string &name);
		NetworkNode *getNode(const string &name);

		//NEAT_DLL_EXPORT NetworkLink *getLink(const string &fromNodeName,const string &toNodeName);
		NetworkLink *getLink(const string &fromNodeName,const string &toNodeName);

		NetworkLink *getLink(size_t index)
		{
		    return links[index];
		}

		inline const size_t getLinkCount()
		{
			return links.size();
		}

		void setValue(const string &nodeName,double value)
		{
		    getNode(nodeName)->setValue(value);
		}

		double getValue(const string &nodeName)
		{
		    return getNode(nodeName)->getValue();
		}

		/*This resets the state of the network to its initial state*/
		//NEAT_DLL_EXPORT void reinitialize();
		void reinitialize();

		//NEAT_DLL_EXPORT void update(int iterations=1);
		void update(int iterations=1);

		//NEAT_DLL_EXPORT int getLongestPathLength();
		int getLongestPathLength();

		inline void dummyActivation()
		{
		    activated=true;
		}
	};

}

#endif

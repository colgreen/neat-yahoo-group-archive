#ifndef __GENETICNODEGENE_H__
#define __GENETICNODEGENE_H__

#include "NEAT_GeneticGene.h"

#include "NEAT_Globals.h"

#include "NEAT_Random.h"

namespace NEAT
{
    /**
     * GeneticNodeGene: This gene contains a link between two GeneticNodeGenes
     */
	//class NEAT_DLL_EXPORT GeneticNodeGene : public GeneticGene
	class GeneticNodeGene : public GeneticGene
	{
    protected:
		string name,type;

		/*Greater drawing position means closer to output!*/
		double drawingPosition;

		ActivationFunction activationFunction;
	public:
		GeneticNodeGene(
		const string &_name,
		const string &_type,
		double _drawingPosition,
		bool randomizeActivation,
		ActivationFunction _activationFunction=ACTIVATION_FUNCTION_SIGMOID
		);

		virtual ~GeneticNodeGene();

		GeneticNodeGene(TiXmlElement *nodeElementPtr);

		virtual bool operator==(const GeneticNodeGene &other) const;

		inline string getName() const
		{
			return name;
		}

		inline string getType() const
		{
			return type;
		}

		/*int getLegacyNodeID()
		{
		return legacyID;
		}*/

		inline const double &getDrawingPosition() const
		{
			return drawingPosition;
		}

		virtual void mutate();

		virtual void dump(TiXmlElement *XMLnode);

		inline ActivationFunction getActivationFunction() const
		{
		    return activationFunction;
		}

		virtual inline void setActivationFunction(ActivationFunction _activationFunction)
		{
		    activationFunction = _activationFunction;
		}
	};

}

#endif

#include "HCUBE_ExperimentRun.h"

#include "Experiments/HCUBE_Experiment.h"

#include "Experiments/HCUBE_FindPointExperiment.h"
#include "Experiments/HCUBE_FindClusterExperiment.h"
#include "Experiments/HCUBE_FindClusterNoGeomExperiment.h"

//#ifndef HCUBE_NOGUI
//#include "HCUBE_MainFrame.h"
//#include "HCUBE_UserEvaluationFrame.h"
//
//#include "HCUBE_ExperimentPanel.h"
//#endif

#include "HCUBE_EvaluationSet.h"

namespace HCUBE
{
    ExperimentRun::ExperimentRun()
            :
            running(false),
            started(false),
            cleanup(false),
            population(NULL),
            populationMutex(new mutex()),
            frame(NULL)
    {
        memset(experiments,0,sizeof(Experiment*)*NUM_THREADS);
    }

    ExperimentRun::~ExperimentRun()
    {
        delete populationMutex;
    }

    void ExperimentRun::setupExperiment(
        int _experimentType,
        string _outputFileName
    )
    {
        experimentType = _experimentType;
        outputFileName = _outputFileName;

        switch (experimentType)
        {
        case EXPERIMENT_FIND_POINT_EXPERIMENT:
            experiments[0] = new FindPointExperiment("");
            break;
        case EXPERIMENT_FIND_CLUSTER_EXPERIMENT:
            experiments[0] = new FindClusterExperiment("");
            break;
        case EXPERIMENT_FIND_CLUSTER_NO_GEOM_EXPERIMENT:
            experiments[0] = new FindClusterNoGeomExperiment("");
            break;
        default:
            cout << string("ERROR: Unknown Experiment Type!\n");
            throw string("ERROR: Unknown Experiment Type!");
        }
        for (int a=1;a<NUM_THREADS;a++)
        {
            experiments[a] = experiments[0]->clone();
        }

    }

    void ExperimentRun::createPopulation(string populationString)
    {
        if (iequals(populationString,""))
        {
            size_t popSize = (size_t)NEAT::Globals::getSingleton()->getParameterValue("PopulationSize");
            population = experiments[0]->createInitialPopulation(popSize);
        }
        else
            population = new NEAT::GeneticPopulation(populationString);
    }

    void ExperimentRun::setupExperimentInProgress(
        string populationFileName,
        string _outputFileName
    )
    {
        outputFileName = _outputFileName;

        {
            TiXmlDocument doc(populationFileName);

            doc.LoadFile();

            TiXmlElement *element = doc.FirstChildElement();

            TiXmlAttribute *firstAttribute = element->FirstAttribute();

            NEAT::Globals* globals = NEAT::Globals::init();

            while (firstAttribute)
            {
                globals->addParameter( firstAttribute->Name() , firstAttribute->DoubleValue() );

                firstAttribute = firstAttribute->Next();
            }

            double randomSeed = NEAT::Globals::getSingleton()->getParameterValue("RandomSeed");
            if (randomSeed<0.0)
                NEAT::Random::init(); //use time as the seed
            else
                NEAT::Random::init((unsigned int)randomSeed);

            //Destroy the document
        }

        int experimentType = int(NEAT::Globals::getSingleton()->getParameterValue("ExperimentType")+0.001);

        cout << "Loading Experiment: " << experimentType << endl;

        setupExperiment(experimentType,_outputFileName);

        cout << "Experiment set up\n";

        createPopulation(populationFileName);

        cout << "Population Created\n";
    }

    void ExperimentRun::start()
    {
        cout << "Experiment started\n";
        size_t maxGenerations = size_t(NEAT::Globals::getSingleton()->getParameterValue("MaxGenerations"));

        started=running=true;

        for (size_t generations=(population->getGenerationCount()-1);generations<maxGenerations;generations++)
        {
            if (generations>0)
            {
                mutex::scoped_lock scoped_lock(*populationMutex);
                cout << "PRODUCING NEXT GENERATION\n";
                produceNextGeneration();
                cout << "DONE PRODUCING\n";
            }

            //if (experiments[0]->performUserEvaluations())
            //{
            //    frame->getUserEvaluationFrame()->updateEvaluationPanels();
            //    running=false;
            //    while (!running)
            //    {
            //        boost::xtime xt;
            //        boost::xtime_get(&xt, boost::TIME_UTC);
            //        xt.sec += 1;
            //        boost::thread::sleep(xt); // Sleep for 1/2 second
            //        //cout << "Sleeping while user evaluates!\n";
            //    }
            //}
            //else
            //{
                while (!running)
                {
                    boost::xtime xt;
                    boost::xtime_get(&xt, boost::TIME_UTC);
                    xt.sec += 1;
                    boost::thread::sleep(xt); // Sleep for 1/2 second
                }
                evaluatePopulation();
//            }		// afc, 04/26/07

            cout << "Finishing evaluations\n";
            finishEvaluations();
            cout << "Evaluations Finished\n";
        //}		// afc, 04/26/07
        }
        cout << "Experiment finished\n";

        cout << "Saving Dump...";
        //population->dump(outputFileName,true,false);
        cout << "Done!\n";

        cout << "Saving best individuals...";
        string bestFileName = outputFileName.substr(0,outputFileName.length()-4)+string("_best.xml");
        population->dumpBest(bestFileName,true,false);
        cout << "Done!\n";
    }

    void ExperimentRun::evaluatePopulation()
    {
        size_t populationSize = population->getIndividualCount();

        size_t populationPerProcess = populationSize/NUM_THREADS;

        boost::thread* threads[NUM_THREADS];
        EvaluationSet* evaluationSets[NUM_THREADS];

        for (int i = 0; i < NUM_THREADS; ++i)
        {
            if (i+1==NUM_THREADS)
            {
                //Fix for uneven distribution
                size_t populationIteratorSize =
                    populationSize
                    - populationPerProcess*(NUM_THREADS-1);
                evaluationSets[i] =
                    new EvaluationSet(
                        experiments[i],
                        population->getIndividualIterator(populationPerProcess*i),
                        populationIteratorSize
                    );
            }
            else
            {

                evaluationSets[i] =
                    new EvaluationSet(
                        experiments[i],
                        population->getIndividualIterator(populationPerProcess*i),
                        populationPerProcess
                    );
            }

            threads[i] =
                new boost::thread(
                    boost::bind(
                        &EvaluationSet::run,
                        evaluationSets[i]
                    )
                );
        }

        //loop through each thread, making sure it is finished before we move on
        for (size_t i=0;i<NUM_THREADS;++i)
        {
            /*if (!evaluationSets[i]->isFinished())
            {
                --i;
                boost::xtime xt;
                boost::xtime_get(&xt, boost::TIME_UTC);
                xt.sec += 1;
                boost::thread::sleep(xt); // Sleep for 1/2 second
            }*/
            threads[i]->join();
        }

        for (int i = 0; i < NUM_THREADS; ++i)
        {
            delete threads[i];
            delete evaluationSets[i];
        }
    }

    void ExperimentRun::finishEvaluations()
    {
        //int generationDumpModulo = int(NEAT::Globals::getSingleton()->getParameterValue("GenerationDumpModulo"));
        if (cleanup)
            population->cleanupOld(INT_MAX/2);
        population->adjustFitness();
        //population->dumpBest(outputFileName,true,false);
        //population->cleanupOld(25);
        //population->dumpBest("out/dumpBestWithGenes(backup).xml",true);

//#ifndef HCUBE_NOGUI
//        if (frame)
//        {
//            frame->updateNumGenerations(population->getGenerationCount());
//        }
//#endif

        NEAT::GeneticGeneration* generation = population->getGeneration();
        experiments[0]->resetGenerationData(generation);

        for (size_t a=0;a<population->getIndividualCount();a++)
        {
            //cout << __FILE__ << ":" << __LINE__ << endl;
            experiments[0]->addGenerationData(generation,population->getIndividual(a));
        }

        /*
        if(experimentType == EXPERIMENT_TIC_TAC_TOE_GAME)
        {
            //Take the best individual and run him a lot

           ((TicTacToeGameExperiment*)experiment)->setNumGames(20000);
           ((TicTacToeGameExperiment*)experiment)->setNumGames(100);
        }
        */
    }

    void ExperimentRun::produceNextGeneration()
    {
        cout << "Producing next generation.\n";
        population->produceNextGeneration();
    }
}

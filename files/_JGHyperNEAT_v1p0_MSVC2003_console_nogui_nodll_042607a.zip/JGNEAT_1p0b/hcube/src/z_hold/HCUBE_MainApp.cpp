#ifndef HCUBE_NOGUI

#include "HCUBE_MainApp.h"

#include "HCUBE_MainFrame.h"

namespace HCUBE
{
    bool MainApp::OnInit()
    {
        wxInitAllImageHandlers();

        cout << "IO Mutex: " << Globals::ioMutex << endl;

        cout << argc << " ARGUMENTS\n";
        cout << argv[0] << endl;

        MainFrame *frame = new MainFrame( NULL );

        frame->Show(TRUE);
        SetTopWindow(frame);
        return true;
    }
}

#endif

#include "HCUBE_Defines.h"

namespace HCUBE
{
    boost::mutex* Globals::ioMutex = new boost::mutex();

    streambuf* Globals::coutBuffer = cout.rdbuf();
}

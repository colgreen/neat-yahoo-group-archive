#ifndef HCUBE_NOGUI

#include "HCUBE_MainFrame.h"

#include "HCUBE_ViewIndividualFrame.h"

#include "Experiments/HCUBE_Experiment.h"

#include "HCUBE_UserEvaluationFrame.h"

namespace HCUBE
{
    MainFrame::MainFrame(
        wxWindow* parent,
        int id,
        wxString title,
        wxPoint pos,
        wxSize size,
        int style
    )
            :
            MainFrameTemplate( parent, id, title, pos, size, style )
    {
        /*
        fileMenu = new wxMenu();
        menuBar = new wxMenuBar();

        experimentPanel = new ExperimentPanel(
                              this,
                              -1,
                              wxPoint(50,50),
                              wxSize(100,20)
                          );
        */

        experimentRun.setFrame(this);

        /*
        experimentPanel->Enable(false);

        wxMenuItem *menuItem;

        menuItem = fileMenu->Append( ID_LoadExperiment, "&Load Experiment" );
        menuItem = fileMenu->Append( ID_RunExperiment, "&Run Experiment" );
        menuItem->Enable(false);
        menuItem = fileMenu->Append( ID_PauseExperiment, "Pause Expe&riment" );
        menuItem->Enable(false);
        menuItem = fileMenu->AppendSeparator();
        menuItem = fileMenu->Append( ID_LoadPopulation, "Load &Population" );
        menuItem = fileMenu->AppendSeparator();
        menuItem = fileMenu->Append( ID_About, "&About..." );
        menuItem = fileMenu->AppendSeparator();
        menuItem = fileMenu->Append( ID_Quit, "E&xit" );

        menuBar->Append( fileMenu, "&File" );

        SetMenuBar( menuBar );

        CreateStatusBar();
        */

        SetStatusText( "Welcome to HyperNEAT!" );
    }

    MainFrame::~MainFrame()
    {
    }

    void MainFrame::exit(wxCommandEvent& WXUNUSED(event))
    {
        Close(TRUE);
    }

    void MainFrame::about(wxCommandEvent& WXUNUSED(event))
    {
        wxMessageBox("Hypercube NEAT.  By Jason Gauci, UCF PhD. Student.  jgauci@cs.ucf.edu",
                     "About Hypercube NEAT", wxOK | wxICON_INFORMATION, this);
    }

    void MainFrame::loadExperiment(wxCommandEvent& WXUNUSED(event))
    {
        if (experimentRun.isStarted())
        {
            throw string("Loading a new experiment while one is running is not yet supported!\n");
        }
        else
        {
            wxFileDialog loadParametersDialog(this,"Choose a Parameter File",wxGetCwd(),"","*.dat",wxOPEN|wxFILE_MUST_EXIST);
            int retVal = loadParametersDialog.ShowModal();

            string fileName = string(loadParametersDialog.GetFilename());

            fileName = fileName.substr(0,fileName.length()-3) + string("xml");

            if (retVal==wxID_OK)
            {
                wxFileDialog outputFileDialog(
                    this,
                    "Choose an Output File",
                    loadParametersDialog.GetDirectory(),
                    wxString(fileName.c_str()),
                    "*.xml",
                    wxSAVE
                );

                retVal = outputFileDialog.ShowModal();

                if (retVal==wxID_OK)
                {

                    NEAT::Globals::init(string(loadParametersDialog.GetPath()));

                    int experimentType = int(NEAT::Globals::getSingleton()->getParameterValue("ExperimentType")+0.001);

                    cout << "Loading Experiment: " << experimentType << endl;

                    experimentRun.setupExperiment(experimentType,string(outputFileDialog.GetPath()));

                    cout << "Experiment set up\n";

                    experimentRun.createPopulation();

                    cout << "Population Created\n";

                    fileMenu->FindItem(wxID_RUNEXPERIMENT_MENUITEM)->Enable(true);
                    setPopulationSize(int(NEAT::Globals::getSingleton()->getParameterValue("PopulationSize")));

                    if (experimentRun.getExperiment()->performUserEvaluations())
                    {
                        cout << "Creating User Evaluation Window...";
                        //Create a Frame for User Evaluations
                        userEvaluationFrame = new UserEvaluationFrame(&experimentRun,(wxWindow*)this);
                        cout << "...Done!\n";
                    }

                    map<string,double>::iterator parameterIterator = NEAT::Globals::getSingleton()->getMapBegin();
                    for(;
                    parameterIterator != NEAT::Globals::getSingleton()->getMapEnd();
                    parameterIterator++)
                    {
                        ostringstream ostr;
                        ostr << parameterIterator->first << ":     " << parameterIterator->second;
                        parameterListBox->AppendString(ostr.str().c_str());
                    }

                    return;
                }
            }
        }
    }

    void MainFrame::loadPopulation(wxCommandEvent& WXUNUSED(event))
    {
        if (experimentRun.isStarted())
        {
        }
        else
        {
            wxFileDialog loadParametersDialog(this,"Choose a Population File",wxGetCwd(),"","*.xml",wxOPEN|wxFILE_MUST_EXIST);
            int retVal = loadParametersDialog.ShowModal();

            if (retVal==wxID_OK)
            {
                cout << "Loading population file: " << string(loadParametersDialog.GetPath()) << endl;

                populationFileName = loadParametersDialog.GetFilename();

                experimentRun.setupExperimentInProgress(
                    string(loadParametersDialog.GetPath()),
                    ""
                );

                fileMenu->FindItem(wxID_RUNEXPERIMENT_MENUITEM)->Enable(true);
                size_t genCount = experimentRun.getPopulation()->getGenerationCount();
                updateNumGenerations(genCount);
                setPopulationSize(int(NEAT::Globals::getSingleton()->getParameterValue("PopulationSize")));
                return;
            }
        }
    }

    void MainFrame::runExperiment(wxCommandEvent& WXUNUSED(event))
    {
        if (!experimentRun.isStarted())
        {
            cout << "Creating Boost Thread\n";
            boost::thread thread( boost::bind(&ExperimentRun::start,&experimentRun) );
            fileMenu->FindItem(wxID_RUNEXPERIMENT_MENUITEM)->SetText("Rerun &Experiment");
            fileMenu->FindItem(wxID_PAUSEEXPERIMENT_MENUITEM)->Enable(true);
        }
    }

    void MainFrame::restartExperiment( wxCommandEvent& event )
    {
    }

    void MainFrame::pauseExperiment(wxCommandEvent& WXUNUSED(event))
    {
        if (experimentRun.isRunning())
        {
            experimentRun.setRunning(false);
            fileMenu->FindItem(wxID_PAUSEEXPERIMENT_MENUITEM)->SetText("Continue Ex&periment");
        }
        else
        {
            experimentRun.setRunning(true);
            fileMenu->FindItem(wxID_PAUSEEXPERIMENT_MENUITEM)->SetText("&Pause Experiment");
        }
    }

    /*void MainFrame::loadExperiment(const string &parameters,const string &outputFileName)
    {
        NEAT::Globals::init(parameters);

        int experimentType = int(NEAT::Globals::getSingleton()->getParameterValue("ExperimentType")+0.001);

        cout << "Loading Experiment: " << experimentType << endl;

        experimentRun.setupExperiment(experimentType);

        experimentRun.createPopulation(populationString);

        experimentPanel->setPopulationSize(NEAT::Globals::getSingleton()->getParameterValue("PopulationSize"));

        cout << "Finished loading and ready to run!\n";
    }*/

    void MainFrame::viewIndividual( wxCommandEvent& event )
    {
        int generation = generationSpinner->GetValue();
        int individual = individualSpinner->GetValue();

        string title;

        title +=
            populationFileName +
            string("_") +
            string("Generation: ") +
            toString(generation) +
            string(" Individual: ") +
            toString(individual);

        mutex *populationMutex = experimentRun.getPopulationMutex();
        {
            mutex::scoped_lock scoped_lock(*populationMutex);

            Experiment *experiment = experimentRun.getExperiment()->clone();

            experiment->setExperimentName(title);

            //We do -1 because indicies are 0-based
            shared_ptr<NEAT::GeneticIndividual> indiv =
                shared_ptr<NEAT::GeneticIndividual>(
                    new NEAT::GeneticIndividual(
                        *(experimentRun.getIndividual(generation-1,individual-1).get())
                    )
                );

            ViewIndividualFrame *viewFrame =
                new ViewIndividualFrame(
                    experiment,
                    indiv,
                    this,
                    wxID_ANY,
                    title.c_str(),
                    wxDefaultPosition,
                    wxSize(720,480)
                );

            viewFrame->Show(TRUE);
        }
    }

    void MainFrame::analyzeIndividual( wxCommandEvent& event )
    {
        int generation = generationSpinner->GetValue();
        int individual = individualSpinner->GetValue();

        string title;

        title +=
            populationFileName +
            string("_") +
            string("Generation: ") +
            toString(generation) +
            string(" Individual: ") +
            toString(individual);

        mutex *populationMutex = experimentRun.getPopulationMutex();
        {
            mutex::scoped_lock scoped_lock(*populationMutex);

            Experiment *experiment = experimentRun.getExperiment()->clone();

            shared_ptr<NEAT::GeneticIndividual> indiv =
                shared_ptr<NEAT::GeneticIndividual>(
                    new NEAT::GeneticIndividual(
                        *(experimentRun.getIndividual(generation-1,individual-1).get())
                    )
                );

            experiment->processIndividualPostHoc(indiv);

            if (indiv->getUserData())
            {
                cout << "PRINTING USER DATA RESULTS:\n";
                cout << indiv->getUserData()->summaryHeaderToString() << endl;
                cout << indiv->getUserData()->summaryToString() << endl;
            }

        }
    }

    void MainFrame::setPopulationSize(int newPopulationSize)
    {
        individualSpinner->SetRange(1,newPopulationSize);
    }

    void MainFrame::updateNumGenerations(int numGenerations)
    {
        if (numGenerations>0)
        {
            cout << "Enabling control...\n";
            viewIndividualButton->Enable(true);
            analyzeIndividualButton->Enable(true);

            generationSpinner->SetRange(1,numGenerations);

            if (generationSpinner->GetValue()==0)
                generationSpinner->SetValue(1);

            cout << "Refreshing...\n";
            Refresh();
            cout << "Done Refreshing\n";
        }
    }
}

#endif

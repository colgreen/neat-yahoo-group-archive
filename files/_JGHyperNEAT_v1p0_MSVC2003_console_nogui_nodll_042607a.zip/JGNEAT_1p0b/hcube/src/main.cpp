#ifndef HCUBE_NOGUI
# include "HCUBE_MainApp.h"
#endif

#include "HCUBE_ExperimentRun.h"

#include "Experiments/HCUBE_Experiment.h"
#include "Experiments/HCUBE_FindClusterExperiment.h"

#ifndef HCUBE_NOGUI
namespace HCUBE
{
    IMPLEMENT_APP_NO_MAIN(MainApp)
}
#endif

int main(int argc,char **argv)
{
    try
    {
        if (argc==1)
        {
#ifndef HCUBE_NOGUI
            cout << "Starting wxEntry...\n";
            return wxEntry(argc, argv);
#else
            cout << "You must pass the parameters and the output file as command "
            << "parameters!\n";
#endif
        }
        else if (argc==2)
        {
            //Run the post-hoc analysis on every generation
            HCUBE::ExperimentRun experimentRun;

            experimentRun.setupExperimentInProgress(
                string(argv[1]),
                ""
            );

            size_t numGenerations = experimentRun.getPopulation()->getGenerationCount();

            HCUBE::Experiment *experiment = experimentRun.getExperiment()->clone();

            {
                string outString = (erase_tail_copy(string(argv[1]),4)+string("_fitness.out"));
                cout << "Creating file " << outString << endl;
                ofstream outfile( outString.c_str() );
                string previousSummary;

                bool doOnce=false;

                for (size_t generation=0;generation<numGenerations;generation++)
                {
                    //system("PAUSE");

                    //system("PAUSE");

                    if( generation &&
                        (*(experimentRun.getIndividual(generation,0).get())) == (*(experimentRun.getIndividual(generation-1,0).get())) )
                    {
                        outfile << (generation+1) << ' ' << previousSummary << endl;
                        continue;
                    }

                    shared_ptr<NEAT::GeneticIndividual> indiv =
                        shared_ptr<NEAT::GeneticIndividual>(
                            new NEAT::GeneticIndividual(
                                *(experimentRun.getIndividual(generation,0).get())
                            )
                        );

                    //system("PAUSE");

                    cout << "Beginning fitness evaluation " << (generation+1) << "/" << numGenerations << "...";
                    experiment->processIndividual(indiv);
                    cout << "done!\n";

                    //system("PAUSE");

                    if (indiv->getUserData())
                    {
                        if (!doOnce)
                        {
                            doOnce=true;
                            outfile
                            << "#Generation: "
                            << indiv->getUserData()->summaryHeaderToString()
                            << endl;
                        }

                        previousSummary = indiv->getUserData()->summaryToString();
                        outfile << (generation+1) << ' ' << previousSummary << endl;
                    }
                    else
                    {
                        throw string("No user data!\n");
                    }

                }
            }

            {
                string outString = (erase_tail_copy(string(argv[1]),4)+string("_lowres.out"));
                cout << "Creating file " << outString << endl;
                ofstream outfile( outString.c_str() );
                string previousSummary;

                bool doOnce=false;

                for (size_t generation=0;generation<numGenerations;generation++)
                {
                    //system("PAUSE");

                    //system("PAUSE");

                    if( generation &&
                        (*(experimentRun.getIndividual(generation,0).get())) == (*(experimentRun.getIndividual(generation-1,0).get())) )
                    {
                        outfile << (generation+1) << ' ' << previousSummary << endl;
                        continue;
                    }

                    shared_ptr<NEAT::GeneticIndividual> indiv =
                        shared_ptr<NEAT::GeneticIndividual>(
                            new NEAT::GeneticIndividual(
                                *(experimentRun.getIndividual(generation,0).get())
                            )
                        );

                    //system("PAUSE");

                    cout << "Beginning post-hoc evaluation " << (generation+1) << "/" << numGenerations << "...";
                    experiment->processIndividualPostHoc(indiv);
                    cout << "done!\n";

                    //system("PAUSE");

                    if (indiv->getUserData())
                    {
                        if (!doOnce)
                        {
                            doOnce=true;
                            outfile
                            << "#Generation: "
                            << indiv->getUserData()->summaryHeaderToString()
                            << endl;
                        }

                        previousSummary = indiv->getUserData()->summaryToString();
                        outfile << (generation+1) << ' ' << previousSummary << endl;
                    }

                }
            }


            cout << "Done with run!  Running medium resolution tests...\n";
            ((HCUBE::FindClusterExperiment*)experiment)->increaseResolution();

            {
                string outString = (erase_tail_copy(string(argv[1]),4)+string("_midres.out"));
                ofstream outfile( outString.c_str() );
                cout << "Creating file " << outString << endl;
                string previousSummary;

                bool doOnce=false;

                for (size_t generation=0;generation<numGenerations;generation++)
                {
                    //system("PAUSE");

                    //system("PAUSE");

                    if( generation &&
                        (*(experimentRun.getIndividual(generation,0).get())) == (*(experimentRun.getIndividual(generation-1,0).get())) )
                    {
                        outfile << (generation+1) << ' ' << previousSummary << endl;
                        continue;
                    }

                    shared_ptr<NEAT::GeneticIndividual> indiv =
                        shared_ptr<NEAT::GeneticIndividual>(
                            new NEAT::GeneticIndividual(
                                *(experimentRun.getIndividual(generation,0).get())
                            )
                        );

                    //system("PAUSE");

                    cout << "Beginning post-hoc evaluation " << (generation+1) << "/" << numGenerations << "...";
                    experiment->processIndividualPostHoc(indiv);
                    cout << "done!\n";

                    //system("PAUSE");

                    if (indiv->getUserData())
                    {
                        if (!doOnce)
                        {
                            doOnce=true;
                            outfile
                            << "#Generation: "
                            << indiv->getUserData()->summaryHeaderToString()
                            << endl;
                        }

                        previousSummary = indiv->getUserData()->summaryToString();
                        outfile << (generation+1) << ' ' << previousSummary << endl;
                    }

                }
            }
        }
        else
        {
            NEAT::Globals::init(string(argv[1]));

            int experimentType = int(NEAT::Globals::getSingleton()->getParameterValue("ExperimentType")+0.001);

            cout << "Loading Experiment: " << experimentType << endl;

            HCUBE::ExperimentRun experimentRun;

            experimentRun.setupExperiment(experimentType,string(argv[2]));

            cout << "Experiment set up\n";

            experimentRun.createPopulation();

            experimentRun.setCleanup(true);

            cout << "Population Created\n";

            experimentRun.start();
        }
    }
    catch (string s)
    {
        cout << "An exception has occured: " << s << endl;
    }
    catch (...)
    {
        cout << "An error has occured!\n";
    }

    return 0;
}


#ifndef HCUBE_MAINAPP_H_INCLUDED
#define HCUBE_MAINAPP_H_INCLUDED

#include "HCUBE_Defines.h"

namespace HCUBE
{
    class MainApp : public wxApp
    {
    public:
    protected:

    public:
        virtual bool OnInit();
    protected:
    };
}

#endif // HCUBE_MAINAPP_H_INCLUDED

#ifndef HCUBE_DEFINES_H_INCLUDED
#define HCUBE_DEFINES_H_INCLUDED

/** THESE ARE THE ONLY INCLUDES FROM THIS PROJECT THAT SHOULD BE IN THIS FILE! **/
#include "HCUBE_STL.h"
#include "HCUBE_Boost.h"

#include "HCUBE_Vector2.h"
#include "HCUBE_Vector3.h"

namespace HCUBE
{
    typedef Vector3<int> Node;
}

//#ifndef HCUBE_NOGUI
////# include "wx/wxprec.h"
//# include "../../wxWidgets/wx/wxprec.h"
//
//# ifndef WX_PRECOMP
///*#  include "wx/wx.h"*/
//#  include "../../wxWidgets/wx/wx.h"
//# endif
//
//# include "../../wxWidgets/wx/spinctrl.h"
//# include "../../wxWidgets/wx/bookctrl.h"
//#else
//class wxDC
//{
//public:
//    void Clear()
//    {
//    }
//
//    void DrawText(string s,int i,int j)
//    {
//    }
//
//    void DrawText(char c,int i,int j)
//    {
//    }
//
//    void DrawRectangle(int a,int b,int c,int d)
//    {
//    }
//
//    void DrawLine(int a,int b,int c,int d)
//    {
//    }
//
//    void DrawCircle(int a,int b,int c)
//    {
//    }
//
//    void SetDeviceOrigin(int a,int b)
//    {
//    }
//
//    HCUBE::Vector2<int> GetSize()
//    {
//        return HCUBE::Vector2<int>();
//    }
//};
//#endif

#include "StringConverter.h"

#include "NEAT.h"

#define HASBIT(NUMBER,BIT)	(((NUMBER)&(1<<(BIT)))>0)
#define SETBIT(NUMBER,BIT)	((NUMBER)|=(1<<(BIT)))
#define UNSETBIT(NUMBER,BIT)	((NUMBER)&=~(1<<(BIT)))
#define TOGGLEBIT(NUMBER,BIT)	((NUMBER)^=(1<<(BIT)))

#define NUM_THREADS (2)

namespace HCUBE
{
    /** class Prototypes **/
    class Experiment;
    class ExperimentRun;

    class MainFrame;
    class ExperimentPanel;

    class UserEvaluationFrame;

    class EvaluationPanel;
    class NetworkPanel;

    class Globals
    {
    public:
        /** Globals **/
        static boost::mutex* ioMutex;
        static streambuf* coutBuffer;
    };
}

/** enums **/

enum ExperimentType
{
    EXPERIMENT_BASIC=0,                                 //0
    EXPERIMENT_1,                             //1
    EXPERIMENT_2,                               //2
    EXPERIMENT_3,                          //3
    EXPERIMENT_4,                      //4
    EXPERIMENT_5,                            //5
    EXPERIMENT_6,                             //6
    EXPERIMENT_7,                               //7
    EXPERIMENT_8,                       //8
    EXPERIMENT_9,                        //9
    EXPERIMENT_10,                //10
    EXPERIMENT_FIND_POINT_EXPERIMENT,                   //11
    EXPERIMENT_FIND_CLUSTER_EXPERIMENT,                 //12
    EXPERIMENT_FIND_CLUSTER_NO_GEOM_EXPERIMENT,         //13
    EXPERIMENT_11,                            //14
    EXPERIMENT_CHECKERS,                                //15
    EXPERIMENT_END
};

#endif // HCUBE_DEFINES_H_INCLUDED

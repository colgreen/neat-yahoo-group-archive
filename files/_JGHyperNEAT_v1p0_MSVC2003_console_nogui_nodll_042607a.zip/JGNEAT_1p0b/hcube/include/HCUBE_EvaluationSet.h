#ifndef HCUBE_EVALUATIONSET_H_INCLUDED
#define HCUBE_EVALUATIONSET_H_INCLUDED

#include "HCUBE_Defines.h"

#include "Experiments/HCUBE_Experiment.h"

namespace HCUBE
{
    class EvaluationSet
    {
    public:
    protected:
        bool running;
        Experiment *experiment;
        vector<shared_ptr<NEAT::GeneticIndividual> >::iterator individualIterator;
        size_t individualCount;
        bool finished;

    public:
        EvaluationSet(
            Experiment *_experiment,
            vector<shared_ptr<NEAT::GeneticIndividual> >::iterator _individualIterator,
            size_t _individualCount
        )
                :
                running(false),
                experiment(_experiment),
                individualIterator(_individualIterator),
                individualCount(_individualCount),
                finished(false)
        {
            //You must copy the experiment because you can't run the same object
            //simultaneously
            //experiment = _experiment->clone();
        }

        virtual ~EvaluationSet()
        {
            //delete experiment;
        }

        void run()
        {
            try
            {
                running=true;

                for (size_t a=0;a<individualCount;a++,individualIterator++)
                {
                    while (!running)
                    {
                        boost::xtime xt;
                        boost::xtime_get(&xt, boost::TIME_UTC);
                        xt.sec += 1;
                        boost::thread::sleep(xt); // Sleep for 1 second
                    }

                    shared_ptr<NEAT::GeneticIndividual> individual = *individualIterator;

                    experiment->processIndividual(individual);
                }

                finished=true;
            }
            catch (string s)
            {
                cout << s << endl;
		system("PAUSE");
            }
            catch(...)
            {
                cout << "An error has occured!\n";
		system("PAUSE");
            }
        }

        bool isFinished()
        {
            return finished;
        }

        bool getRunning()
        {
            return running;
        }

        void setRunning(bool _running)
        {
            running = _running;
        }
    protected:
    };
}

#endif // HCUBE_EVALUATIONSET_H_INCLUDED

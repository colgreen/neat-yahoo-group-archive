#ifndef HCUBE_VECTOR3_H_INCLUDED
#define HCUBE_VECTOR3_H_INCLUDED

namespace HCUBE
{
    template<class T>
    class Vector3
    {
    public:
        T x,y,z;

        Vector3()
                :
                x(0),
                y(0)
        {}

        Vector3(T _x,T _y,T _z)
                :
                x(_x),
                y(_y),
                z(_z)
        {}

        Vector3<T> operator/(T divisor) const
        {
            return Vector3<T>(x/divisor,y/divisor,z/divisor);
        }

        void operator/=(T divisor)
        {
            x/=divisor;
            y/=divisor;
            z/=divisor;
        }

        Vector3<T> operator-() const
        {
            Vector3<T> newVec(-x,-y,-z);
            return newVec;
        }

        Vector3<T> operator-(const Vector3<T> &other) const
        {
            return Vector3<T>(this->x-other.x,this->y-other.y,this->z-other.z);
        }

        Vector3<T> operator+(const Vector3<T> &other) const
        {
            return Vector3<T>(this->x+other.x,this->y+other.y,this->z+other.z);
        }

        Vector3<T> operator*(const T &coeff) const
        {
            return Vector3<T>(x*coeff,y*coeff,z*coeff);
        }

        void operator+=(const Vector3<T> &other)
        {
            x+=other.x;
            y+=other.y;
            z+=other.z;
        }

        void operator-=(const Vector3<T> &other)
        {
            x-=other.x;
            y-=other.y;
            z-=other.z;
        }

        void operator*=(T val)
        {
            x*=val;
            y*=val;
            z*=val;
        }

        T distanceSquared(const Vector3<T> &other) const
        {
            return (x-other.x)*(x-other.x)+(y-other.y)*(y-other.y)+(z-other.z)*(z-other.z);
        }

        bool operator<(const Vector3<T> &other) const
        {
            return (
            (x<other.x) ||
            (x==other.x && y<other.y) ||
            (x==other.x && y==other.y && z<other.z)
            );
        }
    };
}


#endif // HCUBE_VECTOR3_H_INCLUDED

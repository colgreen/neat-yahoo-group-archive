#ifndef HCUBE_EXPERIMENT_H_INCLUDED
#define HCUBE_EXPERIMENT_H_INCLUDED

#include "HCUBE_Defines.h"

namespace HCUBE
{
    class Experiment
    {
    protected:
        string experimentName;

        bool displayGenerationResult;

	    shared_ptr<NEAT::GeneticIndividual> lastIndividualSeen;
	public:
        Experiment(string _experimentName)
        :
        experimentName(_experimentName),
        displayGenerationResult(true)
        {
        }

        virtual ~Experiment()
        {
        }

        string getExperimentName() const
        {
            return experimentName;
        }

        void setExperimentName(string _experimentName)
        {
            experimentName = _experimentName;
        }

		inline void setLastIndividualSeen(shared_ptr<NEAT::GeneticIndividual> _lastIndividualSeen)
		{
			lastIndividualSeen = _lastIndividualSeen;
		}

        virtual NEAT::GeneticPopulation* createInitialPopulation(size_t populationSize) = 0;

        virtual void processIndividual(shared_ptr<NEAT::GeneticIndividual> individual) = 0;

        virtual void processIndividualPostHoc(shared_ptr<NEAT::GeneticIndividual> individual)
        {
        }

//#ifndef HCUBE_NOGUI
//        virtual void createIndividualImage(wxDC &drawContext,shared_ptr<NEAT::GeneticIndividual> individual) = 0;
//#endif

        virtual bool performUserEvaluations() = 0;

//#ifndef HCUBE_NOGUI
//        /**
//         * handleMousePress: returns true if the window needs to be refreshed
//         */
//        virtual bool handleMousePress(wxMouseEvent& event,wxSize &bitmapSize) = 0;
//
//        /**
//         * handleMouseMotion: returns true if the window needs to be refreshed
//         */
//        virtual bool handleMouseMotion(wxMouseEvent& event,wxDC &temp_dc,shared_ptr<NEAT::GeneticIndividual> individual)
//        {
//            return false;
//        }
//#endif

        virtual inline bool isDisplayGenerationResult() { return displayGenerationResult; }

        virtual inline void setDisplayGenerationResult(bool _displayGenerationResult)
        {
            displayGenerationResult=_displayGenerationResult;
        }

        virtual inline void toggleDisplayGenerationResult()
        {
            displayGenerationResult=!displayGenerationResult;
        }

//#ifndef HCUBE_NOGUI
//        inline void drawPixel(int x,int y,int relativeResolution,wxColour** localBuffer,wxColour value)
//        {
//            //you want to draw a pixel at x,y if x,y was over 32, so multiply if it isn't
//
//            int mody,modx;
//            for(mody=0;mody<relativeResolution;mody++)
//            {
//                for(modx=0;modx<relativeResolution;modx++)
//                {
//                    localBuffer[(y*relativeResolution)+mody][(x*relativeResolution)+modx] = value;
//                }
//            }
//        }
//#endif

        virtual Experiment* clone() = 0;

        virtual void resetGenerationData(NEAT::GeneticGeneration *generation)
        {
        }

        virtual void addGenerationData(NEAT::GeneticGeneration *generation,shared_ptr<NEAT::GeneticIndividual> individual)
        {
        }

    };
}

#endif // HCUBE_EXPERIMENT_H_INCLUDED

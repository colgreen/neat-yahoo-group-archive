#include "stdafx.h"
#include "utils.h"
#include "neat.h"

#include <fstream>
#include <math.h>
#include <cstring>
#include <string>

//-----------------------------------------------------------------------
// ACTIVATION FUNCTIONS SUPPORTED: name / output range / formula
// -------------------------------
// NEURAL FUNCTIONS
// ----------------
// sigmoid             : (0  .. 1)      : f(x) = 1/(1+exp(-x));
// gaussian            : (0  .. 1)      : f(x) = ?
// ----------------------
// MATHEMATICAL FUNCTIONS (experimental)
// ----------------------
// sine                : (-1 .. 1)      : f(x) = sin(x);
// cosine              : (-1 .. 1)      : f(x) = cos(x);
// square              : (0, +inf)      : f(x) = x*x;
// square root         : (0, +inf)      : f(x) = sqrt(x);
// exponential         : (?)            : f(x) = exp(x);
// log                 : (?)            : f(x) = log(x);
// inv                 : (-inf, +inf)   : f(x) = (x!=0)?1/x:BIG_NUMBER; 
// absolute value      : (0 .. +inf)    : f(x) = abs(x);
// linear              : (-inf .. +inf) : f(x) = x;
//-----------------------------------------------------------------------

////////////////////////////////////////////////////
// NEURON INPUT SUM FUNCTIONS (experimental)
// -----------------------------------------
// addition       : (i1*w1) + (i2*w2) + (in*wn)       : default      : OR
// multiplication : (i1*w1) * (i2*w2) * (in*wn)       : experimental : AND
// maximal of     : MAX ((i1*w1), (i2*w2), (i3*w3))   : experimental
// minimal of     : MIN ((i1*w1), (i2*w2), (i3*w3))   : experimental
/////////////////////////////////////////////////////





//-----------------------------------------------------------------------
// DEFAULT PARAMETERS
int NEAT::time_alive_minimum = 100;

// Traits
double NEAT::trait_param_mut_prob = 0;
double NEAT::trait_mutation_power = 0; // Power of mutation on a signle trait param 
double NEAT::linktrait_mut_sig = 0; // Amount that mutation_num changes for a trait change inside a link
double NEAT::nodetrait_mut_sig = 0; // Amount a mutation_num changes on a link connecting a node that changed its trait 
double NEAT::mutate_random_trait_prob = 0;
double NEAT::mutate_link_trait_prob = 0;
double NEAT::mutate_node_trait_prob = 0;

// General NEAT/GA params
int    NEAT::pop_size = 64;            // Size of population 
int    NEAT::dropoff_age = 20;         // Age where Species starts to be penalized 
double NEAT::age_significance = 1.0;  // Species niching multiplier (young given a boost)
double NEAT::old_age_penalty  = 0.01; // Species penalization multiplier
double NEAT::survival_thresh = 0.2;   // Percent of individuals to survive (1.0 = 100%)
double NEAT::mutate_only_prob = 0;    // Prob. of an asexual reproduction 

double NEAT::disjoint_coeff = 1;
double NEAT::excess_coeff = 1;
double NEAT::mutdiff_coeff = 1;
double NEAT::biasdiff_coeff = 1;
double NEAT::time_constant_diff_coeff = 1;
double NEAT::func_diff_coeff = 1;
double NEAT::sfunc_diff_coeff = 1;

double NEAT::compat_threshold = 1.0;
int    NEAT::elitism_tresh  = 5;
int    NEAT::species_target = 1;
int    NEAT::dynamic_compat_threshold = 1;
double NEAT::dynamic_compat_mod = 0.3;
double NEAT::dynamic_compat_min = 0.3;


// Weight mutations
double NEAT::mutate_link_weights_prob = 0;
double NEAT::mutate_link_weights_min_prob = 0;
double NEAT::mutate_link_weights_max_prob = 0;
double NEAT::weight_mut_power = 0; // The power of a linkweight mutation 
double NEAT::weight_cap_max = 3.0;
double NEAT::weight_cap_min = -3.0;
double NEAT::weight_mut_severe_prob = 0.5;

double NEAT::mutate_toggle_enable_prob = 0;
double NEAT::mutate_gene_reenable_prob = 0;

// Structural mutations
double NEAT::mutate_add_node_prob = 0;
double NEAT::mutate_add_link_prob = 0;
double NEAT::mutate_rem_link_prob = 0;
double NEAT::mutate_rem_link_percent = 0;

// Recurrent connections
double NEAT::recur_prob = 0;
double NEAT::recur_only_prob = 0;  // Probability of forcing selection of ONLY links that are naturally recurrent 
double NEAT::recur_loop_prob = 0;

// Node internal mutations
double NEAT::bias_clamp = 1;
double NEAT::max_time_constant = 5;
double NEAT::min_time_constant = 0.11;

double NEAT::time_constant_mut_power = 1.0;
double NEAT::time_constant_mut_prob = 0.2;
double NEAT::bias_mut_power = 0.5;
double NEAT::bias_mut_prob = 0.2;

double NEAT::mutate_node_functions_prob = 0;
double NEAT::mutate_node_sum_functions_prob = 0;
double NEAT::mutate_node_functions_percent = 0;
double NEAT::mutate_node_sum_functions_percent = 0;

// Node function specific mutation probabilities
// Indicates the probability for a node's activation/sum function to
// become one of these
double NEAT::func_sigmoid_prob = 1.0;
double NEAT::func_gauss_prob = 0.0;
double NEAT::func_sin_prob = 0.0;
double NEAT::func_cos_prob = 0.0;
double NEAT::func_sqr_prob = 0.0;
double NEAT::func_sqrt_prob = 0.0;
double NEAT::func_exp_prob = 0.0;
double NEAT::func_log_prob = 0.0;
double NEAT::func_inv_prob = 0.0;
double NEAT::func_abs_prob = 0.0;
double NEAT::func_linear_prob = 0.0;

double NEAT::sfunc_add_prob = 1.0;
double NEAT::sfunc_mul_prob = 0.0;

// Mating
double NEAT::interspecies_mate_rate = 0.0; // Prob. of a mate being outside species 
double NEAT::mate_multipoint_prob = 0;     
double NEAT::mate_multipoint_avg_prob = 0;
double NEAT::mate_singlepoint_prob = 0;
double NEAT::mate_slower_growth_prob = 0.0;
double NEAT::mate_only_prob = 0; // Prob. of mating without mutation 


int NEAT::newlink_tries = 10;  // Number of tries mutate_add_link will attempt to find an open link 
int NEAT::func_tries = 10;
int NEAT::print_every = 0; // Tells to print population to file every n generations 
int NEAT::babies_stolen = 0; // The number of babies to siphen off to the champions 
int NEAT::num_runs = 1;

////////////////////////////
// Some utility functions //
////////////////////////////

int NEAT::getUnitCount(const char *string, const char *set)
{
	int count = 0;
	short last = 0;
	while(*string)
	{
		last = *string++;

		for(int i =0; set[i]; i++)
		{
			if(last == set[i])
			{
				count++;
				last = 0;
				break;
			}   
		}
	}
	if(last)
		count++;
	return count;
}   


bool NEAT::load_neat_params(const char *filename, bool output) 
{
    std::ifstream paramFile(filename);

	if(!paramFile) 
	{
		return false;
	}
	char curword[1024];


	// **********LOAD IN PARAMETERS*************** //
	// while not encountered EOF

	while(!paramFile.eof())
	{
		paramFile>>curword;

		std::string wrd(curword);

//		if (wrd == "num_runs") paramFile>>NEAT::num_runs;
//		if (wrd == "time_alive_minimum") paramFile>>NEAT::time_alive_minimum;
//		if (wrd == "elitism_tresh") paramFile>>NEAT::elitism_tresh;

		if (wrd == "trait_param_mut_prob") paramFile>>NEAT::trait_param_mut_prob;
		if (wrd == "trait_mutation_power") paramFile>>NEAT::trait_mutation_power; 
		if (wrd == "linktrait_mut_sig") paramFile>>NEAT::linktrait_mut_sig; 
		if (wrd == "nodetrait_mut_sig") paramFile>>NEAT::nodetrait_mut_sig;
		if (wrd == "weight_mut_power") paramFile>>NEAT::weight_mut_power;
		if (wrd == "recur_prob") paramFile>>NEAT::recur_prob;
		
		if (wrd == "disjoint_coeff") paramFile>>NEAT::disjoint_coeff;
		if (wrd == "excess_coeff") paramFile>>NEAT::excess_coeff;
		if (wrd == "mutdiff_coeff") paramFile>>NEAT::mutdiff_coeff;
		if (wrd == "func_diff_coeff") paramFile>>NEAT::func_diff_coeff;
		if (wrd == "sfunc_diff_coeff") paramFile>>NEAT::sfunc_diff_coeff;
		if (wrd == "compat_threshold") paramFile>>NEAT::compat_threshold;

		if (wrd == "age_significance") paramFile>>NEAT::age_significance;
		if (wrd == "survival_thresh") paramFile>>NEAT::survival_thresh;
		if (wrd == "species_target") paramFile>>NEAT::species_target;
		if (wrd == "dynamic_compat_threshold") paramFile>>NEAT::dynamic_compat_threshold;
		if (wrd == "dynamic_compat_mod") paramFile>>NEAT::dynamic_compat_mod;
		if (wrd == "dynamic_compat_min") paramFile>>NEAT::dynamic_compat_min;

		if (wrd == "mutate_only_prob") paramFile>>NEAT::mutate_only_prob;
		if (wrd == "mutate_random_trait_prob") paramFile>>NEAT::mutate_random_trait_prob;
		if (wrd == "mutate_link_trait_prob") paramFile>>NEAT::mutate_link_trait_prob;
		if (wrd == "mutate_node_trait_prob") paramFile>>NEAT::mutate_node_trait_prob;
		if (wrd == "mutate_link_weights_prob") paramFile>>NEAT::mutate_link_weights_prob;
		if (wrd == "mutate_link_weights_min_prob") paramFile>>NEAT::mutate_link_weights_min_prob;
		if (wrd == "mutate_link_weights_max_prob") paramFile>>NEAT::mutate_link_weights_max_prob;
		if (wrd == "mutate_toggle_enable_prob") paramFile>>NEAT::mutate_toggle_enable_prob;
		if (wrd == "mutate_gene_reenable_prob") paramFile>>NEAT::mutate_gene_reenable_prob;
		if (wrd == "mutate_add_node_prob") paramFile>>NEAT::mutate_add_node_prob;
		if (wrd == "mutate_add_link_prob") paramFile>>NEAT::mutate_add_link_prob;

		if (wrd == "interspecies_mate_rate") paramFile>>NEAT::interspecies_mate_rate;

		if (wrd == "mate_multipoint_prob") paramFile>>NEAT::mate_multipoint_prob;
		if (wrd == "mate_multipoint_avg_prob") paramFile>>NEAT::mate_multipoint_avg_prob;
		if (wrd == "mate_singlepoint_prob") paramFile>>NEAT::mate_singlepoint_prob;
		if (wrd == "mate_slower_growth_prob") paramFile>>NEAT::mate_slower_growth_prob;
		if (wrd == "mate_only_prob") paramFile>>NEAT::mate_only_prob;
		if (wrd == "recur_only_prob") paramFile>>NEAT::recur_only_prob;

		if (wrd == "pop_size") paramFile>>NEAT::pop_size;
		if (wrd == "dropoff_age") paramFile>>NEAT::dropoff_age;
		if (wrd == "newlink_tries") paramFile>>NEAT::newlink_tries;
		if (wrd == "func_tries") paramFile>>NEAT::func_tries;
		if (wrd == "print_every") paramFile>>NEAT::print_every;
		if (wrd == "babies_stolen") paramFile>>NEAT::babies_stolen;
		if (wrd == "num_runs") paramFile>>NEAT::num_runs;
		if (wrd == "time_alive_minimum") paramFile>>NEAT::time_alive_minimum;
		if (wrd == "weight_cap_max") paramFile>>NEAT::weight_cap_max;
		if (wrd == "weight_cap_min") paramFile>>NEAT::weight_cap_min;

		if (wrd == "biasdiff_coeff") paramFile>>NEAT::biasdiff_coeff;
		if (wrd == "time_constant_diff_coeff") paramFile>>NEAT::time_constant_diff_coeff;
		if (wrd == "bias_clamp") paramFile>>NEAT::bias_clamp;
		if (wrd == "max_time_constant") paramFile>>NEAT::max_time_constant;
		if (wrd == "min_time_constant") paramFile>>NEAT::min_time_constant;

		if (wrd == "time_constant_mut_power") paramFile>>NEAT::time_constant_mut_power;
		if (wrd == "time_constant_mut_prob") paramFile>>NEAT::time_constant_mut_prob;
		if (wrd == "bias_mut_power") paramFile>>NEAT::bias_mut_power;
		if (wrd == "bias_mut_prob") paramFile>>NEAT::bias_mut_prob;
		if (wrd == "recur_loop_prob") paramFile>>NEAT::recur_loop_prob;

		if (wrd == "elitism_tresh") paramFile>>NEAT::elitism_tresh;
		if (wrd == "old_age_penalty") paramFile>>NEAT::old_age_penalty;

		if (wrd == "mutate_rem_link_prob") paramFile>>NEAT::mutate_rem_link_prob;
		if (wrd == "mutate_rem_link_percent") paramFile>>NEAT::mutate_rem_link_percent;

		if (wrd == "mutate_node_functions_prob") paramFile>>NEAT::mutate_node_functions_prob;
		if (wrd == "mutate_node_functions_percent") paramFile>>NEAT::mutate_node_functions_percent;
		if (wrd == "mutate_node_sum_functions_prob") paramFile>>NEAT::mutate_node_sum_functions_prob;
		if (wrd == "mutate_node_sum_functions_percent") paramFile>>NEAT::mutate_node_sum_functions_percent;

		if (wrd == "func_sigmoid_prob") paramFile>>NEAT::func_sigmoid_prob;
		if (wrd == "func_gauss_prob") paramFile>>NEAT::func_gauss_prob;
		if (wrd == "func_sin_prob") paramFile>>NEAT::func_sin_prob;
		if (wrd == "func_cos_prob") paramFile>>NEAT::func_cos_prob;
		if (wrd == "func_sqr_prob") paramFile>>NEAT::func_sqr_prob;
		if (wrd == "func_sqrt_prob") paramFile>>NEAT::func_sqrt_prob;
		if (wrd == "func_exp_prob") paramFile>>NEAT::func_exp_prob;
		if (wrd == "func_log_prob") paramFile>>NEAT::func_log_prob;
		if (wrd == "func_inv_prob") paramFile>>NEAT::func_inv_prob;
		if (wrd == "func_abs_prob") paramFile>>NEAT::func_abs_prob;
		if (wrd == "func_linear_prob") paramFile>>NEAT::func_linear_prob;

		if (wrd == "sfunc_add_prob") paramFile>>NEAT::sfunc_add_prob;
		if (wrd == "sfunc_mul_prob") paramFile>>NEAT::sfunc_mul_prob;
		if (wrd == "weight_mut_severe_prob") paramFile>>NEAT::weight_mut_severe_prob;
	}

	paramFile.close();
	return true;
}


double NEAT::gaussrand() 
{
	static int iset=0;
	static double gset;
	double fac,rsq,v1,v2;

	if (iset==0) 
	{
		do 
		{
			v1=2.0*(randfloat())-1.0;
			v2=2.0*(randfloat())-1.0;
			rsq=v1*v1+v2*v2;
		} while (rsq>=1.0 || rsq==0.0);
		fac=sqrt(-2.0*log(rsq)/rsq);
		gset=v1*fac;
		iset=1;
		return v2*fac;
	}
	else 
	{
		iset=0;
		return gset;
	}
}


////////////////////////////
// Learning functions     //
////////////////////////////

double NEAT::oldhebbian(double weight, double maxweight, double active_in, double active_out, double hebb_rate, double pre_rate, double post_rate) {

	bool neg=false;
	double delta;

	//double weight_mag;

	if (maxweight<5.0) maxweight=5.0;

	if (weight>maxweight) weight=maxweight;

	if (weight<-maxweight) weight=-maxweight;

	if (weight<0) {
		neg=true;
		weight=-weight;
	}

	//if (weight<0) {
	//  weight_mag=-weight;
	//}
	//else weight_mag=weight;

	if (!(neg)) {
		//if (true) {
		delta=
			hebb_rate*(maxweight-weight)*active_in*active_out+
			pre_rate*(weight)*active_in*(active_out-1.0)+
			post_rate*(weight)*(active_in-1.0)*active_out;

		//delta=delta-hebb_rate/2; //decay

		//delta=delta+randposneg()*randfloat()*0.01; //noise

		//cout<<"delta: "<<delta<<endl;

		if (weight+delta>0)
			return weight+delta;
		//else return 0.01;

		//return weight+delta;

	}
	else {
		//In the inhibatory case, we strengthen the synapse when output is low and
		//input is high
		delta=
			hebb_rate*(maxweight-weight)*active_in*(1.0-active_out)+ //"unhebb"
			//hebb_rate*(maxweight-weight)*(1.0-active_in)*(active_out)+
			-5*hebb_rate*(weight)*active_in*active_out+ //anti-hebbian
			//hebb_rate*(maxweight-weight)*active_in*active_out+
			//pre_rate*weight*active_in*(active_out-1.0)+
			//post_rate*weight*(active_in-1.0)*active_out;
			0;

		//delta=delta-hebb_rate; //decay

		//delta=delta+randposneg()*randfloat()*0.01; //noise

		if (-(weight+delta)<0)
			return -(weight+delta);
		else return -0.01;

		return -(weight+delta);

	}

	return 0;

}

double NEAT::hebbian(double weight, double maxweight, double active_in, double active_out, double hebb_rate, double pre_rate, double post_rate) {

	bool neg=false;
	double delta;

	//double weight_mag;

	double topweight;

	if (maxweight<5.0) maxweight=5.0;

	if (weight>maxweight) weight=maxweight;

	if (weight<-maxweight) weight=-maxweight;

	if (weight<0) {
		neg=true;
		weight=-weight;
	}


	//if (weight<0) {
	//  weight_mag=-weight;
	//}
	//else weight_mag=weight;


	topweight=weight+2.0;
	if (topweight>maxweight) topweight=maxweight;

	if (!(neg)) {
		//if (true) {
		delta=
			hebb_rate*(maxweight-weight)*active_in*active_out+
			pre_rate*(topweight)*active_in*(active_out-1.0);
		//post_rate*(weight+1.0)*(active_in-1.0)*active_out;

		//delta=delta-hebb_rate/2; //decay

		//delta=delta+randposneg()*randfloat()*0.01; //noise

		//cout<<"delta: "<<delta<<endl;

		//if (weight+delta>0)
		//  return weight+delta;
		//else return 0.01;

		return weight+delta;

	}
	else {
		//In the inhibatory case, we strengthen the synapse when output is low and
		//input is high
		delta=
			pre_rate*(maxweight-weight)*active_in*(1.0-active_out)+ //"unhebb"
			//hebb_rate*(maxweight-weight)*(1.0-active_in)*(active_out)+
			-hebb_rate*(topweight+2.0)*active_in*active_out+ //anti-hebbian
			//hebb_rate*(maxweight-weight)*active_in*active_out+
			//pre_rate*weight*active_in*(active_out-1.0)+
			//post_rate*weight*(active_in-1.0)*active_out;
			0;

		//delta=delta-hebb_rate; //decay

		//delta=delta+randposneg()*randfloat()*0.01; //noise

		//if (-(weight+delta)<0)
		//  return -(weight+delta);
		//  else return -0.01;

		return -(weight+delta);

	}
}



/////////////////////////////////////////////////////////
// Activation functions - SIGNED (return in [-1 .. 1]) //
/////////////////////////////////////////////////////////

#ifndef USE_FAST_SIGMOID

inline double NEAT::af_sigmoid_signed(double activesum,double slope,double constant) 
{
	return ((1/(1+(exp(-(slope*activesum-constant)))))-0.5)*2.0; 
}

#else

///////////////////////////////////////////////////////////////////////////////////////
// This is an approximation of the standard sigmoid that runs MUCH faster (about 50%)
double NEAT::af_sigmoid_signed(double aNetinput, double aResponse, double shit)
{
	const double c0 = 0.5000f;
	const double c1 = 0.2780f;
	const double c2 = -0.0474f;
	const double c3 = -2.4015e-004f;
	const double c4 = 8.9276e-004f;
	const double c5 = -9.0291e-005f;
	const double c6 = 2.8028e-006f;
	const double tUpperAndLowerLimit = 7.92871952056884f;

	double x = aNetinput / aResponse;

	if( x > tUpperAndLowerLimit)
	return 1.0f;

	if(x < -tUpperAndLowerLimit)
	return 0.0f;

	bool tLessThanZero = false;

	if(x < 0.0f)
	{
		x *= -1.0f;
		tLessThanZero = true;
	}

	double xmul = x;
	double tOutput1 = c0;

	tOutput1 += c1*xmul;
	xmul *= x;
	tOutput1 += c2*xmul;
	xmul *= x;
	tOutput1 += c3*xmul;
	xmul *= x;
	tOutput1 += c4*xmul;
	xmul *= x;
	tOutput1 += c5*xmul;
	xmul *= x;
	tOutput1 += c6*xmul;

	double ret;

	if(!tLessThanZero)
		ret = tOutput1;
	else
		ret = 1.0f - tOutput1;

	return (ret-0.5)*2;
}

#endif



inline double NEAT::af_sin_signed(double x)
{
	return sin(x);
}

inline double NEAT::af_cos_signed(double x)
{
	return cos(x);
}


inline double NEAT::af_gauss_signed(double x, double a, double b)
{
	return (exp(-(x*x))-0.5)*2.0;
}



//////////////////////////////////////////////////////////
// Activation functions - UNSIGNED (return in [0 .. 1]) //
//////////////////////////////////////////////////////////

#ifndef USE_FAST_SIGMOID

inline double NEAT::af_sigmoid_unsigned(double activesum,double slope,double constant) 
{
	return (1/(1+(exp(-(slope*activesum-constant))))); 
}

#else

///////////////////////////////////////////////////////////////////////////////////////
// This is an approximation of the standard sigmoid that runs MUCH faster (about 50%)
double NEAT::af_sigmoid_unsigned(double aNetinput, double aResponse, double shit)
{
	const double c0 = 0.5000f;
	const double c1 = 0.2780f;
	const double c2 = -0.0474f;
	const double c3 = -2.4015e-004f;
	const double c4 = 8.9276e-004f;
	const double c5 = -9.0291e-005f;
	const double c6 = 2.8028e-006f;
	const double tUpperAndLowerLimit = 7.92871952056884f;

	double x = aNetinput / aResponse;

	if( x > tUpperAndLowerLimit)
	return 1.0f;

	if(x < -tUpperAndLowerLimit)
	return 0.0f;

	bool tLessThanZero = false;

	if(x < 0.0f)
	{
		x *= -1.0f;
		tLessThanZero = true;
	}

	double xmul = x;
	double tOutput1 = c0;

	tOutput1 += c1*xmul;
	xmul *= x;
	tOutput1 += c2*xmul;
	xmul *= x;
	tOutput1 += c3*xmul;
	xmul *= x;
	tOutput1 += c4*xmul;
	xmul *= x;
	tOutput1 += c5*xmul;
	xmul *= x;
	tOutput1 += c6*xmul;

	double ret;

	if(!tLessThanZero)
		ret = tOutput1;
	else
		ret = 1.0f - tOutput1;

    return ret;
}

#endif



inline double NEAT::af_sin_unsigned(double x)
{
	return (sin(x)+1)/2.0;
}

inline double NEAT::af_cos_unsigned(double x)
{
	return (cos(x)+1)/2.0;
}

inline double NEAT::af_gauss_unsigned(double x, double a, double b)
{
	return exp(-(x*x));
}





////////////////////////////////////////////////////////////////////////
// Activation functions - mathematical (may range up to +/- infinity) //
////////////////////////////////////////////////////////////////////////

// this is always unsigned
inline double NEAT::af_sqr(double x)
{
	// simple square function
	return x*x;
}

// this is always unsigned
inline double NEAT::af_sqrt(double x) // does error checking
{
	double y;
	// square root
	if (x > 0)
	{
		y=sqrt(x);
	}
	else
	{
		y = 0;
	}

	return y;
}

// this is always unsigned
inline double NEAT::af_exp(double x)  // does error checking
{
	return exp(x);
}

// this is always unsigned
inline double NEAT::af_log(double x)  // does error checking
{
	double y;
	if (x > 0)
	{
		y = log(x);
	}
	else
	{
		y = 0;
	}

	return y;
}

// pure mathematical function.
// does not make sense to change sign.
inline double NEAT::af_inv(double x)  // does error checking
{
	double y;

	if (x != 0)
	{
		y = 1.0 / x;
	}
	else
	{
		y = 1;
	}

	return y;
}

// this is always unsigned
inline double NEAT::af_abs(double x)
{
	return abs(x);
}

// pure mathematical function.
// does not make sense to change sign.
inline double NEAT::af_linear(double x)
{
	return x;
}








#include "headers.h"
#include "physics.h"
#include "graphics.h"

//#include "neat\substrate.h"
#include "..\neat\substrate.h"

//#include "neat\network.h"
#include "..\neat\network.h"

#include <time.h>

/*#pragma comment (lib, "irrlicht.lib");
#pragma comment (lib, "winmm.lib");
*/



#define Pressed(x) ((GetAsyncKeyState(x) & 0x8000)!=0)


#define HYPERNEAT
using namespace NEAT;

double dtime;
double steppingThreshold=0.138;//0.21;

// in seconds
#define TIME_TO_LIVE 10
#define NUM_TRIALS 1

// ignore that
#define UPRIGHTNESS_FACTOR 10.91

//#define HEAD_CUT_FACTOR 0.8 // original
#define HEAD_CUT_FACTOR 0.8

#define PHYSICS_STEP_SIZE 0.02

//#define USE_SPRING
#define SPRING_ORIGIN_Y 5.0
#define SPRING_STIFFNESS 15

//#define FREEZE_TORSO
//#define PUSH_FORWARD
//#define PUSH_FORWARD_FORCE 10

#define RANDOM_DROP_HEIGHT_POWER 0.0

#define DO_PHYSICS

double best_fitness_ever=0;

HWND nn_info_wnd;
HDC dc;
// Bitmap for the 3D view
HBITMAP hbmp=NULL;
char* bitmap_video_buffer;

HDC hsrc;
BITMAPINFO *pbmi;

// Initializes the 3D view
void init_bitmap_buffer()
{
  if (hbmp) DeleteObject(hbmp),hbmp=NULL;

  pbmi =(BITMAPINFO *)malloc(sizeof(BITMAPINFO));

  pbmi->bmiHeader.biSize=sizeof(pbmi->bmiHeader);
  pbmi->bmiHeader.biWidth=640;
  pbmi->bmiHeader.biHeight=-480;
  pbmi->bmiHeader.biPlanes=1;
  pbmi->bmiHeader.biBitCount=16;
  pbmi->bmiHeader.biCompression=BI_RGB;
  pbmi->bmiHeader.biSizeImage=0;
  pbmi->bmiHeader.biXPelsPerMeter=0;
  pbmi->bmiHeader.biYPelsPerMeter=0;
  pbmi->bmiHeader.biClrUsed=0;
  pbmi->bmiHeader.biClrImportant=0;

  hbmp=CreateDIBSection(NULL,pbmi,DIB_RGB_COLORS,(void  **)&bitmap_video_buffer,NULL,0);

  hsrc=CreateCompatibleDC(dc);

  SelectObject(hsrc,hbmp);
}
void update_screen() {BitBlt(dc,0,0,640,480,hsrc,0,0,SRCCOPY);}
void clear_buffer() {memset(bitmap_video_buffer,0,(640*480)*2);}


int create_info_window()
{

	WNDCLASSEX winclass; 
	HWND	   hwnd;	 

	// first fill in the window class stucture
	winclass.cbSize       = sizeof(WNDCLASSEX);
	winclass.style			  = CS_HREDRAW | CS_VREDRAW;
	winclass.lpfnWndProc	= DefWindowProc;
	winclass.cbClsExtra		= 0;
	winclass.cbWndExtra		= 0;
	winclass.hInstance		= 0;//hinstance;
	winclass.hIcon			  = 0;//LoadIcon(hinstance, MAKEINTRESOURCE(0));
	winclass.hCursor		  = LoadCursor(NULL, IDC_ARROW); 
	winclass.hbrBackground= NULL; 
	winclass.lpszMenuName	= NULL;
	winclass.lpszClassName= "ClassName";
	winclass.hIconSm      = 0;//LoadIcon(hinstance, MAKEINTRESOURCE(0));

	// register the window class
	if (!RegisterClassEx(&winclass))
	{
		MessageBox(NULL, "Error Registering Class!", "Error", 0);
    return 0;
	}

    nn_info_wnd = CreateWindow ("ClassName",
             "Neural Network View",
	     WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
             0,
             0,
             640,
             510,
             NULL,
             NULL,
             0,
             NULL);

  
    //Show the window
	ShowWindow(nn_info_wnd, SW_SHOWDEFAULT );
	UpdateWindow(nn_info_wnd);

	dc = GetDC(nn_info_wnd);

	init_bitmap_buffer();
}

extern NEAT::Substrate* subst;

int main()
{
	srand(time(0));
//	srand(1);

	char filename[255];
	filename[0]=0;

	printf("Neuro-Evolving Virtual Humans v1.0\n------------------------------------\n\n");
	printf("Controls:\nF - fast/normal mode\nC - CPPN/substrate view\n\n");
	printf("Enter a file name for the seed genome\n");
	printf("or type \"no\" and press ENTER to start evolution from scratch: ");
	scanf("%s", filename);
	printf("\n\n\n");

	if (strcmp(filename, "no") == 0)
	{
		init_population(0);
	}
	else
	{
		init_population(filename);
	}


	create_info_window();
	init_graphics();
	init_physics();



	bool fastmode = true;
	bool draw_cppns = true;
	bool f_pressed = false;
	bool c_pressed = false;
    HBRUSH br = CreateSolidBrush(RGB(0,0,0));

	HANDLE h = GetCurrentProcess();
	SetPriorityClass(h, BELOW_NORMAL_PRIORITY_CLASS);

	while(1)
	{
		for(int i=0; i< NEAT::pop_size; i++)
		{
			printf("ORG #%d SPEC #%d... ",i, pop->organisms[i]->species->id);
			// Create the big network
#ifdef HYPERNEAT
			NEAT::Network* bignet = create_hyper_phenotype(pop->organisms[i]->net, subst);
#endif

#ifdef HYPERNEAT
			if (!draw_cppns)
			{
				SetWindowTextA(nn_info_wnd, "Neural network (substrate) view");
			}
			else
			{
				SetWindowTextA(nn_info_wnd, "CPPN view");
			}
#else
			SetWindowTextA(nn_info_wnd, "Neural network view");
#endif
			RECT r;
			r.top = 0;
			r.bottom = 480;
			r.left = 640;
			r.right = 0;

			int steps_remaining;

			// evaluate this network 
			for(int j = 0; j< NUM_TRIALS; j++)
			{
				// 1 meter tall human
#ifdef HYPERNEAT
				Human* bastard = new Human(physics_world, physics_space, 0, 1.0 + randfloat()*RANDOM_DROP_HEIGHT_POWER, 0, 1.0, bignet);
#else
				Human* bastard = new Human(physics_world, physics_space, 0, 0.9, 0, 1.0, pop->organisms[i]->net);
#endif		
			    // SIMULATE
				int steps=0;
				double avg_head_height=0;
				double max_head_height=0;
				double torso_z_distance=0;
				double feet_z_distance=0;
				double step_size = PHYSICS_STEP_SIZE;
				steps_remaining = (int)((double)TIME_TO_LIVE / step_size);

				bastard->brain->activate_CTRNN(0.01, false); // to see initial biases

				bool stop=false;

				double numberOfStepsTaken=0;
				double previousLeftFootHeight=0;
				double previousRightFootHeight=0;
				char lastFootThatStepped=0;

				previousLeftFootHeight = bastard->LeftFootHeight();
				previousRightFootHeight = bastard->RightFootHeight();

			//	f_pressed = false;
				while((steps_remaining>0) && !stop)
				{  
					device->run();

					// show the NN anyway
					clear_buffer();
#ifdef HYPERNEAT
					if (draw_cppns)
					{
						Draw_NN(pop->organisms[i]->net, hsrc, 640, 480-35, NN_DRAWING_CPPN, 1, 4);
					}
					else
					{
						Draw_NN(bignet, hsrc, 640, 480-35, NN_DRAWING_SUBSTRATE, 0, 1);
					}
#else
					Draw_NN(pop->organisms[i]->net, hsrc, 0, 3);
#endif
					update_screen();
					InvalidateRect(nn_info_wnd, NULL, true);

					if (!(Pressed('F')) && f_pressed) 
					{   fastmode = !fastmode; f_pressed = false; }
					if (Pressed('F')) 
					{  	f_pressed = true; }

					if (!fastmode)
					{
						dtime = ElapsedTime();

						// calculate how many physics steps need to be done this frame
						steps =(int) ceilf(dtime / step_size);
						steps_remaining -= steps;
					}
					else
					{
						steps = steps_remaining;
					}

					for(int ns=0; ns<steps; ns++)
					{
						if (!(Pressed('C')) && c_pressed)
						{   
							draw_cppns = !draw_cppns; c_pressed = false;
							if (!draw_cppns)
							{
//								Prepare_To_Draw_NN(bignet, 640,480-35, NN_DRAWING_SUBSTRATE);
     							SetWindowTextA(nn_info_wnd, "Neural network (substrate) view");
							}
							else
							{
//								Prepare_To_Draw_NN(pop->organisms[i]->net, 640,480-35, NN_DRAWING_NORMAL);
								SetWindowTextA(nn_info_wnd, "CPPN view");
							}
						}
						if (Pressed('C')) 
						{   c_pressed = true; }
						
						if (fastmode) steps_remaining--;

#ifdef USE_SPRING
						// hold the torso up with a spring
						double up_spring_y = SPRING_ORIGIN_Y;
						double down_spring_y = bastard->torso->GetPosition().Y;
						// force up
						double force_up = (up_spring_y - down_spring_y) * SPRING_STIFFNESS;
						if (force_up < 0) force_up = 0;

						dBodyAddForce(bastard->torso->GetBodyID(), 0, force_up, 0);
#endif
						/*dBodyAddForceAtRelPos(bastard->torso->GetBodyID(), 0, force_up, 0, 
							0, bastard->torso->GetYDimension() / 2.0, 0);*/

#ifdef FREEZE_TORSO
						dBodySetAngularVel(bastard->torso->GetBodyID(), 0, 0, 0);
						dBodySetLinearVel(bastard->torso->GetBodyID(), 0, 0, 0);
#endif

#ifdef PUSH_FORWARD
						dBodyAddForce(bastard->torso->GetBodyID(), 0, 0, PUSH_FORWARD_FORCE);
#endif

						// let the human control himself via "NN muscles" 
						bastard->UseBrain(step_size);


#ifdef DO_PHYSICS
						// do physics
						dSpaceCollide(physics_space, 0, &nearCollisionCallback);
						dWorldStep(physics_world, step_size);
						//dWorldQuickStep(physics_world, step_size);
						dJointGroupEmpty(conts);
#endif

    					// update fitness
						{
							//check for left foot steps
							if (bastard->LeftFootMovingDownward())
							{
								if (previousLeftFootHeight > steppingThreshold && 
									bastard->LeftFootHeight() < steppingThreshold &&
									lastFootThatStepped != 'l')
								{
									//foot just moved down past threshold
									numberOfStepsTaken++;
									lastFootThatStepped = 'l';
								}
							}

							//check for right foot steps
							if (bastard->RightFootMovingDownward())
							{
								if (previousRightFootHeight > steppingThreshold && 
									bastard->RightFootHeight() < steppingThreshold &&
									lastFootThatStepped != 'r')
								{
									//foot just moved down past threshold
									numberOfStepsTaken++;
									lastFootThatStepped = 'r';
								}
							}

							//setting variables
							previousLeftFootHeight = bastard->LeftFootHeight();
							previousRightFootHeight = bastard->RightFootHeight();


							double d;
							avg_head_height += bastard->head->GetPosition().Y;

							// termination cases
							if (bastard->head->GetPosition().Y < HEAD_CUT_FACTOR) { stop=true; break; }

							// the bastard must stay upright
							if ( fabs(bastard->GetHeadPosition().Z) > (fabs(bastard->torso->GetPosition().Z) + UPRIGHTNESS_FACTOR)) 
							   { stop=true; break; }

							if ( bastard->GetHeadPosition().Y > max_head_height) 
								max_head_height = bastard->GetHeadPosition().Y;
    					}
					}

					if (!fastmode)
					{
						// draw stuff
						bastard->Update();
						driver->beginScene(true, true, SColor(255,100,101,140));
						smgr->drawAll();
						guienv->drawAll();
    					driver->endScene();
                    //    Sleep(10);
					}

				} // end of trial

				// timesteps lived
				double total_lifetime = (((double)TIME_TO_LIVE / step_size));// - (double)steps_remaining;

				// average height of head for the livetime
				avg_head_height /= total_lifetime; 

				// the fitness function
				double cycles_sum = (bastard->hip1_cycles + bastard->hip2_cycles + bastard->knee1_cycles + bastard->knee2_cycles);
				
				// too many?
				if (cycles_sum > 20)
					cycles_sum = 0.00001; // extreme penalty

				if (steps_remaining == 0) steps_remaining=1;
				//if (numberOfStepsTaken < 2) numberOfStepsTaken = 0;

				{
				    pop->organisms[i]->fitness =
						//cycles_sum *
						sqr(numberOfStepsTaken) +
						//sqrt( sqr( bastard->torso->GetPosition().Z ) + sqr ( bastard->torso->GetPosition().X ) ) *
						//max_head_height
						//total_lifetime; // lifetime
						//(total_lifetime - (double)steps_remaining) * 
						avg_head_height;
				}

				// for jumping
	//			pop->organisms[i]->fitness = max_head_height;
 
				// penalty for falling below threshold height; penalty is greater for falling sooner
				//if (steps_remaining != 0) pop->organisms[i]->fitness /= (double)steps_remaining;

				// make sure the fitness is positive
				//if (pop->organisms[i]->fitness < 0) pop->organisms[i]->fitness = 0;
				//pop->organisms[i]->fitness *= 1000;

				printf("%3.6f : h1: %d h2: %d k1: %d k2: %d s: %3.2f\n", pop->organisms[i]->fitness, 
					bastard->hip1_cycles,bastard->hip2_cycles,bastard->knee1_cycles,bastard->knee2_cycles, numberOfStepsTaken);

     	     	delete bastard;
			}

#ifdef HYPERNEAT
			delete bignet;
#endif

			// final score
		}

		// next generation
		evolve();
	}

	device->drop();

	return 0;
}

#include "headers.h"

using namespace irr;
using namespace core;
using namespace scene;
using namespace video;
using namespace io;
using namespace gui;

#define GRAPHICS_SCALE 100.0

/////////////////////////
// 3D engine data
extern IrrlichtDevice *device;
extern IVideoDriver* driver;
extern ISceneManager* smgr;
extern IGUIEnvironment* guienv;

extern ISceneNode *ground;
extern ICameraSceneNode* cam;

void QuaternionToEuler(const dQuaternion quaternion, vector3df &euler);
void init_graphics();


import java.io.*;
import java.util.StringTokenizer;

public class XmlConverter {
    
    public static void main(String[] args) {
        String in = new String( args[0] );        
        convert( in );
    }
            
    public static void convert( String fileToConvert ) {
        int hintPosition = 1;
        int numInputNodes = 0;
        int numOutputNodes = 0;
        int numHiddenNodes = 0;
        StringBuffer xmlOutput = new StringBuffer();
        xmlOutput.append( "<network>\n" );
        xmlOutput.append( "<title>Test</title>\n" );
        try { 
            BufferedReader bufReader = new BufferedReader(new FileReader(fileToConvert)); 
            String line = null;
            while ((line=bufReader.readLine()) != null){ 
                StringTokenizer tokenizer = new StringTokenizer(line," "); 
                String geneType = tokenizer.nextToken();
                if ( geneType.equals("node") ) {
                    tokenizer.nextToken();
                    tokenizer.nextToken();
                    tokenizer.nextToken();
                    String type = tokenizer.nextToken();
                    if ( type.equals("1") || type.equals("3") ) {
                         numInputNodes++;  
                    }
                    if ( type.equals("2") ) {
                         numOutputNodes++;  
                    }
                    if ( type.equals("0") ) {
                         numHiddenNodes++;  
                    }
                }
            } 
        } catch (IOException e) { 
                System.err.println(e); 
                System.exit(1); 
        }

        int numNodesPerHidden = (int) Math.ceil( (numHiddenNodes / 8) + 1 );
        int nodeQuota = (int) numNodesPerHidden;
        int hidLayerIdx = 2;

        try {
            BufferedReader bufReader = new BufferedReader(new FileReader(fileToConvert)); 
            String line = null; 
            while ((line=bufReader.readLine()) != null){
                if ( numInputNodes == 0 ) {
                    hintPosition = 1;
                    numInputNodes = 100;
                }
                if ( numOutputNodes == 0 ) {
                    hintPosition = 1;
                    numOutputNodes = 100;
                }
                if ( nodeQuota == 0 ) {
                    hintPosition = 1;
                    nodeQuota = (int) numNodesPerHidden;
                    hidLayerIdx++;
                }
                StringTokenizer toke = new StringTokenizer(line," "); 
                String geneType = toke.nextToken();
                if ( geneType.equals("node") ) {
                    xmlOutput.append( "<neuron id=\"" );
                    String nodeId = toke.nextToken();
                    xmlOutput.append( nodeId );
                    xmlOutput.append( "\" type=\"" );
                    toke.nextToken();
                    toke.nextToken();
                    String nodeType = toke.nextToken();
                    if ( nodeType.equals("1") || nodeType.equals("3") ) {
                        xmlOutput.append( "in\" hint-layer=\"1\" hint-position=\"" + hintPosition + "\" />" );
                        hintPosition++;
                        numInputNodes--;   
                    }
                    if ( nodeType.equals("2") ) {
                        xmlOutput.append( "in\" hint-layer=\"10\" hint-position=\"" + hintPosition + "\" />" );
                        hintPosition++;
                        numOutputNodes--;   
                    }
                    if ( nodeType.equals("0") ) {
                        xmlOutput.append( "in\" hint-layer=\"" + hidLayerIdx + "\" hint-position=\"" + hintPosition + "\" />" );
                        hintPosition++;
                        nodeQuota--;   
                    }
                    xmlOutput.append( "\n" );
                }
                if ( geneType.equals("gene") ) {
                    xmlOutput.append( "<connection src-id=\"" );
                    toke.nextToken();
                    String sourceId = toke.nextToken();
                    xmlOutput.append( sourceId + "\" tgt-id=\"" );
                    String tgtId = toke.nextToken();
                    xmlOutput.append( tgtId + "\" weight=\"" );
                    String weight = toke.nextToken();
                    xmlOutput.append( weight + "\" recurrent=\"" );
                    String recurrency = toke.nextToken();
                    if ( recurrency.equals("1") ) {
                        xmlOutput.append( "true\" id=\"" );   
                    } else {
                        xmlOutput.append( "false\" id=\"" );  
                    }                   
                    String connId = toke.nextToken();
                    xmlOutput.append( connId + "\" />" );
                    xmlOutput.append( "\n" );
                }                
            }
            bufReader.close();
        } catch (IOException e) { 
            System.err.println(e); 
            System.exit(1); 
        }
        xmlOutput.append( "</network>" );
        System.out.print( xmlOutput.toString() );
        try { 
            PrintWriter out = new PrintWriter(new FileWriter("network.xml")); 
            out.print( xmlOutput.toString() ); 
            out.close();
        } catch (IOException e) { 
            System.err.println(e); 
            System.exit(1); 
        } 
    }
}
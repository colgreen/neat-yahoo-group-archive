////////////////////////
// Peter Chervenski
// spookey@abv.bg
////////////////////////

// OptionsDialog.cpp : implementation file
//

#include "stdafx.h"
#include "ActiveVision.h"
#include "OptionsDialog.h"
#include "ConfGeneratorsDialog.h"


// COptionsDialog dialog

IMPLEMENT_DYNAMIC(COptionsDialog, CDialog)

COptionsDialog::COptionsDialog(CWnd* pParent /*=NULL*/)
	: CDialog(COptionsDialog::IDD, pParent)
{

}

COptionsDialog::~COptionsDialog()
{
}

void COptionsDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(COptionsDialog, CDialog)
	ON_BN_CLICKED(IDC_BROWSE_SEED_BUTTON, &COptionsDialog::OnBnClickedBrowseSeedButton)
	ON_BN_CLICKED(IDC_CONF_GENERATORS, &COptionsDialog::OnBnClickedConfGenerators)
	ON_BN_CLICKED(IDC_NEAT_OPTIONS, &COptionsDialog::OnBnClickedNeatOptions)
END_MESSAGE_MAP()


// COptionsDialog message handlers

char name[1024];
void COptionsDialog::OnBnClickedBrowseSeedButton()
{
	CFileDialog filedlg(TRUE, "DNA" );
    memset(name, 0, sizeof(name));

	filedlg.GetOFN().lpstrFile = name;
	filedlg.GetOFN().nMaxFile  = 1024;

	filedlg.DoModal();

	SetDlgItemText(IDC_SEED_GENOME, name);
	// TODO: Add your control notification handler code here
}



extern int NUM_SAMPLES;

extern bool TRANSFORM_IMAGES_ROTATION;
extern bool TRANSFORM_IMAGES_ZOOM;
extern bool TRANSFORM_IMAGES_TRANSLATION;

extern int MAX_IMAGE_ROTATION;   //degrees 
extern int MAX_IMAGE_TRANSLATION;   //pixels
extern double MAX_IMAGE_ZOOM;  //percent/100

CConfGeneratorsDialog* ConfGeneratorsDialog;

void COptionsDialog::OnBnClickedConfGenerators()
{
	char str[256];

	if (ConfGeneratorsDialog != NULL) return;
	
	ConfGeneratorsDialog = new CConfGeneratorsDialog(this);

	ConfGeneratorsDialog->Create(IDD_CONF_GENERATORS_DIALOG, this);
	ConfGeneratorsDialog->ShowWindow(SW_SHOW);
	ConfGeneratorsDialog->UpdateWindow();

	// init the dialog with current values
	CWnd* pWnd;

	sprintf(str, "%d", NUM_SAMPLES);
	pWnd = ConfGeneratorsDialog->GetDlgItem(IDC_SAMPLES_PER_GEN);
	pWnd->SetWindowText(str);

	sprintf(str, "%d", MAX_IMAGE_ROTATION);
	pWnd = ConfGeneratorsDialog->GetDlgItem(IDC_MAX_IMAGE_ROTATION);
	pWnd->SetWindowText(str);

	sprintf(str, "%d", MAX_IMAGE_TRANSLATION);
	pWnd = ConfGeneratorsDialog->GetDlgItem(IDC_MAX_IMAGE_TRANSLATION);
	pWnd->SetWindowText(str);

	sprintf(str, "%3.1f", MAX_IMAGE_ZOOM * 100);
	pWnd = ConfGeneratorsDialog->GetDlgItem(IDC_MAX_IMAGE_ZOOM);
	pWnd->SetWindowText(str);

    if (TRANSFORM_IMAGES_ROTATION)
		ConfGeneratorsDialog->CheckDlgButton(IDC_ROTATE_IMAGES, 1);

    if (TRANSFORM_IMAGES_TRANSLATION)
		ConfGeneratorsDialog->CheckDlgButton(IDC_TRANSLATE_IMAGES, 1);

    if (TRANSFORM_IMAGES_ZOOM)
		ConfGeneratorsDialog->CheckDlgButton(IDC_ZOOM_IMAGES, 1);

	// run the dialog
	ConfGeneratorsDialog->RunModalLoop();
	ConfGeneratorsDialog->EndModalLoop(0);

	// set the values back
	ConfGeneratorsDialog->GetDlgItemTextA(IDC_SAMPLES_PER_GEN, str, 128);
	NUM_SAMPLES = atoi(str);

	ConfGeneratorsDialog->GetDlgItemTextA(IDC_MAX_IMAGE_ROTATION, str, 128);
	MAX_IMAGE_ROTATION = atoi(str);

	ConfGeneratorsDialog->GetDlgItemTextA(IDC_MAX_IMAGE_TRANSLATION, str, 128);
	MAX_IMAGE_TRANSLATION = atoi(str);

	ConfGeneratorsDialog->GetDlgItemTextA(IDC_MAX_IMAGE_ZOOM, str, 128);
	MAX_IMAGE_ZOOM = atof(str) / 100.0;


	if (ConfGeneratorsDialog->IsDlgButtonChecked(IDC_ROTATE_IMAGES))
	{
		TRANSFORM_IMAGES_ROTATION = true;
	}
	else
	{
		TRANSFORM_IMAGES_ROTATION = false;
	}

	if (ConfGeneratorsDialog->IsDlgButtonChecked(IDC_TRANSLATE_IMAGES))
	{
		TRANSFORM_IMAGES_TRANSLATION = true;
	}
	else
	{
		TRANSFORM_IMAGES_TRANSLATION = false;
	}

	if (ConfGeneratorsDialog->IsDlgButtonChecked(IDC_ZOOM_IMAGES))
	{
		TRANSFORM_IMAGES_ZOOM = true;
	}
	else
	{
		TRANSFORM_IMAGES_ZOOM = false;
	}

	delete ConfGeneratorsDialog;
	ConfGeneratorsDialog=NULL;
	// TODO: Add your control notification handler code here

	// TODO: Add your control notification handler code here
}

void COptionsDialog::OnBnClickedNeatOptions()
{
	// TODO: Add your control notification handler code here
}

////////////////////////
// Peter Chervenski
// spookey@abv.bg
////////////////////////


/////////////////////////////////
// Eye class implementation    //
/////////////////////////////////

#include "stdafx.h"
#include "image.h"
#include "float.h"
#include "eye.h"
#include "neat\utils.h"
#include "neat\math_vectors.h"
#include "neat\math_matrix.h"
#include "NEAT\organism.h"
#include "NEAT\network.h"
#include "OptionsDialog.h"

// parameter variables
// defaults loaded
int EYE_DIMENSIONS_X = 5;
int EYE_DIMENSIONS_Y = 5;

double MAX_DELTA_X  = 1.0;
double MAX_DELTA_Y  = 1.0;

bool   ENABLE_EYE_ROTATION = false;
double MAX_DELTA_ROTATION = 0.1;

double MAX_DELTA_Z = 0.075;

double MAX_ZOOM  = 100.0;
double MIN_ZOOM  = 1.0;

double LIFETIME  = 100.0;

bool AVERAGE_SAMPLING = false;

double OFF_IMAGE_INPUT = 1.0;

double ERROR_UPPER_LIMIT = 0.8;
double ERROR_LOWER_LIMIT = 0.2;


using namespace std;

RovingEye::RovingEye(NEAT::Network *n, image_t* thefield)
{
	brain = n;
	field = thefield;

	for(int i=0; i<brain->all_nodes.size(); i++) 
	{
		brain->all_nodes[i]->activation = 0.0;
		brain->all_nodes[i]->membranePotential = 0.0;
	}

	Set_Identity(matrix);

	cur_angle=0.0;
	cur_affinity = 0.0;
	aff = 0.0;
	weighted_affinity = 0.0;
	lifetime_sqr = 0.0;

	// start at the center of the field
	x_pos = matrix[3][0] = (double)field->x_size/2.0;
	y_pos = matrix[3][1] = (double)field->y_size/2.0;

	// zoom
	MAX_ZOOM = (double)field->x_size / EYE_DIMENSIONS_X;
	cur_zoom = MAX_ZOOM;

	timestep = 0;
	timesteps_remaining = LIFETIME;

	for(int i=1; i<=LIFETIME; i++)
    {
		lifetime_sqr += sqr(i);
	}

	fieldx = field->x_size;
	fieldy = field->y_size;
}

RovingEye::RovingEye()
{
	cur_affinity = 0.0;
	aff = 0.0;
	weighted_affinity = 0.0;
	lifetime_sqr = 0.0;

	Set_Identity(matrix);

	// start at the center of the field
	x_pos = 0;
	y_pos = 0;
	cur_angle=0.0;

	// middle zoom
	cur_zoom = MIN_ZOOM;

	timestep = 0;
	timesteps_remaining = LIFETIME;

	for(int i=1; i<=LIFETIME; i++)
    {
		lifetime_sqr += sqr(i);
	}

	fieldx = 0;
	fieldy = 0;
}



void RovingEye::reset()
{
	Set_Identity(matrix);
	cur_affinity = 0.0;
	aff = 0.0;
	weighted_affinity = 0.0;
	lifetime_sqr = 0.0;

	cur_angle=0.0;

	// start at the center of the field
	x_pos = matrix[3][0] = (double)field->x_size/2.0;
	y_pos = matrix[3][1] = (double)field->y_size/2.0;

	// zoom
	MAX_ZOOM = field->x_size / EYE_DIMENSIONS_X;
	cur_zoom = MAX_ZOOM;

	timestep = 0;
	timesteps_remaining = LIFETIME;

	for(int i=1; i<=LIFETIME; i++)
    {
		lifetime_sqr += sqr(i);
	}

	fieldx = field->x_size;
	fieldy = field->y_size;

	for(int i=0; i<brain->all_nodes.size(); i++) 
	{
		brain->all_nodes[i]->activation = 0.0;
		brain->all_nodes[i]->membranePotential = 0.0;
	}

//	brain->flush();
}


// Translate the eye matrix with (dx,dy) pixels from its current position
void RovingEye::move(double dx, double dy)
{
	matrix[3][0] += dx * MAX_DELTA_X;
	matrix[3][1] += dy * MAX_DELTA_Y;

	if (matrix[3][0] < 0) matrix[3][0] = 0;
	if (matrix[3][1] < 0) matrix[3][1] = 0;
	if (matrix[3][0] >= field->x_size) matrix[3][0] = field->x_size-1;
	if (matrix[3][1] >= field->y_size) matrix[3][1] = field->y_size-1;

/*	double eye_size_x = ((double)EYE_DIMENSIONS_X/2.0)*cur_zoom;
	double eye_size_y = ((double)EYE_DIMENSIONS_Y/2.0)*cur_zoom;

	// restrict the eye from moving off the image
	if ((matrix[3][0] - eye_size_x) < 0) 
		matrix[3][0] = eye_size_x;

	if ((matrix[3][1] - eye_size_y) < 0) 
		matrix[3][1] = eye_size_y;

	if ((matrix[3][0] + eye_size_x) >= field->x_size) 
		matrix[3][0] = (field->x_size-1) - eye_size_x;

	if ((matrix[3][1] + eye_size_y) >= field->y_size) 
		matrix[3][1] = (field->y_size-1) - eye_size_y;
*/
}



// Multiply the current zoom factor with dz
void RovingEye::zoom(double dz) // dz: [-1 .. 1]
{
	double z = (dz * MAX_DELTA_Z) + 1.0;
	cur_zoom *= z;

	if (cur_zoom < MIN_ZOOM) cur_zoom = MIN_ZOOM;
	if (cur_zoom > MAX_ZOOM) cur_zoom = MAX_ZOOM;
}

void RovingEye::rotate(double a)
{
	cur_angle += a * MAX_DELTA_ROTATION;
	if (cur_angle > 2*3.14) cur_angle = 0;
	if (cur_angle < -2*3.14) cur_angle = 0;

	Rotate_Matrix_Z(matrix, a * MAX_DELTA_ROTATION);
}



// OPTIMIZED VERSION
void RovingEye::input()
{
	// clear inputs array
	inputs.clear();
	double half_dim_x = (double)EYE_DIMENSIONS_X / 2.0;
	double half_dim_y = (double)EYE_DIMENSIONS_Y / 2.0;

	double off_x, off_y;

	if ((EYE_DIMENSIONS_X % 2) == 0)
	{
		off_x = 0;
	}
	else
	{
		off_x = 0.5;
	}

	if ((EYE_DIMENSIONS_Y % 2) == 0)
	{
		off_y = 0;
	}
	else
	{
		off_y = 0.5;
	}

	int pos=0;
	x_pos = matrix[3][0];
	y_pos = matrix[3][1];

	Matrix matrix_tmp;


if  (ENABLE_EYE_ROTATION)
{
	// init the matrix
	memcpy(matrix_tmp, matrix, sizeof(Matrix));

	// scale the matrix with zoom
	matrix_tmp[0][0] *= cur_zoom;
	matrix_tmp[1][0] *= cur_zoom;
	matrix_tmp[0][1] *= cur_zoom;
	matrix_tmp[1][1] *= cur_zoom;
}

if (!AVERAGE_SAMPLING)
{
	// Nearest neighborhood method. Fast.
	// for each receptor
	for(double ry = -half_dim_y; ry < half_dim_y; ry++)
	{
		for(double rx = -half_dim_x; rx < half_dim_x; rx++)
		{
			int dx,dy;

if (ENABLE_EYE_ROTATION)
{
			// this are the actual coordinates of receptors in image space
			dx = (rx + off_x) * matrix_tmp[0][0] + (ry + off_x) * matrix_tmp[1][0] + matrix_tmp[3][0];
			dy = (rx + off_y) * matrix_tmp[0][1] + (ry + off_y) * matrix_tmp[1][1] + matrix_tmp[3][1];
}
else
{
			dx = x_pos + (rx + off_x)*cur_zoom;
			dy = y_pos + (ry + off_y)*cur_zoom;
}
			// out of boundaries?
			if ((dx < 0) || (dy < 0) || (dx > (fieldx-1)) || (dy > (fieldy-1)))
			{
				inputs.push_back( OFF_IMAGE_INPUT );
			}
			// in boundaries
			else
			{
    			inputs.push_back( (double)(field->pixels[dy * fieldx + dx]) / 255.0 ); // normalize to [0..1]
			}
		}
	}
}
else
{
	// Average pixels. Slow, but quality. 
	// for each receptor
	for(double ry = -half_dim_y; ry < half_dim_y; ry++)
	{
		for(double rx = -half_dim_x; rx < half_dim_x; rx++)
		{
			int dx,dy;
			int dx2,dy2;

			// upper-left corner of receptor rectangle
			dx = x_pos + (rx+off_x)*cur_zoom;
			dy = y_pos + (ry+off_y)*cur_zoom;

			// lower-right corner of receptor rectangle
			dx2 = x_pos + (rx+1+off_x)*cur_zoom;
			dy2 = y_pos + (ry+1+off_y)*cur_zoom;

			// out of boundaries?
			if ((dx < 0) || (dy < 0) || (dx > (fieldx-1)) || (dy > (fieldy-1)) ||
				(dx2 < 0) || (dy2 < 0) || (dx2 > (fieldx-1)) || (dy2 > (fieldy-1)))
			{
				inputs.push_back( OFF_IMAGE_INPUT );
			}
			// in boundaries
			else
			{
				// Take the average value of the pixels occluded by the receptor
				// They are in the rectangle (dx,dy - dx2,dy2)
				unsigned int pixels_count = (dx2-dx) * (dy2-dy);
				unsigned int pixel_sum = 0;

				// if there is just one pixel, write it anyway
				if (pixels_count < 2)
				{
					inputs.push_back( (double)(field->pixels[dy * fieldx + dx]) / 255.0 ); // normalize to [0..1]
				}
				else
				{
					// averaging pixels...
					for(int x=dx;x<dx2;x++)
						for(int y=dy;y<dy2;y++)
							pixel_sum += field->pixels[y*fieldx + x];

					double average = (double)pixel_sum / (double)pixels_count;
					inputs.push_back( average / 255.0 ); // normalize to [0..1]
				}
			}
		}
	}
}

	// now the other inputs

	// current X position
    if ((matrix[3][0] < 0) || (matrix[3][0] >= field->x_size))
	{
		inputs.push_back( -1.0 );
	}
	else
	{
		inputs.push_back( matrix[3][0] / (double)field->x_size );
	}

	// current Y position
	if ((matrix[3][1] < 0) || (matrix[3][1] >= field->y_size))
	{
		inputs.push_back( -1.0 );
	}
	else
	{
		inputs.push_back( matrix[3][1] / (double)field->y_size );
	}

if (ENABLE_EYE_ROTATION)
{
	// current matrix orientation
	inputs.push_back( matrix[0][0] );
	inputs.push_back( matrix[0][1] );
	inputs.push_back( matrix[1][0] );
	inputs.push_back( matrix[1][1] );
}

	// current zoom
    double mrn = (cur_zoom-MIN_ZOOM) / (MAX_ZOOM-MIN_ZOOM);
	Clamp(mrn, 0.0, MAX_ZOOM);
    inputs.push_back( mrn );

	// hourglass
	inputs.push_back( (LIFETIME - timesteps_remaining) / LIFETIME );

	// bias
	inputs.push_back( 1.0 );

// avoid shit
	for(int i=0; i<inputs.size(); i++)
	{
		// NAN check
		if (_isnan(inputs[i]))
    	{
	        inputs[i]=0;
			//char msg[128];
			printf("NAN in input number %d\n", i);
    		//MessageBox(NULL, msg, "Error", MB_OK);
    	}
	}

	// load into the neural network
	brain->load_sensors(inputs);
}




void RovingEye::update()
{
	outputs.clear();
	int pos=0;

	// update time
	timestep++;
	timesteps_remaining--;

	// activate the network
//	brain->activate_CTRNN(0.02);
	brain->activate_normal();

	// fill the outputs vector
	for(int i=0; i< (brain->outputs.size()); i++)
	{
		outputs.push_back( brain->outputs[i]->activation );
	}

// avoid shit
	for(int i=0; i<outputs.size(); i++)
	{
		// NAN protection
		if (_isnan(outputs[i]))
    	{
			outputs[i]=0;
			//char msg[128];
			printf("NAN in output number %d\n", i);
			//MessageBox(NULL, msg, "Error", MB_OK);
    	}
	}


	
// interpret the results and move the eye
if (ENABLE_EYE_ROTATION)
{
	rotate((outputs[pos++]-0.5)*2.0);
//	rotate(outputs[pos++]);
}

	move((outputs[pos]-0.5)*2.0, (outputs[pos+1]-0.5)*2.0);
	pos++; pos++;
	zoom((outputs[pos++]-0.5)*2.0);
/*	move(outputs[pos], outputs[pos+1]);
	pos+=2;
	zoom(outputs[pos++]);
*/
	// update affinity
	cur_affinity = outputs[pos++];
//	cur_affinity = (outputs[pos++] * 0.5) + 0.5; // from [-1..1] back to [0..1]

	weighted_affinity += ((cur_affinity * sqr(timestep)) / lifetime_sqr);
//	weighted_affinity += ((cur_affinity * (timestep/LIFETIME)) / LIFETIME);
//	weighted_affinity += cur_affinity / LIFETIME;
//	weighted_affinity = cur_affinity;

	Clamp(weighted_affinity, 0.0, 1.0);
}


double RovingEye::compute_error(bool match)
{
 	double error=0.0;

	if (match)
	{
		if (weighted_affinity > ERROR_UPPER_LIMIT)
		{
			error = 0.0;
		}
		else
		{
			error = abs(weighted_affinity - ERROR_UPPER_LIMIT);
		}
	}
	else
	{
		if (weighted_affinity < ERROR_LOWER_LIMIT)
		{
			error = 0.0;
		}
		else
		{
			error = abs(weighted_affinity - ERROR_LOWER_LIMIT);
		}
	}
    
	return error;
}






#include "stdafx.h"

#ifndef IMAGE_GENERATOR_H
#define IMAGE_GENERATOR_H

#include <stdio.h>
#include <memory.h>
#include "image.h"
#include "neat\math_vectors.h"
#include "neat\math_matrix.h"


class BasicImageGenerator
{
public:

	int type;
	int generator_type;
	image_t* basic_data;

	BasicImageGenerator();
	BasicImageGenerator(int x_size, int y_size, int type);

	// Generates a new instance of the basic image in memory and returns its handle
	image_t* GenerateNew(); 
	
	// Generates an image that is copied into the given destination
	// The size of the destination image MUST be the same as the
	// generatior's basic data image. The type is overwritten. 
	// returns false on failure
	bool GenerateCopy(image_t* dest);
};


class FileImageGenerator : public BasicImageGenerator
{
public:
	
	FileImageGenerator(int x_size, int y_size, int type, char* filename);
};

#endif
////////////////////////
// Peter Chervenski
// spookey@abv.bg
////////////////////////


#include "stdafx.h"
#include <stdio.h>
#include <memory.h>
#include "image.h"
#include "neat\math_vectors.h"
#include "neat\math_matrix.h"
#include "ImageGenerator.h"



BasicImageGenerator::BasicImageGenerator(int x_size, int y_size, int type)
{
	basic_data = new_image(x_size, y_size, type);
	generator_type = 0; // basic
}

BasicImageGenerator::BasicImageGenerator()
{
	basic_data = NULL;
	type=0;
	generator_type=0;
}


image_t* BasicImageGenerator::GenerateNew()
{
	return clone_image(basic_data);
}

bool BasicImageGenerator::GenerateCopy(image_t *dest)
{
	if (basic_data != NULL)
	{
		if ((basic_data->x_size == dest->x_size) && (basic_data->y_size == dest->y_size))
		{
			copy_image(dest, basic_data);
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}






/////////////////////////////////////
// FILE IMAGE GENERATOR            //
/////////////////////////////////////

// assuming the inputs files are Targa16
FileImageGenerator::FileImageGenerator(int x_size, int y_size, int type, char* filename)
{
	basic_data = new_image_read_WindowsBMP24(x_size, y_size, filename, type);
	generator_type=1; // file
}

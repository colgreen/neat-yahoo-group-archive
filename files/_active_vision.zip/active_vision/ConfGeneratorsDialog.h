#pragma once


// CConfGeneratorsDialog dialog

class CConfGeneratorsDialog : public CDialog
{
	DECLARE_DYNAMIC(CConfGeneratorsDialog)

public:
	CConfGeneratorsDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CConfGeneratorsDialog();

// Dialog Data
	enum { IDD = IDD_CONF_GENERATORS_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};

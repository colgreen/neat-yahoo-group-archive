////////////////////////
// Peter Chervenski
// spookey@abv.bg
////////////////////////

#include "stdafx.h"
#include <windows.h>
#include "utils.h"
#include "neat.h"
#include "gene.h"
#include "population.h"
#include "network.h"
#include "organism.h"
#include "math_vectors.h"
#include "math_matrix.h"
//#include "objects.h"
#include "visual.h"

using namespace NEAT;

#define MAX_DEPTH 16
#define YPOS_ALTER 4
#define XPOS_ALTER 4

#define SLOW_NN_TIME_TIMESTEPS 10

//#define DRAW_CTRNN


int mouse_x; int mouse_y;
bool choose_nn;
NEAT::Organism* chosen_nn=NULL;




// drawing types: 
// 0 - normal
// 1 - HyperNEAT substrate
// 2 - CTRNN
void Prepare_To_Draw_NN(Network* net, int FIELD_X, int FIELD_Y, int drawing_type) 
{
	int i;
	int xxsize = FIELD_X;
	int xxpos;
	double depth;
	double depth_inc = 1.0 / MAX_DEPTH;

	if (drawing_type == NN_DRAWING_NORMAL)
	{
		// Normal drawing

		// process X coords
		// for every possible depth
		for(depth=0;depth<=1.0;depth+=depth_inc)
		{
			// count how many nodes at this depth
			int neuron_count=0;
			for(i=0; i<net->all_nodes.size(); i++)
				if (net->all_nodes[i]->split_y == depth) neuron_count++;

			// skip this depth if there are no nodes
			if (neuron_count == 0) continue;

			// calculate X positions for nodes at this depth
			int j=0;
			xxpos = (FIELD_X / (1 + neuron_count));
			for(i=0; i<net->all_nodes.size(); i++)
			{
				if (net->all_nodes[i]->split_y == depth)
				{
					net->all_nodes[i]->xpos = xxpos + j*(FIELD_X/(2 + neuron_count));
					j++;
				}
			}
		}

		// process Y coords 
		for(i=0; i<net->all_nodes.size(); i++)
		{
			if ( net->all_nodes[i]->gen_node_label == NEAT::INPUT)
			{
				net->all_nodes[i]->ypos = net->all_nodes[i]->split_y * (FIELD_Y-MAX_RADIUS_INPUT) + MAX_RADIUS_INPUT;
			}
			else if ( net->all_nodes[i]->gen_node_label == NEAT::HIDDEN)
			{
				net->all_nodes[i]->ypos = net->all_nodes[i]->split_y * (FIELD_Y-MAX_RADIUS_HIDDEN) + MAX_RADIUS_HIDDEN;
			}
			else if ( net->all_nodes[i]->gen_node_label == NEAT::OUTPUT)
			{
				net->all_nodes[i]->ypos = net->all_nodes[i]->split_y * (FIELD_Y-MAX_RADIUS_OUTPUT) + MAX_RADIUS_OUTPUT;
			}
			else
			{
				net->all_nodes[i]->ypos = net->all_nodes[i]->split_y * (FIELD_Y-MAX_RADIUS_DEFAULT) + MAX_RADIUS_DEFAULT;
			}

			// alter position
			if (net->all_nodes[i]->gen_node_label == NEAT::HIDDEN)
			{
				net->all_nodes[i]->xpos += (RandFloat() * XPOS_ALTER) - XPOS_ALTER/2;
				net->all_nodes[i]->ypos += (RandFloat() * YPOS_ALTER) - YPOS_ALTER/2;
			}

			// move outputs up a little bit
			if (net->all_nodes[i]->split_y == 1.0)
			{
				net->all_nodes[i]->ypos -= MAX_RADIUS_OUTPUT * 2.0;
			}
		}
	}

	if (drawing_type == NN_DRAWING_SUBSTRATE)
	{
		// HYPERNEAT Drawing

		for(i=0; i<net->all_nodes.size(); i++)
		{
			net->all_nodes[i]->xpos = ( net->all_nodes[i]->substrate_x) * (FIELD_X/2.15) + FIELD_X/2;
			net->all_nodes[i]->ypos = (-net->all_nodes[i]->substrate_y) * (FIELD_Y/2.15) + FIELD_Y/2;
		}
	}

	if (drawing_type == NN_DRAWING_CTRNN)
	{
		//CTRNN drawing

		double x=FIELD_X/2, y=FIELD_Y/2, x_radius=FIELD_X/2 - 50, y_radius=FIELD_Y/2 - 50; 
		double ang;
		int cur_node = 0;
		for(ang = 0.0; ang < 2*3.14+1; ang += 2*3.14/net->all_nodes.size(), cur_node++)
		{
			if (cur_node == net->all_nodes.size())
				break;

			net->all_nodes[cur_node]->xpos = (int)(x - y_radius * sin(ang));
			net->all_nodes[cur_node]->ypos = (int)(y - y_radius * cos(ang));
		}
	}
}





// Flags: 
// 0 - no info
// 1 - info included
void Draw_NN(Network* net, HDC &dc, int flags)
{
	int i,j;
	NNode* node;
	Link* link;

	// Determine max weight
	double MAX_WEIGHT = 0.0;
	for(i=0; i<net->all_nodes.size(); i++)
	{
		// visit each node and check the weight of incoming links
		node = net->all_nodes[i]; 

		for(j=0; j<node->incoming.size(); j++)
		{
			link = node->incoming[j];

			double w = abs(link->weight);

			if (w > MAX_WEIGHT) MAX_WEIGHT = w;
		}
	}


	// draw connections
	for(i=0; i<net->all_nodes.size(); i++)
	{
		// visit each node and draw connections
		node = net->all_nodes[i]; 

		for(j=0; j<node->incoming.size(); j++)
		{
			link = node->incoming[j];

			HPEN pen;

			double thickness = link->weight;// / MAX_WEIGHT) * MAX_THICKNESS;
			Scale(thickness, NEAT::weight_cap_min, NEAT::weight_cap_max, 1, MAX_THICKNESS);
			double mag = abs(link->weight);
			Scale(mag, 0, NEAT::weight_cap_max, 100, 255);

			//Clamp(thickness, 0, MAX_THICKNESS);
			//Clamp(mag, 0.0, 1.0);
		
			if (!(link->is_recurrent))
			{
				if (link->weight > 0) 
					pen = CreatePen(PS_SOLID, thickness, RGB(mag, 0, 0)); // RED POSITIVE
				else 
					pen = CreatePen(PS_SOLID, thickness, RGB(0, 0, mag)); // BLUE NEGATIVE
			}
			else
			{   // RECURRENT
				if (link->weight > 0) 
					pen = CreatePen(PS_SOLID, thickness, RGB(mag, mag, mag)); // WHITE POSITIVE
				else 
					pen = CreatePen(PS_SOLID, thickness, RGB(0, mag, 0)); // GREEN NEGATIVE
			}


			double max_rad;
			if (node->gen_node_label==NEAT::INPUT)
				max_rad = MAX_RADIUS_INPUT;
			else if (node->gen_node_label==NEAT::HIDDEN)
				max_rad = MAX_RADIUS_HIDDEN;
			else if (node->gen_node_label==NEAT::OUTPUT)
				max_rad = MAX_RADIUS_OUTPUT;
			else
				max_rad = MAX_RADIUS_DEFAULT;


			SelectObject(dc, pen);
					
			if ( link->out_node == link->in_node )
			{
             	// this is the background color! (of the recurrent self-loop)
				HBRUSH brr = CreateSolidBrush(RGB(0, 0, 0));
				SelectObject(dc, brr);

				Ellipse(dc, node->xpos - max_rad-1, node->ypos, 
		        node->xpos + max_rad, node->ypos + max_rad*2);

				DeleteObject(brr);
			}


			// Draw the arrows of the lines 
			// link->out node is the place with the arrows
			vector2D A, B, C;
			vector2D isect;
			int aa,bb;
			line2D ol;

			vector2D result;
			Matrix matrix;

			vector2D tmp,t;

				// Initialize points
			A.x = link->in_node->xpos;
			A.y = link->in_node->ypos;
			B.x = link->out_node->xpos;
     		B.y = link->out_node->ypos;
			C.x = B.x;
			C.y = B.y;

				// draw the arrow .. spikes ;) 
			for(double ang=-ARROW_ANGLE; ang <= ARROW_ANGLE; ang += ARROW_ANGLE * 2)
			{
				B.x = C.x;
				B.y = C.y;

				// init matrix
				Set_Identity(matrix);
				// translate matrix to the vector's position (origin)
				matrix[3][0] = B.x;
				matrix[3][1] = B.y;
				matrix[3][2] = 0;
				// Move B to the edge of the circle
				Transform_Vector_To_Matrix_2D(matrix, A, t);
				t.normalize();
				B.x = C.x + t.x*max_rad;
				B.y = C.y + t.y*max_rad;


				// init matrix
				Set_Identity(matrix);
				// rotate the coordinate system
				Rotate_Matrix_Z(matrix, ang);
				// translate matrix to the vector's position (origin)
				matrix[3][0] = B.x;
				matrix[3][1] = B.y;
				matrix[3][2] = 0;
				// Scale matrix
				matrix[0][0] *= 0.11;
				matrix[1][1] *= 0.11;

				// transform A into the translated coordinate system
				Transform_Vector_To_Matrix_2D(matrix, A, result);
				result.normalize();
				// Draw the line (transformed back)
				MoveToEx(dc, B.x, B.y, NULL);
				aa = B.x + (result.x * ARROW_SPIKE_LENGTH);
				bb = B.y + (result.y * ARROW_SPIKE_LENGTH);
				LineTo(dc, aa, bb);
			}

    		// Draw line of connection
			MoveToEx(dc, C.x - tmp.x*max_rad, C.y - tmp.y*max_rad, NULL);
			LineTo(dc, link->in_node->xpos, link->in_node->ypos);

			DeleteObject(pen);
		}
	}


	// draw nodes
	double radius;
	if (node->gen_node_label==NEAT::INPUT)
		radius = MAX_RADIUS_INPUT;
	if (node->gen_node_label==NEAT::HIDDEN)
		radius = MAX_RADIUS_HIDDEN;
	if (node->gen_node_label==NEAT::OUTPUT)
		radius = MAX_RADIUS_OUTPUT;
//	else
//		radius = MAX_RADIUS_DEFAULT;


	for(i=0; i<net->all_nodes.size(); i++)
	{
		HBRUSH br1 = CreateSolidBrush(RGB(0, 0, 0));
		HBRUSH br2;
    	HPEN pen1;
		HPEN pen2 = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));  

	    // Draw Node
		node = net->all_nodes[i];

		double act = node->activation;
		double tc  = node->time_constant;

		Scale(tc, NEAT::min_time_constant, NEAT::max_time_constant, 1, MAX_THICKNESS);
		tc=1;

		if (act < 0) 
			br2 = CreateSolidBrush(RGB(0*act , 0*act , (int)abs(255*act)));
		else
			br2 = CreateSolidBrush(RGB(255*act , 255*act , 255*act ));

		if (node->gen_node_label == NEAT::INPUT)
			pen1 = CreatePen(PS_SOLID, 1, RGB(255, 0, 0));  // contour
		else if (node->gen_node_label == NEAT::HIDDEN)
			pen1 = CreatePen(PS_SOLID, tc, RGB(255, 255, 0));  // contour
		else if (node->gen_node_label == NEAT::OUTPUT)
			pen1 = CreatePen(PS_SOLID, tc, RGB(0, 255, 0));  // contour
		else
			pen1 = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));  // contour


		SelectObject(dc, br1);
		SelectObject(dc, pen1);
//		radius = max_rad;
		Ellipse(dc, node->xpos - radius-1, node->ypos - radius-1, 
			        node->xpos + radius, node->ypos + radius);


		DeleteObject(pen1);

		
		SelectObject(dc, br2);
		SelectObject(dc, pen2);
		double rad = act * radius + 1;
		rad = abs(rad);

		if (!(rad < 0.5))
		Ellipse(dc, node->xpos - rad, node->ypos - rad, 
			        node->xpos + rad, node->ypos + rad);

		DeleteObject(br2);

		// Display the node's number under the node
		char str[64];
		char type[64];
		char stype[64];
		stype[0]=0;
		type[0]=0;

		if ((node->gen_node_label != NEAT::INPUT) && (node->gen_node_label != NEAT::BIAS))
		switch((node)->ftype)
		{
		case SIGMOID:
			sprintf(type, "SIGM");
			break;
		case TANH:
			sprintf(type, "TANH");
			break;
		case GAUSS:
			sprintf(type, "GAUS");
			break;
		case SIN:
			sprintf(type, "SIN");
			break;
		case COS:
			sprintf(type, "COS");
			break;
		case SQR:
			sprintf(type, "SQR");
			break;
		case SQRT:
			sprintf(type, "SQRT");
			break;
		case EXP:
			sprintf(type, "EXP");
			break;
		case LOG:
			sprintf(type, "LOG");
			break;
		case INV:
			sprintf(type, "INV");
			break;
		case ABS:
			sprintf(type, "ABS");
			break;
		case LINEAR:
			sprintf(type, "LINE");
			break;
		default:
			// default is standart sigmoid
			//sprintf(type, "SIGM");
			break;
		}

		if ((node->gen_node_label != NEAT::INPUT) && (node->gen_node_label != NEAT::BIAS))
		switch(node->sftype)
		{
		case ADD:
			sprintf(stype, "+");
			break;
		case MUL:
			sprintf(stype, "*");
			break;
		case MIN:
			sprintf(stype, "<");
			break;
		case MAX:
			sprintf(stype, ">");
			break;
		default:
			sprintf(stype, "+");
		}

		if (flags == 1)
		{
			sprintf(str, "%s %s %d\n", stype, type, (int)(node->node_id));
			SetBkMode(dc, TRANSPARENT);
			SetTextColor(dc, RGB(255, 255, 0));
			TextOut(dc, node->xpos, node->ypos + radius + 5, str, strlen(str)-1);
		}

		DeleteObject(pen2); 
    	DeleteObject(br1);
	}
}




void Draw_Species(Population* pop, HDC& dc)
{
	int i,j;
	char str[160];

	HPEN pen1 = CreatePen(PS_SOLID, 1, RGB(255, 255, 0));  // contour
	SelectObject(dc, pen1);

	int start_x = 20;
	int end_x = 800-20;

	int start_y = 500;
	int end_y = 750;

	int step_size = (end_x - start_x) / NEAT::pop_size;

	int cur_x = start_x;

	MoveToEx(dc, start_x, start_y, NULL);
	LineTo(dc, end_x, start_y);

	MoveToEx(dc, start_x, end_y, NULL);
	LineTo(dc, end_x, end_y);

//	for(i=0; i<(pop->species.size()); i++) pop->species[i]->compute_average_fitness();

	double best=0;

	for(i=0; i<(pop->species.size()); i++)
	{
		if (best < pop->species[i]->max_fitness_ever) best = pop->species[i]->max_fitness_ever;
	}
	

	for(i=0; i<(pop->species.size()); i++)
	{
		//MoveToEx(dc, cur_x, start_y, NULL);
		//LineTo(dc, cur_x, end_y);

		double fit = pop->species[i]->max_fitness_ever / best;

		Clamp(fit, 0, 1);

		HBRUSH br1 = CreateSolidBrush(RGB(255*fit, 255*fit, 255*fit));
		SelectObject(dc, br1);

		Rectangle(dc, cur_x, start_y, cur_x + (pop->species[i]->size()) * step_size, end_y);

		POINT p;
		GetCursorPos(&p);
		//GetDCOrgEx(dc, &p2);

		mouse_x = p.x; 
		mouse_y = p.y;

		if ((mouse_x > cur_x) && (mouse_x < (cur_x + (pop->species[i]->size()) * step_size)) &&
		   (mouse_y > start_y) && (mouse_y < end_y))
		{
			sprintf(str, "species: #%d, age: %d, improved before: %d, fitness: %3.5f, size: %3.2f", pop->species[i]->id, pop->species[i]->age, pop->species[i]->age_of_last_improvement, pop->species[i]->max_fitness_ever, pop->species[i]->size());
			TextOut(dc, start_x, start_y - 20, str, strlen(str));

			chosen_nn = pop->species[i]->get_champ();
		}

		cur_x += (pop->species[i]->size()) * step_size; 

		DeleteObject(br1);
	}

	DeleteObject(pen1);
}




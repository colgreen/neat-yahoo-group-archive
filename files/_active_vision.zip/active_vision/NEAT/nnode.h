#ifndef _NNODE_H_
#define _NNODE_H_

#include <algorithm>
#include <vector>
#include "neat.h"
#include "trait.h"
#include "link.h"


//-----------------------------------------------------------------------
// ACTIVATION FUNCTIONS SUPPORTED: name / output range / formula
// -------------------------------
// NEURAL FUNCTIONS
// ----------------
// plain sigmoid       : (0  .. 1)      : f(x) = 1/(1+exp(-x));
// hyperbolic tangent  : {-1 .. 1)      : f(x) = tanh(x);
// gaussian            : (0  .. 1)      : f(x) = ?
// ----------------------
// MATHEMATICAL FUNCTIONS (experimental)
// ----------------------
// sine                : (-1 .. 1)      : f(x) = sin(x);
// cosine              : (-1 .. 1)      : f(x) = cos(x);
// square              : (0, +inf)      : f(x) = x*x;
// square root         : (0, +inf)      : f(x) = sqrt(x);
// exponential         : (?)            : f(x) = exp(x);
// log                 : (?)            : f(x) = log(x);
// inv                 : (-inf, +inf)   : f(x) = (x!=0)?1/x:BIG_NUMBER; 
// absolute value      : (0 .. +inf)    : f(x) = abs(x);
// linear              : (-inf .. +inf) : f(x) = x;
//-----------------------------------------------------------------------

//////////////////////////////////////////////////////////////////////////////
// NEURON INPUT SUM FUNCTIONS (experimental)
// -----------------------------------------
// addition       : (i1*w1) + (i2*w2) + (in*wn)       : default      : OR
// multiplication : (i1*w1) * (i2*w2) * (in*wn)       : experimental : AND
// maximal of     : MAX ((i1*w1), (i2*w2), (i3*w3))   : experimental
// minimal of     : MIN ((i1*w1), (i2*w2), (i3*w3))   : experimental
//////////////////////////////////////////////////////////////////////////////


namespace NEAT {

	enum nodetype {
		NEURON  = 0,
		SENSOR  = 1
	};

	enum nodeplace {
		HIDDEN  = 0,
		INPUT   = 1,
		OUTPUT  = 2,
		BIAS    = 3
	};

	enum functype {
		SIGMOID = 0,       
		TANH    = 1,
		GAUSS   = 2,
		SIN     = 3,
		COS     = 4,
		SQR     = 5,
		SQRT    = 6,
		EXP     = 7,
		LOG     = 8,
		INV     = 9,
		ABS     = 10,
		LINEAR  = 11
	};

	enum sfunctype 
	{
		ADD = 0,
		MUL = 1,
		MAX = 2,
		MIN = 3
	};

	class Link;

	// ----------------------------------------------------------------------- 
	// A NODE is either a NEURON or a SENSOR.  
	//   - If it's a sensor, it can be loaded with a value for output
	//   - If it's a neuron, it has a list of its incoming input signals (List<Link> is used) 
	// Use an activation count to avoid flushing
	class NNode {

		friend class Network;
		friend class Genome;

	protected:

		int activation_count;  // keeps track of which activation the node is currently in
		double last_activation; // Holds the previous step's activation for recurrency
		double last_activation2; // Holds the activation BEFORE the prevous step's
		// This is necessary for a special recurrent case when the innode
		// of a recurrent link is one time step ahead of the outnode.
		// The innode then needs to send from TWO time steps ago

		Trait *nodetrait; // Points to a trait of parameters
		int trait_id;     // identify the trait derived by this node

		NNode *dup;       // Used for Genome duplication
		NNode *analogue;  // Used for Gene decoding

		bool overrid;    // The NNode cannot compute its own output- something is overriding it
		double overrid_value; // Contains the activation value that will overrid this node's activation


	public:
		bool frozen;    // When frozen, cannot be mutated (meaning its trait pointer is fixed)

		functype ftype;   // type is either SIGMOID ..or others that can be added
		sfunctype sftype; // SUM function type

		nodetype type;  // type is either NEURON or SENSOR 

		double activesum;  // The incoming activity before being processed 
		double activation; // The total activation entering the NNode 
		bool active_flag;  // To make sure outputs are active

		// Spookey 2006
		// LEAKY INTEGRATOR VARS
        double synapticInput;     //The incoming activity before being processed 
	    double membranePotential; //The total activation entering the NNode
		double time_constant;
	    double bias;
	    double firingRate; 

		double get_active_out_CTRNN();    //CTRNN version
		void   calculate_active_out_CTRNN();


		// ************ LEARNING PARAMETERS *********** 
		// The following parameters are for use in    
		// neurons that learn through habituation,
		// sensitization, or Hebbian-type processes  

		double params[NEAT::num_trait_params];

		std::vector<Link*> incoming; // A list of pointers to incoming weighted signals from other nodes
		std::vector<Link*> outgoing; // A list of pointers to links carrying this node's signal

		// For displaying purposes
		int ypos;
		int xpos;
		double split_x, split_y;

		// HyperNEAT: positions in substrate
		// Z may not be considered important
		double substrate_x, substrate_y, substrate_z; 

		int node_id;               // A node can be given an identification number for saving in files
		nodeplace gen_node_label;  // Used for genetic marking of nodes

		NNode(nodetype ntype,int nodeid);
		NNode(nodetype ntype,int nodeid, nodeplace placement);
		NNode(nodetype ntype,int nodeid, nodeplace placement, double timeConstant, double newBias);

		// Construct a NNode off another NNode for genome purposes
		NNode(NNode *n,Trait *t);

		// Construct the node out of a file specification using given list of traits
		NNode (const char *argline, std::vector<Trait*> &traits);

		// Copy Constructor
		NNode (const NNode& nnode);

		~NNode();

		// Just return activation for step
		double get_active_out();

		// Return activation from PREVIOUS time step
		double get_active_out_td();

		// Returns the type of the node, NEURON or SENSOR
		const nodetype get_type();

		// Allows alteration between NEURON and SENSOR.  Returns its argument
		nodetype set_type(nodetype);

		// If the node is a SENSOR, returns true and loads the value
		bool sensor_load(double);

		// Adds a NONRECURRENT Link to a new NNode in the incoming List
		void add_incoming(NNode*,double);

		// Adds a Link to a new NNode in the incoming List
		void add_incoming(NNode*,double,bool);

		void AddToBias(double value);
		void AddToTimeConstant(double value);

		// Recursively deactivate backwards through the network
		void flushback();

		// Verify flushing for debugging
		void flushback_check(std::vector<NNode*> &seenlist);

		// Print the node to a file
        void print_to_file(std::ostream &outFile);
		void print_to_file(std::ofstream &outFile);

		// Have NNode gain its properties from the trait
		void derive_trait(Trait *curtrait);

		// Returns the gene that created the node
		NNode *get_analogue();

		// Force an output value on the node
		void overrid_output(double new_output);

		// Tell whether node has been overridden
		bool overridden();

		// Set activation to the overrid value and turn off overrid
		void activate_overrid();  

		// Writes back changes weight values into the genome
		// (Lamarckian trasnfer of characteristics)
		void Lamarck();

		//Find the greatest depth starting from this neuron at depth d
		int depth(int d,Network *mynet); 

	};


NEAT::functype choose_random_func();
NEAT::sfunctype choose_random_sfunc();

} // namespace NEAT

#endif

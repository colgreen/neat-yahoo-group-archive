////////////////////////
// Peter Chervenski
// spookey@abv.bg
////////////////////////

#include "stdafx.h"
#include <vector>
#include "gene.h"
#include "neat.h"
#include "genome.h"
#include "network.h"
#include "innovation.h"
#include "math_vectors.h"
#include "utils.h"
#include "substrate.h"

using namespace NEAT;
using namespace std;

Substrate::Substrate(substrate_config config, int inp, int hid, int outp)
{
	int i;
	vector2D tmp;

	num_inputs  = inp;
	num_hidden  = hid;
	num_outputs = outp;

	inputs.clear();
	hidden.clear();
	outputs.clear();

	if (config == RANDOM)
	{
		// Random positions for all nodes
		// The substrate limits are [-1 .. 1] on both axises

		// create inputs positions
		for(i=0; i<inp; i++)
		{
			tmp.x = (randfloat() * 2.0) - 1.0; // scale to -1 .. 1
			tmp.y = (randfloat() * 2.0) - 1.0; // scale to -1 .. 1

			inputs.push_back( tmp );
		}

		// create hidden positions
		for(i=0; i<hid; i++)
		{
			tmp.x = (randfloat() * 2.0) - 1.0; // scale to -1 .. 1
			tmp.y = (randfloat() * 2.0) - 1.0; // scale to -1 .. 1

			hidden.push_back( tmp );
		}

		// create output positions
		for(i=0; i<outp; i++)
		{
			tmp.x = (randfloat() * 2.0) - 1.0; // scale to -1 .. 1
			tmp.y = (randfloat() * 2.0) - 1.0; // scale to -1 .. 1

			outputs.push_back( tmp );
		}

		return;
	}

	if (config == PARRALEL)
	{
		double xxpos=0;
		
		// calculate X positions for nodes

		xxpos = (2.0 / (1.0 + num_inputs));
		for(i=0; i<num_inputs; i++)
		{
			tmp.x = (xxpos + i*(2.0/(2.0 + num_inputs))) - 1.0;
			tmp.y = 1;

			inputs.push_back(tmp);
		}

		xxpos = (2.0 / (1.0 + num_hidden));
		for(i=0; i<num_hidden; i++)
		{
			tmp.x = (xxpos + i*(2.0/(2.0 + num_hidden))) - 1.0;
			tmp.y = 0;

			hidden.push_back(tmp);
		}

		xxpos = (2.0 / (1.0 + num_outputs));
		for(i=0; i<num_outputs; i++)
		{
			tmp.x = (xxpos + i*(2.0/(2.0 + num_outputs))) - 1.0;
			tmp.y = -1;

			outputs.push_back(tmp);
		}

		return;
	}

	if (config == CIRCULAR)
	{
		double ang;
		int cur_node=0;
		
		// inputs
		for(ang = 0.0; ang < 2*3.14152+1; ang += 2.0*3.14152/(double)num_inputs, cur_node++)
		{
			if (cur_node == num_inputs)
				break;

			tmp.x = sin(ang) * 0.999; // outer ring is for the inputs
			tmp.y = cos(ang) * 0.999;

			inputs.push_back( tmp );
		}

		// hidden
		cur_node=0;
		for(ang = 0.0; ang < 2*3.14152+1; ang += 2.0*3.14152/(double)num_hidden, cur_node++)
		{
			if (cur_node == num_hidden)
				break;

			tmp.x = sin(ang) * 0.666; // middle ring is for the hidden
			tmp.y = cos(ang) * 0.666;

			hidden.push_back( tmp );
		}

		// outputs
		cur_node=0;
		for(ang = 0.0; ang < 2*3.14152+1; ang += 2.0*3.14152/(double)num_outputs, cur_node++)
		{
			if (cur_node == num_outputs)
				break;

			tmp.x = sin(ang) * 0.333; // inner ring is for the outputs
			tmp.y = cos(ang) * 0.333;

			outputs.push_back( tmp );
		}
	}
}



Network* NEAT::create_hyper_phenotype(Network* CPPN, Substrate* substrate)
{
	int i,j,tmp;
	NEAT::Genome  *genome;
	NEAT::NNode   *newnode;
	NEAT::Gene    *newgene;
	NEAT::Network *net;

	vector<double> CPPN_input;
	double weight;

	// Create an empty genome
	genome = new Genome(0, 0, 0, 0);

	// Now start adding the nodes, reading info from the substrate
	for(i=0; i<substrate->num_inputs; i++)
	{
		newnode = new NNode((nodetype)SENSOR, i, NEAT::INPUT);

		newnode->substrate_x = substrate->inputs[i].x;
		newnode->substrate_y = substrate->inputs[i].y;

		newnode->split_y = 0;

		genome->node_insert(genome->nodes, newnode);
	}

	for(i=0; i<substrate->num_hidden; i++)
	{
		newnode = new NNode((nodetype)NEURON, i+substrate->num_hidden, NEAT::HIDDEN);

		newnode->substrate_x = substrate->hidden[i].x;
		newnode->substrate_y = substrate->hidden[i].y;

		newnode->split_y = 0.5;

		genome->node_insert(genome->nodes, newnode);
	}

	for(i=0; i<substrate->num_outputs; i++)
	{
		newnode = new NNode((nodetype)NEURON, i+substrate->num_hidden+substrate->num_outputs, NEAT::OUTPUT);

		newnode->substrate_x = substrate->outputs[i].x;
		newnode->substrate_y = substrate->outputs[i].y;

		newnode->split_y = 1.0;

		genome->node_insert(genome->nodes, newnode);
	}

	int depth = CPPN->max_depth();

	// Now the most important part.. For every pair of nodes
	// Query the CPPN with their coordinates and create a new gene
	// for the network.. 
	for(i=0; i<genome->nodes.size(); i++)
	{
		for(j=0; j<genome->nodes.size(); j++)
		{
			// Clear
			CPPN_input.clear();

			// Query the CPPN for the weight
			// The CPPN MUST have 5 inputs AND 1 outputs
			CPPN_input.push_back( genome->nodes[i]->substrate_x );
			CPPN_input.push_back( genome->nodes[i]->substrate_y );
			CPPN_input.push_back( genome->nodes[j]->substrate_x );
			CPPN_input.push_back( genome->nodes[j]->substrate_y );
			CPPN_input.push_back( 1.0 ); // bias

			CPPN->load_sensors( CPPN_input );

			// query
			for(tmp=0;tmp<depth;tmp++)
				CPPN->activate_normal();

			// the weight is the output
			weight = CPPN->outputs[0]->activation;
			Clamp(weight, -1, 1);

			if (abs(weight) > 0.2)
			{
				Scale(weight, -1, 1, -3, 3);

				// Now add the gene, but check out, output to input nodes is not allowed
				if ((genome->nodes[j]->gen_node_label != NEAT::INPUT) && (genome->nodes[j]->gen_node_label != NEAT::BIAS))
				{
					newgene = new Gene(weight, genome->nodes[i], genome->nodes[j], false, 0, 0);
					genome->add_gene(genome->genes, newgene);
				}
			}
		}
	}

	net = genome->genesis(0);

	delete genome;

	// OK, return the big network
	return net;
}
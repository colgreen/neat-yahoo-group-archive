////////////////////////
// Peter Chervenski
// spookey@abv.bg
////////////////////////

#include "stdafx.h"
#include <stdio.h>
#include <fstream>
#include <windows.h>
#include <memory.h>
#include "image.h"
#include "neat\math_vectors.h"
#include "neat\math_matrix.h"

using namespace std;

// **********
// class WindowsBMP
//   - Generic class for BMP raster images.
class WindowsBMP 
{
	public:
		int Width,Height;		// Dimensions
		int BPP;				// Bits Per Pixel.
		char * Raster;			// Bits of the Image.
		RGBQUAD * Palette;		// RGB Palette for the image.
		int BytesPerRow;		// Row Width (in bytes).
		BITMAPINFO * pbmi;		// BITMAPINFO structure

		// Member functions (defined later):
		int LoadBMP (char * szFile);
		int GDIPaint (HDC hdc,int x,int y);
};

// **********
// WindowsBMP::LoadBMPFile (FileName);
//   - loads a BMP file into a WindowsBMP object
//   * supports non-RLE-compressed files of 1, 2, 4, 8 & 24 bits-per-pixel
int WindowsBMP::LoadBMP (char * szFile)
{
	BITMAPFILEHEADER bmfh;
	BITMAPINFOHEADER bmih;

	// Open file.
	ifstream bmpfile (szFile , ios::in | ios::binary);
	if (! bmpfile.is_open()) return 1;		// Error opening file

	// Load bitmap fileheader & infoheader
	bmpfile.read ((char*)&bmfh,sizeof (BITMAPFILEHEADER));
	bmpfile.read ((char*)&bmih,sizeof (BITMAPINFOHEADER));

	// Check filetype signature
	if (bmfh.bfType!='MB') return 2;		// File is not BMP

	// Assign some short variables:
	BPP=bmih.biBitCount;
	Width=bmih.biWidth;
	Height= (bmih.biHeight>0) ? bmih.biHeight : -bmih.biHeight; // absoulte value
	BytesPerRow = Width * BPP / 8;
	BytesPerRow += (4-BytesPerRow%4) % 4;	// int alignment

	// If BPP aren't 24, load Palette:
	if (BPP==24) pbmi=(BITMAPINFO*)new char [sizeof(BITMAPINFO)];
	else
	{
		pbmi=(BITMAPINFO*) new char[sizeof(BITMAPINFOHEADER)+(1<<BPP)*sizeof(RGBQUAD)];
		Palette=(RGBQUAD*)((char*)pbmi+sizeof(BITMAPINFOHEADER));
		bmpfile.read ((char*)Palette,sizeof (RGBQUAD) * (1<<BPP));
	}
	pbmi->bmiHeader=bmih;

	// Load Raster
	bmpfile.seekg (bmfh.bfOffBits,ios::beg);

	Raster= new char[BytesPerRow*Height];

	// (if height is positive the bmp is bottom-up, read it reversed)
	if (bmih.biHeight>0)
		for (int n=Height-1;n>=0;n--)
			bmpfile.read (Raster+BytesPerRow*n,BytesPerRow);
	else
		bmpfile.read (Raster,BytesPerRow*Height);

	// so, we always have a up-bottom raster (that is negative height for windows):
	pbmi->bmiHeader.biHeight=-Height;

	bmpfile.close();

	return 0;
}

// **********
// WindowsBMP::GDIPaint (hdc,x,y);
// * Paints Raster to a Windows DC.
int WindowsBMP::GDIPaint (HDC hdc,int x=0,int y=0)
{
	// Paint the image to the device.
	return SetDIBitsToDevice (hdc,x,y,Width,Height,0,0,
		0,Height,(LPVOID)Raster,pbmi,0);
}



// Temp buffer pool
unsigned char pixels[1024*1024];

#define BACK_COLOR 255


image_t* new_image(int x_size, int y_size, int type)
{
	image_t* image = new image_t;
	image->pixels = new unsigned char[x_size * y_size];

	image->type = type;
	image->x_size = x_size;
	image->y_size = y_size;

	// clear the image and ready to go
	memset(image->pixels, BACK_COLOR, x_size*y_size);

	return image;
}

image_t* new_image_read_raw8(int x_size, int y_size, char* filename, int type)
{
	FILE* f = fopen(filename, "r");
	image_t* image = new image_t;
	image->pixels = new unsigned char[x_size * y_size];
	fread(image->pixels, x_size * y_size, 1, f);
	image->type = type;
	image->x_size = x_size;
	image->y_size = y_size;
	fclose(f);

	return image;
}

int image_read_raw8(image_t* image, char* filename)
{
	FILE* f = fopen(filename, "r");
	fread(image->pixels, image->x_size * image->y_size, 1, f);
	fclose(f);

	return 0;
}


image_t* new_image_read_raw16(int x_size, int y_size, char* filename, int type)
{
	FILE* f = fopen(filename, "r");
	image_t* image = new image_t;
	image->pixels = new unsigned char[x_size * y_size];

	unsigned short* data = new unsigned short[x_size * y_size * 2];
	fread(data, x_size * y_size * 2, 1, f);
	fclose(f);

	for(int x=0; x<x_size; x++)
	{
		for(int y=0; y<y_size; y++)
		{
			image->pixels[y*x_size + x] = (unsigned char)(data[y*x_size + x] >> 8);
		}
	}

	delete data;

	image->type = type;
	image->x_size = x_size;
	image->y_size = y_size;

	return image;
}

int image_read_raw16(image_t* image, char* filename)
{
	FILE* f = fopen(filename, "r");
	int imgsize = image->x_size*image->y_size*2;

	unsigned short* data = new unsigned short[imgsize];
	fread(data, imgsize, 1, f);
	fclose(f);

	for(int x=0; x<image->x_size; x++)
	{
		for(int y=0; y<image->y_size; y++)
		{
			image->pixels[y*image->x_size + x] = (unsigned char)(data[y*image->x_size + x] >> 8);
		}
	}

	delete data;

	return 0;
}
	
image_t* new_image_read_targa16(int x_size, int y_size, char* filename, int type)
{
	FILE* f = fopen(filename, "r");

	if (f == NULL) 
	{
		MessageBox(NULL, strerror(errno), "ERROR: new_image_read_targa16", MB_OK);
		MessageBox(NULL, filename, "filename", MB_OK);
		return NULL;
	}

	image_t* image = new image_t;
	image->pixels = new unsigned char[x_size * y_size];

	unsigned short* data = new unsigned short[x_size * y_size * 2];
	fseek(f, 18, SEEK_SET);
	fread(data, x_size * y_size * 2, 1, f);
	fclose(f);

	for(int x=0; x<x_size; x++)
	{
		for(int y=0; y<y_size; y++)
		{
			image->pixels[y*x_size + x] = (unsigned char)(data[y*x_size + x] >> 7);
		}
	}

	delete data;

	image->type = type;
	image->x_size = x_size;
	image->y_size = y_size;

	return image;
}

int image_read_targa16(image_t* image, char* filename)
{
	FILE* f = fopen(filename, "r");
	int imgsize = image->x_size*image->y_size*2;

	unsigned short* data = new unsigned short[imgsize];
	fseek(f, 18, SEEK_SET);
	fread(data, imgsize, 1, f);
	fclose(f);

	for(int x=0; x<image->x_size; x++)
	{
		for(int y=0; y<image->y_size; y++)
		{
			image->pixels[y*image->x_size + x] = (unsigned char)(data[y*image->x_size + x] >> 7);
		}
	}

	delete data;

	return 0;
}

int image_read_WindowsBMP24(image_t* image, char* filename)
{
	WindowsBMP bmp;
	unsigned char r,g,b;
	unsigned short word;

	bmp.LoadBMP(filename);

	if ((bmp.Height != image->y_size) || (bmp.Width != image->x_size))
	{
		return -1;
	}

	if (bmp.BPP != 24)
	{
		return -1;
	}

	for(int x=0; x<image->x_size; x++)
	{
		for(int y=0; y<image->y_size; y++)
		{

			r = bmp.Raster[y*bmp.BytesPerRow + x*3 + 0];
			g = bmp.Raster[y*bmp.BytesPerRow + x*3 + 1];
			b = bmp.Raster[y*bmp.BytesPerRow + x*3 + 2];

			word = (r+g+b)/3;
		
			image->pixels[y*image->x_size + x] = (unsigned char)word;
		}
	}

	return 0;
}

image_t* new_image_read_WindowsBMP24(int x_size, int y_size, char* filename, int type)
{
	image_t* image = new image_t;
	image->pixels = new unsigned char[x_size * y_size];

	WindowsBMP bmp;
	unsigned char r,g,b;
	unsigned short word;

	bmp.LoadBMP(filename);

	if ((bmp.Height != x_size) || (bmp.Width != x_size))
	{
		return NULL;
	}

	if (bmp.BPP != 24)
	{
		return NULL;
	}

	for(int x=0; x<x_size; x++)
	{
		for(int y=0; y<y_size; y++)
		{

			r = bmp.Raster[y*bmp.BytesPerRow + x*3 + 0];
			g = bmp.Raster[y*bmp.BytesPerRow + x*3 + 1];
			b = bmp.Raster[y*bmp.BytesPerRow + x*3 + 2];

			word = (r+g+b)/3;
		
			image->pixels[y*x_size + x] = (unsigned char)word;
		}
	}

	image->type = type;
	image->x_size = x_size;
	image->y_size = y_size;

	return image;
}









image_t* clone_image(image_t* image)
{
	image_t* newimage = new image_t;
	newimage->pixels = new unsigned char[image->x_size * image->y_size];
	newimage->type = image->type;
	newimage->x_size = image->x_size;
	newimage->y_size = image->y_size;

	memcpy(newimage->pixels, image->pixels, image->x_size * image->y_size);

	return newimage;
}

void copy_image(image_t* dest, image_t* src)
{
	if ((dest->x_size == src->x_size) && (dest->y_size == src->y_size))
	{
		memcpy(dest->pixels, src->pixels, src->x_size*src->y_size);
		dest->type = src->type;
	}
}

void free_image(image_t* image)
{
	delete[] image->pixels;
	delete image;
}


void transform_image_translation(int dx, int dy, image_t* image)
{
	int imgx=image->x_size;
	int imgy=image->y_size;
	
	int size=imgx*imgy;

	int nx,ny,nyimgx,yimgx;

	memset(pixels, BACK_COLOR, size);

	for(int y=0; y < imgy; y++)
	{
		ny = y + dy;
		
		nyimgx = ny*imgx;
		yimgx = y*imgx;

		for(int x=0; x < imgx; x++)
		{
			nx = x + dx;

			if (!((nx < 0) || (ny < 0) || (nx > (imgx-1)) || (ny > (imgy-1))))
			{
				pixels[yimgx + x] = image->pixels[nyimgx + nx];
			}
		}
	}

	memset(image->pixels, BACK_COLOR, size);
	memcpy(image->pixels, pixels, size);
}


void transform_image_zoom(double dz, image_t* image)
{
	vector2D vec;
	Matrix mat;
	memset(pixels, BACK_COLOR, image->x_size * image->y_size);

	Set_Identity(mat);

	// move the matrix into the center of the image
	Translate_Matrix(mat, image->x_size/2, image->y_size/2, 0);
	// scale the matrix
	for(int i=0; i<4; i++)
		for(int j=0; j<4; j++)
			if (mat[i][j] == 1.0) mat[i][j] *= dz;

	// tranform all pixels 
	for (int x=0; x<image->x_size; x++)
	{
		for(int y=0; y<image->y_size; y++)
		{
			vector2D destvec;

			// convert the point into matrix space coordinates
			vec.x = x - image->x_size/2;
			vec.y = y - image->y_size/2;

			// now destvec are the new coordinates of the rotated point
			Transform_Vector_From_Matrix_2D(mat, vec, destvec);

			// write data only if destvec is in the image area
			if ((destvec.x >= 0) && (destvec.x < image->x_size))
			{
				if ((destvec.y >= 0) && (destvec.y < image->y_size))
				{
					pixels[y*image->x_size + x] = image->pixels[(int)destvec.y * image->x_size + (int)destvec.x];
				}
			}
		}
	}

	memset(image->pixels, BACK_COLOR, image->x_size * image->y_size);
	memcpy(image->pixels, pixels, image->x_size * image->y_size);
}


/*
void transform_image_rotation(double a, image_t* image)
{
	vector2D vec;
	Matrix mat;
	memset(pixels, BACK_COLOR, image->x_size * image->y_size);

	Set_Identity(mat);

	// move the matrix into the center of the image
	Translate_Matrix(mat, image->x_size/2, image->y_size/2, 0);
	// rotate the matrix
	Rotate_Matrix_Z(mat, a);

	// tranform all pixels 
	for (int x=0; x<image->x_size; x++)
	{
		for(int y=0; y<image->y_size; y++)
		{
			vector2D destvec;

			// convert the point into matrix space coordinates
			vec.x = x - image->x_size/2;
			vec.y = y - image->y_size/2;

			// now destvec are the new coordinates of the rotated point
			Transform_Vector_From_Matrix_2D(mat, vec, destvec);

			// write data only if destvec is in the image area
			if ((destvec.x >= 0) && (destvec.x < image->x_size))
			{
				if ((destvec.y >= 0) && (destvec.y < image->y_size))
				{
					pixels[y*image->x_size + x] = image->pixels[(int)destvec.y * image->x_size + (int)destvec.x];
				}
			}
		}
	}

	memset(image->pixels, BACK_COLOR, image->x_size * image->y_size);
	memcpy(image->pixels, pixels, image->x_size * image->y_size);
}
*/

// OPTIMIZED VERSION
void transform_image_rotation(double a, image_t* image)
{
	vector2D vec;
	Matrix matrix;

	int imgx,imgy;
	int h_imgx,h_imgy;
	imgx=image->x_size;
	imgy=image->y_size;
	h_imgx = imgx/2;
	h_imgy = imgy/2;

	memset(pixels, BACK_COLOR, imgx * imgy);

	Set_Identity(matrix);

	// move the matrix into the center of the image
	Translate_Matrix(matrix, h_imgx, h_imgy, 0);
	// rotate the matrix
	Rotate_Matrix_Z(matrix, a);

	// tranform all pixels 
	for (int x=0; x<imgx; x++)
	{
		for(int y=0; y<imgy; y++)
		{
			//vector2D destvec;
			int dx,dy;

			// convert the point into matrix space coordinates
			vec.x = x - h_imgx;
			vec.y = y - h_imgy;

			// now destvec are the new coordinates of the rotated point
	    	dx = vec.x * matrix[0][0] + vec.y * matrix[1][0] + matrix[3][0];
			dy = vec.x * matrix[0][1] + vec.y * matrix[1][1] + matrix[3][1];
		
			// write data only if destvec is in the image area
			if ((dx >= 0) && (dx < imgx))
			{
				if ((dy >= 0) && (dy < imgy))
				{
					pixels[y*imgx + x] = image->pixels[dy*imgx + dx];
				}
			}
		}
	}

	memset(image->pixels, BACK_COLOR, imgx * imgy);
	memcpy(image->pixels, pixels, imgx * imgy);
}


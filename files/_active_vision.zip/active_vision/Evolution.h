#ifndef EVOLUTION_H
#define EVOLUTION_H

#include "image.h"
#include "neat\neat.h"
#include "neat\population.h"
#include "neat\organism.h"

using namespace std;
using namespace NEAT;

extern NEAT::Population* pop;
extern int gen;
extern double this_gen_percent;

void init_population(char* file);
void evolve();
void evaluate_organism(NEAT::Organism* org, vector<image_t*> &images, int match_image_type, bool display);
void evolution_thread();
void visual_demo_thread();


#endif
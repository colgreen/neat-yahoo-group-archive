#ifndef DISPLAY_H
#define DISPLAY_H

#include "eye.h"
#include "image.h"
#include "ActiveVision.h"
#include "ActiveVisionDlg.h"
#include "EvolutionInfoDialog.h"
#include "VisualModeDialog.h"

extern CEvolutionInfoDialog* EvInfoDialog;
extern CVisualModeDialog* VisualModeDialog;

extern bool visual_mode;


#endif
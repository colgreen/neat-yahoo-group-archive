#pragma once

#include "eye.h"


// CVisualModeDialog dialog

class CVisualModeDialog : public CDialog
{
	DECLARE_DYNAMIC(CVisualModeDialog)

public:
	CVisualModeDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CVisualModeDialog();

// Dialog Data
	enum { IDD = IDD_DIALOG2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
/*public:
	RovingEye* eye;
	image_t* image;*/
public:
	void init(void);
public:
	int draw(RovingEye* eye);
};

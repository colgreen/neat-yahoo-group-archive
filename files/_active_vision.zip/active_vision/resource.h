//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ActiveVision.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ACTIVEVISION_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_DIALOG2                     130
#define IDB_BITMAP1                     131
#define IDD_OPTIONSDIALOG               132
#define IDD_CONF_GENERATORS_DIALOG      133
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON3                     1002
#define IDC_BUTTON4                     1003
#define IDC_RADIO1                      1004
#define IDC_RADIO2                      1005
#define IDC_PROGRESS1                   1007
#define IDC_EDIT1                       1011
#define IDC_EDIT2                       1012
#define IDC_FITNESS_CHART               1014
#define IDC_FITNESS_SPREAD              1015
#define IDC_SPECIES_GRAPH               1016
#define IDC_BEST_NN                     1017
#define IDC_EV_PICTURE                  1018
#define IDC_EV_X_LIMIT                  1019
#define IDC_EV_Y_LIMIT                  1020
#define IDC_EV_Y_LABEL                  1021
#define IDC_EV_X_LABEL                  1022
#define IDC_BUTTON5                     1023
#define IDC_DEMO_BUTTON                 1023
#define IDC_DEMO_GENERATION             1024
#define IDC_EXPORT_BUTTON               1026
#define IDC_BROWSE_SEED_BUTTON          1027
#define IDC_SEED_GENOME                 1028
#define IDC_INITIAL_MUTATION            1029
#define IDC_EYE_ROTATION_ABILITY        1030
#define IDC_DELTA_X                     1031
#define IDC_DELTA_Y                     1032
#define IDC_DELTA_ZOOM                  1033
#define IDC_DELTA_ALPHA                 1034
#define IDC_NEAREST_SAMPLING            1036
#define IDC_AVERAGE_SAMPLING            1037
#define IDC_LIFETIME                    1038
#define IDC_OFF_INPUT                   1039
#define IDC_MAX_ZOOM                    1040
#define IDC_EDIT9                       1041
#define IDC_MIN_ZOOM                    1041
#define IDC_CONF_GENERATORS             1042
#define IDC_NEAT_OPTIONS                1043
#define IDC_SAMPLES_PER_GEN             1044
#define IDC_TRANSLATE_IMAGES            1045
#define IDC_ROTATE_IMAGES               1046
#define IDC_ZOOM_IMAGES                 1047
#define IDC_MAX_IMAGE_TRANSLATION       1048
#define IDC_MAX_IMAGE_ROTATION          1050
#define IDC_MAX_IMAGE_ZOOM              1051
#define IDC_VIEW_POSITION_SCROLLBAR     1052
#define IDC_SCALE_SLIDER                1053
#define IDC_CHECK1                      1054
#define IDC_AUTO_SCROLL_CHECK           1054

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1055
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

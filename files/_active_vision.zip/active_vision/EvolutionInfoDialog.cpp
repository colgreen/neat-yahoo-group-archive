// EvolutionInfoDialog.cpp : implementation file
//

#include "stdafx.h"
#include "ActiveVision.h"
#include "EvolutionInfoDialog.h"
#include "neat\population.h"
#include "neat\organism.h"
#include "neat\network.h"
#include "neat\neat.h"
#include "neat\visual.h"
#include "neat\substrate.h"

using namespace NEAT;


#define SUBSTRATE





// CEvolutionInfoDialog dialog

IMPLEMENT_DYNAMIC(CEvolutionInfoDialog, CDialog)

CEvolutionInfoDialog::CEvolutionInfoDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CEvolutionInfoDialog::IDD, pParent)
	, best_index(0)
{

}

CEvolutionInfoDialog::~CEvolutionInfoDialog()
{
}

void CEvolutionInfoDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS1, GenProgress);
}


BEGIN_MESSAGE_MAP(CEvolutionInfoDialog, CDialog)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_FITNESS_CHART, &CEvolutionInfoDialog::OnBnClickedFitnessChart)
	ON_BN_CLICKED(IDC_FITNESS_SPREAD, &CEvolutionInfoDialog::OnBnClickedFitnessSpread)
	ON_BN_CLICKED(IDC_BEST_NN, &CEvolutionInfoDialog::OnBnClickedBestNn)
END_MESSAGE_MAP()

RECT ev_rect;
CDC ev_backbuffer_dc;
CBitmap ev_backbuffer_bmp;
CPen black_pen;
CPen black_thick_pen;
CPen green_pen;
CPen green_thick_pen;
CPen white_pen;
CPen white_thick_pen;

void CEvolutionInfoDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	CWnd* thewnd = GetDlgItem(IDC_EV_PICTURE);
	CDC* thedc = thewnd->GetDC();

	thedc->BitBlt(0, 0, ev_rect.right, ev_rect.bottom, &ev_backbuffer_dc, 0, 0, SRCCOPY);

	// TODO: Add your message handler code here
	// Do not call CDialog::OnPaint() for painting messages
}

// inits the back buffer and stuff
bool ev_onetime=true;
void CEvolutionInfoDialog::init(void)
{	
	CWnd* thewnd = GetDlgItem(IDC_EV_PICTURE);
	CDC* thedc = thewnd->GetDC();

	if (ev_onetime)
	{
		thewnd->GetClientRect(&ev_rect);
		ev_backbuffer_bmp.CreateCompatibleBitmap(thedc, ev_rect.right, ev_rect.bottom);
		ev_backbuffer_dc.CreateCompatibleDC(thedc);
		ev_backbuffer_dc.SelectObject(&ev_backbuffer_bmp);

		black_pen.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
		black_thick_pen.CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
		green_pen.CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
		green_thick_pen.CreatePen(PS_SOLID, 2, RGB(0, 255, 0));
		white_pen.CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
		white_thick_pen.CreatePen(PS_SOLID, 2, RGB(255, 255, 255));

		ev_backbuffer_dc.SetTextColor(RGB(255,255,255));
		ev_backbuffer_dc.SetBkMode(TRANSPARENT);

		ev_onetime = false;
    }
}

// Draws stuff in the backbuffer
void CEvolutionInfoDialog::draw(void)
{
	int button_checked = GetCheckedRadioButton(IDC_FITNESS_CHART, IDC_BEST_NN);

	switch (button_checked)
	{
	case IDC_FITNESS_CHART:
		{
			draw_fitness_chart();
			break;
		}

	case IDC_FITNESS_SPREAD:
		{
			draw_fitness_spread();
			break;
		}

	case IDC_BEST_NN:
		{
			draw_best_nn();
			break;
		}

	case IDC_SPECIES_GRAPH:
		{
			draw_species_history();
			break;
		}
	}

	Invalidate(0);
}


// draws a fitness chart into the back buffer
void CEvolutionInfoDialog::draw_fitness_chart(void)
{
	// let's print some text out
    char str[128];
	CWnd* wnd;
	double step_x;

	wnd = GetDlgItem(IDC_EV_Y_LABEL);
	wnd->SetWindowText("Fitness");
	wnd = GetDlgItem(IDC_EV_X_LABEL);
	wnd->SetWindowText("Generations");


	// make a white background first
	ev_backbuffer_dc.FillSolidRect(&ev_rect, RGB(0,0,0));

	// the size cannot be 0
	// must be at least two generations complete
	if (best_fitness.size() < 2) return;

	// calculate the upper bound of fitness
	if (max_fitness_type == 0) // calculate
	{
    	max_fitness = 0;
		for(int i=0; i<best_fitness.size(); i++)
		{
			if (best_fitness[i] > max_fitness) max_fitness = best_fitness[i];
		}
	}

	// Draw the text number labels
	wnd = GetDlgItem(IDC_EV_X_LIMIT);
	sprintf(str, "%d", best_fitness.size()-1);
	wnd->SetWindowText(str);

	wnd = GetDlgItem(IDC_EV_Y_LIMIT);
	sprintf(str, "%3.0f", max_fitness);
	wnd->SetWindowText(str);

	// the points will be from 0 to fitness.size()
	// scaled in X to the window's width and in Y - the height / max_fitness

	// Display the best fitness chart with black
	step_x  = (double)ev_rect.right / ((double)best_fitness.size()-1);

	// display the grid
	CPen* gridpen = new CPen(PS_SOLID, 1, RGB(110, 110, 100));
	ev_backbuffer_dc.SelectObject(gridpen);
	for(double xx=0; xx<best_fitness.size(); xx++)
	{
		ev_backbuffer_dc.MoveTo(xx*step_x, 0);
		ev_backbuffer_dc.LineTo(xx*step_x, ev_rect.bottom);
	}
	for(double yy=0; yy<1.0; yy += (1.0/16.0))
	{
		ev_backbuffer_dc.MoveTo(0, yy*ev_rect.bottom);
		ev_backbuffer_dc.LineTo(ev_rect.right, yy*ev_rect.bottom);
	}
	delete gridpen;


	ev_backbuffer_dc.SelectObject(white_pen);

	// the first step
	ev_backbuffer_dc.MoveTo(0, ev_rect.bottom - (best_fitness[0] / max_fitness) * ev_rect.bottom);

	// now for every other step on X ...
	for(double xstep=1; xstep<best_fitness.size(); xstep++)
	{
		double cur_fitness = best_fitness[xstep];
		double y = (cur_fitness / max_fitness) * ev_rect.bottom;

		ev_backbuffer_dc.LineTo((xstep) * step_x, ev_rect.bottom - y);
	}


	// now display the average fitness chart with green
	step_x  = (double)ev_rect.right / ((double)average_fitness.size()-1);
	ev_backbuffer_dc.SelectObject(green_thick_pen);

	// the first step
	ev_backbuffer_dc.MoveTo(0, ev_rect.bottom - (average_fitness[0] / max_fitness) * ev_rect.bottom);

	// now for every other step on X ...
	for(double xstep=1; xstep<average_fitness.size(); xstep++)
	{
		double cur_fitness = average_fitness[xstep];
		double y = (cur_fitness / max_fitness) * ev_rect.bottom;

		ev_backbuffer_dc.LineTo((xstep) * step_x, ev_rect.bottom - y);
	}

	// display the best ever fitness with a red vertical line and 
	// the generation it appears
	double best=0;
	int index=0;
	for(int i=0; i<best_fitness.size(); i++)
	{
		if (best_fitness[i] >= best)
		{
			best = best_fitness[i];
			index = i;
		}
	}

	CPen* redpen = new CPen(PS_SOLID, 1, RGB(255, 0, 0));
	ev_backbuffer_dc.SelectObject(redpen);

	ev_backbuffer_dc.MoveTo( (int)(((double)(index)) * step_x), 0);
	ev_backbuffer_dc.LineTo( (int)(((double)(index)) * step_x), ev_rect.bottom);

	sprintf(str, "%d \n", index);
	ev_backbuffer_dc.TextOut((int)(((double)(index)) * step_x) + 5, ev_rect.bottom - 20, str, strlen(str)-1);
	delete redpen;
}


extern Population* pop;

// draws a fitness spread chart in the backbuffer
void CEvolutionInfoDialog::draw_fitness_spread(void)
{
	// let's print some text out
    char str[128];
	CWnd* wnd;
	double step_x;

	if (pop == NULL) return;

	wnd = GetDlgItem(IDC_EV_Y_LABEL);
	wnd->SetWindowText("Fitness");
	wnd = GetDlgItem(IDC_EV_X_LABEL);
	wnd->SetWindowText("Organisms");

	// make a white background first
	ev_backbuffer_dc.FillSolidRect(&ev_rect, RGB(0,0,0));

	// calculate the upper bound of fitness
	if (max_fitness_type == 0) // calculate
	{
    	max_fitness = 0;
		for(int i=0; i<NEAT::pop_size; i++)
		{
			if (pop->organisms[i]->fitness > max_fitness) max_fitness = pop->organisms[i]->fitness;
		}
	}

	// Draw the text number labels
	wnd = GetDlgItem(IDC_EV_X_LIMIT);
	sprintf(str, "%d", NEAT::pop_size);
	wnd->SetWindowText(str);

	wnd = GetDlgItem(IDC_EV_Y_LIMIT);
	sprintf(str, "%3.0f", max_fitness);
	wnd->SetWindowText(str);

	// step_x will be the bar's width
	step_x = (double)ev_rect.right / (double)NEAT::pop_size;
	// TODO different colors for different species

	// display the grid
	CPen* gridpen = new CPen(PS_SOLID, 1, RGB(110, 110, 100));
	ev_backbuffer_dc.SelectObject(gridpen);
	for(double yy=0; yy<1.0; yy += (1.0/16.0))
	{
		ev_backbuffer_dc.MoveTo(0, yy*ev_rect.bottom);
		ev_backbuffer_dc.LineTo(ev_rect.right, yy*ev_rect.bottom);
	}
	delete gridpen;

	CPen* sp_pen;
	CBrush* sp_brush;

	// for every species
	int i=0;
	for(int sp = 0; sp < pop->species.size(); sp++)
	{
		sp_pen   = new CPen(PS_SOLID, 1, RGB(pop->species[sp]->color_R, pop->species[sp]->color_G, pop->species[sp]->color_B));
		sp_brush = new CBrush(RGB(pop->species[sp]->color_R, pop->species[sp]->color_G, pop->species[sp]->color_B));

		ev_backbuffer_dc.SelectObject(sp_pen);
	    ev_backbuffer_dc.SelectObject(sp_brush);

		// for every organism in this species
		for(int or = 0; or < pop->species[sp]->organisms.size(); or++)
		{
			double cur_fitness = pop->species[sp]->organisms[or]->fitness;

			double y = (cur_fitness / max_fitness) * ev_rect.bottom;

			ev_backbuffer_dc.Rectangle(step_x*i, ev_rect.bottom - y, step_x*(i+1), ev_rect.bottom);
			i++;
		}

		delete sp_pen;
		delete sp_brush;
	}
}

extern NEAT::Substrate* subst;

// draw the best neural network graph in the backbuffer
void CEvolutionInfoDialog::draw_best_nn(void)
{
	// let's print some text out
    char str[128];
	CWnd* wnd;

	// make a black background first
	ev_backbuffer_dc.FillSolidRect(&ev_rect, RGB(127,127,127));

	wnd = GetDlgItem(IDC_EV_Y_LABEL);
	wnd->SetWindowText("");
	wnd = GetDlgItem(IDC_EV_X_LABEL);
	wnd->SetWindowText("Output");
	wnd = GetDlgItem(IDC_EV_Y_LIMIT);
	wnd->SetWindowText("Input");
	wnd = GetDlgItem(IDC_EV_X_LIMIT);
	wnd->SetWindowText("");

	HDC dc = ev_backbuffer_dc.GetSafeHdc();


#ifdef SUBSTRATE
	NEAT::Network* n = create_hyper_phenotype(pop->organisms[best_index]->net, subst);
#endif
	Prepare_To_Draw_NN(
#ifdef SUBSTRATE		
n
#else
pop->organisms[best_index]->net
#endif
, ev_rect.right, ev_rect.bottom - 30,

#ifdef SUBSTRATE
NN_DRAWING_SUBSTRATE
#else
NN_DRAWING_NORMAL
#endif
);

	Draw_NN(
#ifdef SUBSTRATE
n
#else
pop->organisms[best_index]->net
#endif
, dc,

#ifdef SUBSTRATE
0
#else
1
#endif
);

#ifdef SUBSTRATE
	delete n;
#endif
}

void CEvolutionInfoDialog::OnBnClickedFitnessChart()
{
	draw();
	// TODO: Add your control notification handler code here
}

void CEvolutionInfoDialog::OnBnClickedFitnessSpread()
{
	draw();
	// TODO: Add your control notification handler code here
}

void CEvolutionInfoDialog::OnBnClickedBestNn()
{
//	draw();
	// TODO: Add your control notification handler code here
}




void CEvolutionInfoDialog::draw_species_history(void)
{
	// let's print some text out
    char str[128];
	CWnd* wnd;
	double step_x;
	double step_y;

	wnd = GetDlgItem(IDC_EV_Y_LABEL);
	wnd->SetWindowText("Organisms");
	wnd = GetDlgItem(IDC_EV_X_LABEL);
	wnd->SetWindowText("Generations");

	// make a white background first
	ev_backbuffer_dc.FillSolidRect(&ev_rect, RGB(0,0,0));

	// the size cannot be 0
	// must be at least two generations complete
	if (species_history.size() < 2) return;

	// calculate the upper bound of fitness
	if (max_fitness_type == 0) // calculate
	{
    	max_fitness = 0;
		for(int i=0; i<best_fitness.size(); i++)
		{
			if (best_fitness[i] > max_fitness) max_fitness = best_fitness[i];
		}
	}

	// Draw the text number labels
	wnd = GetDlgItem(IDC_EV_X_LIMIT);
	sprintf(str, "%d", species_history.size()-1);
	wnd->SetWindowText(str);

	wnd = GetDlgItem(IDC_EV_Y_LIMIT);
	sprintf(str, "%d", NEAT::pop_size);
	wnd->SetWindowText(str);

	step_x  = (double)ev_rect.right / ((double)species_history.size()-1);
	step_y  = (double)ev_rect.bottom / (double)NEAT::pop_size;

	// The graphic will be drawn as series of polygons
	// when a species exists in both generations i and i+1, then the poly is 4-sided
	// when a species exist only in generation i and is extinct in i+1, a triangle is drawn

	
	for(int gen=0; gen < (species_history.size()-1); gen++)
	{
		int cur_gen = gen;
		int next_gen = gen+1;
		// the first x axis is cur_gen*step_x
		// the second is for the next generation
		double cur_x1 = cur_gen  * step_x;
		double cur_x2 = next_gen * step_x;

		// for each species in the next generation
		for(int spec = 0; spec < species_history[next_gen].species_size.size(); spec++)
		{
			// get this specie's ID
			int id = species_history[next_gen].species_id[spec];
			
			// see if it exists in the previous generation
			bool exist = false;
			for(int i=0; i< species_history[cur_gen].species_size.size(); i++)
			{
				if (species_history[cur_gen].species_id[i] == id) 
				{
					exist = true;
					break;
				}
			}

			// if it exists, calculate its polyline and display it
			if (exist)
			{
				CPoint pts[4];
				double tmp;
				CPen* pen = new CPen(PS_SOLID, 1, species_history[next_gen].species_color[spec]);
				CBrush* br = new CBrush(species_history[next_gen].species_color[spec]);

				int j;

				// the polygon is: 0-1 : upper next, upper cur
				//                 2-3 : downer cur, downer next
				
				pts[0].x = cur_x2;
				pts[0].y = 0;
				
				// find the start Y point in the next
				j=0;
				tmp=0;
				while(species_history[next_gen].species_id[j] != id)
				{
					tmp += (double)species_history[next_gen].species_size[j] * step_y;
					j++;
				}
				pts[0].y = tmp;
                // the downer next is now calculated
				// now j is the index of the species with this id
				pts[3].x = cur_x2;
				pts[3].y = pts[0].y + ((double)species_history[next_gen].species_size[j] * step_y);


				
				// now for the current generation ... 
				pts[1].x = cur_x1;
				pts[1].y = 0;
				
				// find the start Y point in the cur
				j=0;
				tmp=0;
				while(species_history[cur_gen].species_id[j] != id)
				{
					tmp += (double)species_history[cur_gen].species_size[j] * step_y;
					j++;
				}
				pts[1].y = tmp;

				// now j is the index of the species with this id
				pts[2].x = cur_x1;
				pts[2].y = pts[1].y + ((double)species_history[cur_gen].species_size[j] * step_y);

				ev_backbuffer_dc.SelectObject(pen);
				ev_backbuffer_dc.SelectObject(br);

				// draw the polygon
				ev_backbuffer_dc.Polygon(pts, 4);

				ev_backbuffer_dc.SelectObject(white_pen);
				
				ev_backbuffer_dc.MoveTo(pts[0]);
				ev_backbuffer_dc.LineTo(pts[1]);
				ev_backbuffer_dc.MoveTo(pts[2]);
				ev_backbuffer_dc.LineTo(pts[3]);

				delete pen;
				delete br;
			}
			// THE NEXT SPECIES DOES NOT EXIST IN THE CURRENT GENERATION CASE
			else
			{
				CPoint pts[3];
				double tmp;
				CPen* pen = new CPen(PS_SOLID, 1, species_history[next_gen].species_color[spec]);
				CBrush* br = new CBrush(species_history[next_gen].species_color[spec]);
				int j;

				// the polygon is 0: cur, bottom
				//                1-2: upper-downer next

				// the first point is down in the current generation
				pts[0].x = cur_x1;
				pts[0].y = ev_rect.bottom;

				// find the start Y point in the next
				pts[1].x = cur_x2;
				pts[1].y = 0;
				j=0;
				tmp=0;
				while(species_history[next_gen].species_id[j] != id)
				{
					tmp += (double)species_history[next_gen].species_size[j] * step_y;
					j++;
				}
				pts[1].y = tmp;
                // the downer next is now calculated
				// now j is the index of the species with this id
				pts[2].x = cur_x2;
				pts[2].y = pts[1].y + ((double)species_history[next_gen].species_size[j] * step_y);

				ev_backbuffer_dc.SelectObject(pen);
				ev_backbuffer_dc.SelectObject(br);

				// draw the polygon
				ev_backbuffer_dc.Polygon(pts, 3);

				ev_backbuffer_dc.SelectObject(white_pen);
				
				ev_backbuffer_dc.MoveTo(pts[0]);
				ev_backbuffer_dc.LineTo(pts[1]);
				ev_backbuffer_dc.MoveTo(pts[0]);
				ev_backbuffer_dc.LineTo(pts[2]);

				delete pen;
				delete br;
			}
		}
	}
}


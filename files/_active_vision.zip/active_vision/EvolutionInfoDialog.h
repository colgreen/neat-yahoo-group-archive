#pragma once
#include "afxcmn.h"
#include "afxwin.h"
#include <vector>

using namespace std;

typedef struct species_record_tag
{
	vector<int> species_size;
	vector<int> species_id;
	vector<COLORREF> species_color;
} species_record_t;


// CEvolutionInfoDialog dialog

class CEvolutionInfoDialog : public CDialog
{
	DECLARE_DYNAMIC(CEvolutionInfoDialog)

public:
	CEvolutionInfoDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CEvolutionInfoDialog();

// Dialog Data
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CProgressCtrl GenProgress;
public:
	afx_msg void OnPaint();
public:
	// Keeps track of the best fitness for each generation
	vector<double> best_fitness;
	// Keeps track of the average fitness each generation
	vector<double> average_fitness;

	double max_fitness;
	int max_fitness_type; // 0 - explicitly calculate, 1 - given in max_fitness
public:
	// inits the back buffer and stuff
	void init(void);
public:
	// Draws stuff in the backbuffer
	void draw(void);
public:
	// //draws a fitness chart into the back buffer
	void draw_fitness_chart(void);
public:
	// draws a fitness spread chart in the backbuffer
	void draw_fitness_spread(void);
public:
	// index of the best network for the previous generation
	int best_index;
public:
	// draw the best neural network graph in the backbuffer
	void draw_best_nn(void);
public:
	afx_msg void OnBnClickedFitnessChart();
public:
	afx_msg void OnBnClickedFitnessSpread();
public:
	afx_msg void OnBnClickedBestNn();
public:
	// track the history of species through evolution
	vector<species_record_t> species_history;
public:
	void draw_species_history(void);
};

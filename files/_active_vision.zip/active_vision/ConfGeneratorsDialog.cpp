// ConfGeneratorsDialog.cpp : implementation file
//

#include "stdafx.h"
#include "ActiveVision.h"
#include "ConfGeneratorsDialog.h"


// CConfGeneratorsDialog dialog

IMPLEMENT_DYNAMIC(CConfGeneratorsDialog, CDialog)

CConfGeneratorsDialog::CConfGeneratorsDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CConfGeneratorsDialog::IDD, pParent)
{

}

CConfGeneratorsDialog::~CConfGeneratorsDialog()
{
}

void CConfGeneratorsDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CConfGeneratorsDialog, CDialog)
END_MESSAGE_MAP()


// CConfGeneratorsDialog message handlers

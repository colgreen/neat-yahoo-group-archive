////////////////////////////////////////////
// Image Structures and definitions       //
////////////////////////////////////////////

#ifndef IMAGE_H
#define IMAGE_H

typedef struct image_tag
{
	int x_size, y_size; // test
	unsigned char* pixels;
	int type; 
} image_t;


// All images are converted to 8-bit grayscale

void free_image(image_t* image);
image_t* clone_image(image_t* image);
void copy_image(image_t* dest, image_t* src);

image_t* new_image(int x_size, int y_size, int type);

// generate new image and read data from file
image_t* new_image_read_raw8(int x_size, int y_size, char* filename, int type);
image_t* new_image_read_raw16(int x_size, int y_size, char* filename, int type);
image_t* new_image_read_targa16(int x_size, int y_size, char* filename, int type);
image_t* new_image_read_WindowsBMP24(int x, int y, char* filename, int type);

// read image data from file
int image_read_raw8(image_t* image, char* filename);
int image_read_raw16(image_t* image, char* filename);
int image_read_targa16(image_t* image, char* filename);
int image_read_WindowsBMP24(image_t* image, char* filename);


void transform_image_translation(int dx, int dy, image_t* image);
void transform_image_zoom(double sc, image_t* image);
void transform_image_rotation(double sc, image_t* image);





#endif
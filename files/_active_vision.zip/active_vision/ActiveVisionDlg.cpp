////////////////////////
// Peter Chervenski
// spookey@abv.bg
////////////////////////

// ActiveVisionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "evolution.h"
#include "image.h"
#include "display.h"
#include "ActiveVision.h"
#include "ActiveVisionDlg.h"
#include "EvolutionInfoDialog.h" 
#include "VisualModeDialog.h"
#include "OptionsDialog.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CActiveVisionDlg dialog




CActiveVisionDlg::CActiveVisionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CActiveVisionDlg::IDD, pParent)
	, from_gen(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CActiveVisionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_DEMO_GENERATION, from_gen);
}

BEGIN_MESSAGE_MAP(CActiveVisionDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CActiveVisionDlg::OnBnClickedStartEvolution)
	ON_BN_CLICKED(IDC_BUTTON2, &CActiveVisionDlg::OnBnClickedStopEvolution)
	ON_BN_CLICKED(IDC_BUTTON3, &CActiveVisionDlg::OnBnClickedEvolutionInfo)
	ON_BN_CLICKED(IDC_RADIO1, &CActiveVisionDlg::OnBnClickedFastMode)
	ON_BN_CLICKED(IDC_RADIO2, &CActiveVisionDlg::OnBnClickedVisualMode)
	ON_BN_CLICKED(IDC_DEMO_BUTTON, &CActiveVisionDlg::OnBnClickedDemoButton)
	ON_BN_CLICKED(IDC_BUTTON4, &CActiveVisionDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_EXPORT_BUTTON, &CActiveVisionDlg::OnBnClickedExportButton)
END_MESSAGE_MAP()


// CActiveVisionDlg message handlers

BOOL CActiveVisionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CActiveVisionDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CActiveVisionDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CActiveVisionDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


HANDLE ev_thread_handle;
HANDLE demo_thread_handle;
bool evolution_running=false;
extern bool reproducing;

void CActiveVisionDlg::OnBnClickedStartEvolution()
{
	if (pop == NULL)
	{
		ev_thread_handle = CreateThread(NULL, 65535, (LPTHREAD_START_ROUTINE) &evolution_thread, NULL, 0 , 0);
		SetThreadPriority(ev_thread_handle, THREAD_PRIORITY_BELOW_NORMAL);
		this->SetWindowText("ActiveVision - running evolution...");
		evolution_running = true;
	}
	else
	{
		MessageBox("The evolution process is already running", "Information", MB_OK);
	}
	// TODO: Add your control notification handler code here
}

void CActiveVisionDlg::OnBnClickedStopEvolution()
{
	if (reproducing) return;

	if (evolution_running)
	{
		this->SetWindowText("ActiveVision");
		TerminateThread(ev_thread_handle, 0);
		CloseHandle(ev_thread_handle);
		if (pop)
		{
			delete pop;
			pop = NULL;
		}

		evolution_running = false;
	}
	// TODO: Add your control notification handler code here
}

CEvolutionInfoDialog* EvInfoDialog=NULL;
CVisualModeDialog* VisualModeDialog=NULL;
COptionsDialog* OptionsDialog=NULL;
bool visual_mode = false;

void CActiveVisionDlg::OnBnClickedEvolutionInfo()
{
	if (reproducing) return;

	EvInfoDialog = new CEvolutionInfoDialog(this);

	EvInfoDialog->Create(IDD_DIALOG1, this);
	EvInfoDialog->ShowWindow(SW_SHOW);
	EvInfoDialog->UpdateWindow();

	// the default mode is fitness chart
	EvInfoDialog->CheckRadioButton(IDC_FITNESS_CHART, IDC_BEST_NN, IDC_FITNESS_CHART);

	EvInfoDialog->init();

	EvInfoDialog->Invalidate();

	EvInfoDialog->RunModalLoop();

	// TODO: Add your control notification handler code here
}

void CActiveVisionDlg::OnBnClickedFastMode()
{
	visual_mode = false;
	if (VisualModeDialog != NULL)
		VisualModeDialog->EndModalLoop(0);

	// TODO: Add your control notification handler code here
}


void CActiveVisionDlg::OnBnClickedVisualMode()
{
	visual_mode = true;

	if (reproducing) return;
	if (VisualModeDialog != NULL) return;
	
	VisualModeDialog = new CVisualModeDialog(this);


	VisualModeDialog->Create(IDD_DIALOG2, this);
	VisualModeDialog->ShowWindow(SW_SHOW);
	VisualModeDialog->UpdateWindow();

	VisualModeDialog->init();

	VisualModeDialog->RunModalLoop();

	VisualModeDialog->EndModalLoop(0);


//	VisualModeDialog->DoModal();
	visual_mode = false;

	CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);
	if (VisualModeDialog != NULL)
	{
		VisualModeDialog->EndDialog(0);
		VisualModeDialog->DestroyWindow();
		delete VisualModeDialog;
		VisualModeDialog=NULL;
	}

	// TODO: Add your control notification handler code here
}

extern int demo_from_generation;
extern vector<NEAT::Organism*> superchamps;

void CActiveVisionDlg::OnBnClickedDemoButton()
{
	// save the current eye
	char str[128];

	if (reproducing) return;

	// this stops evolution and will enter demo mode
	GetDlgItemText(IDC_DEMO_GENERATION, str, 128);
	if (strcmp(str, "")==0) strcpy(str, "0");
	demo_from_generation = atoi(str);

	if ((superchamps.size() == 0) || (demo_from_generation >= superchamps.size()))
	{
		MessageBox("Invalid generation number.", "Error", MB_OK);
		return;
	}

//	MessageBox(str, "Demo of champ @ Generation", MB_OK);

	// stop the evolution thread
	SuspendThread(ev_thread_handle);

    // start the demo thread
	demo_thread_handle = CreateThread(NULL, 65535, (LPTHREAD_START_ROUTINE) &visual_demo_thread, NULL, 0 , 0);
	SetThreadPriority(demo_thread_handle, THREAD_PRIORITY_BELOW_NORMAL);
	this->SetWindowText("ActiveVision - demo mode...");

	// create the visual mode dialog
	visual_mode = true;

	if (VisualModeDialog != NULL) return;
	
	VisualModeDialog = new CVisualModeDialog(this);


	VisualModeDialog->Create(IDD_DIALOG2, this);
	VisualModeDialog->ShowWindow(SW_SHOW);
	VisualModeDialog->UpdateWindow();

	VisualModeDialog->init();

	VisualModeDialog->RunModalLoop();
	VisualModeDialog->EndModalLoop(0);

	// OK, now kill off the demo thread
	this->SetWindowText("ActiveVision");
	TerminateThread(demo_thread_handle, 0);
	CloseHandle(demo_thread_handle);

	visual_mode = false;

	if (VisualModeDialog != NULL)
	{
		VisualModeDialog->EndDialog(0);
		VisualModeDialog->DestroyWindow();
		delete VisualModeDialog;
		VisualModeDialog=NULL;
	}

	// resume the evolution thread
	this->SetWindowText("ActiveVision - running evolution...");
	ResumeThread(ev_thread_handle);

	// TODO: Add your control notification handler code here
}

extern char seed_genome[256];
extern double init_mut_power;

void CActiveVisionDlg::OnBnClickedButton4()
{
	char str[256];

	if (OptionsDialog != NULL) return;
	if (evolution_running) return;
	if (reproducing) return;
	
	OptionsDialog = new COptionsDialog(this);

	OptionsDialog->Create(IDD_OPTIONSDIALOG, this);
	OptionsDialog->ShowWindow(SW_SHOW);
	OptionsDialog->UpdateWindow();

	// init the dialog with current values
	CWnd* pWnd;

	sprintf(str, "%3.3f", MAX_DELTA_X);
	pWnd = OptionsDialog->GetDlgItem(IDC_DELTA_X);
	pWnd->SetWindowText(str);

	sprintf(str, "%3.3f", MAX_DELTA_Y);
	pWnd = OptionsDialog->GetDlgItem(IDC_DELTA_Y);
	pWnd->SetWindowText(str);

	sprintf(str, "%3.3f", MAX_DELTA_Z);
	pWnd = OptionsDialog->GetDlgItem(IDC_DELTA_ZOOM);
	pWnd->SetWindowText(str);

	sprintf(str, "%3.3f", MAX_DELTA_ROTATION);
	pWnd = OptionsDialog->GetDlgItem(IDC_DELTA_ALPHA);
	pWnd->SetWindowText(str);

	sprintf(str, "%3.0f", LIFETIME);
	pWnd = OptionsDialog->GetDlgItem(IDC_LIFETIME);
	pWnd->SetWindowText(str);

	sprintf(str, "%3.1f", OFF_IMAGE_INPUT);
	pWnd = OptionsDialog->GetDlgItem(IDC_OFF_INPUT);
	pWnd->SetWindowText(str);

	sprintf(str, "%3.1f", MAX_ZOOM);
	pWnd = OptionsDialog->GetDlgItem(IDC_MAX_ZOOM);
	pWnd->SetWindowText(str);

	sprintf(str, "%3.1f", MIN_ZOOM);
	pWnd = OptionsDialog->GetDlgItem(IDC_MIN_ZOOM);
	pWnd->SetWindowText(str);

	if (AVERAGE_SAMPLING)
		OptionsDialog->CheckRadioButton(IDC_NEAREST_SAMPLING, IDC_AVERAGE_SAMPLING, IDC_AVERAGE_SAMPLING);
	else
		OptionsDialog->CheckRadioButton(IDC_NEAREST_SAMPLING, IDC_AVERAGE_SAMPLING, IDC_NEAREST_SAMPLING);

	OptionsDialog->CheckDlgButton(IDC_INITIAL_MUTATION, 1);

	if (ENABLE_EYE_ROTATION)
		OptionsDialog->CheckDlgButton(IDC_EYE_ROTATION_ABILITY, 1);


	// run the dialog
	OptionsDialog->RunModalLoop();
	OptionsDialog->EndModalLoop(0);

	// set the values back
	OptionsDialog->GetDlgItemTextA(IDC_DELTA_X, str, 128);
	MAX_DELTA_X = atof(str);
	OptionsDialog->GetDlgItemTextA(IDC_DELTA_Y, str, 128);
	MAX_DELTA_Y = atof(str);
	OptionsDialog->GetDlgItemTextA(IDC_DELTA_ZOOM, str, 128);
	MAX_DELTA_Z = atof(str);
	OptionsDialog->GetDlgItemTextA(IDC_DELTA_ALPHA, str, 128);
	MAX_DELTA_ROTATION = atof(str);
	OptionsDialog->GetDlgItemTextA(IDC_LIFETIME, str, 128);
	LIFETIME = atof(str);
	OptionsDialog->GetDlgItemTextA(IDC_OFF_INPUT, str, 128);
	OFF_IMAGE_INPUT = atof(str);
	OptionsDialog->GetDlgItemTextA(IDC_MAX_ZOOM, str, 128);
	MAX_ZOOM = atof(str);
	OptionsDialog->GetDlgItemTextA(IDC_MIN_ZOOM, str, 128);
	MIN_ZOOM = atof(str);

	OptionsDialog->GetDlgItemTextA(IDC_SEED_GENOME, str, 256);
	strcpy(seed_genome, str);

	if (OptionsDialog->IsDlgButtonChecked(IDC_EYE_ROTATION_ABILITY))
	{
		ENABLE_EYE_ROTATION = true;
	}
	else
	{
		ENABLE_EYE_ROTATION = false;
	}


	if (OptionsDialog->IsDlgButtonChecked(IDC_NEAREST_SAMPLING))
	{
		AVERAGE_SAMPLING = false;
	}
	else
	{
		AVERAGE_SAMPLING = true;
	}

	
	if (OptionsDialog->IsDlgButtonChecked(IDC_INITIAL_MUTATION))
	{
		init_mut_power = 1.0;
	}
	else
	{
		init_mut_power = 0.0;
	}

	delete OptionsDialog;
	OptionsDialog=NULL;
	// TODO: Add your control notification handler code here
}

void CActiveVisionDlg::OnBnClickedExportButton()
{
	// save the current eye
	char str[128];
	int save_gen;

	GetDlgItemText(IDC_DEMO_GENERATION, str, 128);
	if (strcmp(str, "")==0) strcpy(str, "0");
	save_gen = atoi(str);

	if ((superchamps.size() == 0) || (save_gen >= superchamps.size()))
	{
		MessageBox("Invalid generation number.", "Error", MB_OK);
		return;
	}

	CFileDialog filedlg(FALSE, "DNA" );

	CString fileName;
    filedlg.GetOFN().lpstrFile = fileName.GetBuffer(1024);

	filedlg.DoModal();

	superchamps[save_gen]->net = superchamps[save_gen]->gnome->genesis(0);

	superchamps[save_gen]->gnome->print_to_filename((char*)fileName.GetBuffer());

	// TODO: Add your control notification handler code here
}

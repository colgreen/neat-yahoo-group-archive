// ActiveVision.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CActiveVisionApp:
// See ActiveVision.cpp for the implementation of this class
//

class CActiveVisionApp : public CWinApp
{
public:
	CActiveVisionApp();

// overrids
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

// For thread sync
extern CRITICAL_SECTION critical_section;

extern CActiveVisionApp theApp;
////////////////////////
// Peter Chervenski
// spookey@abv.bg
////////////////////////

#include "stdafx.h"
#include <iostream>
#include "eye.h"
#include "neat\utils.h"
#include "neat\neat.h"
#include "neat\gene.h"
#include "neat\population.h"
#include "neat\network.h"
#include "neat\organism.h"
#include "neat\math_vectors.h"
#include "neat\math_matrix.h"
#include "neat\visual.h"
#include "neat\substrate.h"
#include "display.h"
#include "ActiveVision.h"
#include "EvolutionInfoDialog.h"
#include "ImageGenerator.h"

using namespace NEAT;
using namespace std;


NEAT::Substrate* subst=NULL;
NEAT::Population* pop=NULL;
vector<NEAT::Organism*> superchamps;

#define GENERATIONS_FOR_THIS_RUN 100000

#define DEG2RAD(x) (((x)/180.0)*3.14)



////////////////////////////
// TO BE CHANGED TO VARS  //
////////////////////////////

int NUM_SAMPLES  = 1;

bool TRANSFORM_IMAGES_ROTATION = false;
bool TRANSFORM_IMAGES_ZOOM = false;
bool TRANSFORM_IMAGES_TRANSLATION = false;

int MAX_IMAGE_ROTATION = 20;   //degrees 
int MAX_IMAGE_TRANSLATION = 10;   //pixels
double MAX_IMAGE_ZOOM  = 0.1;  //percent/100


double init_mut_power = 1.0;


// Initialize the population of genotypes for neural networks (and the NNs too)...
void init_population(char* genomefile)
{
	NEAT::load_neat_params(".\\params.ini", false);
	vector<Genome*> genomes;
	Genome* genome = NULL;
	superchamps.clear();

//	FILE* out;
//	freopen("err.txt", "w", stdout);

	// The user wants to load it from file?
    if (genomefile!=NULL)
	{
		std::ifstream iFile(genomefile);
		genome=new Genome(0,iFile);
		pop = new Population(genome, NEAT::pop_size, 0);
	}
	else
	{
//		for(int i=0; i<NEAT::pop_size; i++)
//		{
			// INPUT : retina pixels + position + rotation + zoom + hourglass + bias
			// OUTPUT: delta x + delta y + delta z + delta alpha + affinity

/*if (ENABLE_EYE_ROTATION)
{
			//genome = new Genome(EYE_DIMENSIONS_X*EYE_DIMENSIONS_Y + 9, 5, 0, 0);
			//genome = new Genome(0, EYE_DIMENSIONS_X*EYE_DIMENSIONS_Y + 9, 5, 0, 0, false, 0.1);
	        

			// ensure that there is a network with at least one connection
			while (genome->genes.size() == 0)
			{
				// oh, a genome with no links? delete it and ask for the next... 
				delete genome;
				genome = new Genome(0, EYE_DIMENSIONS_X*EYE_DIMENSIONS_Y + 9, 5, 0, 0, false, 0.0001);
			} 
}
else
{
*/			//genome = new Genome(EYE_DIMENSIONS_X*EYE_DIMENSIONS_Y + 5, 4, 0, 0);
			//genome = new Genome(0, EYE_DIMENSIONS_X*EYE_DIMENSIONS_Y + 5, 4, 0, 0, false, 0.0001);
	        
	        // CPPN
	        genome = new Genome(5, 1, 0, 0);
			//genome = new Genome(0, 5, 1, 0, 0, false, 0.0001);
	        
			// ensure that there is a network with at least one connection
			while (genome->genes.size() == 0)
			{
				// oh, a genome with no links? delete it and ask for the next... 
				delete genome;
				genome = new Genome(0, 5, 1, 0, 0, false, 0.0001);
			}
//}

			// add the genome
			//genomes.push_back(genome);
//		}

		// create the population from a genome list
        pop = new Population(genome, NEAT::pop_size);//init_mut_power);
	}


	// Create the substrate for the big networks
	subst = new Substrate(NEAT::CIRCULAR, EYE_DIMENSIONS_X*EYE_DIMENSIONS_Y + 5, 6, 4);
}








////////////////////////////////////////////////
// some shitty globals and defines
int gen = 0;
double this_gen_percent = 0;
char* genome_file_name = "genomes\\best_genome";

#define AUTO_SPECIATE
#define SPECIES_TARGET 10
#define COMPAT_MOD 0.3
#define MIN_COMPAT 0.3
//#define ORGS_PER_SPECIES 20
////////////////////////////////////////////////

bool reproducing = false;

void evolve()
{
	reproducing = true;
#ifdef AUTO_SPECIATE
	//We can try to keep the number of species constant at this number
	int num_species_target=SPECIES_TARGET;//NEAT::pop_size / ORGS_PER_SPECIES;
	int num_species=pop->species.size();
	
	// This value is the best choice for dynamic compatibility treshold change
	double compat_mod=COMPAT_MOD; 

	if (gen>1) 
	{ 
		// Adjust the compatibility treshold according to the count of existing species
		if (num_species<num_species_target) 
			NEAT::compat_threshold-=compat_mod; 
		else if (num_species>num_species_target) 
			NEAT::compat_threshold+=compat_mod; 

        // but clamp if below the minimal value
		if (NEAT::compat_threshold<MIN_COMPAT) NEAT::compat_threshold=MIN_COMPAT; 
	} 
#endif

    // Perform a NEAT epoch (reproduce the next brains)
	pop->epoch(++gen);
	reproducing = false;
}














void evaluate_organism(NEAT::Organism* org, vector<image_t*> &images, int match_image_type, bool display)
{
	double total_error=0;
	double max_error=0;

	// Create the big network from the CPPN and substrate
	NEAT::Network* bignet = create_hyper_phenotype(org->net, subst);

	// the maximum error for a given picture is (ERROR_UPPER_LIMIT-ERROR_LOWER_LIMIT)
	max_error = images.size() * (ERROR_UPPER_LIMIT-ERROR_LOWER_LIMIT);

	// to evaluate the organism, we present all images to it, keeping track of its error
	for(int i=0; i<images.size(); i++)
	{
		RovingEye* eye = new RovingEye(bignet, images[i]);

		// proceed for all timesteps
		for(int j=0; j < LIFETIME; j++)
		{
			eye->input();
			eye->update();

			// we can put display code here
			if (visual_mode) 
			{
				if (VisualModeDialog != NULL)
  				{
    				VisualModeDialog->draw(eye);
				}
			}
		}

		bool match;
		// this is a match
		if (images[i]->type == match_image_type)
			match = true;
		else // this is a mismatch
			match = false;
		
		total_error += eye->compute_error(match);

		delete eye;
	}

	// the total error has been calculated, now calculate fitness
	org->fitness = sqr(max_error - total_error);
//	org->fitness /= sqr(max_error);

	delete bignet;
}














vector<double> best_fitness_global;
vector<double> average_fitness_global;

vector<species_record_t> species_history;


// The image generators
vector<BasicImageGenerator*> Generators;
int match_image_type=0;
// Images for testing a given network
vector<image_t*> work_images;

char seed_genome[256];

void evolution_thread()
{
	srand(time(0));

	// Initialize generators
	Generators.clear();
	Generators.push_back( new FileImageGenerator(100, 100, 0, ".\\file1.bmp") );
	Generators.push_back( new FileImageGenerator(100, 100, 1, ".\\file2.bmp") );
	Generators.push_back( new FileImageGenerator(100, 100, 2, ".\\file3.bmp") );

	// Initialize population
	if (strcmp(seed_genome, "")==0)
	{
		init_population(0);
	}
	else
	{
		init_population(seed_genome);
	}

	// Initialize work images array
	work_images.clear();
	for(int i=0; i<Generators.size(); i++)
	{
		for(int j=0; j<NUM_SAMPLES; j++)
		{
			work_images.push_back( new_image(Generators[i]->basic_data->x_size, Generators[i]->basic_data->y_size, Generators[i]->basic_data->type) );
		}
	}
	
	// for tracking the best network(s)
	double best=0;
	double average=0;
	int best_index=0;
	best_fitness_global.clear();
	average_fitness_global.clear();
	species_history.clear();
	double best_ever=0;

	// For every generation
	for(int i=0; i < GENERATIONS_FOR_THIS_RUN; i++)
	{
		// Now for every organism
		for(int j=0; j<NEAT::pop_size; j++)
		{
			reproducing = false;

			// generate the images from the generators
			int cur=0;
			for(int k=0; k<Generators.size(); k++)
			{
				for(int l=0; l<NUM_SAMPLES; l++)
				{
					Generators[k]->GenerateCopy(work_images[cur]);
		    		cur++;
				}
			}
			
			// now tranfsorm those images randomly
			for(int k=0; k<work_images.size(); k++)
			{
if (TRANSFORM_IMAGES_ROTATION)
{
				transform_image_rotation(DEG2RAD((rand() % (MAX_IMAGE_ROTATION*2))-MAX_IMAGE_ROTATION),
					                     work_images[k]);
}


if (TRANSFORM_IMAGES_ZOOM)
{
				double zoom = ((RandFloat() - 0.5) * MAX_IMAGE_ZOOM) + 1.0;
				transform_image_zoom(zoom, work_images[k]); // [0.9 .. 1.1]
}


if (TRANSFORM_IMAGES_TRANSLATION)
{
				transform_image_translation((rand()%MAX_IMAGE_TRANSLATION*2) - MAX_IMAGE_TRANSLATION,
					                        (rand()%MAX_IMAGE_TRANSLATION*2) - MAX_IMAGE_TRANSLATION,
											work_images[k]);
}
			}

			// randomize the order of the images (may skip it)
//			std::random_shuffle(work_images.begin(), work_images.end());

			// evaluate organism with the randomized images
			evaluate_organism(pop->organisms[j], work_images, match_image_type, false);

			// Draw stuff in the dialog, if exists
			if (EvInfoDialog != NULL)
			{
				char str[64];
				CWnd* pWnd;

				sprintf(str, "Generation: %d", i);
				pWnd = EvInfoDialog->GetDlgItem(IDC_EDIT1);
				pWnd->SetWindowText(str);
     			sprintf(str, "%3.1f%%", this_gen_percent);
				pWnd = EvInfoDialog->GetDlgItem(IDC_EDIT2);
				pWnd->SetWindowText(str);
    
				this_gen_percent =  ((double)j / (double)NEAT::pop_size) * 100.0;
				EvInfoDialog->GenProgress.SetPos(this_gen_percent);

				/*if (IsDlgButtonChecked(EvInfoDialog->GetSafeHwnd(), IDC_BEST_NN))
				{
    				EvInfoDialog->best_index = j;
					EvInfoDialog->draw_best_nn();
					EvInfoDialog->Invalidate(FALSE);
				}*/
			}
		}

		// Keep track of some stats
		average=0;
		best=0;
		best_index=0;
		for(int j=0; j<NEAT::pop_size; j++)
		{
			average += pop->organisms[j]->fitness;

			if (pop->organisms[j]->fitness > best)
			{
				best = pop->organisms[j]->fitness;
				best_index = j;
			}
		}


		// save the best organism for future use
		// every best organism is saved for every generation
		Organism* neworg = new Organism(0, pop->organisms[best_index]->gnome, 0);
		neworg->gnome = new Genome((const Genome)(*pop->organisms[best_index]->gnome));
		superchamps.push_back(neworg);

		average /= NEAT::pop_size;

		average_fitness_global.push_back(average);
		best_fitness_global.push_back(best);

		// now save the current species in the population (for displaying)
		species_record_t this_generation;
		this_generation.species_color.clear();
		this_generation.species_size.clear();
		for(int l=0; l<pop->species.size(); l++)
		{
			this_generation.species_id.push_back( pop->species[l]->id );
			this_generation.species_size.push_back( pop->species[l]->organisms.size() );

			// a nice trick is to calculate the average fitness for this species
			// and divide by overall average to get a number [0 .. 1] .. then
			// multipy the color components with it, giving an indication
			// which ones are the good species (bright). 
			// * (not used here)
			double avg=0;
			double best=0;
//				avg += pop->species[l]->organisms[k]->fitness;
			for(int k=0; k<pop->species[l]->organisms.size(); k++) 
			{
				if (pop->species[l]->organisms[k]->fitness > best) best = pop->species[l]->organisms[k]->fitness;
			}
//			avg /= pop->species[l]->organisms.size();
			avg = best;

			double mul = 1;//avg / sqr(work_images.size() * (ERROR_UPPER_LIMIT-ERROR_LOWER_LIMIT));
			this_generation.species_color.push_back( RGB(pop->species[l]->color_R*mul, pop->species[l]->color_G*mul, pop->species[l]->color_B*mul) );
//			this_generation.species_color.push_back( RGB((mul>0.25)?255*mul:0*mul, (mul>0.5)?255*mul:0*mul, (mul>0.75)?255*mul:0*mul) );
		}
		species_history.push_back( this_generation );

		if (EvInfoDialog != NULL)
		{
			CWnd* pWnd;
			SCROLLINFO scrl;
			pWnd = EvInfoDialog->GetDlgItem(IDC_VIEW_POSITION_SCROLLBAR);
			scrl.cbSize = sizeof(SCROLLINFO);
			scrl.fMask = SIF_ALL;
			scrl.nMin = 0;
			scrl.nMax = 100;
			scrl.nPage = 10;
			scrl.nPos = 32;
			scrl.nTrackPos = 0;
			SetScrollInfo(pWnd->GetSafeHwnd(), SB_HORZ, &scrl, TRUE);

			EvInfoDialog->best_fitness.clear();
			for(int f=0; f<best_fitness_global.size(); f++)
			{
				EvInfoDialog->best_fitness.push_back( best_fitness_global[f] );
			}

			EvInfoDialog->average_fitness.clear();
			for(int f=0; f<average_fitness_global.size(); f++)
			{
				EvInfoDialog->average_fitness.push_back( average_fitness_global[f] );
			}

			EvInfoDialog->species_history.clear();
			for(int f=0; f<species_history.size(); f++)
			{
				EvInfoDialog->species_history.push_back( species_history[f] );
			}

			EvInfoDialog->max_fitness = sqr(work_images.size() * (ERROR_UPPER_LIMIT-ERROR_LOWER_LIMIT));
			EvInfoDialog->max_fitness_type = 1;

			EvInfoDialog->best_index = best_index;

			// draw stuff
			EvInfoDialog->draw();
		}

		// New generation
		evolve();
	}
}

















int demo_from_generation=0;

void visual_demo_thread()
{
	while(1)
	{
		if ((superchamps.size() > 0) && (demo_from_generation <= superchamps.size()))
		{
			// generate the images from the generators
			int cur=0;
			for(int k=0; k<Generators.size(); k++)
			{
				for(int l=0; l<NUM_SAMPLES; l++)
				{
					Generators[k]->GenerateCopy(work_images[cur]);
			    	cur++;
				}
			}
			
			// now tranfsorm those images randomly
			for(int k=0; k<work_images.size(); k++)
			{
if (TRANSFORM_IMAGES_ROTATION)
{
				transform_image_rotation(DEG2RAD((rand() % (MAX_IMAGE_ROTATION*2))-MAX_IMAGE_ROTATION),
					                     work_images[k]);
}


if (TRANSFORM_IMAGES_ZOOM)
{
				double zoom = ((RandFloat() - 0.5) * MAX_IMAGE_ZOOM) + 1.0;
				transform_image_zoom(zoom, work_images[k]); // [0.9 .. 1.1]
}


if (TRANSFORM_IMAGES_TRANSLATION)
{
				transform_image_translation((rand()%MAX_IMAGE_TRANSLATION*2) - MAX_IMAGE_TRANSLATION,
					                        (rand()%MAX_IMAGE_TRANSLATION*2) - MAX_IMAGE_TRANSLATION,
											work_images[k]);
}
			}

			// randomize the order of the images
//			std::random_shuffle(work_images.begin(), work_images.end());

			// evaluate organism with the randomized images
			evaluate_organism(superchamps[demo_from_generation], work_images, match_image_type, true);
		}
	}
}

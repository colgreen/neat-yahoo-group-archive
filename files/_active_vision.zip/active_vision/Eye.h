/////////////////////////////////////////
// Main EYE class                      //
/////////////////////////////////////////
#ifndef EYE_H
#define EYE_H

#include "image.h"
#include "NEAT\organism.h"
#include "NEAT\network.h"
#include "NEAT\math_matrix.h"

extern int EYE_DIMENSIONS_X;
extern int EYE_DIMENSIONS_Y;
extern double MAX_DELTA_X;
extern double MAX_DELTA_Y;
extern bool   ENABLE_EYE_ROTATION;
extern double MAX_DELTA_ROTATION;
extern double MAX_DELTA_Z;
extern double MAX_ZOOM;
extern double MIN_ZOOM;
extern double LIFETIME;
extern bool AVERAGE_SAMPLING;
extern double OFF_IMAGE_INPUT;

extern double ERROR_UPPER_LIMIT;
extern double ERROR_LOWER_LIMIT;



using namespace std;

class RovingEye
{
	int fieldx,fieldy;
public:

	// the 2D surface the eye is scanning
	image_t* field;

	// the "brain" of the eye
	NEAT::Network* brain;

	vector<double> inputs;
	vector<double> outputs;

	// current position (absolute coords)
	double x_pos, y_pos;
	double cur_zoom;
	double cur_angle; // in radians
	Matrix matrix; // 2D matrix

	// timesteps remaining
	double timesteps_remaining;
    double lifetime_sqr;

	// current timestep
	double timestep;

	// affinities
	double cur_affinity;
	double aff;
	double weighted_affinity;

	// the constructor
	RovingEye(NEAT::Network* thebrain, image_t* thefield);
	RovingEye();

	// moving (giving normalized deltas [-1 .. 1])
	void move(double dx, double dy);
	void rotate(double a);
	void zoom(double dz);

	// read the pixel values from the current position into the inputs of the network
	void input();

	// activates the network and updates the timestep, position and affinity according to output
	void update();

	// back to inactive state
	void reset();

	// compute fitness based on the affinity
	double compute_error(bool match);
};




#endif
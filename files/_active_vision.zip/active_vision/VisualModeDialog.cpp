////////////////////////
// Peter Chervenski
// spookey@abv.bg
////////////////////////

// VisualModeDialog.cpp : implementation file
//

#include "stdafx.h"
#include <windows.h>
#include "eye.h"
#include "image.h"
#include "display.h"
#include "ActiveVision.h"
#include "VisualModeDialog.h"
#include "neat\visual.h"
#include "neat\math_vectors.h"
#include "neat\math_matrix.h"

// CVisualModeDialog dialog
IMPLEMENT_DYNAMIC(CVisualModeDialog, CDialog)

CVisualModeDialog::CVisualModeDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CVisualModeDialog::IDD, pParent)
{
}

CVisualModeDialog::~CVisualModeDialog()
{
}

void CVisualModeDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CVisualModeDialog, CDialog)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CVisualModeDialog message handlers


char str[128];
RECT vm_rect;
CDC vm_backbuff_dc;
CBitmap vm_backbuff_bmp;

// for drawing the NN
#define VISUAL_NN_FIELDX 400
#define VISUAL_NN_FIELDY 300
#define VISUAL_NN_POSX 130
#define VISUAL_NN_POSY 300

RECT nn_rect;
CDC nn_backbuff_dc;
CBitmap nn_backbuff_bmp;

CPen pen1;
CPen pen2;


void CVisualModeDialog::OnPaint()
{
	CPaintDC paintdc(this); // device context for painting

	paintdc.BitBlt(0, 0, vm_rect.right, vm_rect.bottom, &vm_backbuff_dc, 0, 0, SRCCOPY);

	// TODO: Add your message handler code here
	// Do not call CDialog::OnPaint() for painting messages
}

bool vm_onetime=true;
void CVisualModeDialog::init(void)
{
	if (vm_onetime)
	{
		GetClientRect(&vm_rect);
		vm_backbuff_bmp.CreateCompatibleBitmap(this->GetDC(), vm_rect.right, vm_rect.bottom);
		vm_backbuff_dc.CreateCompatibleDC(this->GetDC());
		vm_backbuff_dc.SelectObject(&vm_backbuff_bmp);

		pen1.CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
		pen2.CreatePen(PS_SOLID, 1, RGB(255, 55, 0));

		nn_rect.top = 0;
		nn_rect.left = 0;
		nn_rect.right = VISUAL_NN_FIELDX;
		nn_rect.bottom = VISUAL_NN_FIELDY;
		nn_backbuff_bmp.CreateCompatibleBitmap(this->GetDC(), nn_rect.right, nn_rect.bottom);
		nn_backbuff_dc.CreateCompatibleDC(this->GetDC());
		nn_backbuff_dc.SelectObject(&nn_backbuff_bmp);

		vm_onetime = false;
	}
}


// Draws what the eye is seeing in a back-buffer DC "vm_backbuff_dc"
int CVisualModeDialog::draw(RovingEye* eye)
{	
	int x_off=50, y_off=50;
	int cell_size= 250 / EYE_DIMENSIONS_X;

	if (eye == NULL) return -1;
	if (visual_mode == false) return -1;
	if (!::IsWindow(m_hWnd)) return -1;

	vm_backbuff_dc.FillSolidRect(&vm_rect, RGB(127, 127, 127));

//	EnterCriticalSection(&critical_section);

	image_t* image = eye->field;


	// display the image
	for(int x=0; x<image->x_size; x++)
	{
		for(int y=0; y<image->y_size; y++)
		{
			int ymul = image->pixels[y*image->x_size + x];
			vm_backbuff_dc.SetPixel(x+x_off, y+y_off, RGB(ymul, ymul, ymul));
		}
	}

	// display a rectangle for the image
	vm_backbuff_dc.SelectObject(pen1);

	vm_backbuff_dc.MoveTo(0+x_off, 0+y_off);
	vm_backbuff_dc.LineTo(image->x_size+x_off, 0+y_off);
	vm_backbuff_dc.LineTo(image->x_size+x_off, image->y_size+x_off);
	vm_backbuff_dc.LineTo(0+x_off, image->y_size+x_off);
	vm_backbuff_dc.LineTo(0+x_off, 0+y_off);

	// Display the eye
	vm_backbuff_dc.SelectObject(pen2);

	Matrix mat;
	memcpy(mat, eye->matrix, sizeof(Matrix));

	double half_dim_x = (double)EYE_DIMENSIONS_X / 2.0;
	double half_dim_y = (double)EYE_DIMENSIONS_Y / 2.0;

    // ensure we draw if the eye is in the image area
	if ((mat[3][0] >= 0) && (mat[3][0] <= image->x_size))
	{
		if ((mat[3][1] >= 0) && (mat[3][1] <= image->y_size))
		{
			vector2D vec,dest;

			vec.x = -half_dim_x*eye->cur_zoom;
			vec.y = -half_dim_y*eye->cur_zoom;
			Transform_Vector_From_Matrix_2D(mat, vec, dest);
			vm_backbuff_dc.MoveTo(x_off + dest.x, y_off + dest.y);
			
			vec.x = half_dim_x*eye->cur_zoom;
			vec.y = -half_dim_y*eye->cur_zoom;
			Transform_Vector_From_Matrix_2D(mat, vec, dest);
			vm_backbuff_dc.LineTo(x_off + dest.x, y_off + dest.y);

			vec.x = half_dim_x*eye->cur_zoom;
			vec.y = half_dim_y*eye->cur_zoom;
			Transform_Vector_From_Matrix_2D(mat, vec, dest);
			vm_backbuff_dc.LineTo(x_off + dest.x, y_off + dest.y);

			vec.x = -half_dim_x*eye->cur_zoom;
			vec.y = half_dim_y*eye->cur_zoom;
			Transform_Vector_From_Matrix_2D(mat, vec, dest);
			vm_backbuff_dc.LineTo(x_off + dest.x, y_off + dest.y);

			vec.x = -half_dim_x*eye->cur_zoom;
			vec.y = -half_dim_y*eye->cur_zoom;
			Transform_Vector_From_Matrix_2D(mat, vec, dest);
			vm_backbuff_dc.LineTo(x_off + dest.x, y_off + dest.y);

			// Draw receptors - vertical lines
			for(double i=0; i<EYE_DIMENSIONS_X; i++)
			{
				vec.x = (i-half_dim_x)*eye->cur_zoom;
				vec.y = -half_dim_y*eye->cur_zoom;
				Transform_Vector_From_Matrix_2D(mat, vec, dest);
				vm_backbuff_dc.MoveTo(x_off + dest.x, y_off + dest.y);
				vec.x = (i-half_dim_x)*eye->cur_zoom;;
				vec.y = half_dim_y*eye->cur_zoom;
				Transform_Vector_From_Matrix_2D(mat, vec, dest);
				vm_backbuff_dc.LineTo(x_off + dest.x, y_off + dest.y);
			}
			// Draw receptors - horiz lines
			for(int i=0; i<EYE_DIMENSIONS_Y; i++)
			{
				vec.x = -half_dim_x*eye->cur_zoom;
				vec.y = (i-half_dim_y)*eye->cur_zoom;
				Transform_Vector_From_Matrix_2D(mat, vec, dest);
				vm_backbuff_dc.MoveTo(x_off + dest.x, y_off + dest.y);
				vec.x = half_dim_x*eye->cur_zoom;
				vec.y = (i-half_dim_y)*eye->cur_zoom;
				Transform_Vector_From_Matrix_2D(mat, vec, dest);
				vm_backbuff_dc.LineTo(x_off + dest.x, y_off + dest.y);
			}

	/*		// just draw a green line to show current orientation
			CPen *p = new CPen(PS_SOLID, 1, RGB(0, 255, 0));
			vm_backbuff_dc.SelectObject(p);

			vec.x = 0; 
			vec.y = -2.5*eye->cur_zoom;
			Transform_Vector_From_Matrix_2D(mat, vec, dest);
			vm_backbuff_dc.MoveTo(x_off + dest.x, y_off + dest.y);
			vec.x = 0;
			vec.y = 0;
			Transform_Vector_From_Matrix_2D(mat, vec, dest);
			vm_backbuff_dc.LineTo(x_off + dest.x, y_off + dest.y);

			delete p;*/
		}
	}

	// Now display what the eye is seeing
	int j=0;
	for(int y= 0; y < EYE_DIMENSIONS_Y; y ++)
	{
		for(int x = 0; x < EYE_DIMENSIONS_X; x++)
		{
			double col = eye->inputs[j];
			COLORREF brr;
			if (col != -1)
				brr = RGB(col * 255, col * 255, col * 255);
			else
				brr = RGB(0, 0, 255);

			int off = image->x_size + x_off*2;
			RECT er;
			er.top = cell_size*y;
			er.left = cell_size*x + off;
			er.bottom = cell_size*y + cell_size;
			er.right = cell_size*x + off + cell_size;

			//vm_backbuff_dc.FillSolidRect(&er, brr);
			vm_backbuff_dc.FillRect(&er, &CBrush(brr));

			j++;
		}
	}


	// Display the weighted affinity
	vm_backbuff_dc.SelectObject(pen1);

	// Up (1.0) and down (0.0) limits
	vm_backbuff_dc.MoveTo(10, 260);
	vm_backbuff_dc.LineTo(60, 260);
	vm_backbuff_dc.MoveTo(10, 360);
	vm_backbuff_dc.LineTo(60, 360);

	vm_backbuff_dc.SelectObject(pen2);

	double hh = eye->weighted_affinity * 100;
	vm_backbuff_dc.MoveTo(10, 360 - hh);
	vm_backbuff_dc.LineTo(60, 360 - hh);

	// Stats, etc
	sprintf(str, "Timestep: %3.0f\n", eye->timestep);
	vm_backbuff_dc.TextOutA(10, 380, str, strlen(str)-1);

	sprintf(str, ": %2.3f\n", hh);
	vm_backbuff_dc.SetTextColor(RGB(0, 255, 0));
	vm_backbuff_dc.TextOutA(70, 360-hh - 10, str, strlen(str)-1);
	vm_backbuff_dc.SetTextColor(RGB(255, 255, 255));


	// Display the Neural Network
	nn_backbuff_dc.FillSolidRect(&nn_rect, RGB(127,127,127));
	Prepare_To_Draw_NN(eye->brain, nn_rect.right, nn_rect.bottom, NN_DRAWING_SUBSTRATE);
	HDC thedc = nn_backbuff_dc.GetSafeHdc();
	Draw_NN(eye->brain, thedc, 0);

	vm_backbuff_dc.BitBlt(image->x_size + x_off*2, 250 + y_off, nn_rect.right, nn_rect.bottom, &nn_backbuff_dc, 0, 0, SRCCOPY);

	Invalidate(0);

	return 0;
}

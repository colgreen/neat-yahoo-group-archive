// 8/16/05 Richard Gong
// max speed of light = 255, minimum Kelvin = 0
// gravity relativity = neural net
// conserved mass, infinite mass, quanta light

#include <iostream>
using namespace std;
#include <vector>
#include "SDL.h"

const double WIDTH = 512, HEIGHT = 320;

struct vect {
	double r, g, cg, cr;
};

enum { u, d, l, r };

class pixel
{
public:
	pixel();
	Uint32 color(SDL_Surface*);
	Uint8 blip(double &, double &);
	void connect(vect*);
	vect v; // vector info for the neighbors
	vector <vect*> neighbor; // like a light cone  / sphere of influence
};
pixel::pixel()
{
	v.r = 0;
	v.g = 0;
	v.cr = 0;
	v.cg = 0;
}
Uint32 pixel::color(SDL_Surface* screen)
{
	return SDL_MapRGB(screen->format, blip(v.r, v.cr), blip(v.g, v.cg), 0);
}
Uint8 pixel::blip(double& x, double& cx)
{
	x += cx;
	cx = 0;
	if (x > 255) return 255;
	if (x < 0) return 0;
	return x;
}
void pixel::connect(vect* pV)
{
	neighbor.push_back(pV);
}

double xwrap(double x)
{
	if (x < 0) return x + WIDTH;
	if (x >= WIDTH) return x - WIDTH;
	return x;
}
double ywrap(double y)
{
	if (y < 0) return y + HEIGHT;
	if (y >= HEIGHT) return y - HEIGHT;
	return y;
}

int main(int argc, char* argv[]){
	SDL_Init(SDL_INIT_VIDEO);
	atexit(SDL_Quit);
	SDL_Surface* screen = SDL_SetVideoMode(WIDTH, HEIGHT, 0, SDL_ANYFORMAT|SDL_FULLSCREEN);	
	SDL_Event event;
	bool go = true;
	vector<vector <pixel> > a(WIDTH, vector<pixel>(HEIGHT, pixel()));

	for (int i = 0; i < WIDTH; i++)
		for (int j = 0; j < HEIGHT; j++)
		{
			pixel* p = &a[i][j];
			p->connect(&a[i][ywrap(j-1)].v);
			p->connect(&a[i][ywrap(j+1)].v);
			p->connect(&a[xwrap(i-1)][j].v);
			p->connect(&a[xwrap(i+1)][j].v);
		}

	//for (i = 100; i < 350; i++)
	//	for (int j = 160; j < 170; j++)
	//		a[i][j].v.r = 255;

	a[256][160].v.r = 256;
	//a[256][170].v.r = 256;
	a[256][170].v.r = 256;

	while (go)
	{
		while (SDL_PollEvent(&event))
			switch (event.type){
			case SDL_QUIT:
				go = 0;
				break;
			case SDL_KEYDOWN:
				switch(event.key.keysym.sym)
				{
				case SDLK_ESCAPE:
					go = 0;
					break;
				}
				break;
			case SDL_MOUSEBUTTONDOWN:
			case SDL_MOUSEMOTION:
				if (SDL_GetMouseState(0,0)&SDL_BUTTON(1))
					a[event.motion.x][event.motion.y].v.cg = 255;
				if (SDL_GetMouseState(0,0)&SDL_BUTTON(3))
					a[event.motion.x][event.motion.y].v.cr = 255;
				break;
			}
		
		for (i = 0; i < WIDTH; i++)
			for (int j = 0; j < HEIGHT; j++)
			{
				double x = a[i][j].v.g;
				pixel* p = &a[i][j];
				if (x)
				{
					for (int k = 0; k < 4; k++)
						p->neighbor[k]->cg += x / 4;
					p->v.cg -= x;
				}
				x = a[i][j].v.r - 1;
				if (x)
				{
					p->v.cg += x; // emit
					p->v.cr -= x; // blink
					double updown = p->neighbor[d]->g - p->neighbor[u]->g;
					double leftright = p->neighbor[r]->g - p->neighbor[l]->g;
					if (updown > 0)
						updown = 1;
					else if
						(updown < 0)
						updown = -1;
					if (leftright > 0)
						leftright = 1;
					else if (leftright < 0)
						leftright = -1;
					a[xwrap(i + leftright)][ywrap(j + updown)].v.cr += x;
				}
			}

		for (i = 0; i < WIDTH; i++)
			for (int j = 0; j < HEIGHT; j++)
			{
				Uint32 *pix = (Uint32*)screen->pixels + j * screen->pitch / 4 + i;
				*pix = a[i][j].color(screen);
			}
		SDL_Flip(screen);
	}

	SDL_FreeSurface(screen);
	return 0;
}
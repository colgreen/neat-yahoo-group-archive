There's only one experiment and it is hard coded. It was my attempt to use multi-layer HyperNeat to classify music chords.

What do I mean by "multi-layer"?
(I wish I have used the best terminologies here.)

A "system" is the whole neural network that composes a few layers of nodes and inter-connecting links. Each layer of links (or nodes) is assigned corresponding "modules" that describes its weight, adaptive rate, delay (or time constant, bias).

The source files that start with "m" deals with module evolution, "s" deals with system evolution.

The two evolution are coupled in the sense that a layer of links can occasionally decide adopt some other species of weight modules. It can also just stick with the same species and adopt the better modules within it. All of these can be adjusted in the parameter.cfg.

Initial DNAs are in modpop, syspop folder with "init" extension.

FFTs folder contains the training data I used, which were just spetrum variations in time for different chords on different instruments.

ExpResults folder contains the expected output for the music training data.

src/wavTool are the tools I used to convert my training datas. It's not required to run the evolution as far as I remembered.

I appologize for bad documentation and design. This was my first Java code ever.
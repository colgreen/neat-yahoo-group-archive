
package ModuleNeat;

/**
 * This class serves as a way to record innovations
 *  specifically, so that an innovation in one genome can be
 *  compared with other innovations in the same epoch, and if they
 *  Are the same innovation, they can both be assigned the same innnovation number.
 *  This class can encode innovations that represent a new link
 *  forming, or a new node being added.  In each case, two
 *  nodes fully specify the innovation and where it must have
 *  occured.  (Between them)
 *
 */
public class mInnovation
{
        /**
         * innovation type NEWLINK : 0, NEWNODE: 1
         */
        int innovation_type;
        
        /**
         * Two nodes specify where the innovation took place : this is the node input
         */
        int node_in_id;
        
        /**
         * Two nodes specify where the innovation took place : this is the node output
         */
        int node_out_id;
        
        /**
         * The number assigned to the innovation
         */
        double innovation_num1;
        
        /**
         * If this is a new node innovation,then there are 2 innovations (links)
         * added for the new node
         */
        double innovation_num2;
        
        /**
         * If a link is added, this is its weight
         */
        double new_weight;
        
        /**
         * If a new node was created, this is its node_id
         */
        int newnode_id;
        
        /**
         * If a new node was created, this is
         *  the innovnum of the gene's link it is being
         * stuck inside
         */
        double old_innov_num;
        
        public mInnovation(int nin, int nout, double num1, double w)
        {
                innovation_type = NeatRoutine.NEWLINK;
                node_in_id=nin;
                node_out_id=nout;
                innovation_num1=num1;
                new_weight=w;
                
                //Unused parameters set to zero
                innovation_num2=0;
                newnode_id=0;
        }
        
        /**
         * Insert the method's description here.
         * Creation date: (24/01/2002 8.09.28)
         */
        public mInnovation(int nin, int nout, double num1,double num2,int newid,double oldinnov)
        {
                innovation_type=NeatRoutine.NEWNODE;
                node_in_id=nin;
                node_out_id=nout;
                innovation_num1=num1;
                innovation_num2=num2;
                newnode_id=newid;
                old_innov_num=oldinnov;
                
                //Unused parameters set to zero
                new_weight=0;
        }
        
}
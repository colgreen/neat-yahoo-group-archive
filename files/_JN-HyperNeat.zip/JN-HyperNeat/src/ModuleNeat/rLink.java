
package ModuleNeat;

import java.util.*;

/**
 *
 * This class describes the real neural links that derived from a system of CPPN modules
 */
public class rLink
{

        /** is a reference to an  input node */
        rNode in_node;
        /** is a reference to a output node; */
        rNode out_node;
        /** this is a flag; if TRUE the connection(link) is recurrent; FALSE otherwise; */
        boolean is_recurrent;
        /** number of delayed signals stored in stored_delay */
        int delay_time;
        double[] delay_train;
        /** weight */
        double weight;
        /** hebbian learning rate */
        double hebb_rate;
        /** presynaptic learning rate */
        double pre_rate;
        /** use to store just removed (and used) activation from time_delay */
        double last_activation;

        /** Creates a real neural link */
        public rLink(sGene fiber, double[] p, Vector wh, rNode in, rNode out)
        {
                is_recurrent = fiber.recurrent;
                in_node = in;
                out_node = out;

                //adjust the parameter with bounds and assign them to the node
                Iterator itr_wh = wh.iterator();
                while(itr_wh.hasNext())
                {
                        mNode _node = (mNode) itr_wh.next();
                        if(_node.node_id == 4)
                        {
                                if(_node.activation > mNeat.max_weight)
                                {
                                        weight = mNeat.max_weight;
                                }
                                else if(_node.activation < mNeat.min_weight)
                                {
                                        weight = mNeat.min_weight;
                                }
                                else
                                {
                                        weight = _node.activation;
                                }
                        }
                        else if(_node.node_id == 5)
                        {
                                double hebb = Math.abs(_node.activation);
                                if(hebb > mNeat.max_hebb_rate)
                                {
                                        hebb_rate = mNeat.max_hebb_rate;
                                }
                                else
                                {
                                        hebb_rate = hebb;
                                }
                        }
                        else if(_node.node_id == 6)
                        {
                                double pre = Math.abs(_node.activation);
                                if(pre > mNeat.max_pre_rate)
                                {
                                        pre_rate = mNeat.max_pre_rate;
                                }
                                else
                                {
                                        pre_rate = pre;
                                }
                        }
                }

                if(is_recurrent)  // if a recurrent fiber, compute delay parameters with respect to position p of the two nodes
                {
                        if(fiber.delay_m_org != null)
                        {
                                Vector de = fiber.delay_m_org.genome.compute_module(p);
                                double delay = ((mNode) de.firstElement()).activation;

                                if(delay < 0.5)
                                {
                                        delay_time = 0; // link will not get computed
                                }
                                else
                                {
                                        if(delay > mNeat.max_time_delay)
                                        {
                                                delay_time = mNeat.max_time_delay;
                                        }
                                        else
                                        {
                                                delay_time = (int) (delay + .5);
                                        }

                                        // fill initial delay signals with zero
                                        delay_train = new double[delay_time];
                                        for(int i = 0; i < delay_time; i++)
                                        {
                                                delay_train[i] = 0;
                                        }
                                        last_activation = 0;
                                }
                        }
                        else
                        {
                                System.out.println("Error: Cannot find delay module!");
                                
                        }
                }
                else
                {
                        delay_time = 0;
                }
        }

        // add a new signal at the end of the array, remove the first entry, shift all index forward by one
        public void add_tail(double num)
        {
                int j = delay_time - 1;
                for(int i = 0; i < j; i++)
                {
                        delay_train[i] = delay_train[i + 1];
                }
                delay_train[j] = num;
        }
}


package ModuleNeat;

import java.util.*;
import java.text.*;

public class sPopulation
{

        /** The organisms in the Population */
        public Vector organisms;
        /** Species in the Population the species should comprise all the genomes */
        public Vector species;
        /** For holding the genetic innovations of the newest generation */
        Vector innovations = new Vector(5, 0);
        /** Current label number available for layers */
        private int cur_node_id;
        /** Current  number of innovation */
        private double cur_innov_num;
        /** The highest species number */
        int last_species;
        /** The last generation played */
        int final_gen;
        //Fitness Statistics
        /** the mean of fitness in current epoch */
        double mean_fitness;
        /** current variance in this epoch */
        double variance;
        /** Is a current standard deviation in current epoch */
        double standard_deviation;
        /** An integer that when above zero tells when the first winner appeared; the number is epoch number. */
        int winnergen;
        /** maximum fitness. (is used for delta code and stagnation detection) */
        double highest_fitness;
        /** If  too high, leads to delta coding process. */
        int highest_last_changed;
        
        double compat_threshold;

        /** create a module population from a file of genomes */
        public sPopulation(String xFileName)
        {
                StringTokenizer st;
                String xline;
                IOseq xFile;

                String curword;
                int idcheck = 0;

                sGenome new_genome;

                organisms = new Vector(10, 0);

                winnergen = 0;
                highest_fitness = 0.0;
                highest_last_changed = 0;
                cur_node_id = 0;
                cur_innov_num = 0.0;
                compat_threshold = mNeat.s_compat_threshold;

                xFile = new IOseq(xFileName);
                boolean ret = xFile.IOseqOpenR();
                if(ret)
                {



                        StringBuffer tmp1 = new StringBuffer("");
                        StringBuffer tmp2 = new StringBuffer("");

                        int status = 0;


                        try
                        {

                                //   System.out.println("  ..opened module population file "+xFileName);

                                xline = xFile.IOseqRead();

                                while(xline.equals("EOF"))
                                {
                                        st = new StringTokenizer(xline);
                                        curword = st.nextToken();

                                        if(curword.equalsIgnoreCase("sysgenomestart"))
                                        {

                                                if(status == 1)
                                                {
                                                        status = 2;
                                                }

                                                curword = st.nextToken();
                                                idcheck = Integer.parseInt(curword);

                                                new_genome = new sGenome(idcheck, xFile);
                                                new_genome.notes = tmp2.toString();

                                                if(new_genome.firing_sequence(0))
                                                {
                                                        organisms.add(new sOrganism(0, new_genome, 1));
                                                }
                                                else
                                                {
                                                        System.out.println("System genome " + new_genome.genome_id + " is disconnnected! It died immediatedly.");
                                                }

                                                if(cur_node_id < new_genome.get_last_node_id())
                                                {
                                                        cur_node_id = new_genome.get_last_node_id();
                                                }
                                                if(cur_innov_num < new_genome.get_last_gene_innovnum())
                                                {
                                                        cur_innov_num = new_genome.get_last_gene_innovnum();
                                                }

                                        }
                                        else if(curword.equals("/*"))
                                        {

                                                if(status == 0)
                                                {
                                                        status = 1;
                                                }

                                                if(status == 2)
                                                {
                                                        status = 1;
                                                //		tmp2 = new StringBuffer("");
                                                }

                                                curword = st.nextToken();
                                                //	 tmp1 = new StringBuffer("");
                                                while(!curword.equals("*/"))
                                                {
                                                        //				tmp1.append(" "+curword);
                                                        //			 			  		System.out.print(" " + curword);
                                                        curword = st.nextToken();
                                                }
//				  				System.out.print("\n");
                                /*	 tmp2.append(" "+tmp1);
                                        System.out.print("\n tmp2 = "+tmp2);*/

                                        }

                                        xline = xFile.IOseqRead();
                                }
                        }
                        catch(Throwable e)
                        {
                                System.err.println(e + " : error during read " + xFileName);
                        }

                        xFile.IOseqCloseR();
                        //System.out.println("\n  ok readed!");

                        speciate();

                }


        }

        /** create and spawn a module population from an initial genome */
        public sPopulation(sGenome g, int size)
        {
                winnergen = 0;
                highest_fitness = 0.0;
                highest_last_changed = 0;
                compat_threshold = mNeat.s_compat_threshold;
                spawn(g, size);
        }

        public void spawn(sGenome g, int size)
        {
                int count;
                sGenome newgenome = null;
                sOrganism neworganism = null;
                organisms = new Vector(size);
                for(count = 1; count <= size; count++)
                {
                        //	  System.out.print("\n Creating organism -> " + count);
                        newgenome = g.duplicate(count);

                        // establish firing sequence of the network for later evaluation, disconnected genome is banned from the population
                        if(newgenome.firing_sequence(0))
                        {
                                newgenome.mutate_node_count(0);
                                neworganism = new sOrganism(0.0, newgenome, 1);
                                organisms.add(neworganism);
                        }
                        else
                        {
                                count--;
                        }
                }

                //Keep a record of the innovation and node number we are on
                cur_node_id = newgenome.get_last_node_id();
                cur_innov_num = newgenome.get_last_gene_innovnum();

        }

        public void speciate()
        {

                Iterator itr_organism;
                Iterator itr_specie;

                sOrganism compare_org = null; //Organism for comparison
                sSpecies newspecies = null;

                species = new Vector(5, 0);
                int counter = 0; //Species counter

                // for each organism.....
                itr_organism = organisms.iterator();
                while(itr_organism.hasNext())
                {

                        sOrganism _organism = ((sOrganism) itr_organism.next());

                        // if list species is empty , create the first species!
                        if(species.isEmpty())
                        {
                                newspecies = new sSpecies(++counter); // create a new specie
                                species.add(newspecies); // add this species to list of species
                                newspecies.organisms.add(_organism);
                                // Add to new spoecies the current organism
                                _organism.species = newspecies; // Point organism to its species

                        }
                        else
                        {
                                // loop in all species.... (each species is a Vector of organism...)
                                itr_specie = species.iterator();
                                boolean done = false;

                                while(!done && itr_specie.hasNext())
                                {

                                        // point _species-esima
                                        sSpecies _specie = ((sSpecies) itr_specie.next());
                                        // point to first organism of this _specie-esima
                                        compare_org = (sOrganism) _specie.organisms.firstElement();
                                        // compare _organism-esimo('_organism') with first organism in current specie('compare_org')
                                        double curr_compat =
                                                _organism.genome.compatibility(compare_org.genome);

                                        if(curr_compat < compat_threshold)
                                        {
                                                //Found compatible species, so add this organism to it
                                                _specie.organisms.add(_organism);
                                                //update in organism pointer to its species
                                                _organism.species = _specie;
                                                //force exit from this block ...
                                                done = true;
                                        }
                                }

                                // if no found species compatible , create specie
                                if(!done)
                                {
                                        newspecies = new sSpecies(++counter); // create a new specie
                                        species.add(newspecies); // add this species to list of species
                                        newspecies.organisms.add(_organism);
                                        // Add to new species the current organism
                                        _organism.species = newspecies; // Point organism to its species

                                }

                        }

                }

                last_species = counter; //Keep track of highest species
        }

        public int getCur_node_id()
        {
                return cur_node_id;
        }

        public void setCur_node_id(int cur_node_id)
        {
                this.cur_node_id = cur_node_id;
        }

        public double getCur_innov_num()
        {
                return cur_innov_num;
        }

        public void setCur_innov_num(double cur_innov_num)
        {
                this.cur_innov_num = cur_innov_num;
        }

        /**
         * the increment of cur_node_id must be
         * executed only from a method of population
         * for security reason
         */
        public int getCur_node_id_and_increment()
        {
                return cur_node_id++;
        }

        /**
         * the increment of cur_innov_num must be
         * executed only from a method of population
         * for security reason
         */
        public double getCurr_innov_num_and_increment()
        {
                return cur_innov_num++;
        }

        public void print_to_filename(String xNameFile)
        {
                //
                // write to file genome in native format (for re-read)
                //
                IOseq xFile;


                xFile = new IOseq(xNameFile);
                xFile.IOseqOpenW(false);

                try
                {
                        print_to_file(xFile);
                }
                catch(Throwable e)
                {
                        System.err.println(e);
                }

                xFile.IOseqCloseW();
        }

        public void print_to_file(IOseq xFile)
        {
                //
                // write to file genome in native format (for re-read)
                //

                Iterator itr_organism;
                sOrganism _organism = null;

                itr_organism = organisms.iterator();

                while(itr_organism.hasNext())
                {
                        _organism = ((sOrganism) itr_organism.next());
                        _organism.genome.print_to_file(xFile);
                }


        }

        public void print_to_file_by_species(String xNameFile)
        {
                //
                // write to file genome in native format (for re-read)
                //
                IOseq xFile;

                xFile = new IOseq(xNameFile);
                xFile.IOseqOpenW(false);


                try
                {

                        Iterator itr_specie;
                        itr_specie = species.iterator();

                        while(itr_specie.hasNext())
                        {
                                sSpecies _specie = ((sSpecies) itr_specie.next());
                                _specie.print_to_file(xFile);
                        }

                }
                catch(Throwable e)
                {
                        System.err.println(e);
                }

                xFile.IOseqCloseW();

        }

        /**
         *
         * epoch turns over a Population to
         * the next generation based on fitness
         *
         */
        public void epoch(int generation, mPopulation tb_pop, mPopulation wh_pop, mPopulation de_pop, boolean module_evolved)
        {

                Iterator itr_specie;
                Iterator itr_organism;
                double total = 0.0;
                //double total_expected=0.0;
                int orgcount = 0;
                int max_expected;
                int total_expected; //precision checking
                int final_expected;
                int half_pop = 0;
                double overall_average = 0.0;
                int total_organisms = 0;
                double skim = 0.0;
                int tmpi = 0;
                int best_species_num = 0;
                int stolen_babies = 0;
                int size_of_curr_specie = 0;
                int NUM_STOLEN = mNeat.s_babies_stolen; //Number of babies to steal
                // al momento NUM_STOLEN=1

                sSpecies _specie = null;
                sSpecies curspecies = null;
                sSpecies best_specie = null;
                Vector sorted_species = null;


                // Use Species' ages to modify the objective fitness of organisms
                // in other words, make it more fair for younger species
                // so they have a chance to take hold
                // Also penalize stagnant species
                // Then adjust the fitness using the species size to "share" fitness
                // within a species.
                // Then, within each Species, mark for death
                // those below survival_thresh * average

                itr_specie = species.iterator();
                while(itr_specie.hasNext())
                {
                        _specie = ((sSpecies) itr_specie.next());
                        _specie.adjust_fitness();
                }

                //Go through the organisms and add up their fitnesses to compute the
                //overall average

                itr_organism = organisms.iterator();
                total = 0.0;
                while(itr_organism.hasNext())
                {
                        sOrganism _organism = ((sOrganism) itr_organism.next());
                        total += _organism.fitness;
                }


                total_organisms = organisms.size();
                overall_average = total / total_organisms;

                //Now compute expected number of offspring for each individual organism
                //
                itr_organism = organisms.iterator();
                int orgnum = 0;
                while(itr_organism.hasNext())
                {
                        sOrganism _organism = ((sOrganism) itr_organism.next());
                        _organism.expected_offspring = _organism.fitness / overall_average;
                }

                //Now add those offspring up within each Species to get the number of
                //offspring per Species
                skim = 0.0;
                total_expected = 0;
                int specount = 0;
                itr_specie = species.iterator();
                while(itr_specie.hasNext())
                {
                        _specie = ((sSpecies) itr_specie.next());
                        skim = _specie.count_offspring(skim);
                        total_expected += _specie.expected_offspring;
                }

                //Need to make up for lost foating point precision in offspring assignment
                //If we lost precision, give an extra baby to the best Species

                if(total_expected < total_organisms)
                {

                        //Find the Species expecting the most
                        max_expected = 0;
                        final_expected = 0;
                        itr_specie = species.iterator();

                        while(itr_specie.hasNext())
                        {
                                _specie = ((sSpecies) itr_specie.next());
                                if(_specie.expected_offspring >= max_expected)
                                {
                                        max_expected = _specie.expected_offspring;
                                        best_specie = _specie;
                                }
                                final_expected += _specie.expected_offspring;
                        }
                        //Give the extra offspring to the best species

                        best_specie.expected_offspring++;
                        final_expected++;

                        //If we still arent at total, there is a problem
                        //Note that this can happen if a stagnant Species
                        //dominates the population and then gets killed off by its age
                        //Then the whole population plummets in fitness
                        //If the average fitness is allowed to hit 0, then we no longer have
                        //an average we can use to assign offspring.
                        if(final_expected < total_organisms)
                        {
                                System.out.print("\n Sorry : System Population has DIED +");
                                System.out.print("\n ------------------------------");
                                itr_specie = species.iterator();
                                while(itr_specie.hasNext())
                                {
                                        _specie = ((sSpecies) itr_specie.next());
                                        _specie.expected_offspring = 0;
                                }
                                best_specie.expected_offspring = total_organisms;
                        }
                }


                sorted_species = new Vector(species.size(), 0);
                //copy the Species pointers into a new Species list for sorting
                itr_specie = species.iterator();
                while(itr_specie.hasNext())
                {
                        _specie = ((sSpecies) itr_specie.next());
                        sorted_species.add(_specie);
                }

                //Sort the population and mark for death those after survival_thresh * pop_size

                Comparator cmp = new sorder_species();
                Collections.sort(sorted_species, cmp);

                // sorted species has all species ordered : the species with orig_fitness maximum is first

                curspecies = (sSpecies) sorted_species.firstElement();
                best_species_num = curspecies.id;




                StringBuffer rep1 = new StringBuffer("");
                //   	System.out.print("\n  The BEST specie is #" + best_species_num);
                rep1.append("\n  the BEST  specie is #" + best_species_num);



                // report current situation

                itr_specie = sorted_species.iterator();
                while(itr_specie.hasNext())
                {
                        _specie = ((sSpecies) itr_specie.next());
                        //	  	System.out.print("\n  orig fitness of Species #" + _specie.id);
                        rep1.append("\n  orig fitness of Species #" + _specie.id);

                        //	  	System.out.print(" (Size " + _specie.getOrganisms().size() + "): ");
                        rep1.append(" (Size " + _specie.organisms.size() + "): ");

                        // 	  	System.out.print(" is " + ((Organism) (_specie.organisms.firstElement())).orig_fitness);
                        rep1.append(" is " + ((sOrganism) (_specie.organisms.firstElement())).orig_fitness);

                        // 	  	System.out.print(" last improved ");
                        rep1.append(" last improved ");

                        //	  	System.out.print(_specie.age - _specie.age_of_last_improvement);
                        rep1.append(_specie.age - _specie.age_of_last_improvement);

                        //	  	System.out.print(" offspring "+_specie.expected_offspring);
                        rep1.append(" offspring " + _specie.expected_offspring);

                }


                NeatRoutine.sREPORT_SPECIES_TESTA = rep1.toString();
                rep1 = new StringBuffer("");





                curspecies = (sSpecies) sorted_species.firstElement();

                //Check for Population-level stagnation
                ((sOrganism) curspecies.organisms.firstElement()).pop_champ = true;


                sOrganism tmp = (sOrganism) curspecies.organisms.firstElement();


                if(((sOrganism) curspecies.organisms.firstElement()).orig_fitness > highest_fitness)
                {
                        highest_fitness = ((sOrganism) curspecies.organisms.firstElement()).orig_fitness;
                        highest_last_changed = 0;
                        //	  	System.out.print("\n    Good! Population has reached a new *RECORD FITNESS* -> " + highest_fitness);
                        rep1.append("\n    population has reached a new *RECORD FITNESS* -> " + highest_fitness);


                        // 01.06.2002
                        NeatRoutine.sCURR_ORGANISM_CHAMPION = tmp;





                        NeatRoutine.sMIN_ERROR = ((sOrganism) curspecies.organisms.firstElement()).error;


                }
                else
                {
                        ++highest_last_changed;
                        NeatRoutine.sREPORT_SPECIES_TESTA = "";

                        //	  	System.out.print("\n  Are passed "+ highest_last_changed+ " generations from last population fitness record: "+ highest_fitness);
                        rep1.append("\n    are passed " + highest_last_changed + " generations from last population fitness record: " + highest_fitness);
                }



                NeatRoutine.sREPORT_SPECIES_CORPO = rep1.toString();

                //Check for stagnation- if there is stagnation, perform delta-coding (mass extinction, then reproduction)

                if(highest_last_changed >= mNeat.s_dropoff_age + mNeat.s_extinction_age)
                {
                        //------------------ block delta coding ----------------------------
                        System.out.print("\n+  <PERFORMING DELTA CODING>");
                        highest_last_changed = 0;
                        half_pop = mNeat.sys_pop_size / 2;
                        tmpi = mNeat.sys_pop_size - half_pop;
                        System.out.print("\n  Sys Pop size is " + mNeat.sys_pop_size);
                        System.out.print(", half_pop=" + half_pop + ",   sys_pop_size - halfpop=" + tmpi);

                        itr_specie = sorted_species.iterator();
                        _specie = ((sSpecies) itr_specie.next());

                        // the first organism of first species can have  offspring = 1/2 pop size
                        ((sOrganism) _specie.organisms.firstElement()).super_champ_offspring = half_pop;
                        // the first species  can have offspring = 1/2 pop size
                        _specie.expected_offspring = half_pop;
                        _specie.age_of_last_improvement = _specie.age;

                        if(itr_specie.hasNext())
                        {
                                _specie = ((sSpecies) itr_specie.next());
                                ((sOrganism) _specie.organisms.firstElement()).super_champ_offspring = half_pop;
                                // the second species  can have offspring = 1/2 pop size
                                _specie.expected_offspring = half_pop;
                                _specie.age_of_last_improvement = _specie.age;
                                // at this moment the offpring is terminated : the remainder species has 0 offspring!
                                while(itr_specie.hasNext())
                                {
                                        _specie = ((sSpecies) itr_specie.next());
                                        _specie.expected_offspring = 0;
                                }
                        }
                        else
                        {
                                ((sOrganism) _specie.organisms.firstElement()).super_champ_offspring += mNeat.sys_pop_size - half_pop;
                                _specie.expected_offspring += mNeat.sys_pop_size - half_pop;
                        }

                }
                else
                {
                        // --------------------------------- block baby stolen (if baby stolen > 0)  -------------------------
                        //		System.out.print("\n   Starting with NUM_STOLEN = "+NUM_STOLEN);

                        if(mNeat.s_babies_stolen > 0)
                        {
                                _specie = null;
                                //Take away a constant number of expected offspring from the worst few species
                                stolen_babies = 0;
                                for(int j = sorted_species.size() - 1; (j >= 0) && (stolen_babies < NUM_STOLEN); j--)
                                {
                                        _specie = (sSpecies) sorted_species.elementAt(j);
                                        //				System.out.print("\n Analisis SPECIE #"+j+" (size = "+_specie.organisms.size()+" )");
                                        if((_specie.age > 5) && (_specie.expected_offspring > 2))
                                        {
                                                //		System.out.print("\n ....STEALING!");
                                                tmpi = NUM_STOLEN - stolen_babies;
                                                if((_specie.expected_offspring - 1) >= tmpi)
                                                {
                                                        _specie.expected_offspring -= tmpi;
                                                        stolen_babies = NUM_STOLEN;
                                                }
                                                else
                                                //Not enough here to complete the pool of stolen
                                                {
                                                        stolen_babies += _specie.expected_offspring - 1;
                                                        _specie.expected_offspring = 1;
                                                }
                                        }
                                }




                                //		 	System.out.print("\n stolen babies = "+ stolen_babies);
                                //Mark the best champions of the top species to be the super champs
                                //who will take on the extra offspring for cloning or mutant cloning
                                //Determine the exact number that will be given to the top three
                                //They get , in order, 1/5 1/5 and 1/10 of the stolen babies

                                int tb_four[] = new int[3];
                                tb_four[0] = mNeat.s_babies_stolen / 5;
                                tb_four[1] = tb_four[0];
                                tb_four[2] = mNeat.s_babies_stolen / 10;

                                boolean done = false;
                                itr_specie = sorted_species.iterator();
                                int i_block = 0;



                                while(!done && itr_specie.hasNext())
                                {
                                        _specie = ((sSpecies) itr_specie.next());
                                        if(_specie.last_improved() <= mNeat.s_dropoff_age)
                                        {
                                                if(i_block < 3)
                                                {
                                                        if(stolen_babies >= tb_four[i_block])
                                                        {
                                                                ((sOrganism) _specie.organisms.firstElement()).super_champ_offspring = tb_four[i_block];
                                                                _specie.expected_offspring += tb_four[i_block];
                                                                stolen_babies -= tb_four[i_block];
                                                                System.out.print("\n  give " + tb_four[i_block] + " babies to specie #" + _specie.id);
                                                        }
                                                        i_block++;
                                                }
                                                else if(i_block >= 3)
                                                {
                                                        if(NeatRoutine.randfloat() > 0.1)
                                                        {
                                                                if(stolen_babies > 3)
                                                                {
                                                                        ((sOrganism) _specie.organisms.firstElement()).super_champ_offspring = 3;
                                                                        _specie.expected_offspring += 3;
                                                                        stolen_babies -= 3;
                                                                        System.out.print("\n    Give 3 babies to Species " + _specie.id);
                                                                }
                                                                else
                                                                {
                                                                        ((sOrganism) _specie.organisms.firstElement()).super_champ_offspring = stolen_babies;
                                                                        _specie.expected_offspring += stolen_babies;
                                                                        System.out.print("\n    Give " + stolen_babies + " babies to Species " + _specie.id);
                                                                        stolen_babies = 0;
                                                                }
                                                        }
                                                        if(stolen_babies == 0)
                                                        {
                                                                done = true;
                                                        }
                                                }
                                        }
                                }

                                if(stolen_babies > 0)
                                {
                                        System.out.print("\n Not all given back, giving to best Species");
                                        itr_specie = sorted_species.iterator();
                                        _specie = ((sSpecies) itr_specie.next());
                                        ((sOrganism) _specie.organisms.firstElement()).super_champ_offspring += stolen_babies;
                                        _specie.expected_offspring += stolen_babies;
                                        System.out.print("\n    force +" + stolen_babies + " offspring to Species " + _specie.id);
                                        stolen_babies = 0;
                                }
                        } // end baby_stolen > 0

                }
                // ---------- phase of elimination of organism with flag eliminate ------------
                itr_organism = organisms.iterator();
                Vector vdel = new Vector(organisms.size());

                while(itr_organism.hasNext())
                {
                        sOrganism _organism = ((sOrganism) itr_organism.next());
                        if(_organism.eliminate)
                        {
                                //Remove the organism from its Species
                                _specie = _organism.species;
                                _specie.remove_org(_organism);
                                //store the organism can be elimanated;
                                vdel.add(_organism);
                        }
                }
                //eliminate organism from master list
                for(int i = 0; i < vdel.size(); i++)
                {
                        sOrganism _organism = (sOrganism) vdel.elementAt(i);
                        //  		organisms.remove(_organism);
                        organisms.removeElement(_organism);
                }


                boolean rc = false;

                itr_specie = sorted_species.iterator();
                // System.out.print("\n verifica");
                //System.out.print("\n this species has "+sorted_species.size()+" elements");
                while(itr_specie.hasNext())
                {
                        _specie = ((sSpecies) itr_specie.next());
                        rc = _specie.reproduce(generation, this, tb_pop, wh_pop, de_pop, sorted_species, module_evolved);
                }

                //Destroy and remove the old generation from the organisms and species
                // (because we have pointer to organisms , the new organisms created
                //  are not in organisms and can't br eliminated;
                // thus are elimate onlyu corrent organisms !)
                
                itr_organism = organisms.iterator();

                while(itr_organism.hasNext())
                {
                        sOrganism _organism = ((sOrganism) itr_organism.next());
                        //Remove the organism from its Species
                        _specie = _organism.species;
                        _specie.remove_org(_organism);
                }

                organisms.clear();

                //Remove all empty Species and age ones that survive
                //As this happens, create master organism list for the new generation

                itr_specie = species.iterator();
                int i_specie = 0;

                vdel = new Vector(species.size());
                orgcount = 0;

                while(itr_specie.hasNext())
                {
                        _specie = ((sSpecies) itr_specie.next());
                        size_of_curr_specie = _specie.organisms.size();
                        i_specie++;
                        if(size_of_curr_specie == 0)
                        {
                                vdel.add(_specie);
                        }
                        else
                        {
                                //Age any Species that is not newly created in this generation
                                if(_specie.novel)
                                {
                                        _specie.novel = false;
                                }
                                else
                                {
                                        _specie.age++;
                                }
                                //from the current species  recostruct thge master list organisms
                                for(int j = 0; j < size_of_curr_specie; j++)
                                {
                                        sOrganism _organism = (sOrganism) _specie.organisms.elementAt(j);
                                        _organism.genome.genome_id = orgcount++;
                                        organisms.add(_organism);
                                }
                        }
                }
                
                // System.out.print("\n the number of species can be eliminated is "+vdel.size());
                //eliminate species marked from master list
                for(int i = 0; i < vdel.size(); i++)
                {
                        _specie = (sSpecies) vdel.elementAt(i);
                        //	  	species.remove(_specie);
                        species.removeElement(_specie);

                }

                //Remove the innovations of the current generation

                innovations.clear();


                //DEBUG: Check to see if the best species died somehow
                // We don't want this to happen

                itr_specie = species.iterator();
                boolean best_ok = false;

                while(itr_specie.hasNext())
                {
                        _specie = ((sSpecies) itr_specie.next());
                        if(_specie.id == best_species_num)
                        {
                                best_ok = true;
                                break;
                        }

                }

                if(!best_ok)
                {
                        NeatRoutine.sREPORT_SPECIES_CODA = "\n  <ALERT>  THE BEST SPECIES DIED!";
                }
                else
                {
                        NeatRoutine.sREPORT_SPECIES_CODA = "\n  Good : the best Specie #" + best_species_num + " survived ";
                }
        //   	System.out.print("\n Epoch complete");

        }
}

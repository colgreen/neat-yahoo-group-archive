package ModuleNeat;

import java.util.*;
/**
 *
 *
 *
 */
public class morder_species implements java.util.Comparator
{
        /**
         * order_species constructor comment.
         */
        public morder_species()
        {
                //super();
        }
        /**
         */
        public int compare(Object o1, Object o2)
        {
                
                mSpecies _sx = (mSpecies) o1;
                mSpecies _sy = (mSpecies) o2;
                
                mOrganism _ox = (mOrganism) _sx.organisms.firstElement();
                mOrganism _oy = (mOrganism) _sy.organisms.firstElement();
                
                if (_ox.orig_fitness < _oy.orig_fitness)
                        return +1;
                if (_ox.orig_fitness > _oy.orig_fitness)
                        return -1;
                return 0;
                
        }
}
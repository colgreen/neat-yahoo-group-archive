

package ModuleNeat;
import java.util.*;
import java.text.*;

/**
 *
 * This class describes a layer of neurons.
 */
public class sNode
{
        
        /** type of layer input=1, output=2, hidden=3 */
        int type;
        
        /** total number of nodes */
        int node_count;
        
        /** refer to the time constant and bias module population */
        int time_bias_species_id;
        
        /** point to module organism */
        mOrganism time_bias_m_org;
        
        /** list of reference of incoming/outgoing fibers */
        Vector incoming_on;
        Vector outgoing_on;
        Vector incoming_off;
        Vector outgoing_off;
        
        /** for deep gene copy */
        sNode dup;
        
        /** Numeric identification of node, Node 1 is always spectrum input layer */
        int node_id;
        
        /** Temporary reference each real node of this layer, used to locate real nodes during rNetwork (link) construction */
        Vector rnodes;
        
        /** the generation this layer got created, module changed, or node count changed */
        int modified_gen;        
        
        /** indicates this node's firing sequence */
        int order_num;
        
        /** used only when reading from a population file */
        int time_bias_id;
        
        /** Creates a layer of neurons from file */
        public sNode(String xline)
        {
                /** Initial substrate geometry are accounted for in CPPN modules with transformations such as (x,y,z)=f(h), h=f(x,y,z) */
                incoming_on = new Vector(3,0);
                outgoing_on = new Vector(3,0);
                incoming_off = new Vector(3,0);
                outgoing_off = new Vector(3,0);
                
                StringTokenizer st;
                String s1;
                st = new StringTokenizer(xline);
                
                //skip keyword
                s1 = st.nextToken();
                
                //Get the layer id
                s1 = st.nextToken();
                node_id = Integer.parseInt(s1);
                
                //Get the count of nodes in the layer
                s1 = st.nextToken();
                node_count = Integer.parseInt(s1);
                
                //get type of layer
                s1 = st.nextToken();
                type = Integer.parseInt(s1);
                
                //get time_constant module id
                s1 = st.nextToken();
                time_bias_id = Integer.parseInt(s1);
                
                //get modified generation
                s1 = st.nextToken();
                modified_gen = Integer.parseInt(s1);
                
                
        }
        
        /** Deep copy system node constructor */
        public sNode(sNode n)
        {
                dup = null;
                incoming_on = new Vector(3,0);
                outgoing_on = new Vector(3,0);
                incoming_off = new Vector(3,0);
                outgoing_off = new Vector(3,0);
                node_id = n.node_id;
                node_count = n.node_count;
                type = n.type;
                time_bias_m_org = n.time_bias_m_org;
                time_bias_species_id = n.time_bias_species_id;
                modified_gen = n.modified_gen;
        }
        
        
        /** used for mutate_add_node */
        public sNode(int id, int t, int nc, mOrganism tb, int gen)
        {
                dup = null;
                incoming_on = new Vector(3,0);
                outgoing_on = new Vector(3,0);
                incoming_off = new Vector(3,0);
                outgoing_off = new Vector(3,0);
                node_id = id;
                node_count = nc;
                type = t;
                time_bias_m_org = tb;
                time_bias_species_id = tb.species.id;
                modified_gen = gen;
        }

        
        public void print_to_file(IOseq xFile)
        {
                
                StringBuffer s2 = new StringBuffer("");
                
                s2.append("node ");
                s2.append(node_id);
                s2.append(" " + node_count);
                s2.append(" " + type);
                s2.append(" " + time_bias_m_org.genome.genome_id);
                s2.append(" " + modified_gen);
                
                xFile.IOseqWrite(s2.toString());
                
        }
        
}

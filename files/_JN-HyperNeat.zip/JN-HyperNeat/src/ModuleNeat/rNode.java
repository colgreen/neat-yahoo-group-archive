
package ModuleNeat;

import java.util.*;

/**
 *
 * This class describes the real neurons that derived from a system of CPPN modules
 */
public class rNode
{

        /** type input=1, output=2, hidden=3 */
        int type;
        /** Leakage time constant */
        double time_constant;
        /** Bias */
        double bias;
        /** Similar function as activesum for leaky node */
        double synapticInput;
        /** synapticInput plus leaky potential from last activation (temperal summation) */
        double membranePotential;
        /** A list of pointers to incoming weighted signals from other nodes */
        Vector incoming;
        /** Position of the node with respect to its layer */
        double position;
        /** activation value */
        double activation;

        /** Creates a real neuron */
        public rNode(mOrganism _org, sNode layer, double[] p)
        {

                type = layer.type;
                synapticInput = 0;
                membranePotential = 0;
                activation = 0;
                position = p[0];
                incoming = new Vector(3, 0);

                //compute the node parameter with respect to the position p of the node
                Vector tb = _org.genome.compute_module(p);

                //adjust the parameter with bounds and assign them to the node
                Iterator itr_tb = tb.iterator();
                while(itr_tb.hasNext())
                {
                        mNode _node = (mNode) itr_tb.next();
                        if(_node.node_id == 3)
                        {
                                if(_node.activation < 1)
                                {
                                        time_constant = 1;
                                }
                                else if(_node.activation > mNeat.max_time_constant)
                                {
                                        time_constant = mNeat.max_time_constant;
                                }
                                else
                                {
                                        time_constant = _node.activation;
                                }
                        }
                        if(_node.node_id == 4)
                        {
                                if(_node.activation < 0)
                                {
                                        bias = 0;
                                }
                                else if(_node.activation > mNeat.max_bias)
                                {
                                        bias = mNeat.max_bias;
                                }
                                else
                                {
                                        bias = _node.activation;
                                }
                        }
                }
        }
}

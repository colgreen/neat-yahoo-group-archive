package ModuleNeat;

public class sorder_orgs implements java.util.Comparator
{
        
        public sorder_orgs()
        {
                //super();
        }
        
        public int compare(Object o1, Object o2)
        {
                
                
                sOrganism _ox = (sOrganism) o1;
                sOrganism _oy = (sOrganism) o2;
                
                if (_ox.fitness < _oy.fitness)
                        return +1;
                if (_ox.fitness > _oy.fitness)
                        return -1;
                return 0;
        }
}
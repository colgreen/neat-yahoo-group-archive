
package ModuleNeat;
import java.io.*;
import java.util.*;
/**
 *
 * @author GABA
 */
public class Input {
        
        /** name of the data file without extention */
        String dataname;
        
        /** used to read file */
        FileInputStream fi;
        BufferedInputStream bi;
        DataInputStream di;
        
        /** contain samples log-magnitude FFTs of a sound file */
        double[][] logFFT;
        
        /** Expected results for evaluating fitness */
        double[][] expResult;
        
        /** number of sample in each FFT */
        int freq_frame;
        
        /** number of sample per second in the original wav file, 22050 usually */
        int samp_rate;
        
        /** total number of FFTs */
        int frame_tot;
        
        /** samples of fft between every two pitches a half step away */
        int bin_per_pitch;
        
        /** number of frequencies sampled */
        int frame_size;
        
        public Input(String name)
        {
                dataname = name;
        }
        
        /** gap = 0 means use every sampled frequency **/
        public void load_logFFT(int gap) throws IOException, InterruptedException
        {
                
                fi = new FileInputStream("FFTs\\" + dataname + ".fft");
                bi = new BufferedInputStream(fi);
                di = new DataInputStream(bi);
                
                freq_frame = di.readInt();
                samp_rate = di.readInt();
                frame_tot = di.readInt();
                bin_per_pitch = di.readInt();
                int ini_size = di.readInt();
                

                frame_size = ini_size / (gap + 1);
                int remain = ini_size - frame_size * (gap + 1);
                
                logFFT = new double[frame_tot][frame_size];

                for (int i = 0; i < frame_tot; i++)
                {
                        for(int j=0; j < frame_size; j++)
                        {
                                logFFT[i][j] = (di.readShort() + 32768.0) / 6553.5;
                                di.skipBytes(2*gap);
                        }
                        di.skipBytes(2*remain);
                }
                
                try
                {
                        di.readByte();
                        System.out.println("Loaded possibly corrupted logFFT: " + dataname);
                }
                catch(EOFException eof)
                {
                        //System.out.println("Finish loading logFFT: " + dataname);
                }

                di.close();
                bi.close();
                fi.close();
        }
        
        public void load_expResult()
        {
                File folder = new File("ExpResults");
                String[] files = folder.list();
                                
                boolean found = false;
                int i;
                int i_size = files.length;
                for(i =0; i < i_size; i++)
                {
                        String tag = files[i].substring(0, files[i].length()-4);
                        if(dataname.startsWith(tag))
                        {
                                found = true;
                                break;
                        }
                }
                
                if(!found)
                {
                        System.out.println("Error: can't find expected result for " + dataname);
                        return;
                }
                
                String xline;
                String s1;
                StringTokenizer st;
                IOseq xFile = new IOseq("ExpResults\\" + files[i]);
                
                if (xFile.IOseqOpenR())
                {                                                    
                        expResult = new double[8][16];
                        
                        for (int row = 0; row < 8; row++) {
                                xline = xFile.IOseqRead();
                                st = new StringTokenizer(xline);

                                for (int col = 0; col < 16; col++) {
                                        s1 = st.nextToken();
                                        expResult[row][col] = Double.parseDouble(s1);
                                }
                        }
                }
                else
                {
                        System.err.println("Error during open " + files[i]);
                        return;
                }
                
                xline = xFile.IOseqRead();
                if(xline.equals("EOF"))
                {
                        //System.out.println("Finish loading expResult: " + dataname);
                }
                else
                {
                        System.out.println("Loaded possibly corrupted expResult: " + dataname);
                }
                
                /* for debugging
                for (int row = 0; row < 8; row++) {
                        System.out.println();
                        for (int col = 0; col < 16; col++) {
                                System.out.print(" " + expResult[row][col]);
                        }
                }
                */
        }
        
        public synchronized double[][] getFFT()
        {
                return logFFT;
        }
}

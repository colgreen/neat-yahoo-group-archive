
package ModuleNeat;

import java.util.*;

/**
 *
 * @author GABA
 */
public class EvaluateMinus extends Thread
{

        Vector organisms;
        int gen;
        int fft_node_count;
        Input[] InputData;
        int data_length;
        double last_result;

        public EvaluateMinus(Vector orgs, int g, int count, Input[] Data)
        {
                organisms = orgs;
                gen = g;
                fft_node_count = count;
                InputData = Data;
                data_length = InputData.length;
                last_result = 0.5;
        }

        public void run()
        {
                while(Procedure.m_index - Procedure.p_index > 1)
                {
                        Procedure.minus_mindex();
                        sOrganism organism = (sOrganism) organisms.elementAt(Procedure.m_index);

                        //find spectrum inputs layer, node id 1
                        int in_size = organism.genome.inputs.size();
                        sNode _spec = null;
                        for(int in = 0; in < in_size; in++)
                        {
                                sNode _node = (sNode) organism.genome.inputs.elementAt(in);
                                if(_node.node_id == 1)
                                {
                                        _spec = _node;
                                        _spec.node_count = fft_node_count;
                                        break;
                                }
                        }

                        // for debugging
                        if(_spec == null)
                        {
                                System.out.println("----> ERROR: NO SPECTRUM INPUT LAYER <---- " + organism.genome.genome_id);
                        }

                        sNode output1 = (sNode) organism.genome.outputs.elementAt(0);
                        sNode output2 = null;
                        if(output1.node_id == 2)
                        {
                                output2 = (sNode) organism.genome.outputs.elementAt(1);
                        }
                        else if(output1.node_id == 3) // swap if some how in reverse order
                        {
                                output2 = output1;
                                output1 = (sNode) organism.genome.outputs.elementAt(1);
                        }


                        //create a real neural network for evaluation
                        rNetwork _net = new rNetwork(organism);
                        if(_net.rLink_c == 0 || _net.rNode_c == 0)
                        {
                                organism.fitness = 0.0001;
                                organism.distribute_fitness(false, gen);
                                //for debugging
                                System.out.println(organism.genome.genome_id + "m Fitness: " + organism.fitness);
                        }
                        else
                        {
                                System.out.println(organism.genome.genome_id + "m ***** Delays# " + _net.delay_links.size() + " Links# " + _net.rLink_c + " Nodes# " + _net.rNode_c + " Layers# " + organism.genome.nodes.size());

                                Input _input;
                                int train_cycle = mNeat.training_cycle;

                                if(gen < 10) // don't worry about learning ability at early stage of evolution
                                {
                                        train_cycle = 1;
                                }

                                double[] fitness = new double[train_cycle];

                                // run through all data however many times
                                for(int tr = 0; tr < train_cycle; tr++)
                                {
                                        double acc_fitness = 0;
                                        double runtime = 0;

                                        int n_size;

                                        for(int d = 0; d < data_length; d++)
                                        {
                                                double[][] result = new double[8][16]; // for two second sample with 2048 wave frame size

                                                _input = InputData[d];
                                                double[][] _logFFT = _input.getFFT();

                                                //System.out.println("Evaluating fitness for data: " + _input.dataname);

                                                double start_time = System.currentTimeMillis(); // for calculating netowrk process speed

                                                n_size = _logFFT.length;
                                                for(int n = 0; n < n_size; n++)
                                                {
                                                        //Activate the network
                                                        _net.activate_CTRNN(_input.logFFT[n], false, true);

                                                        //Record output results of this frame
                                                        result[0][n] = ((rNode) output1.rnodes.elementAt(0)).activation;
                                                        result[1][n] = ((rNode) output1.rnodes.elementAt(1)).activation;
                                                        result[2][n] = ((rNode) output2.rnodes.elementAt(0)).activation;
                                                        result[3][n] = ((rNode) output2.rnodes.elementAt(1)).activation;
                                                        result[4][n] = ((rNode) output2.rnodes.elementAt(2)).activation;
                                                        result[5][n] = ((rNode) output2.rnodes.elementAt(3)).activation;
                                                        result[6][n] = ((rNode) output2.rnodes.elementAt(4)).activation;
                                                        result[7][n] = ((rNode) output2.rnodes.elementAt(5)).activation;

                                                }
                                                runtime += (System.currentTimeMillis() - start_time);
                                                acc_fitness += compute_fitness(result, _input.expResult, runtime);
                                        }

                                        fitness[tr] = acc_fitness / data_length;

                                        // check for NaN error
                                        if(fitness[tr] != fitness[tr])
                                        {
                                                fitness[tr] = 0.0001;
                                                System.out.println("----> ERROR: NaN FITNESS <----");
                                        }

                                        //for debugging
                                        //organism.genome.print_to_filename("cases\\" + organism.genome.genome_id + ".txt");
                                        System.out.println(organism.genome.genome_id + "m Fitness: " + fitness[tr] + "   Runtime: " + runtime / data_length + "   Adapted: " + _net.adapted_weight);
                                }

                                double is_learning = 0;
                                double max_fitness = fitness[0];
                                for(int tr = 1; tr < train_cycle; tr++)
                                {
                                        if(fitness[tr] > fitness[tr - 1])
                                        {
                                                max_fitness = fitness[tr];
                                                is_learning++;
                                        }
                                }

                                organism.fitness = max_fitness + (is_learning / train_cycle);

                                //for garbage collection, for debugging memeory leak
                                organism.genome.reset_rnode_reference();
                        }
                }
                System.out.println("MinusThread DONE");
        }

        public double compute_fitness(double[][] result, double[][] exp, double runtime)
        {
                double fitness = 0;
                double check_num = 0;
                double exp_num = 0;
                
                for(int r = 0; r < 8; r++)
                {
                        for(int c = 0; c < 16; c++)
                        {
                                double amount = (1 - Math.abs(exp[r][c] - result[r][c]));
                                amount *= amount;
                                amount *= amount; // power to the fourth fitness
                                fitness += amount;
                                
                                check_num += result[r][c];
                                exp_num += exp[r][c];
                        }
                }

                // average over every array entry, plus sound clip length over time of processing it
                // 2 is a good fitness
                fitness = fitness / 128.0 * 2.0;
                
                exp_num /= 128.0;
                check_num /= 128.0;
                if(check_num == last_result)
                {
                        fitness = 0.0001;
                }
                                
                last_result = check_num;

                return fitness;
        }
}

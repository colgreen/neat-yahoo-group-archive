package ModuleNeat;

/**
 *
 * @author GABA
 */
public class mOrganism
{
        
        /** A measure of fitness for the Organism */
        double fitness;
        
        /** A fitness measure that won't change during adjustments */
        double orig_fitness;
        
        /** Used just for reporting purposes */
        double error;
        
        /** Win marker (if needed for a particular task) */
        public  boolean winner;
        
        /** The Organism's genotype */
        public mGenome genome;
        
        /** The Organism's Species */
        mSpecies species;
        
        /** Number of children this Organism may have */
        double expected_offspring;
        
        /** Tells which generation this Organism is from */
        int generation;
        
        /** Marker for destruction of inferior Organisms */
        boolean eliminate;
        
        /** Marks the species champ */
        boolean champion;
        
        /** Number of reserved offspring for a population leader */
        int super_champ_offspring;
        
        /** Marks the best in population */
        boolean pop_champ;
        
        /** Marks the duplicate child of a champion (for tracking purposes) */
        boolean pop_champ_child;
        
        /** DEBUG variable- high fitness of champ */
        double high_fit;
        
        /** has a change in a structure of baby ? */
        boolean mut_struct_baby;
        
        /** has a mating  in  baby ? */
        boolean mate_baby;
        
        
        /** Creates a new instance of module Organism */
        public mOrganism(double xfitness, mGenome xgenome, int xgeneration)
        {
                fitness = xfitness;
                orig_fitness = xfitness;
                genome = xgenome;
                species = null;
                expected_offspring = 0;
                generation = xgeneration;
                genome.last_used_gen = xgeneration;
                eliminate = false;
                error = 0;
                winner = false;
                champion = false;
                super_champ_offspring = 0;
                pop_champ = false;
                pop_champ_child = false;
                high_fit = 0;
                mut_struct_baby = false;
                mate_baby = false;
        }
        
        
        public void viewtext()
        {
                System.out.print("\n-ORGANISM -[genomew_id=" + genome.genome_id + "]");
                System.out.print(" Champ(" + champion + ")");
                System.out.print(", fit=" + fitness);
                System.out.print(", Elim=" + eliminate);
                System.out.print(", offspring=" + expected_offspring);
                
        }
        
        
}


package ModuleNeat;

import java.util.*;
/**
 *
 * This class describes the real neural newtwork that derived from a system of CPPN modules
 */
public class rNetwork
{

        /** is a reference to genotype can has  originate this fenotype */
        sGenome genotype;
        /** a collection of all delayed links */
        Vector delay_links;
        
        int rNode_c; // for debugging
        int rLink_c; // for debugging
        double adapted_weight; // for debugging

        /** Creates a real neural network from a system of modules */
        public rNetwork(sOrganism organism)
        {
                rNode_c =0;
                rLink_c =0;
                adapted_weight = 0;

                genotype = organism.genome;
                delay_links = new Vector(genotype.recurr_on.size() * 10, 0);

                double[] position = new double[2];

                //Create real neurons in computing layers
                int n_size = genotype.com_nodes.size();
                for(int n = 0; n < n_size; n++)
                {
                        sNode _layer = (sNode) genotype.com_nodes.elementAt(n);

                        if(_layer.time_bias_m_org != null)
                        {
                                _layer.rnodes = new Vector(3, 0);
                                //number of nodes in this layer
                                double num = (double) _layer.node_count;
                                for(double i = 0; i < num; i++)
                                {
                                        rNode_c++;
                                        //calculate linear position from -1 to 1
                                        position[0] = (i / num) * 2.0 - 1.0;
                                        rNode newnode = new rNode(_layer.time_bias_m_org, _layer, position);
                                        //Temporary reference each real node of this layer
                                        _layer.rnodes.add(newnode);
                                }
                        }
                        else
                        {
                                System.out.println("Error: Cannot find time constant module!");
                        }
                }

                //Create real links between the real neurons in computing fibers
                n_size = genotype.com_genes.size();
                for(int n = 0; n < n_size; n++)
                {
                        sGene _fiber = (sGene) genotype.com_genes.elementAt(n);

                        if(_fiber.weight_hebb_m_org != null)
                        {
                                if(_fiber.enable)
                                {
                                        //find input layer and iterate over its real neuron postion
                                        int i_size = _fiber.in_node.rnodes.size();
                                        int t_size = _fiber.out_node.rnodes.size();
                                        for(int i = 0; i < i_size; i++)
                                        {
                                                rNode _in = (rNode) _fiber.in_node.rnodes.elementAt(i);
                                                position[0] = _in.position;
                                                //for each input node interate over all output nodes
                                                for(int t = 0; t < t_size; t++)
                                                {
                                                        rNode _out = (rNode) _fiber.out_node.rnodes.elementAt(t);
                                                        position[1] = _out.position;

                                                        // compute weight_hebb parameters

                                                        Vector wh = _fiber.weight_hebb_m_org.genome.compute_module(position);
                                                        int w_size = wh.size();
                                                        for(int w = 0; w < w_size; w++)
                                                        {
                                                                mNode _node = (mNode) wh.elementAt(w);
                                                                if(_node.node_id == 0)
                                                                {
                                                                        // make this rLink only if node 0 activation is larger than 1
                                                                        if(_node.activation > 1)
                                                                        {
                                                                                rLink newlink = new rLink(_fiber, position, wh, _in, _out);
                                                                                
                                                                                //enable below to trem out insignificant links
                                                                                //if(Math.abs(weight) > mNeat.weight_threshold)

                                                                                //add link for evaluation only if it's not recurrent, or recurrent and having >1 delay
                                                                                if(!newlink.is_recurrent)
                                                                                {
                                                                                        _out.incoming.add(newlink);
                                                                                        rLink_c++;
                                                                                }
                                                                                else if(newlink.is_recurrent && newlink.delay_time != 0)
                                                                                {
                                                                                        _out.incoming.add(newlink);
                                                                                        delay_links.add(newlink);
                                                                                        rLink_c++;
                                                                                }
                                                                        }
                                                                        break;
                                                                }
                                                        }


                                                }
                                        }
                                }
                        }
                        else
                        {
                                System.out.println("Error: Cannot find weight hebbian module");
                        }
                }
        // for debugging
        //System.out.println("#delay: " + delay_links.size() + " #links: " + rLink_c + " #nodes: " + rNode_c);
        }

        /** Activation with leaky neurons, hebbian adaptation */
        public boolean activate_CTRNN(double[] in_signal, boolean signed_activation, boolean adaptable)
        {
                double add_amount = 0.0; //For adding to the activesum
                double constant;

                rNode _node;
                rLink _link;
                
                double bw;

                int l;
                Vector layers = genotype.com_nodes;

                int l_size;
                int n;
                int n_size;

                int i;
                int i_size;                

                // compute input layers
                l_size = genotype.inputs.size();
                for(l = 0; l < l_size; l++)
                {
                        Vector nodes = ((sNode) layers.elementAt(l)).rnodes;
                        n_size = nodes.size();

                        //for each real node of each input layer
                        for(n = 0; n < n_size; n++)
                        {
                                _node = (rNode) nodes.elementAt(n);
                                // reset synapticInput value to in_signal
                                _node.synapticInput = in_signal[n];

                                Vector links = _node.incoming;
                                i_size = links.size();

                                // compute synaptic input to the node from all incoming links
                                for(i = 0; i < i_size; i++)
                                {
                                        _link = (rLink) links.elementAt(i);

                                        // accumulate synaptic input using stored delayed activation (and remove)
                                        _link.last_activation = _link.delay_train[0];
                                        add_amount = _link.weight * _link.last_activation;

                                        _node.synapticInput += add_amount;
                                }


                                // Activate the node
                                constant = mNeat.delta_time / _node.time_constant;
                                _node.membranePotential = (1.0 - constant) * (_node.membranePotential) + constant * (_node.synapticInput);

                                if(signed_activation)
                                {
                                        _node.activation = NeatRoutine.af_sigmoid_signed(_node.membranePotential + _node.bias, 4.924273, 2.4621365);
                                }
                                else
                                {
                                        _node.activation = NeatRoutine.af_sigmoid_unsigned(_node.membranePotential + _node.bias, 4.924273, 2.4621365);
                                }


                                // For each incoming connection, perform adaptation
                                if(adaptable)
                                {
                                        for(i = 0; i < i_size; i++)
                                        {
                                                _link = (rLink) links.elementAt(i);
                                                bw = _link.weight;
                                                _link.weight =
                                                        hebbian(_link.weight, mNeat.max_weight,
                                                        _link.last_activation,
                                                        _link.out_node.activation,
                                                        _link.hebb_rate, _link.pre_rate);
                                                adapted_weight += Math.abs(bw-_link.weight);
                                        }
                                }
                        }
                }



                // compute remaining layers
                l_size = layers.size();
                for(l = genotype.inputs.size(); l < l_size; l++)
                {
                        Vector nodes = ((sNode) layers.elementAt(l)).rnodes;
                        n_size = nodes.size();

                        //real nodes of each layer
                        for(n = 0; n < n_size; n++)
                        {
                                _node = (rNode) nodes.elementAt(n);
                                // reset synapticInput value
                                _node.synapticInput = 0.0;

                                Vector links = _node.incoming;
                                i_size = links.size();

                                // compute synaptic input to the node from all incoming links
                                for(i = 0; i < i_size; i++)
                                {
                                        _link = (rLink) links.elementAt(i);
                                        if(_link.is_recurrent)
                                        {
                                                // accumulate synaptic input using stored delayed activation (and remove)
                                                _link.last_activation = _link.delay_train[0];
                                                add_amount = _link.weight * _link.last_activation;
                                        }
                                        else
                                        {
                                                add_amount = _link.weight * _link.in_node.activation;
                                        }

                                        _node.synapticInput += add_amount;
                                }


                                // Activate the node
                                constant = mNeat.delta_time / _node.time_constant;
                                _node.membranePotential = (1.0 - constant) * (_node.membranePotential) + constant * (_node.synapticInput);

                                if(signed_activation)
                                {
                                        _node.activation = NeatRoutine.af_sigmoid_signed(_node.membranePotential + _node.bias, 4.924273, 2.4621365);
                                }
                                else
                                {
                                        _node.activation = NeatRoutine.af_sigmoid_unsigned(_node.membranePotential + _node.bias, 4.924273, 2.4621365);
                                }


                                // For each incoming connection, perform adaptation
                                if(adaptable)
                                {
                                        for(i = 0; i < i_size; i++)
                                        {
                                                _link = (rLink) links.elementAt(i);
                                                bw = _link.weight;
                                                if(_link.is_recurrent)
                                                {
                                                        _link.weight =
                                                                hebbian(_link.weight, mNeat.max_weight,
                                                                _link.last_activation,
                                                                _link.out_node.activation,
                                                                _link.hebb_rate, _link.pre_rate);
                                                }
                                                else
                                                {
                                                        _link.weight =
                                                                hebbian(_link.weight, mNeat.max_weight,
                                                                _link.in_node.activation,
                                                                _link.out_node.activation,
                                                                _link.hebb_rate, _link.pre_rate);
                                                }
                                                adapted_weight += Math.abs(bw - _link.weight);
                                        }
                                }
                        }
                }

                // store new activation into delay_links
                i_size = delay_links.size();
                for(i = 0; i < i_size; i++)
                {
                        _link = (rLink) delay_links.elementAt(i);
                        _link.add_tail(_link.in_node.activation);
                }
                        
                return true;
        }

//Hebbian Adaptation Function
//Based on equations in Floreano & Urzelai 2000
//Takes the current weight, the maximum weight in the containing network,
// the activation coming in and out of the synapse,
// and three learning rates for hebbian, presynaptic, and postsynaptic
// modification
//Returns the new modified weight
//NOTE: For an inhibatory connection, it makes sense to
//      emphasize decorrelation on hebbian learning!
        public double hebbian(double weight, double maxweight,
                double active_in, double active_out,
                double hebb_rate, double pre_rate)
        {

                boolean neg = false;
                double delta;

                if(weight > maxweight)
                {
                        weight = maxweight;
                }

                if(weight < -maxweight)
                {
                        weight = -maxweight;
                }

                if(weight < 0)
                {
                        neg = true;
                        weight = -weight;
                }

                //double act_d = Math.abs(active_out - active_in);
                //double act_s = active_out + active_in;

                if(!(neg))
                {

                        delta =
                                hebb_rate * (maxweight - weight) * active_in * active_out +
                                pre_rate * (weight) * active_in * (active_out - 1.0);

                        //delta=delta-hebb_rate/2; //decay

                        //delta=delta+randposneg()*randfloat()*0.01; //noise

                        //cout<<"delta: "<<delta<<endl;

                        if(weight + delta > 0)
                        {
                                return weight + delta;
                        }
                        else
                        {
                                return 0.01;
                        }
                }
                else
                {
                        //In the inhibatory case, we strengthen the synapse when output is low and
                        //input is high
                        delta =
                                pre_rate * (maxweight - weight) * active_in * (1.0 - active_out) -
                                hebb_rate * (weight) * active_in * active_out;

                        //delta=delta-hebb_rate/2; //decay

                        //delta=delta+randposneg()*randfloat()*0.01; //noise

                        if(-(weight + delta) < 0)
                        {
                                return -(weight + delta);
                        }
                        else
                        {
                                return -0.01;
                        }
                }

        }
}


package ModuleNeat;

import java.util.*;
import java.lang.reflect.*;
import java.io.*;

/**
 *
 * @author JT
 */
public class Procedure
{

        public static Input[] InputData;
        public static int fft_node_count;
        public static int p_index;
        public static int m_index;

        /** evolve a system/module population either from scratch or from a previous population */
        public static void audio_experiment_1(boolean from_scratch, int gens, String input_folder)
        {
                //load inputs from files
                File folder = new File(input_folder);
                String[] files = folder.list();

                InputData = new Input[files.length];
                fft_node_count = 2016 / (mNeat.e_node_gap + 1);

                int n = 0;
                int f_size = files.length;
                for(int f = 0; f < f_size; f++)
                {
                        String datatag = files[f].substring(0, files[f].length() - 4);
                        Input _in = new Input(datatag);
                        try
                        {
                                _in.load_logFFT(mNeat.e_node_gap);
                                _in.load_expResult();
                                InputData[f] = _in;
                                n++;
                        }
                        catch(Exception e)
                        {
                                System.out.println("Error in reading input data " + datatag);
                                System.out.println(e.toString());
                        }
                }

                if(n == f_size)
                {
                        System.out.println("okay input/result data read");
                }
                else
                {
                        System.out.println("Error: some input data did not load!");
                }

                // import population genomes
                mPopulation time_pop = null;
                mPopulation delay_pop = null;
                mPopulation weight_pop = null;
                sPopulation sys_pop = null;

                if(from_scratch)
                {

                        //Initiate leakage time constant module population
                        IOseq timeFile = new IOseq("modpop\\time_bias_pop.init");
                        if(timeFile.IOseqOpenR())
                        {
                                mGenome time_init_g = new mGenome(0, timeFile);
                                time_pop = new mPopulation(time_init_g, mNeat.time_bias_pop_size, NeatRoutine.TIME_BIAS);
                                timeFile.IOseqCloseR();
                        }
                        else
                        {
                                System.out.println("Error reading initial time bias population");
                        }

                        //Initiate delay module population
                        IOseq delayFile = new IOseq("modpop\\delay_pop.init");
                        if(delayFile.IOseqOpenR())
                        {
                                mGenome delay_init_g = new mGenome(0, delayFile);
                                delay_pop = new mPopulation(delay_init_g, mNeat.delay_pop_size, NeatRoutine.DELAY);
                                delayFile.IOseqCloseR();
                        }
                        else
                        {
                                System.out.println("Error reading initial delay population");
                        }

                        //Initiate weight module population
                        IOseq weightFile = new IOseq("modpop\\weight_hebb_pop.init");
                        if(weightFile.IOseqOpenR())
                        {
                                mGenome weight_init_g = new mGenome(0, weightFile);
                                weight_pop = new mPopulation(weight_init_g, mNeat.weight_hebb_pop_size, NeatRoutine.WEIGHT_HEBB);
                                weightFile.IOseqCloseR();
                        }
                        else
                        {
                                System.out.println("Error reading initial weight hebbian population");
                        }

                        //Initiate system population
                        IOseq sysFile = new IOseq("syspop\\sys_pop.init");
                        if(sysFile.IOseqOpenR())
                        {
                                sGenome sys_init_g = new sGenome(0, sysFile);
                                sys_pop = new sPopulation(sys_init_g, mNeat.sys_pop_size);
                                sysFile.IOseqCloseR();
                        }
                        else
                        {
                                System.out.println("Error reading initial system population");
                        }

                        //cross reference arbitrary systems to arbitrary module
                        Iterator itr_sys_org = sys_pop.organisms.iterator();
                        int t_last = time_pop.organisms.size() - 1;
                        int d_last = delay_pop.organisms.size() - 1;
                        int w_last = weight_pop.organisms.size() - 1;

                        while(itr_sys_org.hasNext())
                        {
                                sOrganism _sOrganism = ((sOrganism) itr_sys_org.next());

                                Iterator itr_sys_nodes = _sOrganism.genome.nodes.iterator();
                                Iterator itr_sys_genes = _sOrganism.genome.genes.iterator();

                                while(itr_sys_nodes.hasNext())
                                {
                                        sNode _sNode = ((sNode) itr_sys_nodes.next());
                                        mOrganism _time_org = (mOrganism) time_pop.organisms.elementAt(NeatRoutine.randint(0, t_last));
                                        _sNode.time_bias_m_org = _time_org;
                                        _sNode.time_bias_species_id = _time_org.species.id;
                                }

                                while(itr_sys_genes.hasNext())
                                {
                                        sGene _sGene = ((sGene) itr_sys_genes.next());
                                        mOrganism _delay_org = (mOrganism) delay_pop.organisms.elementAt(NeatRoutine.randint(0, d_last));
                                        mOrganism _weight_org = (mOrganism) weight_pop.organisms.elementAt(NeatRoutine.randint(0, w_last));
                                        _sGene.delay_m_org = _delay_org;
                                        _sGene.weight_hebb_m_org = _weight_org;
                                        _sGene.delay_species_id = _delay_org.species.id;
                                        _sGene.weight_hebb_species_id = _weight_org.species.id;
                                }
                        }

                        // Speciation of system moved to here (from spawn), needed to be done after assigning modules
                        sys_pop.speciate();

                        for(int gen = 1; gen <= gens; gen++)
                        {
                                System.out.println("---------------- Generation ----------------------" + gen);

                                // for debugging
                                System.out.println("time species   " + time_pop.last_species + " size: " + time_pop.species.size() + " organisms total: " + time_pop.organisms.size());
                                System.out.println("weight species " + weight_pop.last_species + " size: " + weight_pop.species.size() + " organisms total: " + weight_pop.organisms.size());
                                System.out.println("delay species  " + delay_pop.last_species + " size: " + delay_pop.species.size() + " organisms total: " + delay_pop.organisms.size());
                                System.out.println("sys species    " + sys_pop.last_species + " size: " + sys_pop.species.size() + " organisms total: " + sys_pop.organisms.size());

                                // dynamically change compatibility threshold
                                modify_compatibles(sys_pop, time_pop, weight_pop, delay_pop);

                                boolean esito = audio_epoch(gen, sys_pop, time_pop, weight_pop, delay_pop);

                                System.out.println("  sys_pop : innov num= " + sys_pop.getCur_innov_num() + " cur_node_id= " + sys_pop.getCur_node_id());
                                System.out.println("  time_pop : innov num= " + time_pop.getCur_innov_num() + " cur_node_id= " + time_pop.getCur_node_id());
                                System.out.println("  weight_pop : innov num= " + weight_pop.getCur_innov_num() + " cur_node_id= " + weight_pop.getCur_node_id());
                                System.out.println("  delay_pop : cur_node_id = " + delay_pop.getCur_innov_num() + " cur_node_id= " + delay_pop.getCur_node_id());
                                System.out.println("   result : " + esito);



                        }
                        System.out.println("***** End of experiment ******");
                }
                else
                {
                        //Load module populations from last run
                        time_pop = new mPopulation("modpop\\time_bias_pop.last", mNeat.time_bias_pop_size, NeatRoutine.TIME_BIAS);
                        delay_pop = new mPopulation("modpop\\delay_pop.last", mNeat.delay_pop_size, NeatRoutine.DELAY);
                        weight_pop = new mPopulation("modpop\\weight_hebb_pop.last", mNeat.weight_hebb_pop_size, NeatRoutine.WEIGHT_HEBB);

                        //Load system populaiton from last run
                        sys_pop = new sPopulation("syspop\\sys_pop.last");

                        for(int gen = 1; gen <= gens; gen++)
                        {
                                System.out.println("---------------- Generation ----------------------" + gen);

                                // for debugging
                                System.out.println("time species   " + time_pop.last_species + " size: " + time_pop.species.size() + " organisms total: " + time_pop.organisms.size());
                                System.out.println("weight species " + weight_pop.last_species + " size: " + weight_pop.species.size() + " organisms total: " + weight_pop.organisms.size());
                                System.out.println("delay species  " + delay_pop.last_species + " size: " + delay_pop.species.size() + " organisms total: " + delay_pop.organisms.size());
                                System.out.println("sys species    " + sys_pop.last_species + " size: " + sys_pop.species.size() + " organisms total: " + sys_pop.organisms.size());

                                // dynamically change compatibility threshold
                                modify_compatibles(sys_pop, time_pop, weight_pop, delay_pop);

                                boolean esito = audio_epoch(gen, sys_pop, time_pop, weight_pop, delay_pop);

                                System.out.println("  sys_pop : innov num= " + sys_pop.getCur_innov_num() + " cur_node_id= " + sys_pop.getCur_node_id());
                                System.out.println("  time_pop : innov num= " + time_pop.getCur_innov_num() + " cur_node_id= " + time_pop.getCur_node_id());
                                System.out.println("  weight_pop : innov num= " + weight_pop.getCur_innov_num() + " cur_node_id= " + weight_pop.getCur_node_id());
                                System.out.println("  delay_pop : cur_node_id = " + delay_pop.getCur_innov_num() + " cur_node_id= " + delay_pop.getCur_node_id());
                                System.out.println("   result : " + esito);
                        }
                        System.out.println("***** End of experiment ******");
                }

                time_pop.print_to_filename("modpop\\time_bias_pop.new");
                delay_pop.print_to_filename("modpop\\delay_pop.new");
                weight_pop.print_to_filename("modpop\\weight_hebb_pop.new");
                sys_pop.print_to_filename("syspop\\sys_pop.new");


        //watch out for species id, innovation num, over flow
        //add link recurrent prevention, (just think about it, not a real problem)

        //delete genes and nodes according to disable history, watch out for nodes, genes order (arranged chronologically)
        //clean up repeated genes with same innov num and same modules, especially recurrent genes
        // competing convention?
        //optimize com_node com_gene consistency if only one mutation one generation

        //order num is flawed (already disabled)
        // adjusted fitness if flawed?
        //mating is flawed, 1) after mating find dangling nodes then cascade, do until no more dangling nodes

        //somehow make sure enough modules are used and tested for fitness
        // concurrency, reading two or three species and then spawn

        //replace all iterators, the objects never get collected!!!!!!!
        //test if hebbian work, run through data more than once

        //evolution parameter dynamic change automaiton or manual (winner fitness, mutation prob, etc)
        //module population size may increase with system complexify
        //age_factor should be bigger at early stage of evolution, then gets smaller
        //dynamic number of speciesspecies

        //print to file at the end
        //end evolution manually

        //synchronization, multi-thread
        //more input (reflecting loudness, spaciousness, compression, wavecliping)
        //random generator optimize


        }

        public static boolean audio_epoch(int generation, sPopulation sys_pop,
                mPopulation time_pop, mPopulation weight_pop, mPopulation delay_pop)
        {

                //Evaluate each organism if exist the winner.........
                boolean win = false;


                int i_size = sys_pop.organisms.size();
                
                p_index = -1;
                m_index = i_size;

                //EvaluatePlus t1 = new EvaluatePlus(sys_pop.organisms, generation, fft_node_count, InputData);
                EvaluateMinus t2 = new EvaluateMinus(sys_pop.organisms, generation, fft_node_count, InputData);
                
                //t1.start();
                t2.start();
                
                try
                {
                        //t1.join();
                        t2.join();
                }
                catch(Exception e)
                {
                        System.out.println(e.toString());
                }
                
                // distribute system fitness to modules
                for(int i = 0; i < i_size; i++)
                {
                        sOrganism _organism = (sOrganism) sys_pop.organisms.elementAt(i);
                        if(_organism.fitness >= mNeat.winner_fitness)
                        {
                                _organism.winner = true;

                                _organism.print_winner(generation);

                                //assign fitness (and winner flag) to all the modules of this organism
                                _organism.distribute_fitness(true, generation);
                                win = true;
                        }
                        else
                        {
                                //assign fitness to all the modules of this organism
                                _organism.distribute_fitness(false, generation);
                        }
                }

                //compute average and max fitness for each system species
                Iterator itr_specie;
                itr_specie = sys_pop.species.iterator();
                while(itr_specie.hasNext())
                {
                        sSpecies _specie = ((sSpecies) itr_specie.next());
                        _specie.compute_average_fitness();
                        _specie.compute_max_fitness();
                }
                //compute average and max fitness for each module species
                itr_specie = time_pop.species.iterator();
                while(itr_specie.hasNext())
                {
                        mSpecies _specie = ((mSpecies) itr_specie.next());
                        _specie.compute_average_fitness();
                        _specie.compute_max_fitness();
                }
                itr_specie = delay_pop.species.iterator();
                while(itr_specie.hasNext())
                {
                        mSpecies _specie = ((mSpecies) itr_specie.next());
                        _specie.compute_average_fitness();
                        _specie.compute_max_fitness();
                }
                itr_specie = weight_pop.species.iterator();
                while(itr_specie.hasNext())
                {
                        mSpecies _specie = ((mSpecies) itr_specie.next());
                        _specie.compute_average_fitness();
                        _specie.compute_max_fitness();
                }


                /* Print population by species if there is a winner
                if(win)
                {
                sys_pop.print_to_file_by_species("winner" + generation + "\\sys_pop.last");
                time_pop.print_to_file_by_species("winner" + generation + "\\time_pop.last");
                weight_pop.print_to_file_by_species("winner" + generation + "\\weight_pop.last");
                delay_pop.print_to_file_by_species("winner" + generation + "\\delay_pop.last");
                }
                 */
                // only run module epoch after some number of system epoches, so that modules can be evaluated more comprehensively

                double quot = (double) generation / mNeat.epoch_ratio_s_m;
                quot = quot - Math.floor(quot);

                boolean module_evolved = false;
                if(quot == 0)
                {
                        System.out.println("****    Evolving Modules    ****");
                        time_pop.epoch(generation);
                        weight_pop.epoch(generation);
                        delay_pop.epoch(generation);
                        module_evolved = true;
                }

                sys_pop.epoch(generation, time_pop, weight_pop, delay_pop, module_evolved);

                // reseet all fitness

                if(win)
                {
                        return true;
                }
                else
                {
                        return false;
                }
        }

        public static void modify_compatibles(sPopulation sys_pop, mPopulation time_pop, mPopulation weight_pop, mPopulation delay_pop)
        {
                double sys = (double) sys_pop.organisms.size() / sys_pop.species.size() - 5;
                double time = (double) time_pop.organisms.size() / time_pop.species.size() - 10;
                double weight = (double) weight_pop.organisms.size() / weight_pop.species.size() - 10;
                double delay = (double) delay_pop.organisms.size() / delay_pop.species.size() - 10;

                if(sys < 0)
                {
                        sys_pop.compat_threshold *= (1 + mNeat.compat_modifier);
                }
                else if(sys > 0)
                {
                        sys_pop.compat_threshold *= (1 - mNeat.compat_modifier);
                }

                if(time < 0)
                {
                        time_pop.compat_threshold *= (1 + mNeat.compat_modifier);
                }
                else if(time > 0)
                {
                        time_pop.compat_threshold *= (1 - mNeat.compat_modifier);
                }

                if(weight < 0)
                {
                        weight_pop.compat_threshold *= (1 + mNeat.compat_modifier);
                }
                else if(weight > 0)
                {
                        weight_pop.compat_threshold *= (1 - mNeat.compat_modifier);
                }

                if(delay < 0)
                {
                        delay_pop.compat_threshold *= (1 + mNeat.compat_modifier);
                }
                else if(delay > 0)
                {
                        delay_pop.compat_threshold *= (1 - mNeat.compat_modifier);
                }

                // for debugging
                System.out.println(sys + "   " + time + "   " + weight + "   " + delay);
                System.out.println(" sys_compat: " + sys_pop.compat_threshold + " tb_compat: " + time_pop.compat_threshold + " wh_compat: " + weight_pop.compat_threshold + " de_compat: " + delay_pop.compat_threshold);
        }
        
        public synchronized static void add_pindex()
        {
                p_index++;
        }
        
        public synchronized static void minus_mindex()
        {
                m_index--;
        }
}

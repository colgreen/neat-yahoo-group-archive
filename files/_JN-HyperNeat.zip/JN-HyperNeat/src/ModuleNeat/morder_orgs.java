package ModuleNeat;

/**
 *
 *
 *
 */
public class morder_orgs implements java.util.Comparator
{
        /**
         * order_orgs constructor comment.
         */
        public morder_orgs()
        {
                //super();
        }
        /**
         */
        public int compare(Object o1, Object o2)
        {
                
                
                mOrganism _ox = (mOrganism) o1;
                mOrganism _oy = (mOrganism) o2;
                
                if (_ox.fitness < _oy.fitness)
                        return +1;
                if (_ox.fitness > _oy.fitness)
                        return -1;
                return 0;
        }
}
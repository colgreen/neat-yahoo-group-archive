
package ModuleNeat;

import java.util.*;
import java.text.*;

public class sGene
{

        /** is historical marking of node */
        double innovation_num;
        /** is a flag: is TRUE the gene is enabled FALSE otherwise. */
        boolean enable;
        /** disabled generation */
        int disable_gen;
        /** weather the fiber is delayed or not */
        boolean recurrent;
        /** refer to the weight, hebbian, pre_synaptic module population */
        int weight_hebb_species_id;
        /** refer to the delay module population */
        int delay_species_id;
        /** point to module organism */
        mOrganism delay_m_org;
        mOrganism weight_hebb_m_org;
        /** is a reference to an input layer */
        sNode in_node;
        /** is a reference to a output layer; */
        sNode out_node;
        /** other delay fiber that has the same in_node and out_node */
        Vector delay_comrades;
        /** the generation this fiber gets created, module species changed, or recurrent toggled */
        int modified_gen;
        /** used only when reading from a population file */
        int weight_hebb_id;
        int delay_id;

        /** Creates a new gene from file */
        public sGene(String xline, Vector nodes)
        {
                StringTokenizer st;
                String curword;
                st = new StringTokenizer(xline);

                Iterator itr_node;

                //skip keyword 'gene'
                curword = st.nextToken();

                //Get innovation num
                curword = st.nextToken();
                innovation_num = Double.parseDouble(curword);

                //Get input layer id to the fiber
                curword = st.nextToken();
                int inode_num = Integer.parseInt(curword);

                //Get output layer id from the fiber
                curword = st.nextToken();
                int onode_num = Integer.parseInt(curword);

                //Get recurrent boolean
                curword = st.nextToken();
                recurrent = Integer.parseInt(curword) == 1 ? true : false;

                //Get weight hebbian pre module id
                curword = st.nextToken();
                weight_hebb_id = Integer.parseInt(curword);

                //Get delay module id
                curword = st.nextToken();
                delay_id = Integer.parseInt(curword);

                //Get enable
                curword = st.nextToken();
                enable = Integer.parseInt(curword) == 1 ? true : false;

                //Get disabled generation
                curword = st.nextToken();
                disable_gen = Integer.parseInt(curword);

                //Get modified_gen
                curword = st.nextToken();
                modified_gen = Integer.parseInt(curword);

                itr_node = nodes.iterator();
                int fnd = 0;

                while(itr_node.hasNext() && fnd < 2)
                {
                        sNode _node = ((sNode) itr_node.next());
                        if(_node.node_id == inode_num)
                        {
                                in_node = _node;
                                fnd++;
                        }
                        if(_node.node_id == onode_num)
                        {
                                out_node = _node;
                                fnd++;
                        }
                }

                delay_comrades = new Vector(1, 1);
        }

        /** Deep copy system gene constructor */
        public sGene(sGene g, sNode inode, sNode onode)
        {
                recurrent = g.recurrent;
                if(recurrent)
                {
                        delay_m_org = g.delay_m_org;
                        delay_species_id = g.delay_species_id;
                }
                else
                {
                        delay_m_org = null;
                        delay_species_id = -1;
                }
                weight_hebb_m_org = g.weight_hebb_m_org;
                weight_hebb_species_id = g.weight_hebb_species_id;
                in_node = inode;
                out_node = onode;
                innovation_num = g.innovation_num;
                enable = g.enable;
                disable_gen = g.disable_gen;
                modified_gen = g.modified_gen;
        }

        /** used in mutate_add_link, add_node */
        public sGene(sNode inode, sNode onode, boolean recurr, mOrganism wh, mOrganism de, double innov, int gen)
        {
                recurrent = recurr;
                if(recurr)
                {
                        delay_m_org = de;
                        delay_species_id = de.species.id;
                }
                else
                {
                        delay_m_org = null;
                        delay_species_id = -1;
                }
                weight_hebb_m_org = wh;
                weight_hebb_species_id = wh.species.id;
                in_node = inode;
                out_node = onode;
                innovation_num = innov;
                enable = true;
                disable_gen = 0;
                modified_gen = gen;
        }

        public void print_to_file(IOseq xFile)
        {

                StringBuffer s2 = new StringBuffer("");

                s2.append("gene ");
                s2.append(" " + innovation_num);
                s2.append(" " + in_node.node_id);
                s2.append(" " + out_node.node_id);

                if(recurrent)
                {
                        s2.append(" 1");
                }
                else
                {
                        s2.append(" 0");
                }

                s2.append(" " + weight_hebb_m_org.genome.genome_id);

                if(recurrent)
                {
                        s2.append(" " + delay_m_org.genome.genome_id);
                }
                else
                {
                        s2.append(" -1");
                }
                
                if(enable)
                {
                        s2.append(" 1");
                }
                else
                {
                        s2.append(" 0");
                }

                s2.append(" " + disable_gen);
                s2.append(" " + modified_gen);

                xFile.IOseqWrite(s2.toString());

        }
}

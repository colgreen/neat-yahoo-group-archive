package ModuleNeat;


import java.util.*;
import java.io.*;

public class NeatRoutine
{
        public static final int NEWLINK = 0;
        public static final int NEWNODE = 1;
        public static final int BIAS = 0;
        public static final int INPUT = 1;
        public static final int OUTPUT = 2;
        public static final int HIDDEN = 3;
        public static final int TIME_BIAS = 1;
        public static final int WEIGHT_HEBB = 2;
        public static final int DELAY = 3;
        public static Random myRandom = new Random();        
        
        public static String sREPORT_SPECIES_TESTA = "";
        public static Object sCURR_ORGANISM_CHAMPION = null;
        public static double sMIN_ERROR = 0.0; // public static double MAX_ERROR = 0.0;
        public static String sREPORT_SPECIES_CORPO = "";
        public static String sREPORT_SPECIES_CODA = "";
        
        public static String mREPORT_SPECIES_TESTA = "";
        public static Object mCURR_ORGANISM_CHAMPION = null;
        public static double mMIN_ERROR = 0.0; // public static double MAX_ERROR = 0.0;
        public static String mREPORT_SPECIES_CORPO = "";
        public static String mREPORT_SPECIES_CODA = "";        
        
        /** af_sigmoid_signed(double activesum,double slope,double constant)
         * {
         * return ((1/(1+(exp(-(slope*activesum-constant)))))-0.5)*2.0;
         * }
         * This is an approximation of the standard sigmoid that runs MUCH faster (about 50%) */
        public static double af_sigmoid_signed(double aNetinput, double aResponse, double shit)
        {
                double c0 = 0.5000f;
                double c1 = 0.2780f;
                double c2 = -0.0474f;
                double c3 = -2.4015e-004f;
                double c4 = 8.9276e-004f;
                double c5 = -9.0291e-005f;
                double c6 = 2.8028e-006f;
                double tUpperAndLowerLimit = 7.92871952056884f;
                
                double x = aNetinput / aResponse;
                
                if( x > tUpperAndLowerLimit)
                        return 1.0f;
                
                if(x < -tUpperAndLowerLimit)
                        return 0.0f;
                
                boolean tLessThanZero = false;
                
                if(x < 0.0f)
                {
                        x *= -1.0f;
                        tLessThanZero = true;
                }
                
                double xmul = x;
                double tOutput1 = c0;
                
                tOutput1 += c1*xmul;
                xmul *= x;
                tOutput1 += c2*xmul;
                xmul *= x;
                tOutput1 += c3*xmul;
                xmul *= x;
                tOutput1 += c4*xmul;
                xmul *= x;
                tOutput1 += c5*xmul;
                xmul *= x;
                tOutput1 += c6*xmul;
                
                double ret;
                
                if(!tLessThanZero)
                        ret = tOutput1;
                else
                        ret = 1.0f - tOutput1;
                
                return (ret-0.5)*2;
        }
        
        
        
        /** af_sigmoid_unsigned(double activesum,double slope,double constant)
         * {
         * return (1/(1+(exp(-(slope*activesum-constant)))));
         * This is an approximation of the standard sigmoid that runs MUCH faster (about 50%) */
        public static double af_sigmoid_unsigned(double aNetinput, double aResponse, double shit)
        {
                double c0 = 0.5000f;
                double c1 = 0.2780f;
                double c2 = -0.0474f;
                double c3 = -2.4015e-004f;
                double c4 = 8.9276e-004f;
                double c5 = -9.0291e-005f;
                double c6 = 2.8028e-006f;
                double tUpperAndLowerLimit = 7.92871952056884f;
                
                double x = aNetinput / aResponse;
                
                if( x > tUpperAndLowerLimit)
                        return 1.0f;
                
                if(x < -tUpperAndLowerLimit)
                        return 0.0f;
                
                boolean tLessThanZero = false;
                
                if(x < 0.0f)
                {
                        x *= -1.0f;
                        tLessThanZero = true;
                }
                
                double xmul = x;
                double tOutput1 = c0;
                
                tOutput1 += c1*xmul;
                xmul *= x;
                tOutput1 += c2*xmul;
                xmul *= x;
                tOutput1 += c3*xmul;
                xmul *= x;
                tOutput1 += c4*xmul;
                xmul *= x;
                tOutput1 += c5*xmul;
                xmul *= x;
                tOutput1 += c6*xmul;
                
                double ret;
                
                if(!tLessThanZero)
                        ret = tOutput1;
                else
                        ret = 1.0f - tOutput1;
                
                return ret;
        }
        
        public static double randfloat()
        {
                return myRandom.nextDouble();
        }
        public static int randposneg()
        {
                
                int n = myRandom.nextInt();
                if ((n % 2) == 0)
                        return -1;
                else
                        return 1;
                
        }
        /**
         * Insert the method's description here.
         * Creation date: (24/01/2002 11.15.43)
         */
        
        public static double gaussrand()
        {
                return myRandom.nextGaussian();
        }
        public static int randint(int x, int y)
        {
                int n = myRandom.nextInt(y - x + 1);
                return (n + x);
        }
        

}
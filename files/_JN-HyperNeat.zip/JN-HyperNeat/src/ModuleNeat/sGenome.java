
package ModuleNeat;

import java.util.*;
import java.text.*;

public class sGenome
{

        /** Numeric identification for this genotype */
        public int genome_id;
        /**
         * Each Gene in (3) has a marker telling when it arose historically;
         * Thus, these Genes can be used to speciate the population, and
         * the list of Genes provide an evolutionary history of innovation and link-building
         */
        Vector genes;
        /** Is a collection of all layers mapped in a Vector; */
        Vector nodes;
        /** Is a collection of input, island layers mapped in a Vector; */
        Vector inputs;
        Vector island_nodes; // nodes that has all incoming or outgoing genes disabled
        Vector outputs;
        /** Is a collection of layers that are not inputs */
        Vector com_nodes;
        /** a collection of enabled/disabled genes */
        Vector com_genes;
        Vector dis_genes;
        /** a collection of enabled genes with > 0 delay */
        Vector recurr_on;
        /** a collection of enabled genes with 0 delay */
        Vector recurr_off;
        /** note are two String for store statistics information
         * when genomes are readed (if exist : null otherwise);*/
        public String notes;

        /** Creates a new system genome from an initial file */
        public sGenome(int id, IOseq xFile)
        {

                StringTokenizer st;
                String curword;
                String xline;
                boolean done = false;
                //   	notes = null;

                genome_id = id;

                //	System.out.print("\n genome id current is "+ genome_id);

                nodes = new Vector(5, 0);
                genes = new Vector(5, 0);


                while(!done)
                {
                        xline = xFile.IOseqRead();
                        st = new StringTokenizer(xline);

                        curword = st.nextToken();
                        if(curword.equalsIgnoreCase("sysgenomeend"))
                        {
                                curword = st.nextToken();
                                if(Integer.parseInt(curword) != genome_id)
                                {
                                        System.out.println(" *ERROR* id mismatch in genome");
                                }
                                done = true;
                        }
                        else if(curword.equals("/*"))
                        {
                                curword = st.nextToken();
                                while(!curword.equals("*/"))
                                {
                                        curword = st.nextToken();
                                }
                        }
                        else if(curword.equals("node"))
                        {
                                sNode newnode;
                                newnode = new sNode(xline);
                                nodes.addElement(newnode);

                        }
                        else if(curword.equals("gene"))
                        {
                                sGene newgene;
                                newgene = new sGene(xline, nodes);
                                genes.addElement(newgene);
                        }

                }

        }

        /** Deep copy system genome constructor */
        public sGenome(int id, Vector n, Vector g)
        {
                genome_id = id;
                nodes = n;
                genes = g;
        }

        public sGenome duplicate(int new_id)
        {
                sNode newnode = null;
                sNode inode = null;
                sNode onode = null;
                sGene newgene = null;
                sGenome newgenome = null;

                Vector nodes_dup = new Vector(nodes.size(), 0);
                Vector genes_dup = new Vector(genes.size(), 0);

                Iterator itr_node = nodes.iterator();
                Iterator itr_gene = genes.iterator();


                /**
                 * duplicate sNodes
                 */
                while(itr_node.hasNext())
                {
                        sNode _node = ((sNode) itr_node.next());
                        newnode = new sNode(_node);

                        _node.dup = newnode;
                        nodes_dup.add(newnode);
                }

                /**
                 * duplicate sGenes
                 */
                while(itr_gene.hasNext())
                {

                        sGene _gene = ((sGene) itr_gene.next());

                        // point to news nodes created  at precedent step
                        inode = _gene.in_node.dup;
                        onode = _gene.out_node.dup;

                        // creation of new gene with a pointer to new node
                        newgene = new sGene(_gene, inode, onode);
                        genes_dup.add(newgene);
                }

                // okay all nodes created, the new genome can be generate
                newgenome = new sGenome(new_id, nodes_dup, genes_dup);

                // reset temporary reference for garbage collection
                itr_node = nodes.iterator();
                while(itr_node.hasNext())
                {
                        ((sNode) itr_node.next()).dup = null;
                }

                return newgenome;
        }

        /** re-arrange layers in order of firing sequence */
        public boolean firing_sequence(int gen)
        {
                sNode _node;
                sGene _gene;
                
                boolean good = true;
                
                // create a list of incoming and outgoing links for each node, and dis-abled genes

                com_genes = new Vector(genes.size(), 0);
                recurr_on = new Vector(genes.size(), 0);
                recurr_off = new Vector(genes.size(), 0);
                dis_genes = new Vector(genes.size() >> 1, 0);
                int i;
                int v_size;
                int j;
                int j_size;
                Vector v_incoming = new Vector(5, 0);

                // reset all incoming outgoing Vectors
                int n_size = nodes.size();
                for(i = 0; i < n_size; i++)
                {
                        _node = (sNode) nodes.elementAt(i);
                        _node.incoming_on = new Vector(3, 0);
                        _node.outgoing_on = new Vector(3, 0);
                        _node.incoming_off = new Vector(3, 0);
                        _node.outgoing_off = new Vector(3, 0);
                }

                v_size = genes.size();
                for(i = 0; i < v_size; i++)
                {
                        _gene = (sGene) genes.elementAt(i);

                        if(_gene.enable)
                        {
                                com_genes.add(_gene);
                                _gene.out_node.incoming_on.add(_gene);
                                _gene.in_node.outgoing_on.add(_gene);
                                if(_gene.recurrent)
                                {
                                        recurr_on.add(_gene);
                                }
                                else
                                {
                                        recurr_off.add(_gene);
                                }
                        }
                        else
                        {
                                dis_genes.add(_gene);
                                _gene.out_node.incoming_off.add(_gene);
                                _gene.in_node.outgoing_off.add(_gene);
                        }
                }

                //remove input, island nodes from sorting
                //place inputs to inputs vectors, outputs to outputs vector, un-used nodes to island_node
                inputs = new Vector(mNeat.s_input_size, 0);
                outputs = new Vector(mNeat.s_output_size, 0);
                com_nodes = new Vector(n_size, 0);
                island_nodes = new Vector(n_size >> 1, 0);

                for(i = 0; i < n_size; i++)
                {
                        _node = (sNode) nodes.elementAt(i);
                        if(_node.type == 1)
                        {
                                //_node.order_num = 1;
                                inputs.add(_node);
                        }
                        else if(_node.type == 2)
                        {
                                //_node.order_num = 0; // value zero means the node hasn't been ordered
                                outputs.add(_node);
                                com_nodes.add(_node);
                        }
                        else if(_node.type == 3)
                        {
                                //_node.order_num = 0;
                                if(_node.incoming_on.size() != 0 && _node.outgoing_on.size() != 0)
                                {
                                        com_nodes.add(_node);
                                }
                                else
                                {
                                        island_nodes.add(_node);
                                }
                        }
                }
                // com_nodes has non-input non-island nodes

                // check input output nodes numbers
                if((inputs.size() != mNeat.s_input_size) || (outputs.size() != mNeat.s_output_size))
                {
                        System.out.println("System " + genome_id + " missing inputs or outputs");
                        return false;
                }

                // check all incoming fiber to input should only be recurrent fibers
                v_size = inputs.size();
                for(i = 0; i < v_size; i++)
                {
                        _node = (sNode) inputs.elementAt(i);
                        j_size = _node.incoming_on.size();
                        for(j = 0; j < j_size; j++)
                        {
                                if(!((sGene) _node.incoming_on.elementAt(j)).recurrent)
                                {
                                        System.out.println("System input has non-recurrent incoming fiber!");
                                        good = false;
                                }
                        }
                }


                // for debugging
                // System.out.println("System " + genome_id + " island_nodes size: " + island_nodes.size());

                nodes = new Vector(n_size, 0);
                nodes.addAll(inputs); // place input layers first in order                

                // order other layers depending on if all of its incoming signal come from already ordered layers
                boolean disconnect = false;
                boolean once = true; // at least one node has all incoming nodes from already ordered nodes
                while(once)
                {
                        once = false;

                        v_size = com_nodes.size();
                        for(i = 0; i < v_size; i++)
                        {
                                _node = (sNode) com_nodes.elementAt(i);
                                disconnect = false;

                                // for every incoming gene, check if it's connected to already ordered (neworder) nodes
                                v_incoming = _node.incoming_on;
                                j_size = v_incoming.size();

                                for(j = 0; j < j_size; j++)
                                {
                                        _gene = (sGene) v_incoming.elementAt(j);
                                        if(!_gene.recurrent)
                                        {
                                                if(!nodes.contains(_gene.in_node))
                                                {
                                                        disconnect = true;
                                                        break;
                                                }
                                        /*else
                                        {
                                        if(_gene.in_node.order_num >= _node.order_num)
                                        {
                                        _node.order_num = _gene.in_node.order_num + 1;
                                        }
                                        }*/
                                        }
                                /*else // if the node only has recurrent incoming, it act as an input at next time step
                                {
                                _node.order_num = 1;
                                }*/
                                }

                                // if all incoming genes are from already ordered nodes, move this node into neworder
                                if(!disconnect)
                                {
                                        nodes.add(_node);
                                        com_nodes.removeElement(_node);
                                        once = true;
                                        break;
                                }
                        }
                }// finish ordering

                // for debugging
                // System.out.println("System " + genome_id + " com_nodes size after ordering: " + v_size);

                for(i = 0; i < v_size; i++)
                {
                        _node = (sNode) com_nodes.elementAt(i);
                        if(_node.type == 2)
                        {
                                System.out.println("System " + genome_id + " outputs are disconnected");
                                good = false;
                                break;
                        }
                }

                island_nodes.addAll(com_nodes); // add the remaining disconnected nodes

                v_size = island_nodes.size();
                for(i = 0; i < v_size; i++)
                {
                        _node = (sNode) island_nodes.elementAt(i);
                        if(_node.incoming_on.size() != 0)
                        {
                                j_size = _node.incoming_on.size();
                                for(j =0; j < j_size; j++)
                                {
                                        _gene = (sGene) _node.incoming_on.elementAt(j);
                                        _gene.enable = false;
                                        _gene.disable_gen = gen;
                                }                                
                                
                                _node.incoming_off.addAll(_node.incoming_on);
                                dis_genes.addAll(_node.incoming_on);
                                com_genes.removeAll(_node.incoming_on);
                                _node.incoming_on.clear();
                        }

                        if(_node.outgoing_on.size() != 0)
                        {
                                j_size = _node.outgoing_on.size();
                                for(j =0; j < j_size; j++)
                                {
                                        _gene = (sGene) _node.outgoing_on.elementAt(j);
                                        _gene.enable = false;
                                        _gene.disable_gen = gen;
                                }                                
                                
                                _node.outgoing_off.addAll(_node.outgoing_on);
                                dis_genes.addAll(_node.outgoing_on);
                                com_genes.removeAll(_node.outgoing_on);
                                _node.outgoing_on.clear();
                        }
                }

                // don't take out the inputs from new order, because they too can have incoming recurrent fibers

                com_nodes = new Vector(nodes.size(), 0);

                com_nodes.addAll(nodes); // com_nodes now have inputs, all computing layers, then outputs

                nodes.addAll(island_nodes);

                // for debugging
                //System.out.println("nodes " + nodes.size());
                //System.out.println("comnodes " + com_nodes.size());

                return good;

        }
        
        /* used for mating */
        public void organize()
        {
                sNode _node;
                sGene _gene;
                
                // create a list of incoming and outgoing links for each node, and dis-abled genes

                com_genes = new Vector(genes.size(), 0);
                recurr_on = new Vector(genes.size(), 0);
                recurr_off = new Vector(genes.size(), 0);
                dis_genes = new Vector(genes.size() >> 1, 0);
                int i;
                int v_size;

                // reset all incoming outgoing Vectors
                int n_size = nodes.size();
                for(i = 0; i < n_size; i++)
                {
                        _node = (sNode) nodes.elementAt(i);
                        _node.incoming_on = new Vector(3, 0);
                        _node.outgoing_on = new Vector(3, 0);
                        _node.incoming_off = new Vector(3, 0);
                        _node.outgoing_off = new Vector(3, 0);
                }

                v_size = genes.size();
                for(i = 0; i < v_size; i++)
                {
                        _gene = (sGene) genes.elementAt(i);

                        if(_gene.enable)
                        {
                                com_genes.add(_gene);
                                _gene.out_node.incoming_on.add(_gene);
                                _gene.in_node.outgoing_on.add(_gene);
                                if(_gene.recurrent)
                                {
                                        recurr_on.add(_gene);
                                }
                                else
                                {
                                        recurr_off.add(_gene);
                                }
                        }
                        else
                        {
                                dis_genes.add(_gene);
                                _gene.out_node.incoming_off.add(_gene);
                                _gene.in_node.outgoing_off.add(_gene);
                        }
                }

                inputs = new Vector(mNeat.s_input_size, 0);
                outputs = new Vector(mNeat.s_output_size, 0);
                com_nodes = new Vector(n_size, 0);
                island_nodes = new Vector(n_size >> 1, 0);

                for(i = 0; i < n_size; i++)
                {
                        _node = (sNode) nodes.elementAt(i);
                        if(_node.type == 1)
                        {
                                inputs.add(_node);
                                com_nodes.add(_node);
                        }
                        else if(_node.type == 2)
                        {
                                outputs.add(_node);
                                com_nodes.add(_node);
                        }
                        else if(_node.type == 3)
                        {
                                if(_node.incoming_on.size() != 0 && _node.outgoing_on.size() != 0)
                                {
                                        com_nodes.add(_node);
                                }
                                else
                                {
                                        island_nodes.add(_node);
                                }
                        }
                }                
        }
        
        

        /** vreset (null) temporary reference to real nodes for each layer, (for garbage collection after network evaluation) */
        public void reset_rnode_reference()
        {

                Iterator itr_layer = nodes.iterator();
                while(itr_layer.hasNext())
                {
                        sNode _layer = (sNode) itr_layer.next();
                        _layer.rnodes = null;
                }
        }

        /**
         *     This function gives a measure of compatibility between
         *     two Genomes by computing a linear combination of 3
         *     characterizing variables of their compatibilty.
         *     The 3 variables represent PERCENT DISJOINT GENES,
         *     PERCENT EXCESS GENES, MUTATIONAL DIFFERENCE WITHIN
         *     MATCHING GENES.  So the formula for compatibility
         *     is:  disjoint_coeff*pdg+excess_coeff*peg+mutdiff_coeff*mdmg.
         *     The 3 coefficients are global system parameters
         */
        public double compatibility(sGenome g)
        {

                //Innovation numbers
                double p1innov;
                double p2innov;

                //Intermediate value
                double mut_diff = 0;

                //Set up the counters
                double num_disjoint = 0.0;
                double num_excess = 0.0;
                double mut_diff_total = 0.0;
                double num_matching = 0.0; //Used to normalize mutation_num differences

                sGene _gene1 = null;
                sGene _gene2 = null;

                double max_genome_size; //Size of larger Genome

                //Get the length of the longest Genome for percentage computations
                int size1 = genes.size();
                int size2 = g.genes.size();
                max_genome_size = Math.max(size1, size2);
                //Now move through the Genes of each potential parent
                //until both Genomes end
                int j = 0;
                int j1 = 0;
                int j2 = 0;

                for(j = 0; j < max_genome_size; j++)
                {

                        if(j1 >= size1)
                        {
                                num_excess += 1.0;
                                j2++;
                        }
                        else if(j2 >= size2)
                        {
                                num_excess += 1.0;
                                j1++;
                        }
                        else
                        {
                                _gene1 = (sGene) genes.elementAt(j1);
                                _gene2 = (sGene) g.genes.elementAt(j2);

                                //Extract current innovation numbers
                                p1innov = _gene1.innovation_num;
                                p2innov = _gene2.innovation_num;

                                if(p1innov == p2innov)
                                {
                                        num_matching += 1.0;

                                        // penalize node count difference
                                        double factor = Math.abs(_gene1.in_node.node_count - _gene2.in_node.node_count) / Math.min(_gene1.in_node.node_count, _gene2.in_node.node_count);
                                        if(factor > 1)
                                        {
                                                factor = 1;
                                        }
                                        mut_diff += mNeat.s_node_count_penalty * factor;

                                        factor = Math.abs(_gene1.out_node.node_count - _gene2.out_node.node_count) / Math.min(_gene1.out_node.node_count, _gene2.out_node.node_count);
                                        if(factor > 1)
                                        {
                                                factor = 1;
                                        }
                                        mut_diff += mNeat.s_node_count_penalty * factor;

                                        // penalize if modules are not in the same species
                                        if(_gene1.in_node.time_bias_species_id != _gene2.in_node.time_bias_species_id)
                                        {
                                                mut_diff += mNeat.s_disjoint_mod_penalty;
                                        }

                                        if(_gene1.out_node.time_bias_species_id != _gene2.out_node.time_bias_species_id)
                                        {
                                                mut_diff += mNeat.s_disjoint_mod_penalty;
                                        }

                                        if(_gene1.weight_hebb_species_id != _gene2.weight_hebb_species_id)
                                        {
                                                mut_diff += mNeat.s_disjoint_mod_penalty;
                                        }

                                        if(_gene1.recurrent && _gene2.recurrent)
                                        {
                                                if(_gene1.delay_species_id != _gene2.delay_species_id)
                                                {
                                                        mut_diff += mNeat.s_disjoint_mod_penalty;
                                                }
                                        }

                                        mut_diff_total += mut_diff;
                                        j1++;
                                        j2++;
                                }
                                else if(p1innov < p2innov)
                                {
                                        j1++;
                                        num_disjoint += 1.0;
                                }
                                else if(p2innov < p1innov)
                                {
                                        j2++;
                                        num_disjoint += 1.0;
                                }

                        }

                }

                // Return the compatibility number using compatibility formula
                // Note that mut_diff_total/num_matching gives the AVERAGE
                // difference between mutation_nums for any two matching Genes
                // in the Genome.
                // Look at disjointedness and excess in the absolute (ignoring size)

                return (mNeat.s_disjoint_coeff * (num_disjoint / 1.0) + mNeat.s_excess_coeff * (num_excess / 1.0) + mNeat.s_mutdiff_coeff * (mut_diff_total / num_matching));
        }

        public double get_last_gene_innovnum()
        {
                return (((sGene) genes.lastElement()).innovation_num + 1);
        }

        public int get_last_node_id()
        {
                return (((sNode) nodes.lastElement()).node_id + 1);
        }

        public void print_to_file(IOseq xFile)
        {
                //
                // write to file genome in native format (for re-read)
                //


                String riga = "sysgenomestart  " + genome_id;
                xFile.IOseqWrite(riga);


                Iterator itr_node = nodes.iterator();
                itr_node = nodes.iterator();

                while(itr_node.hasNext())
                {
                        sNode _node = ((sNode) itr_node.next());
                        _node.print_to_file(xFile);
                }

                Iterator itr_gene = genes.iterator();
                itr_gene = genes.iterator();

                while(itr_gene.hasNext())
                {
                        sGene _gene = ((sGene) itr_gene.next());
                        _gene.print_to_file(xFile);
                }

                riga = "sysgenomeend " + genome_id;
                xFile.IOseqWrite(riga);


        }

        public void print_to_filename(String xNameFile)
        {
                //
                // write to file genome in native format (for re-read)
                //
                IOseq xFile;


                xFile = new IOseq(xNameFile);
                xFile.IOseqOpenW(false);

                try
                {

                        print_to_file(xFile);

                }
                catch(Throwable e)
                {
                        System.err.println(e);
                }

                xFile.IOseqCloseW();


        }

        /** mutate the number of nodes in each layer */
        public boolean mutate_node_count(int gen)
        {
                sNode _node;
                Vector temp;

                temp = new Vector(com_nodes.size(), 0);
                temp.addAll(com_nodes);
                temp.removeAll(outputs);
                temp.removeAll(inputs);

                double count;
                double frac;
                double age_frac;

                int n;
                int n_size = temp.size();
                for(n = 0; n < n_size; n++)
                {
                        _node = (sNode) temp.elementAt(n);
                        count = _node.node_count;

                        age_frac = Math.exp((_node.modified_gen - gen) / mNeat.s_mutate_age_factor);

                        // young nodes haeve more chance to have their node counts set to random orders of magnitude
                        if(NeatRoutine.randfloat() < age_frac)
                        {
                                count = Math.pow(2, NeatRoutine.randfloat() * mNeat.s_max_count_pow2);
                                _node.modified_gen = gen; // severe modification record is set
                        }
                        else
                        {
                                // increase node count or decrease node count, within original node count's order of magnitude
                                frac = NeatRoutine.randfloat() * age_frac;
                                if(NeatRoutine.randfloat() < mNeat.s_mutate_count_increase_prob)
                                {
                                        count *= (1 + frac);
                                }
                                else
                                {
                                        count *= (1 - frac);
                                }
                        }

                        if(count < 1) // check node count boundary
                        {
                                count = 1;
                        }
                        else if(count > mNeat.s_max_node_count)
                        {
                                count = mNeat.s_max_node_count;
                        }

                        // rounding and set
                        _node.node_count = (int) (count + .5);
                }

                temp = null;
                return true;
        }

        /** make sure a system's modules are all alive, and randomly shuffle them */
        public void mutate_shuffle_modules(mPopulation tb_pop, mPopulation wh_pop, mPopulation de_pop, boolean module_evolved, int gen, double fitness)
        {
                double age_frac;
                double fit_frac = fitness / mNeat.winner_fitness;
                fit_frac = Math.sqrt(fit_frac);

                // layer modules
                int n_size = nodes.size();
                for(int n = 0; n < n_size; n++)
                {
                        sNode _node = (sNode) nodes.elementAt(n);
                        mOrganism _org;
                        age_frac = Math.exp((_node.modified_gen - gen) / mNeat.s_mutate_age_factor);

                        if(module_evolved) // there will be only be new module organisms
                        {
                                _org = null;
                        }
                        else
                        {
                                _org = _node.time_bias_m_org;

                                // for debugging
                                if(_org == null)
                                {
                                        System.out.println("----> ERROR: TIME MODULE IS NULL <----");
                                }
                        }

                        if(_org == null)
                        {
                                // get the original module species
                                mSpecies _spec = tb_pop.find_species(_node.time_bias_species_id);

                                // higher fitness system tend to pick higher fitness module
                                boolean org_random = (NeatRoutine.randfloat() > fit_frac);
                                _org = tb_pop.pick_organism(org_random, _spec);
                                _node.modified_gen = gen;
                        }
                        else // 
                        {
                                // younger node has more chance to have this module replaced
                                if(NeatRoutine.randfloat() < age_frac)
                                {
                                        mSpecies _spec = _org.species;
                                        int num = tb_pop.species.size() - 1;
                                        // younger node has more chance to pick a random species
                                        if(NeatRoutine.randfloat() < age_frac && num != 0)
                                        {
                                                _node.modified_gen = gen;
                                                while(_spec.id == _org.species.id)
                                                {
                                                        _spec = (mSpecies) tb_pop.species.elementAt(NeatRoutine.randint(0, num));
                                                }
                                        }

                                        // higher fitness system tend to pick higher fitness module
                                        boolean org_random = (NeatRoutine.randfloat() > fit_frac);
                                        _org = tb_pop.pick_organism(org_random, _spec);
                                }
                        }

                        // assign this module
                        _node.time_bias_m_org = _org;
                        _node.time_bias_species_id = _org.species.id;
                }


                // fiber modules
                n_size = genes.size();
                for(int n = 0; n < n_size; n++)
                {
                        sGene _gene = (sGene) genes.elementAt(n);
                        mOrganism _org;
                        age_frac = Math.exp((_gene.modified_gen - gen) / mNeat.s_mutate_age_factor);

                        // delay module, newly created ones won't need this
                        // because its module species has already been specifially picked
                        if(_gene.recurrent && _gene.modified_gen != gen)
                        {
                                if(module_evolved)
                                {
                                        _org = null;
                                }
                                else
                                {
                                        _org = _gene.delay_m_org;

                                        // for debugging
                                        if(_org == null)
                                        {
                                                System.out.println("----> ERROR: DELAY MODULE IS NULL <----");
                                        }
                                }

                                if(_org == null)
                                {
                                        // get the original module species
                                        mSpecies _spec = de_pop.find_species(_gene.delay_species_id);

                                        boolean org_random = (NeatRoutine.randfloat() > fit_frac);
                                        _org = de_pop.pick_organism(org_random, _spec);
                                }
                                else
                                {
                                        // younger gene has more chance to have this module replaced
                                        if(NeatRoutine.randfloat() < age_frac)
                                        {
                                                mSpecies _spec = _org.species;
                                                int num = de_pop.species.size() - 1;
                                                // younger gene has more chance to pick a random species, unless its just created recurrent gene
                                                if(NeatRoutine.randfloat() < age_frac && num != 0)
                                                {
                                                        _gene.modified_gen = gen;
                                                        while(_spec.id == _org.species.id)
                                                        {
                                                                _spec = (mSpecies) de_pop.species.elementAt(NeatRoutine.randint(0, num));
                                                        }
                                                }

                                                boolean org_random = (NeatRoutine.randfloat() > fit_frac);
                                                _org = de_pop.pick_organism(org_random, _spec);
                                        }
                                }

                                // assign this module
                                _gene.delay_m_org = _org;
                                _gene.delay_species_id = _org.species.id;
                        }


                        // weight hebbian module
                        if(module_evolved)
                        {
                                _org = null;
                        }
                        else
                        {
                                _org = _gene.weight_hebb_m_org;

                                // for debugging
                                if(_org == null)
                                {
                                        System.out.println("----> ERROR: WEIGHT MODULE IS NULL <----");
                                }
                        }

                        if(_org == null) // the original module died
                        {
                                // get the original module species
                                mSpecies _spec = wh_pop.find_species(_gene.weight_hebb_species_id);

                                boolean org_random = (NeatRoutine.randfloat() > fit_frac);
                                _org = wh_pop.pick_organism(org_random, _spec);
                        }
                        else
                        {
                                // younger gene has more chance to have this module replaced
                                if(NeatRoutine.randfloat() < age_frac)
                                {
                                        mSpecies _spec = _org.species;
                                        int num = wh_pop.species.size() - 1;
                                        // younger gene has more chance to pick a random species
                                        if(NeatRoutine.randfloat() < age_frac && num != 0)
                                        {
                                                _gene.modified_gen = gen;
                                                while(_spec.id == _org.species.id)
                                                {
                                                        _spec = (mSpecies) wh_pop.species.elementAt(NeatRoutine.randint(0, num));
                                                }
                                        }

                                        boolean org_random = (NeatRoutine.randfloat() > fit_frac);
                                        _org = wh_pop.pick_organism(org_random, _spec);
                                }
                        }

                        // assign this module
                        _gene.weight_hebb_m_org = _org;
                        _gene.weight_hebb_species_id = _org.species.id;
                }
        }

        /** pick a gene and turn recurrent on and off */
        public boolean mutate_toggle_recurrent(mPopulation de_pop, int gen)
        {

                int m;
                sGene _gene;
                double age_frac;
                int num = de_pop.species.size() - 1;

                // a chance to change this gene in to non-recurrent gene
                if(NeatRoutine.randfloat() < mNeat.s_mutate_recurrent_off_prob && recurr_on.size() != 0)
                {
                        int g_num = recurr_on.size() - 1;
                        for(int i = 0; i <= g_num; i++) // until probability gets the younger gene
                        {
                                m = NeatRoutine.randint(0, g_num);
                                _gene = (sGene) recurr_on.elementAt(m);

                                age_frac = Math.exp((_gene.modified_gen - gen) / mNeat.s_mutate_age_factor);

                                if(NeatRoutine.randfloat() < age_frac) // younger gene is more likely get changed
                                {
                                        _gene.recurrent = false;
                                        _gene.modified_gen = gen;
                                        _gene.delay_m_org = null;

                                        recurr_on.remove(_gene);
                                        recurr_off.add(_gene);

                                        return true;
                                }
                        }
                }
                else if(NeatRoutine.randfloat() < mNeat.s_mutate_recurrent_on_prob && recurr_off.size() != 0 && num != 0)
                {
                        int g_num = recurr_off.size() - 1;
                        for(int i = 0; i <= g_num; i++) // until probability gets the younger gene
                        {
                                m = NeatRoutine.randint(0, g_num);
                                _gene = (sGene) recurr_off.elementAt(m);

                                age_frac = Math.exp((_gene.modified_gen - gen) / mNeat.s_mutate_age_factor);


                                if(NeatRoutine.randfloat() < age_frac) // younger gene is more likely get changed
                                {
                                        _gene.recurrent = true;
                                        _gene.modified_gen = gen;

                                        recurr_off.remove(_gene);
                                        recurr_on.add(_gene);

                                        // find if such a recurrent gene already exist, if so find a different species
                                        int temp_id = -1;
                                        int j_size = recurr_on.size();
                                        for(int j = 0; j < j_size; j++)
                                        {
                                                sGene _match = (sGene) recurr_on.elementAt(j);
                                                if((_match.in_node == _gene.in_node) && (_match.out_node == _gene.out_node) && (_match.recurrent == true))
                                                {
                                                        temp_id = _match.delay_species_id;
                                                }
                                        }

                                        mSpecies _spec;

                                        do // find a different species
                                        {
                                                _spec = (mSpecies) de_pop.species.elementAt(NeatRoutine.randint(0, num));
                                        }
                                        while(_spec.id == temp_id);

                                        boolean org_random = (NeatRoutine.randfloat() < .5);
                                        mOrganism _org = de_pop.pick_organism(org_random, _spec);

                                        _gene.delay_m_org = _org;
                                        _gene.delay_species_id = _org.species.id;

                                        return true;
                                }
                        }
                }

                return false;
        }

        /** (1) place it below disable_gene, otherwise it may get disabled (only in non-safe disable_gene)
         *  (2) may create non-recurrent back-track connection if done more than once without doing firing sequence in between
         *  otherwise it's safe
         */
        public boolean mutate_add_link(boolean do_recurr, sPopulation pop, mPopulation wh_pop, mPopulation de_pop, int gen)
        {
                boolean done = false;
                boolean found = false;

                mOrganism d_org = null;
                mOrganism w_org = null;

                // chance of only adding a recurrent link
                if(do_recurr)
                {
                        // assign a random delay module
                        d_org = de_pop.pick_organism(true, null);
                }

                sNode thenode1 = null;
                sNode thenode2 = null;
                sGene new_gene = null;
                sGene _gene = null;

                Iterator itr_innovation = null;

                Vector allnodes;
                int numnodes;
                boolean do_cascade;
                if(NeatRoutine.randfloat() < mNeat.s_mutate_disabled_struct_prob)
                {
                        numnodes = nodes.size();

                        allnodes = new Vector(numnodes, 0);
                        allnodes.addAll(nodes);

                        do_cascade = true;
                }
                else
                {
                        numnodes = com_nodes.size();

                        allnodes = new Vector(numnodes, 0);
                        allnodes.addAll(com_nodes);

                        do_cascade = false; // no reason to cascade if add link only to enabled structures

                }

                int trycount = 0;
                int tries = (numnodes + 1) * numnodes / 2;

                //Make attempts to find an unconnected pair
                found = true;
                while(trycount < tries)
                {
                        //
                        // now point to object's nodes, in_node from all nodes, out_node from non-input nodes
                        //
                        if(do_recurr)
                        {
                                thenode1 = (sNode) allnodes.elementAt(NeatRoutine.randint(0, numnodes - 1));
                                thenode2 = (sNode) allnodes.elementAt(NeatRoutine.randint(0, numnodes - 1));
                        }
                        else
                        {
                                do
                                {
                                        thenode1 = (sNode) allnodes.elementAt(NeatRoutine.randint(0, numnodes - 1));
                                        thenode2 = (sNode) allnodes.elementAt(NeatRoutine.randint(0, numnodes - 1));
                                }
                                while((thenode1.node_id == thenode2.node_id)); // this prevents non-recurrent back-track connection
                        }//(thenode1.order_num > thenode2.order_num) || 

                        //
                        // verify if the possible new gene already EXIST
                        //
                        int j;
                        int j_size = genes.size();
                        for(j = 0; j < j_size; j++)
                        {
                                _gene = (sGene) genes.elementAt(j);
                                if((_gene.in_node == thenode1) && (_gene.out_node == thenode2) && (_gene.recurrent == do_recurr))
                                {
                                        if(do_recurr)
                                        {
                                                if(_gene.delay_species_id == d_org.species.id)
                                                {
                                                        found = false;
                                                        break;
                                                }
                                                else
                                                {
                                                        found = true;
                                                        break;
                                                }
                                        }
                                        else
                                        {
                                                found = false;
                                                break;
                                        }
                                }
                        }


                        if(!found)
                        {
                                trycount++;
                        }
                        else
                        {
                                trycount = tries;
                        }
                } // end block trycount

                if(found)
                {
                        // assign a random weight_hebb module
                        w_org = wh_pop.pick_organism(true, null);

                        //Check to see if this innovation already occured in the population
                        itr_innovation = pop.innovations.iterator();

                        done = false;
                        while(!done)
                        {

                                if(!itr_innovation.hasNext())
                                {


                                        // read current innovation with postincrement
                                        double curr_innov = pop.getCurr_innov_num_and_increment();
                                        //Create the new gene
                                        new_gene = new sGene(thenode1, thenode2, do_recurr, w_org, d_org, curr_innov, gen);
                                        //Add the innovation
                                        pop.innovations.add(new sInnovation(thenode1.node_id, thenode2.node_id, curr_innov, do_recurr));
                                        done = true;

                                }
                                //OTHERWISE, match the innovation in the innovs list
                                else
                                {
                                        sInnovation _innov = ((sInnovation) itr_innovation.next());
                                        if((_innov.innovation_type == NeatRoutine.NEWLINK) && (_innov.node_in_id == thenode1.node_id) && (_innov.node_out_id == thenode2.node_id) && (_innov.recur_flag == do_recurr))
                                        {
                                                new_gene = new sGene(thenode1, thenode2, do_recurr, w_org, d_org, _innov.innovation_num1, gen);
                                                done = true;
                                        }
                                }
                        }

                        if(do_cascade)// check if the new link's in_node or out_node is in island_nodes, if so, reenable subsequent genes
                        {
                                mutate_cascade_reenable(new_gene, gen);
                        }

                        genes.add(new_gene); // not add to com_genes so that it won't get disabled in the same generation
                        com_genes.add(new_gene);

                        allnodes = null;

                        return true;
                }

                allnodes = null;

                return false;
        }

        /** This serves as a simultaneous minor pruning process without deleting ancestral genes,
         * the disabling is cascaded when in unsafe mode (more costly computation)
         */
        public boolean mutate_gene_disable(boolean safe, int gen)
        {
                sGene _gene;
                double age_frac;
                int g_num = com_genes.size() - 1;

                for(int i = 0; i <= g_num; i++)
                {
                        //find a random gene
                        _gene = (sGene) com_genes.elementAt(NeatRoutine.randint(0, g_num));
                        age_frac = Math.exp((_gene.modified_gen - gen) / mNeat.s_mutate_age_factor);

                        if(NeatRoutine.randfloat() < age_frac)
                        {

                                // safe mode: only disable link between nodes that have more than one links
                                if(safe)
                                {
                                        if(_gene.in_node.outgoing_on.size() > 1 && _gene.out_node.incoming_on.size() > 1)
                                        {
                                                _gene.enable = false;
                                                _gene.disable_gen = gen;
                                                com_genes.remove(_gene);
                                                dis_genes.add(_gene);

                                                return true;
                                        }
                                }
                                else // more likely to cascade on older structrues
                                {
                                        if(NeatRoutine.randfloat() > age_frac)
                                        {
                                                return mutate_cascade_disable(_gene, gen);
                                        }
                                }
                        }
                }

                return false;
        }

        /** reenable a disabed gene,  probability of reenabling is higer if, last disabling was recent and fitness is low */
        public boolean mutate_gene_reenable(int gen)
        {
                double age_frac;
                sGene _gene;

                if(dis_genes.size() != 0)
                {
                        int g_num = dis_genes.size() - 1;
                        for(int i = 0; i <= g_num; i++)
                        {
                                _gene = (sGene) dis_genes.elementAt(NeatRoutine.randint(0, g_num));
                                age_frac = Math.exp((_gene.disable_gen - gen) / mNeat.s_mutate_age_factor);

                                // this might undo bad recent disabling
                                if(NeatRoutine.randfloat() < age_frac)
                                {
                                        mutate_cascade_reenable(_gene, gen);
                                        return true;
                                }
                        }
                }
                return false;
        }

        /** used in unsafe gene_disable , maybe remove link */
        public boolean mutate_cascade_disable(sGene thegene, int generation)
        {
                sGene _gene = null;
                sNode _node = null;

                boolean has_enable = false;
                boolean output_gone = false;

                Vector store_island = new Vector(5, 0);

                // collection of genes that need to be cascade in down (then up) direction
                Vector casc_genes = new Vector(5, 0);
                casc_genes.add(thegene);

                int i;
                int v_size;
                v_size = casc_genes.size();
                for(i = 0; i < v_size; i++)
                {
                        _gene = (sGene) casc_genes.elementAt(i);
                        _node = _gene.out_node;

                        _gene.enable = false;
                        _gene.disable_gen = generation;

                        // move this gene from its out_node's incoming on to off
                        _node.incoming_on.remove(_gene);
                        _node.incoming_off.add(_gene);

                        // if this gene's out_node has no more enabled incoming genes
                        if(_node.incoming_on.size() == 0)
                        {
                                // if one output has no more incoming genes, break and reverse process
                                if(_node.type == 2)
                                {
                                        output_gone = true;
                                        break;
                                }

                                // add the out_node's outgoing genes for disabling
                                casc_genes.addAll(_node.outgoing_on);
                                v_size = casc_genes.size();

                                // move all outgoing on to off
                                _node.outgoing_off.addAll(_node.outgoing_on);
                                _node.outgoing_on.clear();

                                // add this node to potential island_nodes
                                store_island.add(_node);
                        }
                }

                if(output_gone)
                {
                        v_size = casc_genes.size();
                        // for the first gene, nothing happen to its in_node
                        _gene = (sGene) casc_genes.elementAt(0);
                        _gene.out_node.incoming_off.remove(_gene);
                        _gene.out_node.incoming_on.add(_gene);

                        v_size = casc_genes.size();
                        for(i = 1; i < v_size; i++)
                        {
                                _gene = (sGene) casc_genes.elementAt(i);
                                _gene.enable = true;
                                _gene.out_node.incoming_off.remove(_gene);
                                _gene.out_node.incoming_on.add(_gene);
                                _gene.in_node.outgoing_off.remove(_gene);
                                _gene.in_node.outgoing_on.add(_gene);
                        }

                        casc_genes = null;
                        store_island = null;

                        return false;
                }
                else
                {
                        // adding new island nodes to the list, if new link connect to them, a different topology can form
                        com_nodes.removeAll(store_island);
                        island_nodes.addAll(store_island);
                        com_genes.removeAll(casc_genes);
                        dis_genes.addAll(casc_genes);
                        store_island = null;

                        casc_genes = new Vector(5, 0);
                        casc_genes.add(thegene);

                        // no reason to store disabling genes, since there's no way to screw it up now
                        // unless... there are dangling nodes hanging around, which means bugs in link methods (this or other)
                        v_size = casc_genes.size();
                        for(i = 0; i < v_size; i++)
                        {
                                _gene = (sGene) casc_genes.elementAt(i);
                                _node = _gene.in_node;

                                if(i != 0) // already did these for the first gene
                                {
                                        _gene.enable = false;
                                        _gene.disable_gen = generation;
                                        com_genes.remove(_gene);
                                        dis_genes.add(_gene);
                                }

                                _node.outgoing_on.remove(_gene);
                                _node.outgoing_off.add(_gene);

                                if(_node.outgoing_on.size() == 0)
                                {
                                        // add the in_node's incoming genes for disabling
                                        casc_genes.addAll(_node.incoming_on);
                                        v_size = casc_genes.size();

                                        _node.incoming_off.addAll(_node.incoming_on);
                                        _node.incoming_on.clear();

                                        com_nodes.remove(_node);
                                        island_nodes.add(_node);
                                }
                        }

                        casc_genes = null;

                        return true;
                }
        }

        /** used for mutate_gene_reenable, and sometimes mutate_add_link */
        public boolean mutate_cascade_reenable(sGene thegene, int gen)
        {
                // if cascaded at least one other gene
                boolean once = false;
                sGene _gene = null;
                sNode _node = null;

                // collections of genes that need to be cascade in either up or down direction
                Vector up_genes = new Vector(5, 0);
                Vector down_genes = new Vector(5, 0);

                up_genes.add(thegene);
                down_genes.add(thegene);

                int i;
                int v_size = up_genes.size();
                for(i = 0; i < v_size; i++)
                {
                        _gene = (sGene) up_genes.elementAt(i);
                        _node = _gene.in_node;

                        // check if this gene's in_node is an island node
                        // if so, all of its incoming genes will be enabled next iteration
                        if(_node.incoming_on.size() == 0)
                        {
                                once = true;

                                // add all incoming genes of its in_node for further checking
                                up_genes.addAll(_node.incoming_off);
                                v_size = up_genes.size();

                                // move all genes from incoming_off to incoming_on
                                _node.incoming_on.addAll(_node.incoming_off);
                                _node.incoming_off.clear();

                                // remove this node from island_nodes so it won't get check again
                                island_nodes.remove(_node);
                                com_nodes.add(_node);
                        }

                        _gene.enable = true;
                        _gene.modified_gen = gen - 1; // treat reenabled gene as new gene, so it can get re-evolved
                        com_genes.add(_gene);
                        dis_genes.remove(_gene);
                }


                v_size = down_genes.size();
                for(i = 0; i < v_size; i++)
                {
                        _gene = (sGene) down_genes.elementAt(i);
                        _node = _gene.out_node;

                        // check if this gene's out_node is an island node
                        // if so,  all of its outgoing genes will be enabled next iteration
                        if(_node.outgoing_on.size() == 0)
                        {
                                once = true;

                                // add all outoing genes of its out_node for further checking
                                down_genes.addAll(_node.outgoing_off);
                                v_size = down_genes.size();

                                // move all genes from outgoing_off to outgoing_on
                                _node.outgoing_on.addAll(_node.outgoing_off);
                                _node.outgoing_off.clear();

                                // remove this node from island_nodes so it won't get check again
                                island_nodes.remove(_node);
                                com_nodes.add(_node);
                        }

                        if(i != 0)
                        {
                                _gene.enable = true;
                                _gene.modified_gen = gen - 1; // treat reenabled gene as new gene, so it can get re-evolved
                                com_genes.add(_gene);
                                dis_genes.remove(_gene);
                        }

                }

                up_genes = null;
                down_genes = null;
                return once;
        }

        /** has a risk of being disabled if done before disabling (and if cascading is on) */
        public boolean mutate_add_node(int gen, sPopulation pop, mPopulation tb_pop, mPopulation wh_pop, mPopulation de_pop)
        {

                sGene _gene = null;

                sGene newgene1 = null;
                sGene newgene2 = null;
                sNode in_node = null;
                sNode out_node = null;
                sNode new_node = null;
                Iterator itr_innovation;

                double gene_innov1;
                double gene_innov2;

                boolean do_cascade;
                if(NeatRoutine.randfloat() < mNeat.s_mutate_disabled_struct_prob)
                {
                        _gene = (sGene) genes.elementAt(NeatRoutine.randint(0, genes.size() - 1));
                        do_cascade = true;
                }
                else
                {
                        if(com_genes.size() == 0)
                        {
                                _gene = (sGene) genes.elementAt(NeatRoutine.randint(0, genes.size() - 1));
                        }
                        else
                        {
                                _gene = (sGene) com_genes.elementAt(NeatRoutine.randint(0, com_genes.size() - 1));
                        }
                        do_cascade = false;
                }

                // sometimes the old gene is disabled
                if(NeatRoutine.randfloat() < mNeat.s_newnode_geneoff_prob)
                {
                        _gene.enable = false;
                        _gene.disable_gen = gen;
                        com_genes.remove(_gene);
                        dis_genes.add(_gene);
                }

                // pick random time bias module, node count for the new node
                int n_count = (int) (Math.pow(2, NeatRoutine.randfloat() * mNeat.s_max_count_pow2) + .5);
                int m = NeatRoutine.randint(0, tb_pop.organisms.size() - 1);
                mOrganism t_org = (mOrganism) tb_pop.organisms.elementAt(m);

                mOrganism d_org1;
                boolean recurr1;
                // pick random modules for gene 1
                if(NeatRoutine.randfloat() < mNeat.s_mutate_recurrent_on_prob)
                {
                        recurr1 = true;
                        // assign a random delay module
                        m = NeatRoutine.randint(0, de_pop.organisms.size() - 1);
                        d_org1 = (mOrganism) de_pop.organisms.elementAt(m);
                }
                else
                {
                        recurr1 = false;
                        d_org1 = null;
                }

                // assgn a random weight hebb module
                m = NeatRoutine.randint(0, wh_pop.organisms.size() - 1);
                mOrganism w_org1 = (mOrganism) wh_pop.organisms.elementAt(m);


                // Extract old gene weight hebbian, delay module id
                mOrganism w_org2 = _gene.weight_hebb_m_org;
                mOrganism d_org2;
                boolean recurr2 = _gene.recurrent;
                if(recurr2)
                {
                        if(_gene.delay_m_org == null)
                        {
                                _gene.delay_m_org = de_pop.pick_organism(true, null);
                                System.out.println("----> ERROR: DELAY MODULE IS NULL IN ADD NODE <----");
                        }

                        d_org2 = _gene.delay_m_org;
                }
                else
                {
                        d_org2 = null;
                }

                //Extract the nodes
                in_node = _gene.in_node;
                out_node = _gene.out_node;

                boolean done = false;
                itr_innovation = pop.innovations.iterator();

                while(!done)
                {
                        //Check to see if this innovation already occured in the population
                        if(!itr_innovation.hasNext())
                        {

                                //The innovation is totally novel
                                //Create the new Genes
                                //Create the new NNode
                                int curnode_id = pop.getCur_node_id_and_increment();
                                new_node = new sNode(curnode_id, NeatRoutine.HIDDEN, n_count, t_org, gen);

                                gene_innov1 = pop.getCurr_innov_num_and_increment();
                                newgene1 = new sGene(in_node, new_node, recurr1, w_org1, d_org1, gene_innov1, gen);

                                gene_innov2 = pop.getCurr_innov_num_and_increment();
                                newgene2 = new sGene(new_node, out_node, recurr2, w_org2, d_org2, gene_innov2, gen - 1);

                                new_node.incoming_on.add(newgene1);
                                new_node.outgoing_on.add(newgene2);

                                pop.innovations.add(new sInnovation(in_node.node_id, out_node.node_id, gene_innov1, gene_innov2,
                                        new_node.node_id, _gene.innovation_num));
                                done = true;
                        }
                        // end for new innovation case
                        else
                        {
                                sInnovation _innov = ((sInnovation) itr_innovation.next());

                                if((_innov.innovation_type == NeatRoutine.NEWNODE) && (_innov.node_in_id == in_node.node_id) && (_innov.node_out_id == out_node.node_id) && (_innov.old_innov_num == _gene.innovation_num))
                                {
                                        // Create the new Genes
                                        // pass this current nodeid to newnode

                                        new_node = new sNode(_innov.newnode_id, NeatRoutine.HIDDEN, n_count, t_org, gen);
                                        newgene1 = new sGene(in_node, new_node, recurr1, w_org1, d_org1, _innov.innovation_num1, gen);
                                        newgene2 = new sGene(new_node, out_node, recurr2, w_org2, d_org2, _innov.innovation_num2, gen - 1);

                                        new_node.incoming_on.add(newgene1);
                                        new_node.outgoing_on.add(newgene2);

                                        done = true;

                                }
                        }

                }

                // cascading if the node is added between island nodes.
                if(do_cascade)
                {
                        mutate_cascade_reenable(newgene1, gen);
                        mutate_cascade_reenable(newgene2, gen);
                }

                //Now add the new NNode and new Genes to the Genome

                genes.add(newgene1);
                genes.add(newgene2);
                com_genes.add(newgene1);
                com_genes.add(newgene2);
                nodes.add(new_node);
                com_nodes.add(new_node);

                return true;

        }

        public sGenome mate_multipoint(sGenome g, int genomeid, double fitness1, double fitness2, int generation)
        {
                sGenome new_genome = null;
                int disable_status = 0; // 0: both enabled 1: both disabled , 2: one enable, one disable
                boolean disable_all = (NeatRoutine.randfloat() < .5); // if false, it will choose all enabled and cascade reenable
                boolean done = false;

                Vector cascade_genes = new Vector(5, 0);

                sGene _curgene2 = null;
                sGene newgene = null;
                sNode inode = null;
                sNode onode = null;
                sNode new_inode = null;
                sNode new_onode = null;
                sNode curnode = null;

                sGene chosengene = null;
                sGene _p1gene = null;
                sGene _p2gene = null;
                double p1innov = 0;
                double p2innov = 0;

                int j1;
                int j2;


                //Tells if the first genome (this one) has better fitness or not
                boolean skip = false;

                //Figure out which genome is better
                //The worse genome should not be allowed to add extra structural baggage
                //If they are the same, use the smaller one's disjoint and excess genes only

                boolean p1better = false;

                int size1 = genes.size();
                int size2 = g.genes.size();

                if(fitness1 > fitness2)
                {
                        p1better = true;
                }
                else if(fitness1 == fitness2)
                {
                        if(size1 < size2)
                        {
                                p1better = true;
                        }
                }

                int len_genome = Math.max(size1, size2);
                int len_nodes = nodes.size();

                Vector newgenes = new Vector(len_genome, 0);
                Vector newnodes = new Vector(len_nodes, 0);

                newnodes.addAll(inputs);
                newnodes.addAll(outputs);

                Iterator itr_newgenes;

                j1 = 0;
                j2 = 0;

                while(j1 < size1 || j2 < size2)
                {
                        //
                        //  chosen of 'just' gene
                        //

                        skip = false; //Default to not skipping a chosen gene
                        if(j1 >= size1)
                        {
                                chosengene = (sGene) g.genes.elementAt(j2);
                                j2++;
                                if(p1better)
                                {
                                        skip = true;
                                } //Skip excess from the worse genome
                        }
                        else if(j2 >= size2)
                        {
                                chosengene = (sGene) genes.elementAt(j1);
                                j1++;
                                if(!p1better)
                                {
                                        skip = true;
                                } //Skip excess from the worse genome
                        }
                        else
                        {

                                _p1gene = (sGene) genes.elementAt(j1);
                                _p2gene = (sGene) g.genes.elementAt(j2);

                                p1innov = _p1gene.innovation_num;
                                p2innov = _p2gene.innovation_num;
                                if(p1innov == p2innov)
                                {
                                        if(NeatRoutine.randfloat() < 0.5)
                                        {
                                                chosengene = _p1gene;
                                        }
                                        else
                                        {
                                                chosengene = _p2gene;
                                        }

                                        //If one is disabled, the corresponding gene in the offspring
                                        //will likely be disabled
                                        disable_status = 0;
                                        if((_p1gene.enable == false) || (_p2gene.enable == false))
                                        {
                                                // if only one gene is enabled
                                                if((_p2gene.enable == true) || (_p1gene.enable == true))
                                                {
                                                        disable_status = 2;
                                                }
                                                else // if both genes were disabled
                                                {
                                                        disable_status = 1;
                                                }
                                        }
                                        j1++;
                                        j2++;

                                }
                                else if(p1innov < p2innov)
                                {
                                        chosengene = _p1gene;
                                        j1++;
                                        if(!p1better)
                                        {
                                                skip = true;
                                        }
                                }
                                else if(p2innov < p1innov)
                                {
                                        chosengene = _p2gene;
                                        j2++;
                                        if(p1better)
                                        {
                                                skip = true;
                                        }
                                }
                        }// end chosen gene

                        //
                        //
                        //Check to see if the chosengene conflicts with an already chosen gene
                        //i.e. do they represent the same link
                        //

                        itr_newgenes = newgenes.iterator();

                        while(itr_newgenes.hasNext())
                        {
                                _curgene2 = ((sGene) itr_newgenes.next());

                                if(_curgene2.in_node.node_id == chosengene.in_node.node_id && _curgene2.out_node.node_id == chosengene.out_node.node_id)
                                {
                                        skip = true;
                                        break;
                                }
                                if(_curgene2.in_node.node_id == chosengene.out_node.node_id && _curgene2.out_node.node_id == chosengene.in_node.node_id)
                                {
                                        skip = true;
                                        break;
                                }

                        }

                        //
                        //
                        //
                        if(!skip)
                        {
                                //Now add the chosengene to the baby
                                //Next check for the nodes, add them if not in the baby Genome already
                                inode = chosengene.in_node;
                                onode = chosengene.out_node;

                                //Check for inode in the newnodes list

                                //
                                //Check for inode, onode in the newnodes list
                                //


                                //--------------------------------------------------------------------------------
                                boolean found = false;

                                //
                                // search the inode
                                //
                                for(int ix = 0; ix < newnodes.size(); ix++)
                                {
                                        curnode = (sNode) newnodes.elementAt(ix);
                                        if(curnode.node_id == inode.node_id)
                                        {
                                                found = true;
                                                break;
                                        }

                                }

                                // if exist , point to exitsting version
                                if(found)
                                {
                                        // 50/50 chance of taking either nodes node_count/time_bias_id
                                        if(NeatRoutine.randfloat() < .5)
                                        {
                                                curnode.node_count = inode.node_count;
                                                curnode.time_bias_m_org = inode.time_bias_m_org;
                                        }

                                        new_inode = curnode;
                                }
                                // else create the inode
                                else
                                {
                                        new_inode = new sNode(inode);
                                        //insert in newnodes list
                                        newnodes.add(new_inode);
                                }
                                //
                                // search the onode
                                //
                                found = false;
                                for(int ix = 0; ix < newnodes.size(); ix++)
                                {
                                        curnode = (sNode) newnodes.elementAt(ix);
                                        if(curnode.node_id == onode.node_id)
                                        {
                                                found = true;
                                                break;
                                        }

                                }

                                // if exist , point to exitsting version
                                if(found)
                                {
                                        // 50/50 chance of taking either nodes node_count/time_bias_id
                                        if(NeatRoutine.randfloat() < .5)
                                        {
                                                curnode.node_count = onode.node_count;
                                                curnode.time_bias_m_org = onode.time_bias_m_org;
                                        }

                                        new_onode = curnode;
                                }
                                // else create the onode
                                else
                                {
                                        new_onode = new sNode(onode);
                                        //insert in newnodes list
                                        newnodes.add(new_onode);
                                }

                                //--------------------------------------------------------------------------------


                                //Add the Gene
                                newgene = new sGene(chosengene, new_inode, new_onode);
                                if(disable_status == 1)
                                {
                                        newgene.enable = false;
                                }
                                else if(disable_status == 2)
                                {
                                        cascade_genes.add(newgene);
                                }

                                newgenes.add(newgene);
                        }

                } // end block genome (while)



                new_genome = new sGenome(genomeid, newnodes, newgenes);
                
                new_genome.organize();

                // cascade disabled or reenabled genes
                int count = cascade_genes.size();
                if(disable_all)
                {
                        for(int i = 0; i < count; i++)
                        {
                                new_genome.mutate_cascade_disable((sGene) cascade_genes.elementAt(i), generation);
                        }
                }
                else
                {
                        for(int i = 0; i < count; i++)
                        {
                                new_genome.mutate_cascade_reenable((sGene) cascade_genes.elementAt(i), generation);
                        }
                }

                cascade_genes = null;

                return new_genome;
        }

        /** enable not cascaded yet */
        public sGenome mate_singlepoint(sGenome g, int genomeid)
        {
                sGenome new_genome = null;
                sGene chosengene = null;
                int stopA = 0;
                int stopB = 0;
                int j;
                int j1;
                int j2;
                int size1 = genes.size();
                int size2 = g.genes.size();
                int crosspoint = 0;
                int len_genome = 0;

                double p1innov = 0.0;
                double p2innov = 0.0;

                Iterator itr_newgenes;

                sNode curnode = null;
                sNode inode = null;
                sNode onode = null;
                sNode new_inode = null;
                sNode new_onode = null;
                sGene newgene = null;

                Vector genomeA;
                Vector genomeB;
                sGene geneA = null;
                sGene geneB = null;
                sGene _curgene2 = null;
                int genecounter = 0; //Ready to count to crosspoint
                boolean skip = false; //Default to not skip a Gene

                Vector newgenes = new Vector(genes.size(), 0);
                Vector newnodes = new Vector(nodes.size(), 0);
                
                newnodes.addAll(inputs);
                newnodes.addAll(outputs);                

                if(size1 < size2)
                {
                        crosspoint = NeatRoutine.randint(0, size1 - 1);
                        stopA = size1;
                        stopB = size2;
                        len_genome = size2;
                        genomeA = genes;
                        genomeB = g.genes;
                }
                else
                {
                        crosspoint = NeatRoutine.randint(0, size2 - 1);
                        stopA = size2;
                        stopB = size1;
                        len_genome = size1;
                        genomeA = g.genes;
                        genomeB = genes;
                }

                //System.out.print("\n crossing point is :"+crosspoint);

                genecounter = 0;

                boolean doneA = false;
                boolean doneB = false;
                boolean done = false;
                double v1 = 0.0;
                double v2 = 0.0;
                double cellA = 0.0;
                double cellB = 0.0;

                j1 = 0;
                j2 = 0;
                j = 0;

                //
                // compute what is the hight innovation
                //

                double last_innovB = ((sGene) genomeB.elementAt(stopB - 1)).innovation_num;
                double cross_innov = 0;

                while(!done)
                {

                        doneA = false;
                        doneB = false;
                        skip = false;

                        if(j1 < stopA)
                        {
                                geneA = (sGene) genomeA.elementAt(j1);
                                v1 = geneA.innovation_num;
                                doneA = true;
                        }
                        if(j2 < stopB)
                        {
                                geneB = (sGene) genomeB.elementAt(j2);
                                v2 = geneB.innovation_num;
                                doneB = true;
                        }

                        if(doneA && doneB)
                        {
                                //
                                if(v1 < v2)
                                {
                                        cellA = v1;
                                        cellB = 0.0;
                                        j1++;
                                }
                                else if(v1 == v2)
                                {
                                        cellA = v1;
                                        cellB = v1;
                                        j1++;
                                        j2++;
                                }
                                else
                                {
                                        cellA = 0.0;
                                        cellB = v2;
                                        j2++;
                                }
                        }
                        else
                        {
                                if(doneA && !doneB)
                                {
                                        cellA = v1;
                                        cellB = 0.0;
                                        j1++;
                                }
                                else if(!doneA && doneB)
                                {
                                        cellA = 0.0;
                                        cellB = v2;
                                        j2++;
                                }
                                else
                                {
                                        done = true;
                                }
                        }





                        if(!done)
                        {

                                // -------------------------------------------------------------------------------
                                //                        innovA = innovB
                                // -------------------------------------------------------------------------------

                                if(cellA == cellB)
                                {
                                        if(genecounter < crosspoint)
                                        {
                                                chosengene = geneA;
                                                genecounter++;
                                        }
                                        else if(genecounter == crosspoint)
                                        {
                                                if(NeatRoutine.randfloat() > 0.5)
                                                {
                                                        chosengene = geneA;
                                                }
                                                else
                                                {
                                                        chosengene = geneB;
                                                }

                                                //If one is disabled, the corresponding gene in the offspring
                                                //will likely be disabled

                                                if((geneA.enable == false) || (geneB.enable == false))
                                                {
                                                        chosengene.enable = false;
                                                }

                                                genecounter++;
                                                cross_innov = cellA;
                                        }
                                        else if(genecounter > crosspoint)
                                        {
                                                chosengene = geneB;
                                                genecounter++;
                                        }
                                }
                                // -------------------------------------------------------------------------------
                                //                        innovA < innovB
                                // -------------------------------------------------------------------------------
                                else if(cellA != 0 && cellB == 0)
                                {
                                        if(genecounter < crosspoint)
                                        {
                                                chosengene = geneA; //make geneA
                                                genecounter++;
                                        }
                                        else if(genecounter == crosspoint)
                                        {
                                                chosengene = geneA;
                                                genecounter++;
                                                cross_innov = cellA;
                                        }
                                        else if(genecounter > crosspoint)
                                        {
                                                if(cross_innov > last_innovB)
                                                {
                                                        chosengene = geneA;
                                                        genecounter++;
                                                }
                                                else
                                                {
                                                        skip = true;
                                                }
                                        }
                                }
                                // -------------------------------------------------------------------------------
                                //                        innovA > innovB
                                // -------------------------------------------------------------------------------
                                else
                                {
                                        if(cellA == 0 && cellB != 0)
                                        {
                                                if(genecounter < crosspoint)
                                                {
                                                        skip = true; //skip geneB
                                                }
                                                else if(genecounter == crosspoint)
                                                {
                                                        skip = true; //skip an illogic case
                                                }
                                                else if(genecounter > crosspoint)
                                                {
                                                        if(cross_innov > last_innovB)
                                                        {
                                                                chosengene = geneA; //make geneA
                                                                genecounter++;
                                                        }
                                                        else
                                                        {
                                                                chosengene = geneB; //make geneB : this is a pure case o single crossing
                                                                genecounter++;
                                                        }
                                                }

                                        }
                                }

                                itr_newgenes = newgenes.iterator();

                                while(itr_newgenes.hasNext())
                                {
                                        _curgene2 = ((sGene) itr_newgenes.next());

                                        if(_curgene2.in_node.node_id == chosengene.in_node.node_id && _curgene2.out_node.node_id == chosengene.out_node.node_id)
                                        {
                                                skip = true;
                                                break;
                                        }

                                        if(_curgene2.in_node.node_id == chosengene.out_node.node_id && _curgene2.out_node.node_id == chosengene.in_node.node_id)
                                        {
                                                skip = true;
                                                break;
                                        }

                                } // and else for control of position in gennomeA/B

                                if(!skip)
                                {
                                        //Now add the chosengene to the baby
                                        //check for the nodes, add them if not in the baby Genome already

                                        inode = chosengene.in_node;
                                        onode = chosengene.out_node;

                                        //
                                        //Check for inode, onode in the newnodes list
                                        //
                                        boolean found = false;
                                        //
                                        // search the inode
                                        //
                                        for(int ix = 0; ix < newnodes.size(); ix++)
                                        {
                                                curnode = (sNode) newnodes.elementAt(ix);
                                                if(curnode.node_id == inode.node_id)
                                                {
                                                        found = true;
                                                        break;
                                                }
                                        }
                                        // if exist , point to exitsting version
                                        if(found)
                                        {
                                                new_inode = curnode;
                                        }
                                        // else create the inode
                                        else
                                        {
                                                new_inode = new sNode(inode);
                                                //insert in newnodes list
                                                newnodes.add(new_inode);
                                        }

                                        //
                                        // search the onode
                                        //
                                        found = false;
                                        for(int ix = 0; ix < newnodes.size(); ix++)
                                        {
                                                curnode = (sNode) newnodes.elementAt(ix);
                                                if(curnode.node_id == onode.node_id)
                                                {
                                                        found = true;
                                                        break;
                                                }
                                        }
                                        // if exist , point to exitsting version
                                        if(found)
                                        {
                                                new_onode = curnode;
                                        }
                                        // else create the onode
                                        else
                                        {
                                                new_onode = new sNode(onode);
                                                //insert in newnodes list
                                                newnodes.add(new_onode);
                                        }

                                        //Add the Gene
                                        newgene = new sGene(chosengene, new_inode, new_onode);
                                        newgenes.add(newgene);

                                } // end of block gene creation if !skip

                        }
                        j++;

                }

                new_genome = new sGenome(genomeid, newnodes, newgenes);

                return new_genome;

        }
}

package ModuleNeat;

import java.util.*;
/**
 *
 *
 *
 */
public class sorder_species implements java.util.Comparator
{
        /**
         * order_species constructor comment.
         */
        public sorder_species()
        {
                //super();
        }
        /**
         */
        public int compare(Object o1, Object o2)
        {
                
                sSpecies _sx = (sSpecies) o1;
                sSpecies _sy = (sSpecies) o2;
                
                sOrganism _ox = (sOrganism) _sx.organisms.firstElement();
                sOrganism _oy = (sOrganism) _sy.organisms.firstElement();
                
                if (_ox.orig_fitness < _oy.orig_fitness)
                        return +1;
                if (_ox.orig_fitness > _oy.orig_fitness)
                        return -1;
                return 0;
                
        }
}
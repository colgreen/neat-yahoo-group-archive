
package ModuleNeat;
import java.util.*;
import java.text.*;

/**
 *
 * @author GABA
 */
public class mGene
{
        
        /** is historical marking of node */
        double innovation_num;
        /** the generation this gene was disabled last, if too long ago, the gene will be deleted permanently via major pruning phase*/
        int disable_gen;
        
        /** is a flag: is TRUE the gene is enabled FALSE otherwise. */
        boolean enable;
        /** used for compatibility */
        double mutation_num;
        
        /** is a real value of weight of connection(link) */
        double weight;
        /** is a reference to an input node */
        mNode in_node;
        /** is a reference to a output node; */
        mNode out_node;
        
        /** the generation this gene got created or weight severely changed */
        int modified_gen;        
        
        /** Creates a new module gene from file */
        public mGene(String xline, Vector nodes)
        {
                
                StringTokenizer st;
                String curword;
                st = new StringTokenizer(xline);
                Iterator itr_node;
                
                //skip keyword 'gene'
                curword = st.nextToken();
                
                //Get innovation num
                curword = st.nextToken();
                innovation_num = Double.parseDouble(curword);                
                
                //Get input node
                curword = st.nextToken();
                int inode_num = Integer.parseInt(curword);
                
                //Get output node
                curword = st.nextToken();
                int onode_num = Integer.parseInt(curword);
                
                //Get weight
                curword = st.nextToken();
                weight = Double.parseDouble(curword);
                
                //Get mutation num
                curword = st.nextToken();
                mutation_num = Double.parseDouble(curword);
                
                //Get enable
                curword = st.nextToken();
                enable = Integer.parseInt(curword) == 1 ? true : false;
                
                //Get disable generation
                curword = st.nextToken();
                disable_gen = Integer.parseInt(curword);
                
                //Get modified generation
                curword = st.nextToken();
                modified_gen = Integer.parseInt(curword);                
                
                itr_node = nodes.iterator();
                int fnd = 0;
                while (itr_node.hasNext() && fnd < 2)
                {
                        mNode _node = ((mNode) itr_node.next());
                        
                        if (_node.node_id == inode_num)
                        {
                                in_node = _node;
                                fnd++;
                        }
                        if (_node.node_id == onode_num)
                        {
                                out_node = _node;
                                fnd++;
                        }
                }
        }
        
        /** Deep copy module gene constructor */
        public mGene(mGene g, mNode in, mNode out)
        {
                weight = g.weight;
                in_node = in;
                out_node = out;
                innovation_num = g.innovation_num;
                mutation_num = g.mutation_num;
                enable = g.enable;
                disable_gen = 0;
                modified_gen = g.modified_gen;
        }
        
        /** for mutate add module link constructor */
        public mGene(double w, mNode in, mNode out, double innov_num, double mut_num, int gen)
        {
                weight = w;
                in_node = in;
                out_node = out;
                innovation_num = innov_num;
                mutation_num = mut_num;
                enable = true;
                disable_gen = 0;
                modified_gen = gen;
        }
        
        public void print_to_file(IOseq xFile)
        {
                
                StringBuffer s2 = new StringBuffer("");
                
                s2.append("gene ");
                s2.append(" " + innovation_num);                
                s2.append(" " + in_node.node_id);
                s2.append(" " + out_node.node_id);
                s2.append(" " + weight);
                s2.append(" " + mutation_num);
                
                if (enable)
                        s2.append(" 1");
                else
                        s2.append(" 0");
                
                s2.append(" " + disable_gen);
                s2.append(" " + modified_gen);
                
                xFile.IOseqWrite(s2.toString());
                
        }
        
        
        
}

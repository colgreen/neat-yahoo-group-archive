
package ModuleNeat;

import java.util.*;
import java.lang.reflect.*;
/**
 *
 * @author GABA
 */
public class mNeat
{
        // population size of each module
        public static int delay_pop_size;
        public static int weight_hebb_pop_size;
        public static int time_bias_pop_size;
        
        public static int sys_pop_size;
        
        public static int epoch_ratio_s_m; // system epoch to module epoch ratio, eg. run 5 sys epoch, then run 1 mod epoch
        
        // used for activation of neural network
        // lower bound of leakage constant is 1, so delta_time should usually be 1
        public static double delta_time;
        
        // fitness of a winner, default is 1
        public static double winner_fitness;
        
        
        // Used for speciation of systems
        public static double s_compat_threshold;
        public static double s_disjoint_coeff;
        public static double s_excess_coeff;
        public static double s_mutdiff_coeff;
        public static double s_disjoint_mod_penalty;
        public static double s_node_count_penalty;
        
        
        // System epoch reproduction
        public static int s_babies_stolen; // Take away a constant number of expected offspring from the worst few species
        public static int s_dropoff_age; // age to eliminate counting from last improvement
        public static double s_age_significance; // fitness = fitness * s_age_significance, if 1 not boost for young organisms
        public static double s_survival_thresh;  // num_parents = s_survival_thresh * population size + 1.0
        public static int s_extinction_age; //if after mNeat.s_dropoff_age + mNeat.s_extinction_age, no higher fitness, mass extinction
        
        // used in system firing sequence
        public static int s_input_size;
        public static int s_output_size;
        
        // watch out: disable/enabling happen before other mutations
        public static double s_mutate_fitness_power; // (fitness / winner_fitness)^fitness_power, fit_frac, higher has less chance to get mutation, default 3
        public static double s_mutate_age_factor; // e^(- age_since_mutation / factor), age_frac use to preserve older mutation, default 10 (diable, reenable, module shuffle, node count)
        public static double s_mutate_node_count_prob;
        public static double s_mutate_count_increase_prob; // probability of increasing node count, else decrease node count, (Future: dynamic)
        public static int s_max_node_count; // max node count boundary, min is 1
        public static double s_max_count_pow2; // pow of 2 index for max node count, used to set random node count (eg 10 for 1024 max nodes)
        public static double s_mutate_disabled_struct_prob; // if add link/node, change node count, be done on disabled structures (not module toggle)
        public static double s_mutate_add_link_prob;
        public static double s_mutate_recurrent_toggle_prob;
        public static double s_mutate_recurrent_on_prob; // prob of switching form non-recurrent to recurrent
        public static double s_mutate_recurrent_off_prob; // should be lower than recurrent_on_prob, if time correlation is crucial in inputs
        public static double s_mutate_gene_disable_prob; // probability of disabling a gene
        public static double s_mutate_unsafe_disable_prob; // probability to activate unsafe mode when disabling a gene
        public static double s_mutate_gene_reenable_prob;
        public static double s_mutate_only_prob; // probability of non-mating reproduction
        public static double s_mutate_add_node_prob;
        public static double s_newnode_geneoff_prob; // probability of turning off old gene when a new node is added (default .5)
        public static double s_mutate_time_bias_prob; // Future: high prob immediate after module epoch
        public static double s_mutate_weight_hebb_prob;
        public static double s_mutate_delay_prob;
        
        // system mating
        public static double s_interspecies_mate_rate;
        public static double s_mate_multipoint_prob; // otherwise do mate_singlepoint (NOT USED, because no enable cascade yet), multipoint with cascade should work better
        public static double s_mate_only_prob; // no mutation after mating, (yet, if parents are too compatible, mutation will happen)
        
        
        // used for adjusting parameters after computing them in modules
        public static int max_time_delay;
        public static double max_weight;
        public static double min_weight;
        public static double max_hebb_rate; // hebbian rate and pre rate are currently all positive
        public static double max_pre_rate;
        public static double max_time_constant;
        public static double max_bias; // usually [0, 1]
        
        // used when enabled in rNetwork constructor, links below this weight threshold won't get made
        public static double weight_threshold;
        
        // Used for speciation of modules
        public static double m_t_compat_threshold;
        public static double m_w_compat_threshold;
        public static double m_d_compat_threshold;
        public static double m_disjoint_coeff;
        public static double m_excess_coeff;
        public static double m_mutdiff_coeff;
        public static double m_disjoint_ftype_penalty;
        public static double m_disjoint_sftype_penalty;
        public static double m_disjoint_input_penalty; // if two modules takes completely different inputs, eg. only position 1 vs only bias
        public static double m_weight_penalty; // this factor is multiply to order of magnitude difference of the weights
        
        // Module epoch reproduction
        public static int m_babies_stolen; // Take away a constant number of expected offspring from the worst few species
        public static int m_dropoff_age; // age to eliminate counting from last improvement
        public static double m_age_significance; // fitness = fitness * s_age_significance, if 1 not boost for young organisms
        public static double m_survival_thresh;  // num_parents = s_survival_thresh * population size + 1.0
        public static int m_extinction_age; // if after mNeat.s_dropoff_age + mNeat.s_extinction_age, no higher fitness, mass extinction
        
        // watch out: disable/enabling happen before other mutations
        public static double m_mutate_fitness_power; // (fitness / winner_fitness)^fitness_power, fit_frac, higher has less chance to get mutation, default 3
        public static double m_mutate_age_factor; // e^(- age_since_mutation / epoch_ratio_s_m / factor) is the probability use to preserve older mutation, default 10
        public static double m_max_weight_pow2;
        public static double m_mutate_link_weights_prob;
        public static double m_mutate_disabled_struct_prob; // if add link/node, mutate weight, be done on disabled structures (not function toggle)
        public static double m_mutate_add_link_prob;
        public static double m_mutate_gene_disable_prob; // probability of disabling a gene
        public static double m_mutate_unsafe_disable_prob; // probability to activate unsafe mode when disabling a gene
        public static double m_mutate_gene_reenable_prob;
        public static double m_mutate_only_prob; // probability of non-mating reproduction
        public static double m_mutate_add_node_prob;
        public static double m_newnode_geneoff_prob; // probability of turning off old gene when a new node is added (default .5)
        public static double m_mutate_toggle_ftype; // probability of doing either ftype or sftype mutation
        public static double m_mutate_toggle_sftype; // probability of a sftype mutation, if not ftype mutation
        public static int m_sftype_allowed; // 0: add, 1: multiply, 2: max, 3: min
        public static int m_ftype_allowed; // default is 10 (11 functions)
        
        // module mating
        public static double m_interspecies_mate_rate;
        public static double m_mate_multipoint_prob; // otherwise do mate_singlepoint (NOT USED, because no enable cascade yet), multipoint with cascade should work better
        public static double m_mate_weight_avg_prob; // averaging weights during mate_multipoint (USED: every paired genes. NOT: entire all genes of one mating)
        public static double m_mate_only_prob; // no mutation after mating, (yet, if parents are too compatible, mutation will happen)
        
        
        // other parameter
        public static int e_node_gap; // number of fft input to skip over after creating a real fft node (in 2016 log-sampled fft inputs, with 16 bins every two half step)
        public static int training_cycle; // number of times an organism run through all the data, (good for hebbian learning)
        public static double compat_modifier; // factor that used to dynamnically change compat_threshold
        //
        
        public static void initbase()
        {
                delay_pop_size = 500;
                weight_hebb_pop_size = 500;
                time_bias_pop_size = 500;
                
                sys_pop_size = 500;
                
                epoch_ratio_s_m = 5;
                
                delta_time = 1;
                
                winner_fitness = 1;
                
                s_compat_threshold = .1;
                s_disjoint_coeff = 0;
                s_excess_coeff = 0;
                s_mutdiff_coeff = 0;
                s_disjoint_mod_penalty = 0;
                s_node_count_penalty = 0;
                
                s_babies_stolen = 0;
                s_dropoff_age = 0;
                s_age_significance = 0;
                s_survival_thresh = 0;
                s_extinction_age = 0;
                
                s_input_size = 0;
                s_output_size = 0;
                
                s_mutate_fitness_power = 3;
                s_mutate_age_factor = 5;
                s_mutate_node_count_prob = 0;
                s_mutate_count_increase_prob = .5;
                s_max_node_count = 256;
                s_max_count_pow2 = 8;
                s_mutate_disabled_struct_prob = 0;
                s_mutate_add_link_prob = 0;
                s_mutate_recurrent_toggle_prob = 0;
                s_mutate_recurrent_on_prob = 0;
                s_mutate_recurrent_off_prob = 0;
                s_mutate_gene_disable_prob = 0;
                s_mutate_unsafe_disable_prob = 0;
                s_mutate_gene_reenable_prob = 0;
                s_mutate_only_prob = 0;
                s_mutate_add_node_prob = 0;
                s_newnode_geneoff_prob = .5;
                s_mutate_time_bias_prob = 0;
                s_mutate_weight_hebb_prob = 0;
                s_mutate_delay_prob = 0;
                
                s_interspecies_mate_rate = 0;
                s_mate_multipoint_prob = 1.1;
                s_mate_only_prob = 0;
                
                max_time_delay = 10;
                max_weight = 10;
                min_weight = -10;
                max_hebb_rate = 1;
                max_pre_rate = 1;
                max_time_constant = 10;
                max_bias = 1;
                
                weight_threshold = 0;
                
                m_t_compat_threshold = 1.1;
                m_w_compat_threshold = 1.1;
                m_d_compat_threshold = 1.1;
                m_disjoint_coeff = 0;
                m_excess_coeff = 0;
                m_mutdiff_coeff = 0;
                m_disjoint_ftype_penalty = 0;
                m_disjoint_sftype_penalty = 0;
                m_disjoint_input_penalty = 0;
                m_weight_penalty = 1;
                
                m_babies_stolen = 0;
                m_dropoff_age = 0;
                m_age_significance = 0;
                m_survival_thresh = 0;
                m_extinction_age = 0;
                
                m_mutate_fitness_power = 3;
                m_mutate_age_factor = 5;
                m_max_weight_pow2 = 10;
                m_mutate_link_weights_prob = 0;
                m_mutate_disabled_struct_prob = 0;
                m_mutate_add_link_prob = 0;
                m_mutate_gene_disable_prob = 0;
                m_mutate_unsafe_disable_prob = 0;
                m_mutate_gene_reenable_prob = 0;
                m_mutate_only_prob = 0;
                m_mutate_add_node_prob = 0;
                m_newnode_geneoff_prob = .5;
                m_mutate_toggle_ftype = 0;
                m_mutate_toggle_sftype = 0;
                m_sftype_allowed = 1;
                m_ftype_allowed = 10;
                
                m_interspecies_mate_rate = 0;
                m_mate_multipoint_prob = 0;
                m_mate_weight_avg_prob = .5;
                m_mate_only_prob = 0;
                
                e_node_gap = 1;
                training_cycle = 1;
                compat_modifier = .1;
        }
        
        public static void writeParam(String xNameFile)
        {
                //
                // write to file xpar all parameters.....
                //
                IOseq xFile;
                
                xFile = new IOseq(xNameFile);
                xFile.IOseqOpenW(false);
                
                try
                {
                        
                        Class c = Class.forName("ModuleNeat.mNeat");
                        Field[] fieldlist = c.getDeclaredFields();
                        
                        int number_params = fieldlist.length;
                        for (int i = 0; i < number_params; i++)
                        {
                                Field f1 = fieldlist[i];
                                String x1 = f1.getName();
                                
                                Object s1 = f1.get(c);
                                
                                String riga = x1 + "  " + s1;
                                xFile.IOseqWrite(riga);
                        }
                        
                }
                catch (Throwable e)
                {
                        System.err.println(e);
                }
                
                xFile.IOseqCloseW();
                
        }
        
        public static boolean readParam(String xNomeFile)
        {
                
                boolean ret = true;
                String xline;
                IOseq xFile;
                StringTokenizer st;
                String s1;
                String s2;
                Object m1;
                
                xFile = new IOseq(xNomeFile);
                ret = xFile.IOseqOpenR();
                if (ret)
                        
                        
                {
                        try
                        {
                                Class c = Class.forName("ModuleNeat.mNeat");
                                Field[] fieldlist = c.getDeclaredFields();
                                
                                int number_params = fieldlist.length;
                                
                                for (int i = 0; i < number_params; i++)
                                {
                                        Field f1 = fieldlist[i];
                                        String x1 = f1.getName();
                                        Object x2 = f1.getType();
                                        xline = xFile.IOseqRead();
                                        
                                        st = new StringTokenizer(xline);
                                        //skip comment
                                        
                                        s1 = st.nextToken();
                                        // real value
                                        s1 = st.nextToken();
                                        
                                        if (x2.toString().equals("double"))
                                        {
                                                double n1 = Double.parseDouble(s1);
                                                f1.set(c, (new Double(n1)));
                                        }
                                        if (x2.toString().equals("int"))
                                        {
                                                int n1 = Integer.parseInt(s1);
                                                f1.set(c, (new Integer(n1)));
                                        }
                                }
                                
                        }
                        catch (Throwable e)
                        {
                                System.err.println(e);
                        }
                        
                        xFile.IOseqCloseR();
                        
                }
                
                
                else
                        System.err.print("\n : error during open " + xNomeFile);
                
                
                
                return ret;
        }
        
}

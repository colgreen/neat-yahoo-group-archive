
package ModuleNeat;

import java.util.*;
import java.text.*;

/**
 *
 * @author GABA
 */
public class sOrganism
{

        /** The time tis organism took to evaluate all of the data */
        //       double run_time;
        /** A measure of fitness for the Organism */
        double fitness;
        /** A fitness measure that won't change during adjustments */
        double orig_fitness;
        /** Used just for reporting purposes */
        double error;
        /** Win marker (if needed for a particular task) */
        public boolean winner;
        /** The Organism's genotype */
        public sGenome genome;
        /** The Organism's Species */
        sSpecies species;
        /** Number of children this Organism may have */
        double expected_offspring;
        /** Tells which generation this Organism is from */
        int generation;
        /** Marker for destruction of inferior Organisms */
        boolean eliminate;
        /** Marks the species champ */
        boolean champion;
        /** Number of reserved offspring for a population leader */
        int super_champ_offspring;
        /** Marks the best in population */
        boolean pop_champ;
        /** Marks the duplicate child of a champion (for tracking purposes) */
        boolean pop_champ_child;
        /** DEBUG variable- high fitness of champ */
        double high_fit;
        /** has a change in a structure of baby ? */
        boolean mut_struct_baby;
        /** has a mating  in  baby ? */
        boolean mate_baby;

        /** Creates a new instance of  system Organism */
        public sOrganism(double xfitness, sGenome xgenome, int xgeneration)
        {
                fitness = xfitness;
                orig_fitness = xfitness;
                genome = xgenome;
                species = null;
                expected_offspring = 0;
                generation = xgeneration;
                eliminate = false;
                error = 0;
                winner = false;
                champion = false;
                super_champ_offspring = 0;
                pop_champ = false;
                pop_champ_child = false;
                high_fit = 0;
                mut_struct_baby = false;
                mate_baby = false;
        }

        /** distribute system fitness (and winner flag) to module fitness,
         * eventually each module gets fitness only from the most succesful system organism
         */
        public void distribute_fitness(boolean win, int gen)
        {
                mOrganism _org;
                Vector _vect = genome.com_nodes;
                int i;
                int v_size = _vect.size();

                for(i = 0; i < v_size; i++)
                {
                        _org = ((sNode) _vect.elementAt(i)).time_bias_m_org;

                        if(win)
                        {
                                _org.winner = true;
                        }

                        if(fitness > _org.fitness)
                        {
                                _org.fitness = fitness;
                        }

                        if(gen > _org.genome.last_used_gen)
                        {
                                _org.genome.last_used_gen = gen;
                        }
                }

                _vect = genome.com_genes;
                v_size = _vect.size();

                for(i = 0; i < v_size; i++)
                {
                        sGene _gene = (sGene) _vect.elementAt(i);
                        _org = _gene.weight_hebb_m_org;

                        if(win)
                        {
                                _org.winner = true;
                        }

                        if(fitness > _org.fitness)
                        {
                                _org.fitness = fitness;
                        }

                        if(gen > _org.genome.last_used_gen)
                        {
                                _org.genome.last_used_gen = gen;
                        }


                        if(_gene.recurrent)
                        {
                                _org = _gene.delay_m_org;

                                if(win)
                                {
                                        _org.winner = true;
                                }

                                if(fitness > _org.fitness)
                                {
                                        _org.fitness = fitness;
                                }

                                if(gen > _org.genome.last_used_gen)
                                {
                                        _org.genome.last_used_gen = gen;
                                }
                        }
                }


        }

        public void print_winner(int gen)
        {
                String mask6 = "0000";
                DecimalFormat fmt6 = new DecimalFormat(mask6);
                int fit = (int) (fitness * 100 + .5);
                genome.print_to_filename("winners\\s_" + gen + "_" + fmt6.format(genome.genome_id) + "_" + fmt6.format(fit) + ".txt");

                int n_size = genome.nodes.size();
                for(int n = 0; n < n_size; n++)
                {
                        sNode _node = (sNode) genome.nodes.elementAt(n);
                        _node.time_bias_m_org.genome.print_to_filename("winners\\t_" + gen + "_" + fmt6.format(_node.time_bias_m_org.genome.genome_id) + "_" + fmt6.format(fit) + ".txt");
                }

                n_size = genome.genes.size();
                for(int n = 0; n < n_size; n++)
                {
                        sGene _gene = (sGene) genome.genes.elementAt(n);
                        _gene.weight_hebb_m_org.genome.print_to_filename("winners\\w_" + gen + "_" + fmt6.format(_gene.weight_hebb_m_org.genome.genome_id) + "_" + fmt6.format(fit) + ".txt");
                        if(_gene.recurrent)
                        {
                                _gene.delay_m_org.genome.print_to_filename("winners\\d_" + gen + "_" + fmt6.format(_gene.delay_m_org.genome.genome_id) + "_" + fmt6.format(fit) + ".txt");
                        }
                }
        }

        public void viewtext()
        {
                System.out.print("\n-ORGANISM -[genomew_id=" + genome.genome_id + "]");
                System.out.print(" Champ(" + champion + ")");
                System.out.print(", fit=" + fitness);
                System.out.print(", Elim=" + eliminate);
                System.out.print(", offspring=" + expected_offspring);

        }
}


package ModuleNeat;

import java.util.*;
import java.text.*;

/**
 *
 * @author GABA
 */
public class mGenome
{

        /** Numeric identification for this genotype */
        public int genome_id;
        /** the last generation this module was used */
        int last_used_gen;
        /**
         * Each Gene in (3) has a marker telling when it arose historically;
         * Thus, these Genes can be used to speciate the population, and
         * the list of Genes provide an evolutionary history of innovation and link-building
         */
        Vector genes; // master list
        /** Is a collection of all nodes mapped in a Vector; */
        Vector nodes; // master list
        /** note are two String for store statistics information
         * when genomes are readed (if exist : null otherwise);*/
        public String notes;
        /** Is a collection of input, output, island nodes and bias node mapped in a Vector; */
        Vector inputs;
        Vector outputs;
        /** nodes that has all incoming and outgoing genes disabled
         * is zero if always use safe gene disabling (mNeat.m_mutate_unsafe_disable_prob = 0)
         */
        Vector island_nodes;
        /** Is a collection of nodes that computes signals are not in inputs or island nodes
         * is all non-inputs if always use safe gene disabling (mNeat.m_mutate_unsafe_disable_prob = 0)
         */
        Vector com_nodes;
        /** a collection of enabled/disabled genes */
        Vector com_genes;
        Vector dis_genes;

        /** Creates a new module genome from a file of previous module populaiton */
        public mGenome(int id, IOseq xFile)
        {

                StringTokenizer st;
                String curword;
                String xline;
                boolean done = false;
                //   	notes = null;

                genome_id = id;

                //	System.out.print("\n genome id current is "+ genome_id);

                nodes = new Vector(3, 0);
                genes = new Vector(3, 0);


                while(!done)
                {
                        xline = xFile.IOseqRead();
                        st = new StringTokenizer(xline);

                        curword = st.nextToken();
                        if(curword.equalsIgnoreCase("modgenomeend"))
                        {
                                curword = st.nextToken();
                                if(Integer.parseInt(curword) != genome_id)
                                {
                                        System.out.println(" *ERROR* id mismatch in genome");
                                }
                                done = true;
                        }
                        else if(curword.equals("/*"))
                        {
                                curword = st.nextToken();
                                while(!curword.equals("*/"))
                                {
                                        curword = st.nextToken();
                                }
                        }
                        else if(curword.equals("last_used_gen"))
                        {
                                //Get input node
                                curword = st.nextToken();
                                last_used_gen = Integer.parseInt(curword);
                        }
                        else if(curword.equals("node"))
                        {
                                mNode newnode;
                                newnode = new mNode(xline);
                                nodes.addElement(newnode);
                        }
                        else if(curword.equals("gene"))
                        {
                                mGene newgene;
                                newgene = new mGene(xline, nodes);
                                genes.addElement(newgene);
                        }

                }

        }

        /** Deep copy module genome constructor */
        public mGenome(int id, Vector n, Vector g)
        {
                genome_id = id;
                nodes = n;
                genes = g;
                last_used_gen = 0;
        }

        /**
         *     This function gives a measure of compatibility between
         *     two Genomes by computing a linear combination of 3
         *     characterizing variables of their compatibilty.
         *     The 3 variables represent PERCENT DISJOINT GENES,
         *     PERCENT EXCESS GENES, MUTATIONAL DIFFERENCE WITHIN
         *     MATCHING GENES.  So the formula for compatibility
         *     is:  disjoint_coeff*pdg+excess_coeff*peg+mutdiff_coeff*mdmg.
         *     The 3 coefficients are global system parameters
         */
        public double compatibility(mGenome g)
        {

                //Innovation numbers
                double p1innov;
                double p2innov;

                //Intermediate value
                double mut_diff;

                //Set up the counters
                double num_disjoint = 0.0;
                double num_excess = 0.0;
                double mut_diff_total = 0.0;
                double num_matching = 0.0; //Used to normalize mutation_num differences

                int in_size = inputs.size();
                for(int in1 = 0; in1 < in_size; in1++)
                {
                        mNode _node1 = (mNode) inputs.elementAt(in1);
                        // find the same input in the other module
                        for(int in2 = 0; in2 < in_size; in2++)
                        {
                                mNode _node2 = (mNode) g.inputs.elementAt(in2);
                                if(_node2.node_id == _node1.node_id)
                                {
                                        // if one module uses this input, and the other doesn't
                                        if((_node2.outgoing_on.size() == 0 && _node1.outgoing_on.size() != 0) || (_node2.outgoing_on.size() != 0 && _node1.outgoing_on.size() == 0))
                                        {
                                                num_disjoint += mNeat.m_disjoint_input_penalty;
                                        }
                                        break;
                                }
                        }
                }

                mGene _gene1 = null;
                mGene _gene2 = null;

                double max_genome_size; //Size of larger Genome

                //Get the length of the longest Genome for percentage computations
                int size1 = genes.size();
                int size2 = g.genes.size();
                max_genome_size = Math.max(size1, size2);
                //Now move through the Genes of each potential parent
                //until both Genomes end
                int j = 0;
                int j1 = 0;
                int j2 = 0;

                for(j = 0; j < max_genome_size; j++)
                {

                        if(j1 >= size1)
                        {
                                num_excess += 1.0;
                                j2++;
                        }
                        else if(j2 >= size2)
                        {
                                num_excess += 1.0;
                                j1++;
                        }
                        else
                        {
                                _gene1 = (mGene) genes.elementAt(j1);
                                _gene2 = (mGene) g.genes.elementAt(j2);

                                //Extract current innovation numbers
                                p1innov = _gene1.innovation_num;
                                p2innov = _gene2.innovation_num;

                                if(p1innov == p2innov)
                                {
                                        num_matching += 1.0;
                                        // larger order magnitude differece are less related
                                        double w1 = Math.max(_gene1.weight, _gene2.weight);
                                        double w2 = Math.min(_gene1.weight, _gene2.weight);
                                        
                                        if( (w1 - w2) < 0.000003)
                                        {
                                                mut_diff = 0;
                                        }
                                        else if(w1*w2 <= 0)
                                        {
                                                mut_diff = 2 * mNeat.m_weight_penalty;
                                        }
                                        else
                                        {
                                                mut_diff = (w1 / w2) / (mNeat.m_max_weight_pow2 * 2) * mNeat.m_weight_penalty;
                                        }
                                        
                                        // penalize if in_node functions are mis-matched
                                        if(_gene1.in_node.type > 1)
                                        {
                                                if(_gene1.in_node.ftype != _gene2.in_node.ftype)
                                                {
                                                        mut_diff += mNeat.m_disjoint_ftype_penalty;
                                                }
                                                if(_gene1.in_node.sftype != _gene2.in_node.sftype)
                                                {
                                                        mut_diff += mNeat.m_disjoint_sftype_penalty;
                                                }
                                        }

                                        // penalize if out_node functions are mis-matched
                                        if(_gene1.out_node.ftype != _gene2.out_node.ftype)
                                        {
                                                mut_diff += mNeat.m_disjoint_ftype_penalty;
                                        }
                                        if(_gene1.out_node.sftype != _gene2.out_node.sftype)
                                        {
                                                mut_diff += mNeat.m_disjoint_sftype_penalty;
                                        }

                                        mut_diff_total += mut_diff;
                                        j1++;
                                        j2++;
                                }
                                else if(p1innov < p2innov)
                                {
                                        j1++;
                                        num_disjoint += 1.0;
                                }
                                else if(p2innov < p1innov)
                                {
                                        j2++;
                                        num_disjoint += 1.0;
                                }

                        }

                }

                // Return the compatibility number using compatibility formula
                // Note that mut_diff_total/num_matching gives the AVERAGE
                // difference between mutation_nums for any two matching Genes
                // in the Genome.
                // Look at disjointedness and excess in the absolute (ignoring size)

                return (mNeat.m_disjoint_coeff * (num_disjoint / 1.0) + mNeat.m_excess_coeff * (num_excess / 1.0) + mNeat.m_mutdiff_coeff * (mut_diff_total / num_matching));

        }

        public double get_last_gene_innovnum()
        {
                return (((mGene) genes.lastElement()).innovation_num + 1);
        }

        public int get_last_node_id()
        {
                return (((mNode) nodes.lastElement()).node_id + 1);
        }

        public void print_to_file(IOseq xFile)
        {
                //
                // write to file genome in native format (for re-read)
                //


                String riga = "modgenomestart  " + genome_id;
                xFile.IOseqWrite(riga);

                riga = "last_used_gen " + last_used_gen;
                xFile.IOseqWrite(riga);

                Iterator itr_node = nodes.iterator();
                itr_node = nodes.iterator();

                while(itr_node.hasNext())
                {
                        mNode _node = ((mNode) itr_node.next());
                        _node.print_to_file(xFile);
                }

                Iterator itr_gene = genes.iterator();
                itr_gene = genes.iterator();

                while(itr_gene.hasNext())
                {
                        mGene _gene = ((mGene) itr_gene.next());
                        _gene.print_to_file(xFile);
                }

                riga = "modgenomeend " + genome_id;
                xFile.IOseqWrite(riga);


        }

        public void print_to_filename(String xNameFile)
        {
                //
                // write to file genome in native format (for re-read)
                //
                IOseq xFile;


                xFile = new IOseq(xNameFile);
                xFile.IOseqOpenW(false);

                try
                {

                        print_to_file(xFile);

                }
                catch(Throwable e)
                {
                        System.err.println(e);
                }

                xFile.IOseqCloseW();


        }

        public mGenome duplicate(int new_id)
        {
                mNode newnode = null;
                mNode inode = null;
                mNode onode = null;
                mGene newgene = null;
                mGenome newgenome = null;

                Vector nodes_dup = new Vector(nodes.size(), 0);
                Vector genes_dup = new Vector(genes.size(), 0);

                Iterator itr_node = nodes.iterator();
                Iterator itr_gene = genes.iterator();


                /**
                 * duplicate NNodes
                 */
                while(itr_node.hasNext())
                {
                        mNode _node = ((mNode) itr_node.next());
                        newnode = new mNode(_node);

                        _node.dup = newnode;
                        nodes_dup.add(newnode);
                }

                /**
                 * duplicate Genes
                 */
                while(itr_gene.hasNext())
                {

                        mGene _gene = ((mGene) itr_gene.next());

                        // point to news nodes created  at precedent step
                        inode = _gene.in_node.dup;
                        onode = _gene.out_node.dup;

                        // creation of new gene with a pointer to new node
                        newgene = new mGene(_gene, inode, onode);
                        genes_dup.add(newgene);
                }
                // okay all nodes created, the new genome can be generate
                newgenome = new mGenome(new_id, nodes_dup, genes_dup);

                // reset temporary reference for garbage collection
                itr_node = nodes.iterator();
                while(itr_node.hasNext())
                {
                        ((mNode) itr_node.next()).dup = null;
                }

                return newgenome;
        }
   
        

        /** re-arrange nodes in order of firing sequence,
         * this is done after new module is reproduced,
         * so that disconnected modules are deleted */
        public boolean firing_sequence(int m_type, int gen)
        {
                mNode _node;
                mGene _gene;
                
                boolean good = true;

                // create a list of incoming and outgoing links for each node, and dis-abled genes

                com_genes = new Vector(genes.size() >> 1, 0);
                dis_genes = new Vector(genes.size() >> 1, 0);
                int i;
                int v_size;
                int j;
                int j_size;
                Vector v_incoming = new Vector(5, 0);

                // reset all incoming outgoing Vectors
                int n_size = nodes.size();
                for(i = 0; i < n_size; i++)
                {
                        _node = (mNode) nodes.elementAt(i);
                        _node.incoming_on = new Vector(3, 0);
                        _node.outgoing_on = new Vector(3, 0);
                        _node.incoming_off = new Vector(3, 0);
                        _node.outgoing_off = new Vector(3, 0);
                }

                v_size = genes.size();
                for(i = 0; i < v_size; i++)
                {
                        _gene = (mGene) genes.elementAt(i);

                        if(_gene.enable)
                        {
                                com_genes.add(_gene);
                                _gene.out_node.incoming_on.add(_gene);
                                _gene.in_node.outgoing_on.add(_gene);
                        }
                        else
                        {
                                dis_genes.add(_gene);
                                _gene.out_node.incoming_off.add(_gene);
                                _gene.in_node.outgoing_off.add(_gene);
                        }
                }

                //place all input layers first in order, remove input, island nodes from sorting
                //and inputs to inputs vectors, outputs to outputs vector, un-used nodes to island_node
                inputs = new Vector(3, 0);
                outputs = new Vector(4, 0);
                com_nodes = new Vector(n_size, 0);
                island_nodes = new Vector(n_size >> 1, 0);

                for(i = 0; i < n_size; i++)
                {
                        _node = (mNode) nodes.elementAt(i);
                        if(_node.type == 1 || _node.type == 0)
                        {
                                //_node.order_num = 1;
                                inputs.add(_node);
                        }
                        else if(_node.type == 2)
                        {
                                //_node.order_num = 0;
                                outputs.add(_node);
                                com_nodes.add(_node);
                        }
                        else if(_node.type == 3)
                        {
                                //_node.order_num = 0;
                                if(_node.incoming_on.size() != 0 && _node.outgoing_on.size() != 0)
                                {
                                        com_nodes.add(_node);
                                }
                                else
                                {
                                        island_nodes.add(_node);
                                }
                        }
                // for debugging
                /**
                 * System.out.println(_node.node_id);
                 * System.out.println(_node.incoming_on.size());
                 * System.out.println(_node.incoming_off.size());
                 * System.out.println(_node.outgoing_on.size());
                 * System.out.println(_node.outgoing_off.size());
                 */
                }
                // com_nodes has non-input non-island nodes


                // check input output nodes numbers for differnt module type
                boolean ok = true;
                if(m_type == NeatRoutine.TIME_BIAS)
                {
                        if(inputs.size() != 2)
                        {
                                ok = false;
                        }
                        if(outputs.size() != 2)
                        {
                                ok = false;
                        }
                }
                else if(m_type == NeatRoutine.WEIGHT_HEBB)
                {
                        if(inputs.size() != 3)
                        {
                                ok = false;
                        }
                        if(outputs.size() != 4)
                        {
                                ok = false;
                        }
                }
                else if(m_type == NeatRoutine.DELAY)
                {
                        if(inputs.size() != 3)
                        {
                                ok = false;
                        }
                        if(outputs.size() != 1)
                        {
                                ok = false;
                        }
                }

                if(!ok)
                {
                        System.out.println("Type " + m_type + " module " + genome_id + " missing inputs or outputs");
                        return false;
                }

                // for debugging
                // System.out.println("Mod_type " + m_type + " Genome " + genome_id + " island_nodes size: " + island_nodes.size());

                nodes = new Vector(n_size, 0);
                nodes.addAll(inputs); // place input layers first in order

                // order other layers depending on if all of its incoming signal come from already ordered layers
                boolean disconnect = false;
                boolean once = true; // at least one node has all incoming nodes from already ordered nodes
                while(once)
                {
                        once = false;

                        // find the next order node from the remaining nodes
                        v_size = com_nodes.size();
                        for(i = 0; i < v_size; i++)
                        {
                                _node = (mNode) com_nodes.elementAt(i);
                                disconnect = false;

                                // for every incoming gene, check if it's connected to already ordered (neworder) nodes
                                v_incoming = _node.incoming_on;
                                j_size = v_incoming.size();

                                for(j = 0; j < j_size; j++)
                                {
                                        _gene = (mGene) v_incoming.elementAt(j);

                                        if(!nodes.contains(_gene.in_node))
                                        {
                                                disconnect = true;
                                                break;
                                        }
                                /*else
                                {
                                // take the highest in_node order_num plus one;
                                if(_gene.in_node.order_num >= _node.order_num)
                                {
                                _node.order_num = _gene.in_node.order_num + 1;
                                }
                                }*/
                                }

                                // if all incoming genes are from already ordered nodes, move this node into neworder
                                if(!disconnect)
                                {
                                        nodes.add(_node);
                                        com_nodes.remove(_node);
                                        once = true;
                                        break;
                                }
                        }
                }// finish ordering

                // for debugging
                //System.out.println("Mod_type " + m_type + " Genome " + genome_id + " com_nodes size after ordering: " + v_size);

                for(i = 0; i < v_size; i++)
                {
                        _node = (mNode) com_nodes.elementAt(i);
                        if(_node.type == 2)
                        {
                                System.out.println("Type " + m_type + " module " + genome_id + " won't reach outputs (maybe infitite loop)");
                                good = false;
                                break;
                        }
                }

                island_nodes.addAll(com_nodes); // add the remaining disconnected nodes

                v_size = island_nodes.size();
                for(i = 0; i < v_size; i++)
                {
                        _node = (mNode) island_nodes.elementAt(i);
                        if(_node.incoming_on.size() != 0)
                        {
                                j_size = _node.incoming_on.size();
                                for(j =0; j < j_size; j++)
                                {
                                        _gene = (mGene) _node.incoming_on.elementAt(j);
                                        _gene.enable = false;
                                        _gene.disable_gen = gen;
                                }
                                
                                _node.incoming_off.addAll(_node.incoming_on);
                                dis_genes.addAll(_node.incoming_on);
                                com_genes.removeAll(_node.incoming_on);
                                _node.incoming_on.clear();
                        }

                        if(_node.outgoing_on.size() != 0)
                        {
                                j_size = _node.outgoing_on.size();
                                for(j =0; j < j_size; j++)
                                {
                                        _gene = (mGene) _node.outgoing_on.elementAt(j);
                                        _gene.enable = false;
                                        _gene.disable_gen = gen;
                                }
                                
                                _node.outgoing_off.addAll(_node.outgoing_on);
                                dis_genes.addAll(_node.outgoing_on);
                                com_genes.removeAll(_node.outgoing_on);
                                _node.outgoing_on.clear();
                        }
                }

                com_nodes = new Vector(nodes.size(), 0);
                com_nodes.addAll(nodes);

                for(int k = 0; k < inputs.size(); k++) // take out the inputs, now have computing nodes and outputs
                {
                        com_nodes.removeElementAt(0);
                }

                nodes.addAll(island_nodes);

                return good;

        }
        
        /* used for mating */
        public void organize()
        {
                mNode _node;
                mGene _gene;

                // create a list of incoming and outgoing links for each node, and dis-abled genes

                com_genes = new Vector(genes.size() >> 1, 0);
                dis_genes = new Vector(genes.size() >> 1, 0);
                
                int i;
                int v_size;

                // reset all incoming outgoing Vectors
                int n_size = nodes.size();
                for(i = 0; i < n_size; i++)
                {
                        _node = (mNode) nodes.elementAt(i);
                        _node.incoming_on = new Vector(3, 0);
                        _node.outgoing_on = new Vector(3, 0);
                        _node.incoming_off = new Vector(3, 0);
                        _node.outgoing_off = new Vector(3, 0);
                }

                v_size = genes.size();
                for(i = 0; i < v_size; i++)
                {
                        _gene = (mGene) genes.elementAt(i);

                        if(_gene.enable)
                        {
                                com_genes.add(_gene);
                                _gene.out_node.incoming_on.add(_gene);
                                _gene.in_node.outgoing_on.add(_gene);
                        }
                        else
                        {
                                dis_genes.add(_gene);
                                _gene.out_node.incoming_off.add(_gene);
                                _gene.in_node.outgoing_off.add(_gene);
                        }
                }

                inputs = new Vector(3, 0);
                outputs = new Vector(4, 0);
                com_nodes = new Vector(n_size, 0);
                island_nodes = new Vector(n_size >> 1, 0);

                for(i = 0; i < n_size; i++)
                {
                        _node = (mNode) nodes.elementAt(i);
                        if(_node.type == 1 || _node.type == 0)
                        {
                                inputs.add(_node);
                        }
                        else if(_node.type == 2)
                        {
                                outputs.add(_node);
                                com_nodes.add(_node);
                        }
                        else if(_node.type == 3)
                        {
                                if(_node.incoming_on.size() != 0 && _node.outgoing_on.size() != 0)
                                {
                                        com_nodes.add(_node);
                                }
                                else
                                {
                                        island_nodes.add(_node);
                                }
                        }
                }                
        }        
        
        

        /** compute the node's parameters according to the node's position */
        public synchronized Vector compute_module(double[] position)
        {

                Iterator itr_node;
                Iterator itr_gene;
                double add_amount = 0.0;

                //load input and bias nodes
                itr_node = inputs.iterator();
                while(itr_node.hasNext())
                {
                        mNode _node = (mNode) itr_node.next();
                        if(_node.type == 0 && _node.node_id == 1)
                        {
                                _node.activation = 1.0;
                        }
                        else if(_node.type == 1)
                        {
                                if(_node.node_id == 2)
                                {
                                        _node.activation = position[0];
                                }
                                else if(_node.node_id == 3)
                                {
                                        _node.activation = position[1];
                                }
                        }
                }

                //activate all nodes and compute output
                itr_node = com_nodes.iterator();
                while(itr_node.hasNext())
                {
                        mNode _node = (mNode) itr_node.next();

                        //compute signal sum to the node
                        itr_gene = _node.incoming_on.iterator();
                        if(_node.sftype == 0)
                        {
                                while(itr_gene.hasNext())
                                {
                                        mGene _gene = ((mGene) itr_gene.next());
                                        add_amount = _gene.weight * _gene.in_node.activation;
                                        _node.activesum += add_amount;
                                }
                        }
                        //multiplying link signals
                        else if(_node.sftype == 1)
                        {
                                while(itr_gene.hasNext())
                                {
                                        mGene _gene = ((mGene) itr_gene.next());
                                        add_amount = _gene.weight * _gene.in_node.activation;
                                        _node.activesum *= add_amount;
                                }
                        }
                        //maximum link signal
                        else if(_node.sftype == 2)
                        {
                                while(itr_gene.hasNext())
                                {
                                        mGene _gene = ((mGene) itr_gene.next());
                                        add_amount = _gene.weight * _gene.in_node.activation;
                                        if(_node.activesum < add_amount)
                                        {
                                                _node.activesum = add_amount;
                                        }
                                }
                        }
                        //minimum link signal
                        else if(_node.sftype == 3)
                        {
                                mGene first = ((mGene) itr_gene.next());
                                _node.activesum = first.weight * first.in_node.activation;
                                while(itr_gene.hasNext())
                                {
                                        mGene _gene = ((mGene) itr_gene.next());
                                        add_amount = _gene.weight * _gene.in_node.activation;
                                        if(_node.activesum > add_amount)
                                        {
                                                _node.activesum = add_amount;
                                        }
                                }
                        }

                        if(_node.activesum != _node.activesum)
                        {
                                _node.activesum = 0;
                        }
                        else if(_node.activesum > 100000000)
                        {
                                _node.activesum = 100000000;
                        }
                        else if(_node.activesum < -100000000)
                        {
                                _node.activesum = -100000000;
                        }

                        //activate the node
                        //linear activation
                        if(_node.ftype == 0)
                        {
                                _node.activation = _node.activesum;
                        }
                        //sigmoid activation
                        if(_node.ftype == 1)
                        {
                                _node.activation = 1 / (1 + Math.exp(-(_node.activesum)));
                        }
                        //gaussian activation
                        else if(_node.ftype == 2)
                        {
                                _node.activation = Math.exp(-(_node.activesum) * (_node.activesum));
                        }
                        //sine activation
                        else if(_node.ftype == 3)
                        {
                                _node.activation = Math.sin(_node.activesum);
                        }
                        //cosine activation
                        else if(_node.ftype == 4)
                        {
                                _node.activation = Math.cos(_node.activesum);
                        }
                        //square
                        else if(_node.ftype == 5)
                        {
                                _node.activation = (_node.activesum) * (_node.activesum);
                        }
                        //square root (negative sign preserved, even) activation
                        else if(_node.ftype == 6)
                        {
                                if(_node.activesum < 0)
                                {
                                        _node.activation = Math.sqrt(-_node.activesum);
                                }
                                else
                                {
                                        _node.activation = Math.sqrt(_node.activesum);
                                }
                        }
                        //exponential activation
                        else if(_node.ftype == 7)
                        {
                                _node.activation = Math.exp(_node.activesum);
                        }
                        //log (negative sign preserved, even) activation
                        else if(_node.ftype == 8)
                        {
                                if(_node.activesum < 0.0000000001 && _node.activesum > -0.0000000001)
                                {
                                        _node.activation = -10;
                                }
                                else if(_node.activesum < 0)
                                {
                                        _node.activation = Math.log(-_node.activesum);
                                }
                                else
                                {
                                        _node.activation = Math.log(_node.activesum);
                                }
                        }
                        //inverse activation
                        else if(_node.ftype == 9)
                        {
                                if(_node.activesum < 0.00000001 && _node.activesum >= 0)
                                {
                                        _node.activation = 100000000;
                                }
                                else if(_node.activesum > -0.00000001 && _node.activesum <= 0)
                                {
                                        _node.activation = -100000000;
                                }
                                else
                                {
                                        _node.activation = 1 / (_node.activesum);
                                }
                        }
                        //absolute value activation
                        else if(_node.ftype == 10)
                        {
                                _node.activation = Math.abs(_node.activesum);
                        }

                }

                return outputs;
        }

        public void mutate_link_weight(int gen)
        {
                double age_frac;
                double frac;
                double factor = mNeat.epoch_ratio_s_m * mNeat.m_mutate_age_factor;
                mGene _gene;

                // mutate all genes or only enabled genes
                Iterator itr_gene;
                if(NeatRoutine.randfloat() < mNeat.m_mutate_disabled_struct_prob)
                {
                        itr_gene = genes.iterator();
                }
                else
                {
                        itr_gene = com_genes.iterator();
                }

                while(itr_gene.hasNext())
                {

                        _gene = ((mGene) itr_gene.next());
                        age_frac = Math.exp((_gene.modified_gen - gen) / factor);

                        // young genes are more likely to have their weight set to random orders of magnitude
                        if(NeatRoutine.randfloat() < age_frac)
                        {
                                _gene.weight = NeatRoutine.randposneg() * Math.pow(2, NeatRoutine.randposneg()* NeatRoutine.randfloat() * mNeat.m_max_weight_pow2 - 7);
                                _gene.modified_gen = gen; // severe modification record is set
                        }
                        else
                        {
                                // increase node count or decrease node count, within original node count's order of magnitude
                                frac = NeatRoutine.randfloat() * age_frac;
                                if(NeatRoutine.randfloat() < mNeat.s_mutate_count_increase_prob)
                                {
                                        _gene.weight *= (1 + frac);
                                }
                                else
                                {
                                        _gene.weight *= (1 - frac);
                                }
                        }

                }


        }

        /** (1) has a risk of being disabled if done before disabling (only when non-safe disable_gene)
         *  (2) may create back-track connection if done more than once without doing firing sequence in between,
         *  otherwise it's safe
         */
        public boolean mutate_add_link(mPopulation pop, int gen, double bias_link_prob)
        {
                boolean done = false;
                boolean found = false;

                double new_weight;

                mNode thenode1 = null;
                mNode thenode2 = null;
                mGene new_gene = null;
                mGene _gene = null;

                Iterator itr_gene = null;
                Iterator itr_innovation = null;

                Vector allnodes;
                Vector non_inputs;
                int numnodes = 0;
                int numnoninput = 0;
                boolean do_cascade;
                if(NeatRoutine.randfloat() < mNeat.m_mutate_disabled_struct_prob)
                {
                        numnodes = nodes.size();
                        numnoninput = com_nodes.size() + island_nodes.size();

                        allnodes = new Vector(numnodes, 0);
                        allnodes.addAll(nodes);

                        non_inputs = new Vector(numnoninput, 0);
                        non_inputs.addAll(com_nodes);
                        non_inputs.addAll(island_nodes);

                        do_cascade = true;
                }
                else
                {
                        numnodes = inputs.size() + com_nodes.size();
                        numnoninput = com_nodes.size();

                        allnodes = new Vector(numnodes, 0);
                        allnodes.addAll(inputs);
                        allnodes.addAll(com_nodes);

                        non_inputs = new Vector(numnoninput, 0);
                        non_inputs.addAll(com_nodes);

                        do_cascade = false; // no reason to cascade if add link only to enabled structures

                }

                boolean do_bias_link = false;
                if(NeatRoutine.randfloat() < bias_link_prob) //sometime, only add a link from bias node
                {
                        do_bias_link = true;
                        for(int b = 0; b < inputs.size(); b++)
                        {
                                mNode b_node = (mNode) inputs.elementAt(b);
                                if(b_node.type == 0)
                                {
                                        thenode1 = b_node;
                                        break;
                                }
                        }
                }

                int trycount = 0;
                int tries = (numnodes + 1) * numnodes / 2;

                //Make attempts to find an unconnected pair
                found = true;
                while(trycount < tries)
                {
                        //
                        // now point to object's nodes, in_node from all nodes, out_node from non-input nodes
                        //
                        if(do_bias_link)
                        {
                                thenode2 = (mNode) non_inputs.elementAt(NeatRoutine.randint(0, numnoninput - 1));
                        }
                        else
                        {
                                do
                                {
                                        thenode1 = (mNode) allnodes.elementAt(NeatRoutine.randint(0, numnodes - 1));
                                        thenode2 = (mNode) non_inputs.elementAt(NeatRoutine.randint(0, numnoninput - 1));
                                }
                                while((thenode1.node_id == thenode2.node_id)); // this prevents back-track connection
                        } // (thenode1.order_num > thenode2.order_num) || 
                        // if thenode1 is down cascade of thenode2, it will create recurrent or infinite loop
                        // which will get detected by firing sequence later on

                        //
                        // verify if the possible new gene already EXIST
                        //
                        if(thenode2.type == 1 || thenode2.type == 0)
                        {
                                found = false;
                        }
                        else
                        {
                                for(int j = 0; j < genes.size(); j++)
                                {
                                        _gene = (mGene) genes.elementAt(j);
                                        if((_gene.in_node == thenode1) && (_gene.out_node == thenode2))
                                        {
                                                found = false;
                                                break;
                                        }
                                }
                        }

                        if(!found)
                        {
                                trycount++;
                        }
                        else
                        {
                                trycount = tries;
                        }
                } // end block trycount

                if(found)
                {

                        //Check to see if this innovation already occured in the population
                        itr_innovation = pop.innovations.iterator();

                        done = false;
                        while(!done)
                        {

                                if(!itr_innovation.hasNext())
                                {

                                        //Choose the new weight
                                        //newweight=(gaussrand())/1.5;  //Could use a gaussian
                                        new_weight = NeatRoutine.randposneg() * NeatRoutine.randfloat() * 10.0;

                                        // read current innovation with postincrement
                                        double curr_innov = pop.getCurr_innov_num_and_increment();
                                        //Create the new gene
                                        new_gene = new mGene(new_weight, thenode1, thenode2, curr_innov, new_weight, gen);
                                        //Add the innovation
                                        pop.innovations.add(new mInnovation(thenode1.node_id, thenode2.node_id, curr_innov, new_weight));
                                        done = true;

                                }
                                //OTHERWISE, match the innovation in the innovs list
                                else
                                {
                                        mInnovation _innov = ((mInnovation) itr_innovation.next());
                                        if((_innov.innovation_type == NeatRoutine.NEWLINK) && (_innov.node_in_id == thenode1.node_id) && (_innov.node_out_id == thenode2.node_id))
                                        {

                                                new_gene = new mGene(_innov.new_weight, thenode1, thenode2, _innov.innovation_num1, 0, gen);
                                                done = true;
                                        }
                                }
                        }

                        if(do_cascade) // check if the new link's in_node or out_node is in island_nodes, if so, reenable subsequent genes
                        {
                                mutate_cascade_reenable(new_gene, gen);
                        }

                        genes.add(new_gene);
                        com_genes.add(new_gene);

                        allnodes = null;
                        non_inputs = null;

                        return true;
                }

                allnodes = null;
                non_inputs = null;

                return false;
        }

        /** this toggles either ftype or sftype of the node */
        public boolean mutate_toggle_ftype(int gen)
        {
                int rand;
                int g_num = com_nodes.size() - 1;
                double age_frac;
                double factor = mNeat.epoch_ratio_s_m * mNeat.m_mutate_age_factor;
                mNode _node;

                for(int i = 0; i <= g_num; i++)
                {
                        _node = (mNode) com_nodes.elementAt((NeatRoutine.randint(0, g_num)));
                        age_frac = Math.exp((_node.modified_gen - gen) / factor);

                        if(NeatRoutine.randfloat() < age_frac) // youger node are more likely to get toggled
                        {
                                // there is a chance that the toggling happens for sftype
                                if(NeatRoutine.randfloat() < mNeat.m_mutate_toggle_sftype)
                                {
                                        // find a random number that is not equal to original sftype
                                        rand = _node.sftype;
                                        while(_node.sftype == rand)
                                        {
                                                rand = NeatRoutine.randint(0, mNeat.m_sftype_allowed);
                                        }
                                        _node.sftype = rand;
                                        _node.modified_gen = gen;
                                        return true;
                                }
                                else
                                {
                                        // find a random number that is not equal to original ftype
                                        rand = _node.ftype;
                                        while(_node.ftype == rand)
                                        {
                                                rand = NeatRoutine.randint(0, mNeat.m_ftype_allowed);
                                        }
                                        _node.ftype = rand;
                                        _node.modified_gen = gen;
                                        return true;
                                }
                        }
                }
                return false;
        }

        /** This serves as a simultaneous minor pruning process without deleting ancestral genes,
         * the disabling is cascaded when in unsafe mode (more costly computation)
         */
        public boolean mutate_gene_disable(int gen, boolean safe)
        {
                int g_num = com_genes.size() - 1;
                double age_frac;
                double factor = mNeat.epoch_ratio_s_m * mNeat.m_mutate_age_factor;
                mGene _gene;

                for(int i = 0; i <= g_num; i++)
                {
                        //find a random gene
                        _gene = (mGene) com_genes.elementAt(NeatRoutine.randint(0, g_num));
                        age_frac = Math.exp((_gene.modified_gen - gen) / factor);

                        if(NeatRoutine.randfloat() < age_frac)
                        {
                                // safe mode: only disable link between nodes that have more than one links
                                if(safe)
                                {
                                        if(_gene.in_node.outgoing_on.size() > 1 && _gene.out_node.incoming_on.size() > 1)
                                        {
                                                _gene.enable = false;
                                                _gene.disable_gen = gen;
                                                com_genes.remove(_gene);
                                                dis_genes.add(_gene);
                                                return true;
                                        }
                                }
                                else // older gene are more likely to get cascaded
                                {
                                        if(NeatRoutine.randfloat() > age_frac)
                                        {
                                                return mutate_cascade_disable(_gene, gen);
                                        }
                                }
                        }
                }
                return false;
        }

        /** reenable a disabed gene,  probability of reenabling is higer if, last disabling was recent and fitness is low */
        public boolean mutate_gene_reenable(int gen)
        {
                int g_num = dis_genes.size() - 1;
                double age_frac;
                double factor = mNeat.epoch_ratio_s_m * mNeat.m_mutate_age_factor;
                mGene _gene;

                if(dis_genes.size() != 0)
                {
                        for(int i = 0; i <= g_num; i++)
                        {
                                _gene = (mGene) dis_genes.elementAt(NeatRoutine.randint(0, g_num));
                                age_frac = Math.exp((_gene.disable_gen - gen) / factor);

                                if(NeatRoutine.randfloat() < age_frac)
                                {
                                        // this might undo bad recent disabling
                                        if(NeatRoutine.randfloat() < age_frac)
                                        {
                                                mutate_cascade_reenable(_gene, gen);
                                                return true;
                                        }
                                }
                        }
                }
                return false;
        }

        /** used in unsafe gene_disable , maybe remove link */
        public boolean mutate_cascade_disable(mGene thegene, int generation)
        {
                mGene _gene = null;
                mNode _node = null;

                boolean has_enable = false;
                boolean output_gone = false;

                Vector store_island = new Vector(5, 0);

                // collection of genes that need to be cascade in down (then up) direction
                Vector casc_genes = new Vector(5, 0);
                casc_genes.add(thegene);

                int i;
                int v_size;
                v_size = casc_genes.size();
                for(i = 0; i < v_size; i++)
                {
                        _gene = (mGene) casc_genes.elementAt(i);
                        _node = _gene.out_node;

                        _gene.enable = false;
                        _gene.disable_gen = generation;

                        // move this gene from its out_node's incoming on to off
                        _node.incoming_on.remove(_gene);
                        _node.incoming_off.add(_gene);

                        // if this gene's out_node has no more enabled incoming genes
                        if(_node.incoming_on.size() == 0)
                        {
                                // if one output has no more incoming genes, break and reverse process
                                if(_node.type == 2)
                                {
                                        output_gone = true;
                                        break;
                                }

                                // add the out_node's outgoing genes for disabling
                                casc_genes.addAll(_node.outgoing_on);
                                v_size = casc_genes.size();

                                // move all outgoing on to off
                                _node.outgoing_off.addAll(_node.outgoing_on);
                                _node.outgoing_on.clear();

                                // add this node to potential island_nodes
                                store_island.add(_node);
                        }
                }

                if(output_gone)
                {
                        v_size = casc_genes.size();
                        // for the first gene, nothing happen to its in_node
                        _gene = (mGene) casc_genes.elementAt(0);
                        _gene.enable = true;
                        _gene.out_node.incoming_off.remove(_gene);
                        _gene.out_node.incoming_on.add(_gene);

                        v_size = casc_genes.size();
                        for(i = 1; i < v_size; i++)
                        {
                                _gene = (mGene) casc_genes.elementAt(i);
                                _gene.enable = true;
                                _gene.out_node.incoming_off.remove(_gene);
                                _gene.out_node.incoming_on.add(_gene);
                                _gene.in_node.outgoing_off.remove(_gene);
                                _gene.in_node.outgoing_on.add(_gene);
                        }

                        casc_genes = null;
                        casc_genes = null;
                        store_island = null;

                        return false;
                }
                else
                {
                        // finishing off down cascade action
                        // adding new island nodes to the list, if new link connect to them, a different topology can form
                        // add to dis_genes, makes sure for mutation in one generation is either disable or reenable
                        com_nodes.removeAll(store_island);
                        island_nodes.addAll(store_island);
                        com_genes.removeAll(casc_genes);
                        dis_genes.addAll(casc_genes);
                        store_island = null;

                        casc_genes = new Vector(5, 0);
                        casc_genes.add(thegene);

                        // no reason to store disabling genes, since there's no way to screw it up now
                        // unless... there are dangling nodes hanging around, which means bugs in link methods (this or other)
                        v_size = casc_genes.size();
                        for(i = 0; i < v_size; i++)
                        {
                                _gene = (mGene) casc_genes.elementAt(i);
                                _node = _gene.in_node;

                                if(i != 0) // already did this for the first gene
                                {
                                        _gene.enable = false;
                                        _gene.disable_gen = generation;
                                        com_genes.remove(_gene);
                                        dis_genes.add(_gene);
                                }

                                _node.outgoing_on.remove(_gene);
                                _node.outgoing_off.add(_gene);

                                if(_node.outgoing_on.size() == 0)
                                {
                                        // add the in_node's incoming genes for disabling
                                        casc_genes.addAll(_node.incoming_on);
                                        v_size = casc_genes.size();

                                        _node.incoming_off.addAll(_node.incoming_on);
                                        _node.incoming_on.clear();

                                        com_nodes.remove(_node);
                                        island_nodes.add(_node);
                                }
                        }

                        casc_genes = null;

                        return true;
                }
        }

        /** used for mutate_gene_reenable, and sometimes mutate_add_link */
        public boolean mutate_cascade_reenable(mGene thegene, int gen)
        {
                // if cascaded at least one other gene
                boolean once = false;
                mGene _gene = null;
                mNode _node = null;

                // collections of genes that need to be cascade in either up or down direction
                Vector up_genes = new Vector(5, 0);
                Vector down_genes = new Vector(5, 0);

                up_genes.add(thegene);
                down_genes.add(thegene);

                int i;
                int v_size = up_genes.size();
                for(i = 0; i < v_size; i++)
                {
                        _gene = (mGene) up_genes.elementAt(i);
                        _node = _gene.in_node;

                        // check if this gene's in_node is an island node
                        // if so, all of its incoming genes will be enabled next iteration
                        if(_node.incoming_on.size() == 0)
                        {
                                once = true;

                                // add all incoming genes of its in_node for further checking
                                up_genes.addAll(_node.incoming_off);
                                v_size = up_genes.size();

                                // move all genes from incoming_off to incoming_on
                                _node.incoming_on.addAll(_node.incoming_off);
                                _node.incoming_off.clear();

                                // remove this node from island_nodes so it won't get check again
                                island_nodes.remove(_node);
                                com_nodes.add(_node);
                        }

                        _gene.enable = true;
                        _gene.modified_gen = gen - 1;
                        com_genes.add(_gene);
                        dis_genes.remove(_gene);
                // these genes are not added to com_genes so that they won't get disabled in the same generation
                }

                v_size = down_genes.size();
                for(i = 0; i < v_size; i++)
                {
                        _gene = (mGene) down_genes.elementAt(i);
                        _node = _gene.out_node;

                        // check if this gene's out_node is an island node
                        // if so,  all of its outgoing genes will be enabled next iteration
                        if(_node.outgoing_on.size() == 0)
                        {
                                once = true;

                                // add all outoing genes of its out_node for further checking
                                down_genes.addAll(_node.outgoing_off);
                                v_size = down_genes.size();

                                // move all genes from outgoing_off to outgoing_on
                                _node.outgoing_on.addAll(_node.outgoing_off);
                                _node.outgoing_off.clear();

                                // remove this node from island_nodes so it won't get check again
                                island_nodes.remove(_node);
                                com_nodes.add(_node);
                        }

                        if(i != 0) // already did these for the first gene
                        {
                                _gene.enable = true;
                                _gene.modified_gen = gen - 1;
                                com_genes.add(_gene);
                                dis_genes.remove(_gene);
                        }
                }

                up_genes = null;
                down_genes = null;
                return once;
        }

        /** has a risk of being disabled if done before disabling (and if cascading is on) */
        public boolean mutate_add_node(int gen, mPopulation pop)
        {
                mGene _gene = null;

                mGene newgene1 = null;
                mGene newgene2 = null;
                mNode in_node = null;
                mNode out_node = null;
                mNode new_node = null;
                Iterator itr_innovation;

                double gene_innov1;
                double gene_innov2;

                boolean do_cascade;
                if(NeatRoutine.randfloat() < mNeat.m_mutate_disabled_struct_prob)
                {
                        _gene = (mGene) genes.elementAt(NeatRoutine.randint(0, genes.size() - 1));
                        do_cascade = true;
                }
                else
                {
                        if(com_genes.size() == 0)
                        {
                                _gene = (mGene) genes.elementAt(NeatRoutine.randint(0, genes.size() - 1));   
                        }
                        else
                        {
                                _gene = (mGene) com_genes.elementAt(NeatRoutine.randint(0, com_genes.size() - 1));
                        }
                        do_cascade = false;
                }

                // sometimes the old gene is disabled
                if(NeatRoutine.randfloat() < mNeat.m_newnode_geneoff_prob)
                {
                        _gene.enable = false;
                        _gene.disable_gen = gen;
                        com_genes.remove(_gene);
                        dis_genes.add(_gene);
                }

                //Extract the weight;
                double oldweight = _gene.weight;

                //Extract the nodes
                in_node = _gene.in_node;
                out_node = _gene.out_node;

                boolean done = false;
                itr_innovation = pop.innovations.iterator();

                int new_f; // new ftype
                int new_sf; // new sftype

                while(!done)
                {
                        //Check to see if this innovation already occured in the population
                        if(!itr_innovation.hasNext())
                        {

                                //The innovation is totally novel
                                //Create the new Genes
                                //Create the new NNode
                                //By convention, it will point to the first trait
                                // get the current node id with postincrement

                                int curnode_id = pop.getCur_node_id_and_increment();

                                // pass this current nodeid to newnode and create the new node
                                new_f = NeatRoutine.randint(0, mNeat.m_ftype_allowed);
                                new_sf = NeatRoutine.randint(0, mNeat.m_sftype_allowed);
                                new_node = new mNode(curnode_id, NeatRoutine.HIDDEN, new_f, new_sf, gen);

                                // get the current gene inovation with post increment
                                gene_innov1 = pop.getCurr_innov_num_and_increment();

                                // create gene with the current gene inovation
                                newgene1 = new mGene(1.0, in_node, new_node, gene_innov1, 0, gen);

                                // re-read the current innovation with increment
                                gene_innov2 = pop.getCurr_innov_num_and_increment();

                                // create the second gene with this innovation incremented
                                newgene2 = new mGene(oldweight, new_node, out_node, gene_innov2, 0, gen - 1);

                                new_node.incoming_on.add(newgene1);
                                new_node.outgoing_on.add(newgene2);

                                pop.innovations.add(new mInnovation(in_node.node_id, out_node.node_id, gene_innov1, gene_innov2,
                                        new_node.node_id, _gene.innovation_num));
                                done = true;
                        }
                        // end for new innovation case
                        else
                        {
                                mInnovation _innov = ((mInnovation) itr_innovation.next());

                                if((_innov.innovation_type == NeatRoutine.NEWNODE) && (_innov.node_in_id == in_node.node_id) && (_innov.node_out_id == out_node.node_id) && (_innov.old_innov_num == _gene.innovation_num))
                                {
                                        // Create the new Genes
                                        // pass this current nodeid to newnode, same innovation can still have different ftype/sftype
                                        new_f = NeatRoutine.randint(0, mNeat.m_ftype_allowed);
                                        new_sf = NeatRoutine.randint(0, mNeat.m_sftype_allowed);
                                        new_node = new mNode(_innov.newnode_id, NeatRoutine.HIDDEN, new_f, new_sf, gen);

                                        newgene1 = new mGene(1.0, in_node, new_node, _innov.innovation_num1, 0, gen);
                                        newgene2 = new mGene(oldweight, new_node, out_node, _innov.innovation_num2, 0, gen - 1);
                                        new_node.incoming_on.add(newgene1);
                                        new_node.outgoing_on.add(newgene2);
                                        done = true;

                                }
                        }

                }

                // cascading if the node is added between island nodes.
                if(do_cascade)
                {
                        mutate_cascade_reenable(newgene1, gen);
                        mutate_cascade_reenable(newgene2, gen);
                }

                //Now add the new NNode and new Genes to the Genome

                genes.add(newgene1);
                genes.add(newgene2);
                com_genes.add(newgene1);
                com_genes.add(newgene2);
                nodes.add(new_node);
                com_nodes.add(new_node);

                return true;

        }

        public mGenome mate_multipoint(mGenome g, int genomeid, double fitness1, double fitness2, int generation, int m_type)
        {

                mGenome new_genome = null;
                int disable_status = 0; // 0: both enabled 1: both disabled , 2: one enable, one disable
                boolean disable_all = (NeatRoutine.randfloat() < .5); // if false, it will choose all enabled and cascade reenable


                Vector cascade_genes = new Vector(5, 0);

                mGene _curgene2 = null;
                mGene newgene = null;
                mNode inode = null;
                mNode onode = null;
                mNode new_inode = null;
                mNode new_onode = null;
                mNode curnode = null;

                mGene chosengene = null;
                mGene _p1gene = null;
                mGene _p2gene = null;
                double p1innov = 0;
                double p2innov = 0;

                int j1;
                int j2;


                //Tells if the first genome (this one) has better fitness or not
                boolean skip = false;

                //Figure out which genome is better
                //The worse genome should not be allowed to add extra structural baggage
                //If they are the same, use the smaller one's disjoint and excess genes only

                boolean p1better = false;

                int size1 = genes.size();
                int size2 = g.genes.size();

                if(fitness1 > fitness2)
                {
                        p1better = true;
                }
                else if(fitness1 == fitness2)
                {
                        if(size1 < size2)
                        {
                                p1better = true;
                        }
                }

                int len_genome = Math.max(size1, size2);
                int len_nodes = nodes.size();

                Vector newgenes = new Vector(len_genome, 0);
                Vector newnodes = new Vector(len_nodes, 0);

                newnodes.addAll(inputs);
                newnodes.addAll(outputs);

                Iterator itr_newgenes;

                j1 = 0;
                j2 = 0;

                while(j1 < size1 || j2 < size2)
                {
                        //
                        //  chosen of 'just' gene
                        //

                        skip = false; //Default to not skipping a chosen gene
                        if(j1 >= size1)
                        {
                                chosengene = (mGene) g.genes.elementAt(j2);
                                j2++;
                                if(p1better)
                                {
                                        skip = true;
                                } //Skip excess from the worse genome
                        }
                        else if(j2 >= size2)
                        {
                                chosengene = (mGene) genes.elementAt(j1);
                                j1++;
                                if(!p1better)
                                {
                                        skip = true;
                                } //Skip excess from the worse genome
                        }
                        else
                        {

                                _p1gene = (mGene) genes.elementAt(j1);
                                _p2gene = (mGene) g.genes.elementAt(j2);

                                p1innov = _p1gene.innovation_num;
                                p2innov = _p2gene.innovation_num;
                                if(p1innov == p2innov)
                                {
                                        if(NeatRoutine.randfloat() < 0.5)
                                        {
                                                chosengene = _p1gene;
                                        }
                                        else
                                        {
                                                chosengene = _p2gene;
                                        }

                                        if(NeatRoutine.randfloat() < mNeat.m_mate_weight_avg_prob)
                                        {
                                                chosengene.weight = (_p1gene.weight + _p2gene.weight) / 2.0;
                                        }

                                        //If one is disabled, the corresponding gene in the offspring
                                        //will likely be disabled
                                        disable_status = 0;
                                        if((_p1gene.enable == false) || (_p2gene.enable == false))
                                        {
                                                // if only one gene is enabled
                                                if((_p2gene.enable == true) || (_p1gene.enable == true))
                                                {
                                                        disable_status = 2;
                                                }
                                                else // if both genes were disabled
                                                {
                                                        disable_status = 1;
                                                }
                                        }
                                        j1++;
                                        j2++;

                                }
                                else if(p1innov < p2innov)
                                {
                                        chosengene = _p1gene;
                                        j1++;
                                        if(!p1better)
                                        {
                                                skip = true;
                                        }
                                }
                                else if(p2innov < p1innov)
                                {
                                        chosengene = _p2gene;
                                        j2++;
                                        if(p1better)
                                        {
                                                skip = true;
                                        }
                                }
                        }// end chosen gene

                        //
                        //
                        //Check to see if the chosengene conflicts with an already chosen gene
                        //i.e. do they represent the same link
                        //

                        itr_newgenes = newgenes.iterator();

                        while(itr_newgenes.hasNext())
                        {
                                _curgene2 = ((mGene) itr_newgenes.next());

                                if(_curgene2.in_node.node_id == chosengene.in_node.node_id && _curgene2.out_node.node_id == chosengene.out_node.node_id)
                                {
                                        skip = true;
                                        break;
                                }
                                if(_curgene2.in_node.node_id == chosengene.out_node.node_id && _curgene2.out_node.node_id == chosengene.in_node.node_id)
                                {
                                        skip = true;
                                        break;
                                }

                        }

                        //
                        //
                        //
                        if(!skip)
                        {
                                //Now add the chosengene to the baby
                                //Next check for the nodes, add them if not in the baby Genome already
                                inode = chosengene.in_node;
                                onode = chosengene.out_node;

                                //Check for inode in the newnodes list

                                //
                                //Check for inode, onode in the newnodes list

                                int ix;
                                int ix_size = newnodes.size();
                                boolean found = false;

                                //
                                // search the inode
                                //

                                for(ix = 0; ix < ix_size; ix++)
                                {
                                        curnode = (mNode) newnodes.elementAt(ix);
                                        if(curnode.node_id == inode.node_id)
                                        {
                                                found = true;
                                                break;
                                        }

                                }

                                // if exist , point to exitsting version
                                if(found)
                                {
                                        // 50/50 chance of taking either nodes ftype/sftype
                                        if(NeatRoutine.randfloat() < .5)
                                        {
                                                curnode.ftype = inode.ftype;
                                        }

                                        if(NeatRoutine.randfloat() < .5)
                                        {
                                                curnode.sftype = inode.sftype;
                                        }

                                        new_inode = curnode;
                                }
                                // else create the inode
                                else
                                {
                                        new_inode = new mNode(inode);
                                        //insert in newnodes list
                                        newnodes.add(new_inode);
                                }
                                //
                                // search the onode
                                //
                                found = false;
                                for(ix = 0; ix < ix_size; ix++)
                                {
                                        curnode = (mNode) newnodes.elementAt(ix);
                                        if(curnode.node_id == onode.node_id)
                                        {
                                                found = true;
                                                break;
                                        }

                                }

                                // if exist , point to exitsting version
                                if(found)
                                {
                                        // 50/50 chance of taking either nodes ftype/sftype
                                        if(NeatRoutine.randfloat() < .5)
                                        {
                                                curnode.ftype = onode.ftype;
                                        }

                                        if(NeatRoutine.randfloat() < .5)
                                        {
                                                curnode.sftype = onode.sftype;
                                        }

                                        new_onode = curnode;
                                }
                                // else create the onode
                                else
                                {
                                        new_onode = new mNode(onode);
                                        //insert in newnodes list
                                        newnodes.add(new_onode);
                                }


                                //--------------------------------------------------------------------------------

                                //Add the Gene
                                newgene = new mGene(chosengene, new_inode, new_onode);

                                if(disable_status == 1)
                                {
                                        newgene.enable = false;
                                }
                                else if(disable_status == 2)
                                {
                                        cascade_genes.add(newgene);
                                }

                                newgenes.add(newgene);
                        }

                } // end block genome (while)


                new_genome = new mGenome(genomeid, newnodes, newgenes);
                
                new_genome.organize();

                // cascade disabled or reenabled genes
                int count = cascade_genes.size();
                if(disable_all)
                {
                        for(int i = 0; i < count; i++)
                        {
                                new_genome.mutate_cascade_disable((mGene) cascade_genes.elementAt(i), generation);
                        }
                }
                else
                {
                        for(int i = 0; i < count; i++)
                        {
                                new_genome.mutate_cascade_reenable((mGene) cascade_genes.elementAt(i), generation);
                        }
                }

                cascade_genes = null;

                return new_genome;
        }

        /** enable not cascaded yet */
        public mGenome mate_singlepoint(mGenome g, int genomeid)
        {
                mGenome new_genome = null;
                mGene chosengene = null;
                int stopA = 0;
                int stopB = 0;
                int j;
                int j1;
                int j2;
                int size1 = genes.size();
                int size2 = g.genes.size();
                int crosspoint = 0;
                int len_genome = 0;

                double p1innov = 0.0;
                double p2innov = 0.0;

                Iterator itr_newgenes;

                mNode curnode = null;
                mNode inode = null;
                mNode onode = null;
                mNode new_inode = null;
                mNode new_onode = null;
                mGene newgene = null;

                Vector genomeA;
                Vector genomeB;
                mGene geneA = null;
                mGene geneB = null;
                mGene _curgene2 = null;
                int genecounter = 0; //Ready to count to crosspoint
                boolean skip = false; //Default to not skip a Gene

                Vector newgenes = new Vector(genes.size(), 0);
                Vector newnodes = new Vector(nodes.size(), 0);

                newnodes.addAll(inputs);
                newnodes.addAll(outputs);

                if(size1 < size2)
                {
                        crosspoint = NeatRoutine.randint(0, size1 - 1);
                        stopA = size1;
                        stopB = size2;
                        len_genome = size2;
                        genomeA = genes;
                        genomeB = g.genes;
                }
                else
                {
                        crosspoint = NeatRoutine.randint(0, size2 - 1);
                        stopA = size2;
                        stopB = size1;
                        len_genome = size1;
                        genomeA = g.genes;
                        genomeB = genes;
                }

                //System.out.print("\n crossing point is :"+crosspoint);

                genecounter = 0;

                boolean doneA = false;
                boolean doneB = false;
                boolean done = false;
                double v1 = 0.0;
                double v2 = 0.0;
                double cellA = 0.0;
                double cellB = 0.0;

                j1 = 0;
                j2 = 0;
                j = 0;

                //
                // compute what is the hight innovation
                //

                double last_innovB = ((mGene) genomeB.elementAt(stopB - 1)).innovation_num;
                double cross_innov = 0;

                while(!done)
                {

                        doneA = false;
                        doneB = false;
                        skip = false;

                        if(j1 < stopA)
                        {
                                geneA = (mGene) genomeA.elementAt(j1);
                                v1 = geneA.innovation_num;
                                doneA = true;
                        }
                        if(j2 < stopB)
                        {
                                geneB = (mGene) genomeB.elementAt(j2);
                                v2 = geneB.innovation_num;
                                doneB = true;
                        }

                        if(doneA && doneB)
                        {
                                //
                                if(v1 < v2)
                                {
                                        cellA = v1;
                                        cellB = 0.0;
                                        j1++;
                                }
                                else if(v1 == v2)
                                {
                                        cellA = v1;
                                        cellB = v1;
                                        j1++;
                                        j2++;
                                }
                                else
                                {
                                        cellA = 0.0;
                                        cellB = v2;
                                        j2++;
                                }
                        }
                        else
                        {
                                if(doneA && !doneB)
                                {
                                        cellA = v1;
                                        cellB = 0.0;
                                        j1++;
                                }
                                else if(!doneA && doneB)
                                {
                                        cellA = 0.0;
                                        cellB = v2;
                                        j2++;
                                }
                                else
                                {
                                        done = true;
                                }
                        }





                        if(!done)
                        {

                                // -------------------------------------------------------------------------------
                                //                        innovA = innovB
                                // -------------------------------------------------------------------------------

                                if(cellA == cellB)
                                {
                                        if(genecounter < crosspoint)
                                        {
                                                chosengene = geneA;
                                                genecounter++;
                                        }
                                        else if(genecounter == crosspoint)
                                        {
                                                if(NeatRoutine.randfloat() > 0.5)
                                                {
                                                        chosengene = geneA;
                                                }
                                                else
                                                {
                                                        chosengene = geneB;
                                                }
                                                //WEIGHTS AVERAGED HERE
                                                chosengene.weight = (geneA.weight + geneB.weight) / 2.0;
                                                chosengene.mutation_num = (geneA.mutation_num + geneB.mutation_num) / 2.0;

                                                //If one is disabled, the corresponding gene in the offspring
                                                //will likely be disabled

                                                if((geneA.enable == false) || (geneB.enable == false))
                                                {
                                                        chosengene.enable = false;
                                                }

                                                genecounter++;
                                                cross_innov = cellA;
                                        }
                                        else if(genecounter > crosspoint)
                                        {
                                                chosengene = geneB;
                                                genecounter++;
                                        }
                                }
                                // -------------------------------------------------------------------------------
                                //                        innovA < innovB
                                // -------------------------------------------------------------------------------
                                else if(cellA != 0 && cellB == 0)
                                {
                                        if(genecounter < crosspoint)
                                        {
                                                chosengene = geneA; //make geneA
                                                genecounter++;
                                        }
                                        else if(genecounter == crosspoint)
                                        {
                                                chosengene = geneA;
                                                genecounter++;
                                                cross_innov = cellA;
                                        }
                                        else if(genecounter > crosspoint)
                                        {
                                                if(cross_innov > last_innovB)
                                                {
                                                        chosengene = geneA;
                                                        genecounter++;
                                                }
                                                else
                                                {
                                                        skip = true;
                                                }
                                        }
                                }
                                // -------------------------------------------------------------------------------
                                //                        innovA > innovB
                                // -------------------------------------------------------------------------------
                                else
                                {
                                        if(cellA == 0 && cellB != 0)
                                        {
                                                if(genecounter < crosspoint)
                                                {
                                                        skip = true; //skip geneB
                                                }
                                                else if(genecounter == crosspoint)
                                                {
                                                        skip = true; //skip an illogic case
                                                }
                                                else if(genecounter > crosspoint)
                                                {
                                                        if(cross_innov > last_innovB)
                                                        {
                                                                chosengene = geneA; //make geneA
                                                                genecounter++;
                                                        }
                                                        else
                                                        {
                                                                chosengene = geneB; //make geneB : this is a pure case o single crossing
                                                                genecounter++;
                                                        }
                                                }

                                        }
                                }

                                itr_newgenes = newgenes.iterator();

                                while(itr_newgenes.hasNext())
                                {
                                        _curgene2 = ((mGene) itr_newgenes.next());

                                        if(_curgene2.in_node.node_id == chosengene.in_node.node_id && _curgene2.out_node.node_id == chosengene.out_node.node_id)
                                        {
                                                skip = true;
                                                break;
                                        }

                                        if(_curgene2.in_node.node_id == chosengene.out_node.node_id && _curgene2.out_node.node_id == chosengene.in_node.node_id)
                                        {
                                                skip = true;
                                                break;
                                        }

                                } // and else for control of position in gennomeA/B

                                if(!skip)
                                {
                                        //Now add the chosengene to the baby
                                        //check for the nodes, add them if not in the baby Genome already

                                        inode = chosengene.in_node;
                                        onode = chosengene.out_node;

                                        //
                                        //Check for inode, onode in the newnodes list
                                        //
                                        boolean found = false;
                                        //
                                        // search the inode
                                        //
                                        for(int ix = 0; ix < newnodes.size(); ix++)
                                        {
                                                curnode = (mNode) newnodes.elementAt(ix);
                                                if(curnode.node_id == inode.node_id)
                                                {
                                                        found = true;
                                                        break;
                                                }
                                        }
                                        // if exist , point to exitsting version
                                        if(found)
                                        {
                                                new_inode = curnode;
                                        }
                                        // else create the inode
                                        else
                                        {
                                                new_inode = new mNode(inode);
                                                //insert in newnodes list
                                                newnodes.add(new_inode);
                                        }

                                        //
                                        // search the onode
                                        //
                                        found = false;
                                        for(int ix = 0; ix < newnodes.size(); ix++)
                                        {
                                                curnode = (mNode) newnodes.elementAt(ix);
                                                if(curnode.node_id == onode.node_id)
                                                {
                                                        found = true;
                                                        break;
                                                }
                                        }
                                        // if exist , point to exitsting version
                                        if(found)
                                        {
                                                new_onode = curnode;
                                        }
                                        // else create the onode
                                        else
                                        {
                                                new_onode = new mNode(onode);
                                                //insert in newnodes list
                                                newnodes.add(new_onode);
                                        }

                                        //Add the Gene
                                        newgene = new mGene(chosengene, new_inode, new_onode);
                                        newgenes.add(newgene);

                                } // end of block gene creation if !skip

                        }
                        j++;

                }

                new_genome = new mGenome(genomeid, newnodes, newgenes);

                return new_genome;

        }
}

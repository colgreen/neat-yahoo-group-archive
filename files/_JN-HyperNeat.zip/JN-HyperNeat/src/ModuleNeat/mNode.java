
package ModuleNeat;
import java.util.*;
import java.text.*;

/**
 *
 * @author GABA
 */
public class mNode
{
        
        /** Numeric identification of node.
         * 0 is and output in weight_hebb module, that decides whether to build a rLink or not (positive activation = build)
         * 1 is always bias,
         * 2 is always input
         * 3 can be input for weight_hebb, delay module
         * outputs for time, bias: 3, 4
         * outputs for weight, hebb, pre: 4, 5, 6
         * outputs for delay: 4
         */
        int node_id;
        
        /** type of node:
         *   0: bias, 1: input, 2: output, 3: hidden
         */
        int type;
        
        /** Composite Function type for creating patterns */
// 0:   linear              : (-inf .. +inf) : f(x) = x;
// 1:   sigmoid             : (0  .. 1)      : f(x) = 1/(1+exp(-x));
// 2:   gaussian            : (0  .. 1)      : f(x) = exp(-(x*x))
// 3:   sine                : (-1 .. 1)      : f(x) = sin(x);
// 4:   cosine              : (-1 .. 1)      : f(x) = cos(x);
// 5:   square              : (0, +inf)      : f(x) = x*x;
// 6:   square root         : (0, +inf)      : f(x) = sqrt(x); if x<0, f(x) = sqrt(-x)
// 7:   exponential         : (?)            : f(x) = exp(x);
// 8:   log                 : (?)            : f(x) = log(x); if x < 0, f(x) = log(-x)
// 9:   inv                 : (-inf, +inf)   : f(x) = (x!=0)?1/x:BIG_NUMBER;
// 10:  absolute value      : (0 .. +inf)    : f(x) = abs(x);
        int ftype;
        
        /** summing function type  */
// 0:   addition       : (i1*w1) + (i2*w2) + (in*wn)       : default      : OR
// 1:   multiplication : (i1*w1) * (i2*w2) * (in*wn)       : experimental : AND
// 2:   maximal of     : MAX ((i1*w1), (i2*w2), (i3*w3))   : experimental
// 3:   minimal of     : MIN ((i1*w1), (i2*w2), (i3*w3))   : experimental
        int sftype;
        
        /** used for deep copy of gene */
        mNode dup;
        
        /** lists of pointers to incoming/outgoing links from other nodes */
        Vector incoming_on;
        Vector incoming_off;
        Vector outgoing_on;
        Vector outgoing_off;
        
        /** The incoming activity before being processed */
        
        double activesum;
        
        /** The total activation entering in this Node */
        double activation;
        
        /** the generation this node got created or function changed */
        int modified_gen;
        
        /** this number indicates the node's placement in firing sequence */
        int order_num;
        
        /** Creates a new module node from file */
        public mNode(String xline)
        {
                dup = null;
                activesum = 0;
                activation = 0;
                incoming_on = new Vector(3,0);
                outgoing_on = new Vector(3,0);
                incoming_off = new Vector(3,0);
                outgoing_off = new Vector(3,0);
                
                StringTokenizer st;
                String s1;
                st = new StringTokenizer(xline);
                
                //skip keyword
                s1 = st.nextToken();
                
                //Get the node parameters
                s1 = st.nextToken();
                node_id = Integer.parseInt(s1);
                
                //get type of node
                s1 = st.nextToken();
                type = Integer.parseInt(s1);
                
                //get ftype of node
                s1 = st.nextToken();
                ftype = Integer.parseInt(s1);
                
                //get sftype of node
                s1 = st.nextToken();
                sftype = Integer.parseInt(s1);
                
                //get sftype of node
                s1 = st.nextToken();
                modified_gen = Integer.parseInt(s1);
        }
        
        /** Deep copy module node constructor */
        public mNode(mNode n)
        {
                dup = null;
                activesum = 0;
                activation = 0;
                type = n.type;
                node_id = n.node_id;
                ftype = n.ftype;
                sftype = n.sftype;
                incoming_on = new Vector(3,0);
                outgoing_on = new Vector(3,0);
                incoming_off = new Vector(3,0);
                outgoing_off = new Vector(3,0);
                modified_gen = n.modified_gen;
        }
        
        /** mutate_add_node */
        public mNode( int id, int t, int ft, int sft, int gen)
        {
                dup = null;
                activesum = 0;
                activation = 0;
                type = t;
                node_id = id;
                ftype = ft;
                sftype = sft;
                incoming_on = new Vector(3,0);
                outgoing_on = new Vector(3,0);
                incoming_off = new Vector(3,0);
                outgoing_off = new Vector(3,0);
                modified_gen = gen;
        }
        
        public void print_to_file(IOseq xFile)
        {
                
                StringBuffer s2 = new StringBuffer("");
                
                s2.append("node ");
                s2.append(node_id);
                s2.append(" " + type);
                s2.append(" " + ftype);
                s2.append(" " + sftype);
                s2.append(" " + modified_gen);
                
                xFile.IOseqWrite(s2.toString());
                
        }
        
        
}

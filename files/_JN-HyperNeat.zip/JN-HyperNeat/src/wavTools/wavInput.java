
package wavTools;
import java.io.*;

/**
 *
 * @author Jingtian Yu
 */
public class wavInput
{
        /** used for writing data */
        FileInputStream fi;
        BufferedInputStream bi;
        DataInputStream wavin;
        
        /** Number of channels, Mono: 1, Stereo: 2 */
        int NumCh;
        /** Sampling rate */
        int SampRate;
        /** Bits per sample */
        int BitsSamp;
        /** Actual wave size in bytes */
        int DataSize;
        /** number of samples to read from wave file for each frame */
        int FrameSize;
        /** Total number of frames */
        //int NumFrame;
        /** a frame of wave data from the left channel*/
        double[] LeftWave;
        /** a frame of wave data from the right channel*/
        double[] RightWave;
        /** a frame of wave data from merging left and right channel (or from mono channel wave file) */
        double[] MonoWave;
        /** number of samples in FFT frequency domain (real, imaginary)*/
        int FreqFrame;
        int FreqFramePow2;
        /** Magnitude of the frequencies (FFT), amplitude is scale logrithmically, range [0, 1] */
        double[] LogMag;
        /** folder path of the wave file */
        String path;
        /** if we have reached the end of the wave file */
        boolean EOF;
        
        int NumFrame;
        
        public wavInput(String filepath, int size, int bits) throws IOException, InterruptedException
        {
                path = filepath;
                EOF = false;
                
                fi = new FileInputStream(filepath);
                bi = new BufferedInputStream(fi);
                wavin = new DataInputStream(bi);
                
                wavin.skipBytes(22);
                NumCh = readShort();
                SampRate = readInt();
                wavin.skipBytes(6);
                BitsSamp = readShort();
                
                //Wave File Info
                //System.out.println(NumCh);
                //System.out.println(SampRate);
                //System.out.println(BitsSamp);
                
                //DATA BEGINS
                int[] sData;
                sData = new int[4];
                
                sData[0] = wavin.readByte();
                sData[1] = wavin.readByte();
                sData[2] = wavin.readByte();
                sData[3] = wavin.readByte();
                
                if ( (sData[0] == 100) && (sData[1] == 97) && (sData[2] == 116) && (sData[3] == 97))
                {
                        //System.out.println("Wave data found");
                }
                else
                {
                        System.out.println(" Wave file head might be corrupt        " + path);
                }
                
                //Wave data size in bytes
                DataSize = readInt();
                //System.out.println(DataSize);
                
                // Tempo = 646;
                FrameSize = size;
                FreqFramePow2 = bits;
                FreqFrame = MathTools.Pow2Int(bits);
                NumFrame = DataSize/(FrameSize*(BitsSamp/8)*(NumCh));
        }
        
        
        /**Skip to seconds of the song for some seconds */
        public void skip_frames(int fr)
        {
                try
                {
                        wavin.skipBytes( FrameSize*(BitsSamp/8)*(NumCh) * fr);
                }
                catch(EOFException eof)
                {
                        EOF = true;
                        //System.out.println("End of wave file" + path);
                }
                catch(IOException e)
                {
                        System.out.println("Error in skip_seconds " + path);
                        System.out.println(e.toString());
                }
        }        
        
        
        
        /**Skip to seconds of the song for some seconds */
        public boolean skip_seconds(double skip_time)
        {
                try
                {
                        wavin.skipBytes( (int) (BitsSamp*NumCh*SampRate/8*(skip_time)) );
                }
                catch(EOFException eof)
                {
                        EOF = true;
                        //System.out.println("End of wave file" + path);
                        return false;
                }
                catch(IOException e)
                {
                        System.out.println("Error in skip_seconds " + path);
                        System.out.println(e.toString());
                        return false;
                }
                return true;
        }
        
        
        
        /** read actual waveform for some seconds */
        public boolean read_wave(int Tempo, boolean MonoOnly, boolean do_hanning)
        {
                //NumFrame = (int) (DataSize/(FrameSize*(BitsSamp/8)*(NumCh)));
                // Tempo = 646;
                // FrameSize = 4096*(SampRate/44100)*(646/Tempo);
                
                //Read a frame of wave samples into a 2-d double array
                
                if ( (BitsSamp == 16) && (NumCh == 2) && MonoOnly)
                {
                        MonoWave = new double[FrameSize];
                        
                        for (int i=0; i<= (FrameSize -1); i++)
                        {
                                try
                                {
                                        double left = (double)readShort();
                                        double right = (double)readShort();
                                        MonoWave[i] = (left+right)/65536;
                                }
                                catch(EOFException eof)
                                {
                                        EOF = true;
                                        System.out.println("End of wave file " + path);
                                        System.out.println(i + " last samples not processed");
                                        return false;
                                }
                                catch(IOException e)
                                {
                                        System.out.println("Error in read_wave " + path);
                                        System.out.println(e.toString());
                                        return false;
                                }
                        }
                        
                        //Perform FFT with 2^16 samples in frequency space, then compute magnitude with log scaled amplitude
                        FFT(do_hanning);
                }
                else if ( (BitsSamp == 16) && (NumCh == 2) && !MonoOnly)
                {
                        LeftWave = new double[FrameSize];
                        RightWave = new double[FrameSize];
                        
                        for (int i=0; i<= (FrameSize -1); i++)
                        {
                                try
                                {
                                        LeftWave[i] = ((double)readShort())/32768;
                                        RightWave[i] = ((double)readShort())/32768;
                                        MonoWave[i] = (LeftWave[i]+RightWave[i])/32768;
                                }
                                catch(EOFException eof)
                                {
                                        EOF = true;
                                        return false;
                                }
                                catch(IOException e)
                                {
                                        System.out.println("Error in read_wave " + path);
                                        System.out.println(e.toString());
                                        return false;
                                }
                        }
                }
                else if ( (BitsSamp == 16) && (NumCh == 1))
                {
                        MonoWave = new double[FrameSize];
                        
                        for (int i=0; i<= (FrameSize -1); i++)
                        {
                                try
                                {
                                        MonoWave[i] = ((double)readShort())/32768;
                                }
                                catch(EOFException eof)
                                {
                                        EOF = true;
                                        // System.out.println("End of wave file" + path);
                                        return false;
                                }
                                catch(IOException e)
                                {
                                        System.out.println("Error in read_wave " + path);
                                        System.out.println(e.toString());
                                        return false;
                                }
                        }
                }
                else
                {
                        System.out.println(path + " is not 16bit mono or stereo");
                        System.exit(1);
                }
                return true;
        }
        
        
        /** Compute fast fourier transform */
        public void FFT(boolean do_hanning)
        {
                double[] real_f = null;
                double[] img_f = null;
                
                // Zero-padding of Real Input to desireble Frame size.
                if ( MonoWave.length < FreqFrame )
                {
                        real_f = new double[FreqFrame];
                        for (int i = 0; i < MonoWave.length; i++)
                        {
                                real_f[i] = MonoWave[i];
                        }
                        for (int i = MonoWave.length; i < FreqFrame; i++)
                        {
                                real_f[i] = 0;
                        }
                }
                
                if ( MonoWave.length > FreqFrame )
                {
                        System.out.println("Specified FFT Array size ( " + FreqFrame + ") is smaller real input array");
                        System.exit(1);
                }
                
                //Creates a zero filled imaginary component of the input if none was specified.
                if (img_f == null)
                {
                        img_f = new double[FreqFrame];
                        for (int i = 0; i < FreqFrame; i++)
                        {
                                img_f[i] = 0;
                        }
                }
                
                // apply hanning window
                if (do_hanning)
		{
                        for (int i = 0; i < real_f.length; i++) 
                        {
                                double hanning = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / FreqFrame);
                                real_f[i] *= hanning;
                        }
		}
                
                // Reorder the input data into reverse binary order
                int HalfF = FreqFrame >> 1;
                int j = HalfF;
                for (int i = 1; i < FreqFrame-1; ++i)
                {
                        if (j > i)
                        {
                                double tempr = real_f[j];
                                double tempi = img_f[j];
                                real_f[j] = real_f[i];
                                img_f[j] = img_f[i];
                                real_f[i] = tempr;
                                img_f[i] = tempi;
                        }
                        int m = HalfF;
                        while (j >= m)
                        {
                                j -= m;
                                m >>= 1;
                        }
                        j += m;
                }
                
                
                
                // Perform the spectral recombination stage by stage
                int le;
                int leh;
                double angle;
                double ur;
                double ui;
                double sr;
                double si;
                double tr;
                double ti;
                int right;
                
                for( int l = 0; l < FreqFramePow2; l++)
                {
                        leh = MathTools.Pow2Int(l);
                        le = leh << 1;
                        angle = Math.PI / leh;
                        ur = 1;
                        ui = 0;
                        sr = Math.cos(angle);
                        si = - Math.sin(angle);
                        
                        // Loop once for each individual spectra
                        for (int k = 0; k < leh ; k++)
                        {
                                for (int left = k; left < FreqFrame; left += le )
                                {
                                        right = left + leh;
                                        tr = ur * real_f[right] -
                                                ui * img_f[right];
                                        ti = ur * img_f[right] +
                                                ui * real_f[right];
                                        real_f[right] = real_f[left] - tr;
                                        img_f[right] = img_f[left] - ti;
                                        real_f[left] += tr;
                                        img_f[left] += ti;
                                }
                                tr = ur;
                                ur = tr * sr - ui * si;
                                ui = tr * si + ui * sr;
                        }
                }
                
                //Compute and scale log Magnitude Spectrum
                LogMag = new double[HalfF];
                for(int i = 0; i < HalfF; i++)
                {
                        LogMag[i] = (Math.log(real_f[i] * real_f[i] + img_f[i] * img_f[i]) + 14.5)/1.6;
                }
                
        }
        
        /** used to read 16bits sample data **/
        public int readShort() throws EOFException, IOException
        {
                int a, b;
                a = wavin.readByte();
                
                //Prevents sign extention
                a = 255 & a;
                
                //Needed sign extension for negative value sample at 16bit
                b = wavin.readByte();
                return ( b << 8 ) | a;
        }
        
        /** used to read 32bits data in the file header **/
        public int readInt() throws EOFException, IOException
        {
                int a, b, c, d;
                a = wavin.readByte();
                a = 255 & a;
                
                b = wavin.readByte();
                b = 255 & b;
                
                c = wavin.readByte();
                c = 255 & c;
                
                d = wavin.readByte();
                d = 255 & d;
                return ( d << 24 ) | ( c << 16 ) | ( b << 8 ) | a;
        }
        
        public void closeR()
        {
                try
                {
                        wavin.close();
                        bi.close();
                        fi.close();
                }
                catch(Exception e)
                {
                        System.out.println("Error when close reading file " + path);
                        System.out.println(e.toString());
                }

        }
}

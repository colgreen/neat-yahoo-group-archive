
package wavTools;

/**
 *
 * @author GABA
 */
public class MathTools {
        public static int Pow2Int(int x)
        {
                int y = 1;
                for(int i = 0; i < x; i++)
                {
                        y  <<= 1;
                }
                return y;
        }
}

package wavTools;

import java.io.*;
/**
 *
 * @author GABA
 */
public class Converter {
    
        public static void main(String[] args)
        {
                int total = 16; // number of frame to convert;
                
                //load inputs from wavefiles and evaluate
                File folder = new File("InputWavs");
                String[] wavs = folder.list();
                
                int i_size = wavs.length;
                for(int i = 0; i < i_size; i++)
                {
                        System.out.println("Processing file " + wavs[i]);
                        
                        try
                        {
                                wavInput _wavIn = new wavInput("InputWavs\\" + wavs[i], 4096, 18);
                                fftOutput _fftOut = new fftOutput( "FFTs\\" + wavs[i].substring(0, wavs[i].length()-4), 131072, _wavIn.SampRate >>1, total , 16 );
                                
                                // for debugging, and skipping over bad head to actual wav data
                                //_wavIn.skip_frames(1);
                                int n = 0;
                                while( n < total && !_wavIn.EOF)
                                {
                                        if(_wavIn.read_wave(646, true, true));
                                        {
                                                _fftOut.write_frame(_wavIn.LogMag);
                                                n++;
                                        }
                                }
                                
                                // for debugging
                                System.out.println("    FFT frame: " + _fftOut.freq_frame);
                                System.out.println("    Wav sampling rate: " + _fftOut.samp_rate);
                                System.out.println("    Total FFT frame " + n + "/" + total);
                                System.out.println("    logFFT frame size: " + _fftOut.frame_size);
                                
                                _wavIn.closeR();
                                _fftOut.closeW();
                        }
                        catch(IOException e1)
                        {
                                System.out.println("Error when processing wav file " + wavs[i]);
                                System.out.println(e1.toString());
                                
                        }
                        catch(InterruptedException e2)
                        {
                                System.out.println("Error when processing wav file " + wavs[i]);
                                System.out.println(e2.toString());
                        }
                }
        }
        
}

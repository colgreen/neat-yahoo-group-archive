
package wavTools;
import java.io.*;
/**
 *
 * @author GABA
 */
public class fftOutput {
        
        /** used to data to file */
        FileOutputStream fo;
        BufferedOutputStream bo;
        DataOutputStream fftout;
        
        /** the path of the file we are writing in */
        String filepath;
        
        /** number of samples in each fft */
        int freq_frame;
        
        /** sampling rate per second in the original wav file, 22050 usually */
        int samp_rate;
        
        /** number of frequencies between two half step pitches */
        int bin_per_pitch;
        
        /** the size of a log-sampled frequency frame */
        int frame_size;
        
        /** total number of FFTs */
        int frame_tot;
        
        /** an array of frequency indexes that we use to sample FFT */
        int[] freq_index;
        
        public fftOutput(String path, int size, int rate, int tot, int bin) throws IOException, InterruptedException
        {
                filepath = path + ".fft";
                fo = new FileOutputStream(filepath);
                bo = new BufferedOutputStream(fo);
                fftout = new DataOutputStream(bo);
                
                freq_frame = size;
                samp_rate = rate;
                frame_tot = tot;
                
                fftout.writeInt(freq_frame);
                fftout.writeInt(samp_rate);
                fftout.writeInt(frame_tot);
                
                bin_per_pitch = bin;
                fftout.writeInt(bin_per_pitch);
                
                int low = 10 * bin_per_pitch;
                int high = 136 * bin_per_pitch;
                
                frame_size = high - low;
                fftout.writeInt(frame_size);
                
                freq_index = new int[frame_size];
                int n=0;
                for(double pp = low; pp < high; pp++)
                {
                        // derived from http://en.wikipedia.org/wiki/Pitch_(music)
                        // pitch_shift range [-.5, .5]
                        freq_index[n] = (int) ( Math.pow(2, ( pp / bin_per_pitch - 69.0) / 12.0 ) * 440.0 / samp_rate * freq_frame + .5 );
                        n++;
                }
        }
        
        /** writing log-magnitude fft into 16bits data */
        public void write_frame(double[] fft)
        {
                if(fft.length != freq_frame)
                {
                        System.out.println("Warning: writing non-default size fft to file " + filepath);
                }
                
                try
                {
                        for (int i = 0; i < frame_size; i++)
                        {
                                if(fft[freq_index[i]] <= 0)
                                {
                                        fftout.writeShort(-32768);
                                }
                                else if(fft[freq_index[i]] >= 10)
                                {
                                        fftout.writeShort(32767);
                                }
                                else
                                {
                                        int sh = (int) (fft[freq_index[i]] / 10.0 * 65535 - 32767.5 );
                                        fftout.writeShort(sh);
                                }
                        }
                }
                catch(IOException e)
                {
                        System.out.println("Error in writing to file " + filepath);
                }
        }
        
        public void closeW()
        {
                try
                {
                        fftout.close();
                        bo.close();
                        fo.close();
                }
                catch (Exception e)
                {
                        System.out.println("Error when close writing file " + filepath);
                        System.out.println(e.toString());
                }
        }
}

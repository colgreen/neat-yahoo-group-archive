#include "experiments.h"

#define NO_SCREEN_OUT 

//Perform evolution on XOR, for gens generations
Population *xor_test(int gens) {
    Population *pop;
    Genome *start_genome;
    char curword[20];
    int id;
	
    ostrstream *fnamebuf;
    int gen;
	
    int evals[NEAT::num_runs];  //Hold records for each run
    int genes[NEAT::num_runs];
    int nodes[NEAT::num_runs];
    int winnernum;
    int winnergenes;
    int winnernodes;
    //For averaging
    int totalevals=0;
    int totalgenes=0;
    int totalnodes=0;
    int expcount;
	
    ifstream iFile("xorstartgenes",ios::in);
	
    cout<<"START XOR TEST"<<endl;
	
    cout<<"Reading in the start genome"<<endl;
    //Read in the start Genome
    iFile>>curword;
    iFile>>id;
    cout<<"Reading in Genome id "<<id<<endl;
    start_genome=new Genome(id,iFile);
    iFile.close();
	
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		//Spawn the Population
		cout<<"Spawning Population off Genome2"<<endl;
		
		pop=new Population(start_genome,NEAT::pop_size);
		
		cout<<"Verifying Spawned Pop"<<endl;
		pop->verify();
		
		for (gen=1;gen<=gens;gen++) {
			cout<<"Epoch "<<gen<<endl;	
			
			//This is how to make a custom filename
			fnamebuf=new ostrstream();
			(*fnamebuf)<<"gen_"<<gen<<ends;  //needs end marker
			
#ifndef NO_SCREEN_OUT
			cout<<"name of fname: "<<fnamebuf->str()<<endl;
#endif
			
			//Check for success
			if (xor_epoch(pop,gen,fnamebuf->str(),winnernum,winnergenes,winnernodes)) {
				//Collect Stats on end of experiment
				evals[expcount]=NEAT::pop_size*(gen-1)+winnernum;
				genes[expcount]=winnergenes;
				nodes[expcount]=winnernodes;
				gen=gens;
				
			}
			
			//Clear output filename
			fnamebuf->clear();
			delete fnamebuf;
			
		}
		
		if (expcount<NEAT::num_runs-1) delete pop;
		
    }
	
    //Average and print stats
    cout<<"Nodes: "<<endl;
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		cout<<nodes[expcount]<<endl;
		totalnodes+=nodes[expcount];
    }
    
    cout<<"Genes: "<<endl;
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		cout<<genes[expcount]<<endl;
		totalgenes+=genes[expcount];
    }
    
    cout<<"Evals "<<endl;
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		cout<<evals[expcount]<<endl;
		totalevals+=evals[expcount];
    }
	
    cout<<"Average Nodes: "<<((double) totalnodes/NEAT::num_runs)<<endl;
    cout<<"Average Genes: "<<((double) totalgenes/NEAT::num_runs)<<endl;
    cout<<"Average Evals: "<<((double) totalevals/NEAT::num_runs)<<endl;
    return pop;
	
}

bool xor_evaluate(Organism *org) {
	Network *net;
	double out[4]; //The four outputs
	double this_out; //The current output
	int count;
	double errorsum;
	
	bool success;  //Check for successful activation
				   int numnodes;  /* Used to figure out how many nodes
				   should be visited during activation */
				   
				   int net_depth; //The max depth of the network to be activated
				   int relax; //Activates until relaxation
				   
				   //The four possible input combinations to xor
				   //The first number is for biasing
				   double in[4][3]={{1.0,0.0,0.0},
				   {1.0,0.0,1.0},
				   {1.0,1.0,0.0},
				   {1.0,1.0,1.0}};
				   
				   net=org->net;
				   numnodes=((org->gnome)->nodes).size();
				   
				   net_depth=net->max_depth();
				   
				   //TEST CODE: REMOVE
				   //cout<<"ACTIVATING: "<<org->gnome<<endl;
				   //cout<<"DEPTH: "<<net_depth<<endl;
				   
				   //Load and activate the network on each input
				   for(count=0;count<=3;count++) {
					   net->load_sensors(in[count]);
					   
					   //Relax net and get output
					   success=net->activate();
					   
					   //use depth to ensure relaxation
					   for (relax=0;relax<=net_depth;relax++) {
						   success=net->activate();
						   this_out=(*(net->outputs.begin()))->activation;
					   }
					   
					   out[count]=(*(net->outputs.begin()))->activation;
					   
					   net->flush();
					   
				   }
				   
				   if (success) {
					   errorsum=(fabs(out[0])+fabs(1.0-out[1])+fabs(1.0-out[2])+fabs(out[3]));
					   org->fitness=pow((4.0-errorsum),2);
					   org->error=errorsum;
				   }
				   else {
					   //The network is flawed (shouldnt happen)
					   errorsum=999.0;
					   org->fitness=0.001;
				   }
				   
#ifndef NO_SCREEN_OUT
				   cout<<"Org "<<(org->gnome)->genome_id<<"                                     error: "<<errorsum<<"  ["<<out[0]<<" "<<out[1]<<" "<<out[2]<<" "<<out[3]<<"]"<<endl;
				   cout<<"Org "<<(org->gnome)->genome_id<<"                                     fitness: "<<org->fitness<<endl;
#endif
				   
				   //  if (errorsum<0.05) { 
				   //if (errorsum<0.2) {
				   if ((out[0]<0.5)&&(out[1]>=0.5)&&(out[2]>=0.5)&&(out[3]<0.5)) {
					   org->winner=true;
					   return true;
				   }
				   else {
					   org->winner=false;
					   return false;
				   }
				   
}

int xor_epoch(Population *pop,int generation,char *filename,int &winnernum,int &winnergenes,int &winnernodes) {
	list<Organism*>::iterator curorg;
	list<Species*>::iterator curspecies;
	
	bool win=false;
	
	
	//Evaluate each organism on a test
	for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
		if (xor_evaluate(*curorg)) {
			win=true;
			winnernum=(*curorg)->gnome->genome_id;
			winnergenes=(*curorg)->gnome->extrons();
			winnernodes=((*curorg)->gnome->nodes).size();
			if (winnernodes==5) {
				//You could dump out optimal genomes here if desired
				//(*curorg)->gnome->print_to_filename("xor_optimal");
				//cout<<"DUMPED OPTIMAL"<<endl;
			}
		}
	}
	
	//Average and max their fitnesses for dumping to file and snapshot
	for(curspecies=(pop->species).begin();curspecies!=(pop->species).end();++curspecies) {
		
		//This experiment control routine issues commands to collect ave
		//and max fitness, as opposed to having the snapshot do it, 
		//because this allows flexibility in terms of what time
		//to observe fitnesses at
		
		(*curspecies)->compute_average_fitness();
		(*curspecies)->compute_max_fitness();
	}
	
	//Take a snapshot of the population, so that it can be
	//visualized later on
	if ((generation%1)==0)
		pop->snapshot();
	
	//Only print to file every print_every generations
	if  (win||
		((generation%(NEAT::print_every))==0))
		pop->print_to_file_by_species(filename);
	
	
	if (win) {
		for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
			if ((*curorg)->winner) {
				cout<<"WINNER IS #"<<((*curorg)->gnome)->genome_id<<endl;
				//Prints the winner to file
				//IMPORTANT: This causes generational file output!
				print_Genome_tofile((*curorg)->gnome,"xor_winner");
			}
		}
		
	}
	
	pop->epoch(generation);
	
	if (win) return 1;
	else return 0;
	
}

//Perform evolution on single pole balacing, for gens generations
Population *pole1_test(int gens) {
    Population *pop;
    Genome *start_genome;
    char curword[20];
    int id;
	
    ostrstream *fnamebuf;
    int gen;
    int pause;
	
    int expcount;
    int status;
    int runs[NEAT::num_runs];
    int totalevals;
	
    ifstream iFile("pole1startgenes",ios::in);
	
    cout<<"START SINGLE POLE BALANCING EVOLUTION"<<endl;
	
    cout<<"Reading in the start genome"<<endl;
    //Read in the start Genome
    iFile>>curword;
    iFile>>id;
    cout<<"Reading in Genome id "<<id<<endl;
    start_genome=new Genome(id,iFile);
    iFile.close();
	
    //Run multiple experiments
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		
		cout<<"EXPERIMENT #"<<expcount<<endl;
		
		cout<<"Start Genome: "<<start_genome<<endl;
		
		//Spawn the Population
		cout<<"Spawning Population off Genome"<<endl;
		
		pop=new Population(start_genome,NEAT::pop_size);
		
		cout<<"Verifying Spawned Pop"<<endl;
		pop->verify();
		
		for (gen=1;gen<=gens;gen++) {
			cout<<"Generation "<<gen<<endl;
			
			fnamebuf=new ostrstream();
			(*fnamebuf)<<"gen_"<<gen<<ends;  //needs end marker
			
#ifndef NO_SCREEN_OUT
			cout<<"name of fname: "<<fnamebuf->str()<<endl;
#endif
			
			status=(pole1_epoch(pop,gen,fnamebuf->str()));
			
			if (status) {
				runs[expcount]=status;
				gen=gens+1;
			}
			
			fnamebuf->clear();
			delete fnamebuf;
			
		}
		
    }
	
    totalevals=0;
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		cout<<runs[expcount]<<endl;
		totalevals+=runs[expcount];
    }
    cout<<"Average evals: "<<totalevals/NEAT::num_runs<<endl;
	
    return pop;
	
}

int pole1_epoch(Population *pop,int generation,char *filename) {
	list<Organism*>::iterator curorg;
	list<Species*>::iterator curspecies;
	
	bool win=false;
	int winnernum;
	
	//Evaluate each organism on a test
	for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
		if (pole1_evaluate(*curorg)) win=true;
	}
	
	//Average and max their fitnesses for dumping to file and snapshot
	for(curspecies=(pop->species).begin();curspecies!=(pop->species).end();++curspecies) {
		
		//This experiment control routine issues commands to collect ave
		//and max fitness, as opposed to having the snapshot do it, 
		//because this allows flexibility in terms of what time
		//to observe fitnesses at
		
		(*curspecies)->compute_average_fitness();
		(*curspecies)->compute_max_fitness();
	}
	
	//Take a snapshot of the population, so that it can be
	//visualized later on
	if ((generation%1)==0)
		pop->snapshot();
	
	//Only print to file every print_every generations
	if  (win||
		((generation%(NEAT::print_every))==0))
		pop->print_to_file_by_species(filename);
	
	if (win) {
		for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
			if ((*curorg)->winner) {
				winnernum=((*curorg)->gnome)->genome_id;
				cout<<"WINNER IS #"<<((*curorg)->gnome)->genome_id<<endl;
			}
		}    
	}
	
	//Create the next generation
	pop->epoch(generation);
	
	if (win) return ((generation-1)*NEAT::pop_size+winnernum);
	else return 0;
	
}

bool pole1_evaluate(Organism *org) {
	Network *net;
	
	int numnodes;  /* Used to figure out how many nodes
	should be visited during activation */
	int thresh;  /* How many visits will be allowed before giving up 
		  (for loop detection) */
	
	//  int MAX_STEPS=120000;
	int MAX_STEPS=100000;
	
	net=org->net;
	numnodes=((org->gnome)->nodes).size();
	thresh=numnodes*2;  //Max number of visits allowed per activation
	
	//Try to balance a pole now
	org->fitness = go_cart(net,MAX_STEPS,thresh);
	
#ifndef NO_SCREEN_OUT
	cout<<"Org "<<(org->gnome)->genome_id<<" fitness: "<<org->fitness<<endl;
#endif
	
	//Decide if its a winner
	if (org->fitness>=MAX_STEPS) { 
		org->winner=true;
		return true;
	}
	else {
		org->winner=false;
		return false;
	}
	
}

//     cart_and_pole() was take directly from the pole simulator written
//     by Richard Sutton and Charles Anderson.
int go_cart(Network *net,int max_steps,int thresh)
{
	float x,			/* cart position, meters */
		x_dot,			/* cart velocity */
		theta,			/* pole angle, radians */
		theta_dot;		/* pole angular velocity */
	int steps=0,y;
	
	int random_start=1;
	
	double in[5];  //Input loading array
	
	double out1;
	double out2;
	
	double one_degree= 0.0174532;	/* 2pi/360 */
	double six_degrees=0.1047192;
	double twelve_degrees=0.2094384;
	double thirty_six_degrees= 0.628329;
	double fifty_degrees=0.87266;
	
	list<NNode*>::iterator out_iter;
	
	if (random_start) {
		/*set up random start state*/
		x = (lrand48()%4800)/1000.0 - 2.4;
		x_dot = (lrand48()%2000)/1000.0 - 1;
		theta = (lrand48()%400)/1000.0 - .2;
		theta_dot = (lrand48()%3000)/1000.0 - 1.5;
    }
	else 
		x = x_dot = theta = theta_dot = 0.0;
	
	/*--- Iterate through the action-learn loop. ---*/
	while (steps++ < max_steps)
	{
		
		/*-- setup the input layer based on the four iputs --*/
		//setup_input(net,x,x_dot,theta,theta_dot);
		in[0]=1.0;  //Bias
		in[1]=(x + 2.4) / 4.8;;
		in[2]=(x_dot + .75) / 1.5;
		in[3]=(theta + twelve_degrees) / .41;
		in[4]=(theta_dot + 1.0) / 2.0;
		net->load_sensors(in);
		
		//activate_net(net);   /*-- activate the network based on the input --*/
		//Activate the net
		//If it loops, exit returning only fitness of 1 step
		if (!(net->activate())) return 1;
		
		/*-- decide which way to push via which output unit is greater --*/
		out_iter=net->outputs.begin();
		out1=(*out_iter)->activation;
		++out_iter;
		out2=(*out_iter)->activation;
		if (out1 > out2)
			y = 0;
		else
			y = 1;
		
		/*--- Apply action to the simulated cart-pole ---*/
		cart_pole(y, &x, &x_dot, &theta, &theta_dot);
		
		/*--- Check for failure.  If so, return steps ---*/
		if (x < -2.4 || x > 2.4  || theta < -twelve_degrees ||
			theta > twelve_degrees) 
			return steps;             
	}
	
	return steps;
} 


//     cart_and_pole() was take directly from the pole simulator written
//     by Richard Sutton and Charles Anderson.
//     This simulator uses normalized, continous inputs instead of 
//    discretizing the input space.
/*----------------------------------------------------------------------
cart_pole:  Takes an action (0 or 1) and the current values of the
four state variables and updates their values by estimating the state
TAU seconds later.
----------------------------------------------------------------------*/
int cart_pole(int action, float *x,float *x_dot, float *theta, float *theta_dot) {
	float xacc,thetaacc,force,costheta,sintheta,temp;
	
	const float GRAVITY=9.8;
	const float MASSCART=1.0;
	const float MASSPOLE=0.1;
	const float TOTAL_MASS=(MASSPOLE + MASSCART);
	const float LENGTH=0.5;	  /* actually half the pole's length */
	const float POLEMASS_LENGTH=(MASSPOLE * LENGTH);
	const float FORCE_MAG=10.0;
	const float TAU=0.02;	  /* seconds between state updates */
	const float FOURTHIRDS=1.3333333333333;
	
	force = (action>0)? FORCE_MAG : -FORCE_MAG;
	costheta = cos(*theta);
	sintheta = sin(*theta);
	
	temp = (force + POLEMASS_LENGTH * *theta_dot * *theta_dot * sintheta)
		/ TOTAL_MASS;
	
	thetaacc = (GRAVITY * sintheta - costheta* temp)
		/ (LENGTH * (FOURTHIRDS - MASSPOLE * costheta * costheta
		/ TOTAL_MASS));
	
	xacc  = temp - POLEMASS_LENGTH * thetaacc* costheta / TOTAL_MASS;
	
	/*** Update the four state variables, using Euler's method. ***/
	
	*x  += TAU * *x_dot;
	*x_dot += TAU * xacc;
	*theta += TAU * *theta_dot;
	*theta_dot += TAU * thetaacc;
}

/* ------------------------------------------------------------------ */
/* Double pole balacing                                               */
/* ------------------------------------------------------------------ */

//Perform evolution on double pole balacing, for gens generations
//If velocity is false, then velocity information will be withheld from the 
//network population (non-Markov)
Population *pole2_test(int gens,int velocity) {
    Population *pop;
    Genome *start_genome;
    char curword[20];
    int id;
	
    ostrstream *fnamebuf;
    int gen;
    int pause;
    CartPole *thecart;
	
    //Stat collection variables
    int highscore;
    int record[NEAT::num_runs][1000];
    double recordave[1000];
    int genesrec[NEAT::num_runs][1000];
    double genesave[1000];
    int nodesrec[NEAT::num_runs][1000];
    double nodesave[1000];
    int winnergens[NEAT::num_runs];
    int initcount;
    int champg, champn, winnernum;  //Record number of genes and nodes in champ
    int run;
    int curtotal; //For averaging
    int samples;  //For averaging
	
    ofstream oFile("statout",ios::out);
	
    champg=0;
    champn=0;
	
    //Initialize the stat recording arrays
    for (initcount=0;initcount<200;initcount++) {
		recordave[initcount]=0;
		genesave[initcount]=0;
		nodesave[initcount]=0;
		for (run=0;run<NEAT::num_runs;++run) {
			record[run][initcount]=0;
			genesrec[run][initcount]=0;
			nodesrec[run][initcount]=0;
		}
    }
	
    ifstream iFile("pole2startgenes",ios::in);
	
    cout<<"START DOUBLE POLE BALANCING EVOLUTION"<<endl;
    if (!velocity)
		cout<<"NO VELOCITY INPUT"<<endl;
	
    cout<<"Reading in the start genome"<<endl;
    //Read in the start Genome
    iFile>>curword;
    iFile>>id;
    cout<<"Reading in Genome id "<<id<<endl;
    start_genome=new Genome(id,iFile);
    iFile.close();
	
    cout<<"Start Genome: "<<start_genome<<endl;
	
    cin>>pause;  
	
    for (run=0;run<NEAT::num_runs;run++) {
		
		cout<<"RUN #"<<run<<endl;
		
		//Spawn the Population from starter gene
		cout<<"Spawning Population off Genome"<<endl;
		pop=new Population(start_genome,NEAT::pop_size);
		
		//Alternative way to start off of randomly connected genomes
		//pop=new Population(pop_size,7,1,10,false,0.3);
		
		cout<<"Verifying Spawned Pop"<<endl;
		pop->verify();
		
		//Create the Cart
		thecart=new CartPole(true,velocity);
		
		for (gen=1;gen<=gens;gen++) {
			cout<<"Epoch "<<gen<<endl;
			
			fnamebuf=new ostrstream();
			(*fnamebuf)<<"gen_"<<gen<<ends;  //needs end marker
#ifndef NO_SCREEN_OUT
			cout<<"name of fname: "<<fnamebuf->str()<<endl;
#endif
			
			highscore=pole2_epoch(pop,gen,fnamebuf->str(),velocity, thecart,champg,champn,winnernum,oFile);  
			
			cout<<"GOT HIGHSCORE FOR GEN "<<gen<<": "<<highscore-1<<endl;
			
			record[run][gen-1]=highscore-1;
			genesrec[run][gen-1]=champg;
			nodesrec[run][gen-1]=champn;
			
			fnamebuf->clear();
			delete fnamebuf;
			
			//Stop right at the winnergen
			if (((pop->winnergen)!=0)&&(gen==(pop->winnergen))) {
				winnergens[run]=NEAT::pop_size*(gen-1)+winnernum;
				gen=gens+1;
			}
			
			//In non-MARKOV, stop right at winning (could go beyond if desired)
			if ((!(thecart->MARKOV))&&((pop->winnergen)!=0))
				gen=gens+1;
			
#ifndef NO_SCREEN_OUT
			cout<<"gen = "<<gen<<" gens = "<<gens<<endl;
#endif
			
			if (gen==(gens-1)) oFile<<"FAIL: Last gen on run "<<run<<endl;
			
			
		}
		
		if (run<NEAT::num_runs-1) delete pop;
		delete thecart;
		
    }
	
    cout<<"Generation highs: "<<endl;
    oFile<<"Generation highs: "<<endl;
    for(gen=0;gen<=gens-1;gen++) {
		curtotal=0;
		for (run=0;run<NEAT::num_runs;++run) {
			if (record[run][gen]>0) {
				cout<<setw(8)<<record[run][gen]<<" ";
				oFile<<setw(8)<<record[run][gen]<<" ";
				curtotal+=record[run][gen];
			}
			else {
				cout<<"         ";
				oFile<<"         ";
				curtotal+=100000;
			}
			recordave[gen]=(double) curtotal/NEAT::num_runs;
			
		}
		cout<<endl;
		oFile<<endl;
    }
	
    cout<<"Generation genes in champ: "<<endl;
    for(gen=0;gen<=gens-1;gen++) {
		curtotal=0;
		samples=0;
		for (run=0;run<NEAT::num_runs;++run) {
			if (genesrec[run][gen]>0) {
				cout<<setw(4)<<genesrec[run][gen]<<" ";
				oFile<<setw(4)<<genesrec[run][gen]<<" ";
				curtotal+=genesrec[run][gen];
				samples++;
			}
			else {
				cout<<setw(4)<<"     ";
				oFile<<setw(4)<<"     ";
			}
		}
		genesave[gen]=(double) curtotal/samples;
		
		cout<<endl;
		oFile<<endl;
    }
	
    cout<<"Generation nodes in champ: "<<endl;
    oFile<<"Generation nodes in champ: "<<endl;
    for(gen=0;gen<=gens-1;gen++) {
		curtotal=0;
		samples=0;
		for (run=0;run<NEAT::num_runs;++run) {
			if (nodesrec[run][gen]>0) {
				cout<<setw(4)<<nodesrec[run][gen]<<" ";
				oFile<<setw(4)<<nodesrec[run][gen]<<" ";
				curtotal+=nodesrec[run][gen];
				samples++;
			}
			else {
				cout<<setw(4)<<"     ";
				oFile<<setw(4)<<"     ";
			}
		}
		nodesave[gen]=(double) curtotal/samples;
		
		cout<<endl;
		oFile<<endl;
    }
	
    cout<<"Generational record fitness averages: "<<endl;
    oFile<<"Generational record fitness averages: "<<endl;
    for(gen=0;gen<gens-1;gen++) {
		cout<<recordave[gen]<<endl;
		oFile<<recordave[gen]<<endl;
    }
	
    cout<<"Generational number of genes in champ averages: "<<endl;
    oFile<<"Generational number of genes in champ averages: "<<endl;
    for(gen=0;gen<gens-1;gen++) {
		cout<<genesave[gen]<<endl;
		oFile<<genesave[gen]<<endl;
    }
	
    cout<<"Generational number of nodes in champ averages: "<<endl;
    oFile<<"Generational number of nodes in champ averages: "<<endl;
    for(gen=0;gen<gens-1;gen++) {
		cout<<nodesave[gen]<<endl;
		oFile<<nodesave[gen]<<endl;
    }
	
    cout<<"Winner evals: "<<endl;
    oFile<<"Winner evals: "<<endl;
    curtotal=0;
    samples=0;
    for (run=0;run<NEAT::num_runs;++run) {
		cout<<winnergens[run]<<endl;
		oFile<<winnergens[run]<<endl;
		curtotal+=winnergens[run];
		samples++;
    }
    cout<<"Average # evals: "<<((double) curtotal/samples)<<endl;
    oFile<<"Average # evals: "<<((double) curtotal/samples)<<endl;
	
    oFile.close();
	
    return pop;
	
}

//This is used for list sorting of Species by fitness of best organism
//highest fitness first
//Used to choose which organism to test
bool order_new_species(Species *x, Species *y) {
	
	return (x->compute_max_fitness() > 
		y->compute_max_fitness());
}

int pole2_epoch(Population *pop,int generation,char *filename,bool velocity,
				CartPole *thecart,int &champgenes,int &champnodes,
				int &winnernum, ofstream &oFile) {
	list<Organism*>::iterator curorg;
	list<Species*>::iterator curspecies;
	
	list<Species*> sorted_species;  //Species sorted by max fit org in Species
	
	int pause;
	bool win=false;
	
	double champ_fitness;
	Organism *champ;
	
	//double statevals[5]={-0.9,-0.5,0.0,0.5,0.9};
	double statevals[5]={0.05, 0.25, 0.5, 0.75, 0.95};
	
	int s0c,s1c,s2c,s3c;
	
	int score;
	
	thecart->nmarkov_long=false;
	thecart->generalization_test=false;
	
	//Evaluate each organism on a test
	for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
		
		//shouldn't happen
		if (((*curorg)->gnome)==0) {
			cout<<"ERROR EMPTY GEMOME!"<<endl;
			cin>>pause;
		}
		
		if (pole2_evaluate((*curorg),velocity,thecart)) win=true;
		
	}
	
	//Average and max their fitnesses for dumping to file and snapshot
	for(curspecies=(pop->species).begin();curspecies!=(pop->species).end();++curspecies) {
		
		//This experiment control routine issues commands to collect ave
		//and max fitness, as opposed to having the snapshot do it, 
		//because this allows flexibility in terms of what time
		//to observe fitnesses at
		
		(*curspecies)->compute_average_fitness();
		(*curspecies)->compute_max_fitness();
	}
	
	//Take a snapshot of the population, so that it can be
	//visualized later on
	if ((generation%1)==0)
		pop->snapshot();
	
	//Find the champion in the markov case simply for stat collection purposes
	if (thecart->MARKOV) {
		champ_fitness=0.0;
		for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
			if (((*curorg)->fitness)>champ_fitness) {
				champ=(*curorg);
				champ_fitness=champ->fitness;
				champgenes=champ->gnome->genes.size();
				champnodes=champ->gnome->nodes.size();
				winnernum=champ->gnome->genome_id;
			}
		}
	}
	
	//Check for winner in Non-Markov case
	if (!(thecart->MARKOV)) {
		
		//Sort the species
		for(curspecies=(pop->species).begin();curspecies!=(pop->species).end();++curspecies) {
			sorted_species.push_back(*curspecies);
		}
		sorted_species.sort(order_new_species);
		
		cout<<"Number of species sorted: "<<sorted_species.size()<<endl;
		
		//First update what is checked and unchecked
		for(curspecies=sorted_species.begin();curspecies!=sorted_species.end();++curspecies) {
			if (((*curspecies)->compute_max_fitness())>((*curspecies)->max_fitness_ever))
				(*curspecies)->checked=false;
			
		}
		
		//Now find a species that is unchecked
		curspecies=sorted_species.begin();
		cout<<"Is the first species checked? "<<(*curspecies)->checked<<endl;
		while((curspecies!=(sorted_species.end()))&&
			((*curspecies)->checked))
		{
			cout<<"Species #"<<(*curspecies)->id<<" is checked"<<endl;
			++curspecies;
		}
		
		if (curspecies==(sorted_species.end())) curspecies=sorted_species.begin();
		
		//Remember it was checked
		(*curspecies)->checked=true;
		cout<<"Is the species now checked? "<<(*curspecies)->checked<<endl;
		
		//Extract the champ
		cout<<"Champ chosen from Species "<<(*curspecies)->id<<endl;
		champ=(*curspecies)->get_champ();
		champ_fitness=champ->fitness;
		cout<<"Champ is organism #"<<champ->gnome->genome_id<<endl;
		cout<<"Champ fitness: "<<champ_fitness<<endl;
		winnernum=champ->gnome->genome_id;
		
		cout<<champ->gnome<<endl;
		
		//Now check to make sure the champ can do 100,000
		thecart->nmarkov_long=true;
		thecart->generalization_test=false;
		
		//The champ needs tp be flushed here because it may have
		//leftover activation from its last test run that could affect
		//its recurrent memory
		(champ->net)->flush();
		
		if (pole2_evaluate(champ,velocity,thecart)) {
			cout<<"The champ passed the 100,000 test!"<<endl;
			
			thecart->nmarkov_long=false;
			
			//Given that the champ passed, now run it on generalization tests
			score=0;
			for (s0c=0;s0c<=4;++s0c)
				for (s1c=0;s1c<=4;++s1c)
					for (s2c=0;s2c<=4;++s2c)
						for (s3c=0;s3c<=4;++s3c) {
							thecart->state[0] = statevals[s0c] * 4.32 - 2.16;
							thecart->state[1] = statevals[s1c] * 2.70 - 1.35;
							thecart->state[2] = statevals[s2c] * 0.12566304 - 0.06283152;
							/* 0.06283152 =  3.6 degrees */
							thecart->state[3] = statevals[s3c] * 0.30019504 - 0.15009752;
							/* 00.15009752 =  8.6 degrees */
							thecart->state[4]=0.0;
							thecart->state[5]=0.0;
							
							cout<<"On combo "<<thecart->state[0]<<" "<<thecart->state[1]<<" "<<thecart->state[2]<<" "<<thecart->state[3]<<endl;
							thecart->generalization_test=true;
							
							(champ->net)->flush();  //Reset the champ for each eval
							
							if (pole2_evaluate(champ,velocity,thecart)) {
								cout<<"----------------------------The champ passed its "<<score<<"th test"<<endl;
								score++;
							}
							
						}
						
						if (score>=200) {
							cout<<"The champ wins!!! (generalization = "<<score<<" )"<<endl;
							oFile<<"(generalization = "<<score<<" )"<<endl;
							oFile<<"generation= "<<generation<<endl;
							(champ->gnome)->print_to_file(oFile);
							champ_fitness=champ->fitness;
							champgenes=champ->gnome->genes.size();
							champnodes=champ->gnome->nodes.size();
							winnernum=champ->gnome->genome_id;
							win=true;
						}
						else {
							cout<<"The champ couldn't generalize"<<endl;
							champ->fitness=champ_fitness; //Restore the champ's fitness
						}
		}
		else {
			cout<<"The champ failed the 100,000 test :("<<endl;
			champ->fitness=champ_fitness; //Restore the champ's fitness
		}
  }
  
  //Only print to file every print_every generations
  if  (win||
	  ((generation%(NEAT::print_every))==0)) {
	  cout<<"printing file: "<<filename<<endl;
	  pop->print_to_file_by_species(filename);
  }
  
  if ((win)&&((pop->winnergen)==0)) pop->winnergen=generation;
  
  //Prints a champion out on each generation
  //IMPORTANT: This causes generational file output!
  print_Genome_tofile(champ->gnome,"champ");
  
  //Create the next generation
  pop->epoch(generation);
  
  return champ_fitness;
  
}

bool pole2_evaluate(Organism *org,bool velocity, CartPole *thecart) {
	Network *net;
	
	int thresh;  /* How many visits will be allowed before giving up 
		  (for loop detection)  NOW OBSOLETE */
	
	int pause;
	
	net=org->net;
	
	thresh=100;  //this is obsolete
	
	//DEBUG :  Check flushedness of org
	//org->net->flush_check();
	
	//Try to balance a pole now
	org->fitness = thecart->evalNet(net,thresh);
	
#ifndef NO_SCREEN_OUT
	if (org->pop_champ_child)
		cout<<" <<DUPLICATE OF CHAMPION>> ";
	
	//Output to screen
	cout<<"Org "<<(org->gnome)->genome_id<<" fitness: "<<org->fitness;
	cout<<" ("<<(org->gnome)->genes.size();
	cout<<" / "<<(org->gnome)->nodes.size()<<")";
	cout<<"   ";
	if (org->mut_struct_baby) cout<<" [struct]";
	if (org->mate_baby) cout<<" [mate]";
	cout<<endl;
#endif
	
	if ((!(thecart->generalization_test))&&(!(thecart->nmarkov_long)))
		if (org->pop_champ_child) {
			cout<<org->gnome<<endl;
			//DEBUG CHECK
			if (org->high_fit>org->fitness) {
				cout<<"ALERT: ORGANISM DAMAGED"<<endl;
				print_Genome_tofile(org->gnome,"failure_champ_genome");
				cin>>pause;
			}
		}
		
		//Decide if its a winner, in Markov Case
		if (thecart->MARKOV) {
			if (org->fitness>=(thecart->maxFitness)) { 
				org->winner=true;
				return true;
			}
			else {
				org->winner=false;
				return false;
			}
		}
		//if doing the long test non-markov 
		else if (thecart->nmarkov_long) {
			if (org->fitness>=99999) { 
				//if (org->fitness>=9000) { 
				org->winner=true;
				return true;
			}
			else {
				org->winner=false;
				return false;
			}
		}
		else if (thecart->generalization_test) {
			if (org->fitness>=999) {
				org->winner=true;
				return true;
			}
			else {
				org->winner=false;
				return false;
			}
		}
		else {
			org->winner=false;
			return false;  //Winners not decided here in non-Markov
		}
}

CartPole::CartPole(bool randomize,bool velocity)
{
	maxFitness = 100000;
	
	MARKOV=velocity;
	
	MIN_INC = 0.001;
	POLE_INC = 0.05;
	MASS_INC = 0.01;
	
	LENGTH_2 = 0.05;
	MASSPOLE_2 = 0.01;
	
	// CartPole::reset() which is called here
}

//Faustino Gomez wrote this physics code using the differential equations from 
//Alexis Weiland's paper and added the Runge-Kutta himself.
double CartPole::evalNet(Network *net,int thresh)
{
	int steps=0;
	double input[NUM_INPUTS];
	double output;
	
	int nmarkovmax;  
	
	double nmarkov_fitness;
	
	double jiggletotal; //total jiggle in last 100
	int count;  //step counter
	
	//init(randomize);		// restart at some point
	
	if (nmarkov_long) nmarkovmax=100000;
	else if (generalization_test) nmarkovmax=1000;
	else nmarkovmax=1000;
	
	
	init(0);
	
	if (MARKOV) {
		while (steps++ < maxFitness) {
			
			
			input[0] = state[0] / 4.8;
			input[1] = state[1] /2;
			input[2] = state[2]  / 0.52;
			input[3] = state[3] /2;
			input[4] = state[4] / 0.52;
			input[5] = state[5] /2;
			input[6] = .5;
			
			net->load_sensors(input);
			
			//Activate the net
			//If it loops, exit returning only fitness of 1 step
			if (!(net->activate())) return 1.0;
			
			output=(*(net->outputs.begin()))->activation;
			
			performAction(output,steps);
			
			if (outsideBounds())	// if failure
				break;			// stop it now
		}
		return (double) steps;
	}
	else {  //NON MARKOV CASE
		
		while (steps++ < nmarkovmax) {
			
			
			//Do special parameter summing on last hundred
			//if ((steps==900)&&(!nmarkov_long)) last_hundred=true;
			
			/*
			input[0] = state[0] / 4.8;
			input[1] = 0.0;
			input[2] = state[2]  / 0.52;
			input[3] = 0.0;
			input[4] = state[4] / 0.52;
			input[5] = 0.0;
			input[6] = .5;
			*/
			
			input[0] = state[0] / 4.8;
			input[1] = state[2]  / 0.52;
			input[2] = state[4] / 0.52;
			input[3] = .5;
			
			net->load_sensors(input);
			
			//Activate the net
			//If it loops, exit returning only fitness of 1 step
			if (!(net->activate())) return 0.0001;
			
			output=(*(net->outputs.begin()))->activation;
			
			performAction(output,steps);
			
			if (outsideBounds())	// if failure
				break;			// stop it now
			
			if (nmarkov_long&&(outsideBounds()))	// if failure
				break;			// stop it now
		}
		
		//If we are generalizing we just need to balance it a while
		if (generalization_test)
			return (double) balanced_sum;
		
		//Sum last 100
		if ((steps>100)&&(!nmarkov_long)) {
			int pause;
			
			jiggletotal=0;
			//cout<<"step "<<steps-99-2<<" to step "<<steps-2<<endl;
			//Adjust for array bounds and count
			for (count=steps-99-2;count<=steps-2;count++)
				jiggletotal+=jigglestep[count];
		}
		
		if (!nmarkov_long) {
			if (balanced_sum>100) 
				nmarkov_fitness=((0.1*(((double) balanced_sum)/1000.0))+
				(0.9*(0.75/(jiggletotal))));
			else nmarkov_fitness=(0.1*(((double) balanced_sum)/1000.0));
			
#ifndef NO_SCREEN_OUT
			cout<<"Balanced:  "<<balanced_sum<<" jiggle: "<<jiggletotal<<" ***"<<endl;
#endif
			
			return nmarkov_fitness;
		}
		else return (double) steps;
		
	}
	
}

void CartPole::init(bool randomize)
{
	static int first_time = 1;
	
	if (!MARKOV) {
		//Clear all fitness records
		cartpos_sum=0.0;
		cartv_sum=0.0;
		polepos_sum=0.0;
		polev_sum=0.0;
	}
	
	balanced_sum=0; //Always count # balanced
	
	last_hundred=false;
	
	/*if (randomize) {
    state[0] = (lrand48()%4800)/1000.0 - 2.4;
    state[1] = (lrand48()%2000)/1000.0 - 1;
    state[2] = (lrand48()%400)/1000.0 - 0.2;
    state[3] = (lrand48()%400)/1000.0 - 0.2;
    state[4] = (lrand48()%3000)/1000.0 - 1.5;
    state[5] = (lrand48()%3000)/1000.0 - 1.5;
	}
	else {*/
	
	
	if (!generalization_test) {
		state[0] = state[1] = state[3] = state[4] = state[5] = 0;
		state[2] = 0.07; // one_degree;
	}
	else {
		state[4] = state[5] = 0;
	}
	
    //}
	if(first_time){
		cout<<"Initial Long pole angle = %f\n"<<state[2]<<endl;;
		cout<<"Initial Short pole length = %f\n"<<LENGTH_2<<endl;
		first_time = 0;
	}
}

void CartPole::performAction(double output, int stepnum)
{ 
	
	int i;
	double  dydx[6];
	
	const bool RK4=true; //Set to Runge-Kutta 4th order integration method
	const double EULER_TAU= TAU/4;
	
	/*random start state for long pole*/
	/*state[2]= drand48();   */
	
	/*--- Apply action to the simulated cart-pole ---*/
	
	if(RK4){
		for(i=0;i<2;++i){
			dydx[0] = state[1];
			dydx[2] = state[3];
			dydx[4] = state[5];
			step(output,state,dydx);
			rk4(output,state,dydx,state);
		}
	}
	else{
		for(i=0;i<8;++i){
			step(output,state,dydx);
			state[0] += EULER_TAU * dydx[0];
			state[1] += EULER_TAU * dydx[1];
			state[2] += EULER_TAU * dydx[2];
			state[3] += EULER_TAU * dydx[3];
			state[4] += EULER_TAU * dydx[4];
			state[5] += EULER_TAU * dydx[5];
		}
	}
	
	//Record this state
	cartpos_sum+=fabs(state[0]);
	cartv_sum+=fabs(state[1]);
	polepos_sum+=fabs(state[2]);
	polev_sum+=fabs(state[3]);
	if (stepnum<=1000)
		jigglestep[stepnum-1]=fabs(state[0])+fabs(state[1])+fabs(state[2])+fabs(state[3]);
	
	if (false) {
		//cout<<"[ x: "<<state[0]<<" xv: "<<state[1]<<" t1: "<<state[2]<<" t1v: "<<state[3]<<" t2:"<<state[4]<<" t2v: "<<state[5]<<" ] "<<
		//cartpos_sum+cartv_sum+polepos_sum+polepos_sum+polev_sum<<endl;
		if (!(outsideBounds())) {
			if (balanced_sum<1000) {
				cout<<".";
				++balanced_sum;
			}
		}
		else {
			if (balanced_sum==1000)
				balanced_sum=1000;
			else balanced_sum=0;
		}
	}
	else if (!(outsideBounds()))
		++balanced_sum;
	
}

void CartPole::step(double action, double *st, double *derivs)
{
    double force,costheta_1,costheta_2,sintheta_1,sintheta_2,
		gsintheta_1,gsintheta_2,temp_1,temp_2,ml_1,ml_2,fi_1,fi_2,mi_1,mi_2;
	
    force =  (action - 0.5) * FORCE_MAG * 2;
    costheta_1 = cos(st[2]);
    sintheta_1 = sin(st[2]);
    gsintheta_1 = GRAVITY * sintheta_1;
    costheta_2 = cos(st[4]);
    sintheta_2 = sin(st[4]);
    gsintheta_2 = GRAVITY * sintheta_2;
    
    ml_1 = LENGTH_1 * MASSPOLE_1;
    ml_2 = LENGTH_2 * MASSPOLE_2;
    temp_1 = MUP * st[3] / ml_1;
    temp_2 = MUP * st[5] / ml_2;
    fi_1 = (ml_1 * st[3] * st[3] * sintheta_1) +
		(0.75 * MASSPOLE_1 * costheta_1 * (temp_1 + gsintheta_1));
    fi_2 = (ml_2 * st[5] * st[5] * sintheta_2) +
		(0.75 * MASSPOLE_2 * costheta_2 * (temp_2 + gsintheta_2));
    mi_1 = MASSPOLE_1 * (1 - (0.75 * costheta_1 * costheta_1));
    mi_2 = MASSPOLE_2 * (1 - (0.75 * costheta_2 * costheta_2));
    
    derivs[1] = (force + fi_1 + fi_2)
		/ (mi_1 + mi_2 + MASSCART);
    
    derivs[3] = -0.75 * (derivs[1] * costheta_1 + gsintheta_1 + temp_1)
		/ LENGTH_1;
    derivs[5] = -0.75 * (derivs[1] * costheta_2 + gsintheta_2 + temp_2)
		/ LENGTH_2;
	
}

void CartPole::rk4(double f, double y[], double dydx[], double yout[])
{
	
	int i;
	
	double hh,h6,dym[6],dyt[6],yt[6];
	
	
	hh=TAU*0.5;
	h6=TAU/6.0;
	for (i=0;i<=5;i++) yt[i]=y[i]+hh*dydx[i];
	step(f,yt,dyt);
	dyt[0] = yt[1];
	dyt[2] = yt[3];
	dyt[4] = yt[5];
	for (i=0;i<=5;i++) yt[i]=y[i]+hh*dyt[i];
	step(f,yt,dym);
	dym[0] = yt[1];
	dym[2] = yt[3];
	dym[4] = yt[5];
	for (i=0;i<=5;i++) {
		yt[i]=y[i]+TAU*dym[i];
		dym[i] += dyt[i];
	}
	step(f,yt,dyt);
	dyt[0] = yt[1];
	dyt[2] = yt[3];
	dyt[4] = yt[5];
	for (i=0;i<=5;i++)
		yout[i]=y[i]+h6*(dydx[i]+dyt[i]+2.0*dym[i]);
}

bool CartPole::outsideBounds()
{
	const double failureAngle = thirty_six_degrees; 
	
	return 
		state[0] < -2.4              || 
		state[0] > 2.4               || 
		state[2] < -failureAngle     ||
		state[2] > failureAngle      ||
		state[4] < -failureAngle     ||
		state[4] > failureAngle;  
}

void CartPole::nextTask()
{
	
	LENGTH_2 += POLE_INC;   /* LENGTH_2 * INCREASE;   */
	MASSPOLE_2 += MASS_INC; /* MASSPOLE_2 * INCREASE; */
	//  ++new_task;
	cout<<"#Pole Length %2.4f\n"<<LENGTH_2<<endl;
}

void CartPole::simplifyTask()
{
	if(POLE_INC > MIN_INC) {
		POLE_INC = POLE_INC/2;
		MASS_INC = MASS_INC/2;
		LENGTH_2 -= POLE_INC;
		MASSPOLE_2 -= MASS_INC;
		cout<<"#SIMPLIFY\n"<<endl;
		cout<<"#Pole Length %2.4f\n"<<LENGTH_2;
	}
	else
    {
		cout<<"#NO TASK CHANGE\n"<<endl;
    }
}


///////////////////////////////////////////////////////////////////
//Darren's Block-Searching Experiment

Population *dazblock_test(int gens)
{
    Population *pop;
    Genome *start_genome;
    char curword[20];
    int id;
	
    ostrstream *fnamebuf;
    int gen;
    int pause;
	
    int expcount;
    int status;
    int runs[NEAT::num_runs];
    int totalevals;
	
    ifstream iFile("dazblockstartgenes",ios::in);
	
    cout<<"START DAZ BLOCK EVOLUTION"<<endl;
	
    cout<<"Reading in the start genome"<<endl;
    //Read in the start Genome
    iFile>>curword;
    iFile>>id;
    cout<<"Reading in Genome id "<<id<<endl;
    start_genome=new Genome(id,iFile);
    iFile.close();
	
    //Run multiple experiments
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		
		cout<<"EXPERIMENT #"<<expcount<<endl;
		
		cout<<"Start Genome: "<<start_genome<<endl;
		
		//Spawn the Population
		cout<<"Spawning Population off Genome"<<endl;
		
		pop=new Population(start_genome,NEAT::pop_size);
		
		cout<<"Verifying Spawned Pop"<<endl;
		pop->verify();
		
		for (gen=1;gen<=gens;gen++) {
			cout<<"Generation "<<gen<<endl;
			
			fnamebuf=new ostrstream();
			(*fnamebuf)<<"gen_"<<gen<<ends;  //needs end marker
			
#ifndef NO_SCREEN_OUT
			cout<<"name of fname: "<<fnamebuf->str()<<endl;
#endif
			
			status=(dazblock_epoch(pop,gen,fnamebuf->str()));
			
			if (status) {
				runs[expcount]=status;
				gen=gens+1;
			}
			
			fnamebuf->clear();
			delete fnamebuf;
			
		}
		
    }
	
    totalevals=0;
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		cout<<runs[expcount]<<endl;
		totalevals+=runs[expcount];
    }
    cout<<"Average evals: "<<totalevals/NEAT::num_runs<<endl;
	
    return pop;
}

int dazblock_epoch(Population *pop,int generation,char *filename) {
	list<Organism*>::iterator curorg,record;
	list<Species*>::iterator curspecies;
	
	bool win=false;
	int winnernum;
	
	//Evaluate each organism on a test
	for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
		if (dazblock_evaluate(*curorg,false,false)) win=true;
	}
	
	//Average and max their fitnesses for dumping to file and snapshot
	for(curspecies=(pop->species).begin();curspecies!=(pop->species).end();++curspecies) {
		
		//This experiment control routine issues commands to collect ave
		//and max fitness, as opposed to having the snapshot do it, 
		//because this allows flexibility in terms of what time
		//to observe fitnesses at
		
		(*curspecies)->compute_average_fitness();
		(*curspecies)->compute_max_fitness();
	}
	
	//Take a snapshot of the population, so that it can be
	//visualized later on
	if ((generation%1)==0)
		pop->snapshot();
	
	//Only print to file every print_every generations
	if  (win||
		((generation%(NEAT::print_every))==0))
		pop->print_to_file_by_species(filename);
	
	if (win) {
		for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
			if ((*curorg)->winner) {
				winnernum=((*curorg)->gnome)->genome_id;
				cout<<"WINNER IS #"<<((*curorg)->gnome)->genome_id<<endl;
				dazblock_evaluate(*curorg,true,true);
			}
		}    
	} else {
		double recfitness=-10000.0;
		for(curorg=(pop->organisms).begin(); curorg!=(pop->organisms).end(); curorg++) {
			if((*curorg)->fitness>recfitness) {
				record=curorg;
				recfitness=(*curorg)->fitness;
			}
		}
		dazblock_evaluate(*record,true,false);
	}
	
	//Create the next generation
	pop->epoch(generation);
	
	if (win) return ((generation-1)*NEAT::pop_size+winnernum);
	else return 0;
	
}

bool dazblock_evaluate(Organism *org,bool dump,bool dumpalltests)
{
	Network *net;
	
	int numnodes;  /* Used to figure out how many nodes
	should be visited during activation */
	int thresh;  /* How many visits will be allowed before giving up 
		  (for loop detection) */
	
	const int MAX_STEPS=100,MAX_BLOCKS=10;
	const int GRIDSIZE=10;
	const char GSPACE='.',GBLOCK='*';
	const int TESTS=15;
	int t,r,testix;
	int posx,posy,dir,step;
	int gotblocks;
	double in[6];
	double fitness=0.0;
	list<NNode*>::iterator out_iter;
	
	char grid[GRIDSIZE][GRIDSIZE];
	
	for(testix=0; (dump&&!dumpalltests)?(testix<1):(testix<TESTS); testix++) {
		if(dump) {
			cout<<endl<<"Test #"<<testix<<":-"<<endl;
		}
		gotblocks=0;
		step=0;
		dir=0;
		for(t=0; t<GRIDSIZE; t++) {
			for(r=0; r<GRIDSIZE; r++) {
				grid[t][r]=GSPACE;
			}
		}
		
		for(t=0; t<MAX_BLOCKS; t++) {
			int x,y;
			do {
				x=rand()%GRIDSIZE;
				y=rand()%GRIDSIZE;
			} while(grid[y][x]!=GSPACE);
			grid[y][x]=GBLOCK;
		}
		
		do {
			posx=rand()%GRIDSIZE;
			posy=rand()%GRIDSIZE;
		} while(grid[posy][posx]!=GSPACE);
		
		net=org->net;
		net->flush();
		numnodes=((org->gnome)->nodes).size();
		thresh=numnodes*2;  //Max number of visits allowed per activation
		
		static const signed char xdirs[]={0,-1,-1,-1,0,1,1,1};
		static const signed char ydirs[]={1,1,0,-1,-1,-1,0,1};
		
#define GETGRID(x,y) ((grid[(y)%GRIDSIZE][(x)%GRIDSIZE]==GBLOCK)?1.0:0.0)
#define GETGRIDDIR(d) (GETGRID(posx+xdirs[(d)&7],posy+ydirs[(d)&7]))
		
		do {
			step++;
			if(dump) {
				cout<<endl<<"Step "<<step<<"..."<<endl;
				for(t=0; t<GRIDSIZE; t++) {
					for(r=0; r<GRIDSIZE; r++) {
						if((t==posy)&&(r==posx)) {
							cout.put("v<^>"[dir/2]);
						} else {
							cout.put(grid[t][r]);
						}
					}
					cout<<endl;
				}
			}
			in[0]=GETGRIDDIR(dir-2);
			in[1]=GETGRIDDIR(dir-1);
			in[2]=GETGRIDDIR(dir);
			in[3]=GETGRIDDIR(dir+1);
			in[4]=GETGRIDDIR(dir+2);
			in[5]=1.0;	//bias
			net->load_sensors(in);
			
			//Activate the net
			//If it loops, exit returning only fitness of 1 step
			if (!(net->activate())) return 1;
			
			//read outputs
			out_iter=net->outputs.begin();
			bool wheelleft=((*out_iter)->activation>0.5);
			out_iter++;
			bool wheelright=((*out_iter)->activation>0.5);
			
			if(wheelleft) {
				if(wheelright) {
					//fwd
					if(dump){cout<<"FWD"<<endl;}
					posx=(posx+xdirs[dir]+GRIDSIZE)%GRIDSIZE;
					posy=(posy+ydirs[dir]+GRIDSIZE)%GRIDSIZE;
					if(grid[posy][posx]==GBLOCK) {
						gotblocks++;
						grid[posy][posx]=GSPACE;
						if(gotblocks>=MAX_BLOCKS) {
							break;
						}
					}
				} else {
					//rotate left
					if(dump){cout<<"LFT"<<endl;}
					dir=(dir+6)&7;
				}
			} else {
				if(wheelright) {
					//rotate right
					if(dump){cout<<"RGT"<<endl;}
					dir=(dir+2)&7;
				}
			}
		} while(step<MAX_STEPS);
		if(dump) {
			cout << "Stopped; blocks collected = " << gotblocks << endl;
		}
		fitness+=gotblocks;
	}
#undef GETGRID
#undef GETGRIDDIR
	
	fitness/=TESTS;
	
	org->fitness = fitness;
	
#ifndef NO_SCREEN_OUT
	cout<<"Org "<<(org->gnome)->genome_id<<" fitness: "<<org->fitness<<endl;
#endif
	
	//Decide if its a winner
	if (fitness>=MAX_BLOCKS) { 
		org->winner=true;
		return true;
	}
	else {
		org->winner=false;
		return false;
	}
	
}

///////////////////////////////////////////////////////////////////
//Darren's Char-Recognising Experiment

Population *dazchar_test(int gens)
{
    Population *pop;
    Genome *start_genome;
    char curword[20];
    int id;
	
    ostrstream *fnamebuf;
    int gen;
    int pause;
	
    int expcount;
    int status;
    int runs[NEAT::num_runs];
    int totalevals;
	
    ifstream iFile("dazcharstartgenes",ios::in);
	
    cout<<"START DAZ CHAR EVOLUTION"<<endl;
	
    cout<<"Reading in the start genome"<<endl;
    //Read in the start Genome
    iFile>>curword;
    iFile>>id;
    cout<<"Reading in Genome id "<<id<<endl;
    start_genome=new Genome(id,iFile);
    iFile.close();
	
    //Run multiple experiments
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		
		cout<<"EXPERIMENT #"<<expcount<<endl;
		
		cout<<"Start Genome: "<<start_genome<<endl;
		
		//Spawn the Population
		cout<<"Spawning Population off Genome"<<endl;
		
		pop=new Population(start_genome,NEAT::pop_size);
		
		cout<<"Verifying Spawned Pop"<<endl;
		pop->verify();
		
		for (gen=1;gen<=gens;gen++) {
			cout<<"Generation "<<gen<<endl;
			
			fnamebuf=new ostrstream();
			(*fnamebuf)<<"gen_"<<gen<<ends;  //needs end marker
			
#ifndef NO_SCREEN_OUT
			cout<<"name of fname: "<<fnamebuf->str()<<endl;
#endif
			
			status=(dazchar_epoch(pop,gen,fnamebuf->str()));
			
			if (status) {
				runs[expcount]=status;
				gen=gens+1;
			}
			
			fnamebuf->clear();
			delete fnamebuf;
			
		}
		
    }
	
    totalevals=0;
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		cout<<runs[expcount]<<endl;
		totalevals+=runs[expcount];
    }
    cout<<"Average evals: "<<totalevals/NEAT::num_runs<<endl;
	
    return pop;
}

int dazchar_epoch(Population *pop,int generation,char *filename) {
	list<Organism*>::iterator curorg,record;
	list<Species*>::iterator curspecies;
	
	bool win=false;
	int winnernum;
	
	//Evaluate each organism on a test
	for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
		if (dazchar_evaluate(*curorg,false,false)) win=true;
	}
	
	//Average and max their fitnesses for dumping to file and snapshot
	for(curspecies=(pop->species).begin();curspecies!=(pop->species).end();++curspecies) {
		
		//This experiment control routine issues commands to collect ave
		//and max fitness, as opposed to having the snapshot do it, 
		//because this allows flexibility in terms of what time
		//to observe fitnesses at
		
		(*curspecies)->compute_average_fitness();
		(*curspecies)->compute_max_fitness();
	}
	
	//Take a snapshot of the population, so that it can be
	//visualized later on
	if ((generation%1)==0)
		pop->snapshot();
	
	//Only print to file every print_every generations
	if  (win||
		((generation%(NEAT::print_every))==0))
		pop->print_to_file_by_species(filename);
	
	if (win) {
		for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
			if ((*curorg)->winner) {
				winnernum=((*curorg)->gnome)->genome_id;
				cout<<"WINNER IS #"<<((*curorg)->gnome)->genome_id<<endl;
				dazchar_evaluate(*curorg,true,true);
			}
		}    
	} else {
		double recfitness=-10000.0;
		for(curorg=(pop->organisms).begin(); curorg!=(pop->organisms).end(); curorg++) {
			if((*curorg)->fitness>recfitness) {
				record=curorg;
				recfitness=(*curorg)->fitness;
			}
		}
		dazchar_evaluate(*record,true,false);
	}
	
	//Create the next generation
	pop->epoch(generation);
	
	if (win) return ((generation-1)*NEAT::pop_size+winnernum);
	else return 0;
	
}

bool dazchar_evaluate(Organism *org,bool dump,bool dumpalltests)
{
	Network *net;
	
	int numnodes;  /* Used to figure out how many nodes
	should be visited during activation */
	int thresh;  /* How many visits will be allowed before giving up 
		  (for loop detection) */
	
	const int MAX_STEPS=200;
	int t,r,testix;
	int posx,posy,step;
	double in[6];
	double fitness=0.0;
	list<NNode*>::iterator out_iter;
	
	static const char *gridcirc[]={
		"...#....",
			".#####..",
			".#####..",
			"#######.",
			".#####..",
			".#####..",
			"...#....",
			"........",
	};
	
	static const char *griddiamond[]={
		"...#....",
			"..###...",
			".#####..",
			"#######.",
			".#####..",
			"..###...",
			"...#....",
			"........",
	};
	
	static const char *gridsquare[]={
		"........",
			".######.",
			".######.",
			".######.",
			".######.",
			".######.",
			".######.",
			"........",
	};
	
	struct DazGrid {
		const char *name;
		const char **grid;
		int w,h;
	};
	
	static const struct DazGrid grids[]={
		{"Circle",gridcirc,8,8},
		{"Square",gridsquare,8,8},
		{"Diamond",griddiamond,8,8},
	};
	const int numgrids=sizeof(grids)/sizeof(struct DazGrid);
	const int TESTS=numgrids*25;
	const int coordscale=2;
	int chosengrid;
	bool answergiven;
	
	for(testix=0; (dump&&!dumpalltests)?(testix<numgrids):(testix<TESTS); testix++) {
		if(dump) {
			cout<<endl<<"Test #"<<testix<<":-"<<endl;
		}
		chosengrid=testix%numgrids;
		if(dump) {
			cout << "Chosen grid: " << grids[chosengrid].name << endl;
		}
		step=0;
		posx=(testix*coordscale)%grids[chosengrid].w;
		posy=((testix*coordscale)/grids[chosengrid].w)%grids[chosengrid].h;
		
		net=org->net;
		net->flush();
		numnodes=((org->gnome)->nodes).size();
		thresh=numnodes*2;  //Max number of visits allowed per activation
		
		answergiven=false;
		
#define GETGRID(x,y) \
	((grids[chosengrid]. \
	grid[((y)+grids[chosengrid].h)%grids[chosengrid].h] \
		[((x)+grids[chosengrid].w)%grids[chosengrid].w]=='#')?1.0:0.0)
		
		do {
			step++;
			if(dump) {
				cout<<"Step "<<step<<": "<<posx<<","<<posy<<endl;
			}
			in[0]=GETGRID(posx,posy);
			in[1]=GETGRID(posx,posy-1);
			in[2]=GETGRID(posx+1,posy);
			in[3]=GETGRID(posx,posy+1);
			in[4]=GETGRID(posx-1,posy);
			in[5]=1.0;	//bias
			net->load_sensors(in);
			
			//Activate the net
			//If it loops, exit returning only fitness of 1 step
			if (!(net->activate())) return 1;
			
			//read outputs
			out_iter=net->outputs.begin();
			bool moveleft=((*out_iter)->activation>0.5);
			out_iter++;
			bool moveup=((*out_iter)->activation>0.5);
			out_iter++;
			bool moveright=((*out_iter)->activation>0.5);
			out_iter++;
			bool movedown=((*out_iter)->activation>0.5);
			out_iter++;
			bool answerknown=((*out_iter)->activation>0.5);
			
			posx=(posx+grids[chosengrid].w+(moveleft?-1:0)+(moveright?1:0))%grids[chosengrid].w;
			posy=(posy+grids[chosengrid].h+(moveup?-1:0)+(movedown?1:0))%grids[chosengrid].h;
			
			if(answerknown) {
				double max=-1000000.0;
				int answer=0;
				for(t=0; t<3; t++) {
					out_iter++;
					if((*out_iter)->activation>max) {
						max=(*out_iter)->activation;
						answer=t;
					}
				}
				answergiven=true;
				if(dump) {
					cout << "My answer is " << grids[answer].name << endl;
				}
				if(answer==chosengrid) {
					fitness+=100.0;
					if(dump) {
						cout << "Correct!" << endl;
					}
				} else {
					if(dump) {
						cout << "Wrong!" << endl;
					}
				}
				break;
			}
		} while(step<MAX_STEPS);
		if(dump && !answergiven) {
			cout << "Out of time." << endl;
		}
	}
#undef GETGRID
	
	fitness/=TESTS;
	
	org->fitness = fitness;
	
#ifndef NO_SCREEN_OUT
	cout<<"Org "<<(org->gnome)->genome_id<<" fitness: "<<org->fitness<<endl;
#endif
	
	//Decide if its a winner
	//	if (fitness>=100.0) {
	if(0) {
		org->winner=true;
		return true;
	}
	else {
		org->winner=false;
		return false;
	}
}

///////////////////////////////////////////////////////////////////
//Darren's Shape-Recognising Experiment

Population *dazshape_test(int gens)
{
    Population *pop;
    Genome *start_genome;
    char curword[20];
    int id;
	
    ostrstream *fnamebuf;
    int gen;
    int pause;
	
    int expcount;
    int status;
    int runs[NEAT::num_runs];
    int totalevals;
	
    ifstream iFile("dazshapestartgenes",ios::in);
	
    cout<<"START DAZ SHAPE EVOLUTION"<<endl;
	
    cout<<"Reading in the start genome"<<endl;
    //Read in the start Genome
    iFile>>curword;
    iFile>>id;
    cout<<"Reading in Genome id "<<id<<endl;
    start_genome=new Genome(id,iFile);
    iFile.close();
	
    //Run multiple experiments
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		
		cout<<"EXPERIMENT #"<<expcount<<endl;
		
		cout<<"Start Genome: "<<start_genome<<endl;
		
		//Spawn the Population
		cout<<"Spawning Population off Genome"<<endl;
		
		pop=new Population(start_genome,NEAT::pop_size);
		
		cout<<"Verifying Spawned Pop"<<endl;
		pop->verify();
		
		for (gen=1;gen<=gens;gen++) {
			cout<<"Generation "<<gen<<endl;
			
			fnamebuf=new ostrstream();
			(*fnamebuf)<<"gen_"<<gen<<ends;  //needs end marker
			
#ifndef NO_SCREEN_OUT
			cout<<"name of fname: "<<fnamebuf->str()<<endl;
#endif
			
			status=(dazshape_epoch(pop,gen,fnamebuf->str()));
			
			if (status) {
				runs[expcount]=status;
				gen=gens+1;
			}
			
			fnamebuf->clear();
			delete fnamebuf;
			
		}
		
    }
	
    totalevals=0;
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		cout<<runs[expcount]<<endl;
		totalevals+=runs[expcount];
    }
    cout<<"Average evals: "<<totalevals/NEAT::num_runs<<endl;
	
    return pop;
}

int dazshape_epoch(Population *pop,int generation,char *filename) {
	list<Organism*>::iterator curorg,record;
	list<Species*>::iterator curspecies;
	
	bool win=false;
	int winnernum;
	
	//Evaluate each organism on a test
	for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
		if (dazshape_evaluate(*curorg,false,false)) win=true;
	}
	
	//Average and max their fitnesses for dumping to file and snapshot
	for(curspecies=(pop->species).begin();curspecies!=(pop->species).end();++curspecies) {
		
		//This experiment control routine issues commands to collect ave
		//and max fitness, as opposed to having the snapshot do it, 
		//because this allows flexibility in terms of what time
		//to observe fitnesses at
		
		(*curspecies)->compute_average_fitness();
		(*curspecies)->compute_max_fitness();
	}
	
	//Take a snapshot of the population, so that it can be
	//visualized later on
	if ((generation%1)==0)
		pop->snapshot();
	
	//Only print to file every print_every generations
	if  (win||
		((generation%(NEAT::print_every))==0))
		pop->print_to_file_by_species(filename);
	
	if (win) {
		for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
			if ((*curorg)->winner) {
				winnernum=((*curorg)->gnome)->genome_id;
				cout<<"WINNER IS #"<<((*curorg)->gnome)->genome_id<<endl;
				dazshape_evaluate(*curorg,true,true);
			}
		}    
	} else {
		double recfitness=-10000.0;
		for(curorg=(pop->organisms).begin(); curorg!=(pop->organisms).end(); curorg++) {
			if((*curorg)->fitness>recfitness) {
				record=curorg;
				recfitness=(*curorg)->fitness;
			}
		}
		dazshape_evaluate(*record,true,false);
	}
	
	//Create the next generation
	pop->epoch(generation);
	
	if (win) return ((generation-1)*NEAT::pop_size+winnernum);
	else return 0;
	
}


class DazShapeSpec
{
public:
	virtual char *GetName() {return "Dummy";};
	virtual bool GetPoint(double pointx,double pointy) {return false;};
	double GetGrid(double x,double y) {
		const int xsteps=5,ysteps=5;	//subsampling steps in a single unit
		double level=0.0;
		int xoffset,yoffset;
		while(x>=10.0) {x-=10.0;}
		while(y>=10.0) {y-=10.0;}
		while(x<0.0) {x+=10.0;}
		while(y<0.0) {y+=10.0;}
		for(yoffset=0; yoffset<ysteps; yoffset++) {
			for(xoffset=0; xoffset<xsteps; xoffset++) {
				level+=GetPoint(x+double(xoffset)/xsteps,y+double(yoffset)/ysteps)?1.0:0.0;
			}
		}
		return level/(xsteps*ysteps);
	};
};

class DazShapeCircle : public DazShapeSpec
{
public:
	char *GetName() {return "Circle";};
	bool GetPoint(double pointx,double pointy) {
		pointx=(pointx-5.0)/4.0;
		pointy=(pointy-5.0)/4.0;
		return sqrt(pointx*pointx+pointy*pointy)<1.0;
	};
};

class DazShapeRing : public DazShapeSpec
{
public:
	char *GetName() {return "Ring";};
	bool GetPoint(double pointx,double pointy) {
		double dist;
		pointx=(pointx-5.0)/4.0;
		pointy=(pointy-5.0)/4.0;
		dist=sqrt(pointx*pointx+pointy*pointy);
		return (dist>0.6)&&(dist<1.0);
	};
};

class DazShapeSquare : public DazShapeSpec
{
public:
	char *GetName() {return "Square";};
	bool GetPoint(double pointx,double pointy) {
		return (pointx>1.0)&&(pointy>1.0)&&(pointx<9.0)&&(pointy<9.0);
	};
};

class DazShapeDiamond : public DazShapeSpec
{
public:
	char *GetName() {return "Diamond";};
	bool GetPoint(double pointx,double pointy) {
		return (fabs(pointx-5.0)+fabs(pointy-5.0))<4.0;
	};
};


bool dazshape_evaluate(Organism *org,bool dump,bool dumpalltests)
{
	Network *net;
	
	int numnodes;  /* Used to figure out how many nodes
	should be visited during activation */
	int thresh;  /* How many visits will be allowed before giving up 
		  (for loop detection) */
	
	const int MAX_STEPS=200;
	int t,r,testix;
	double posx,posy;
	int step;
	double in[6];
	double fitness=0.0;
	static bool gridsdumped=false;
	list<NNode*>::iterator out_iter;
	
	DazShapeCircle dscircle;
	DazShapeSquare dssquare;
	DazShapeDiamond dsdiamond;
	DazShapeRing dsring;
	
	DazShapeSpec *shapes[]={
		&dscircle,&dssquare,&dsdiamond,&dsring
	};
	
	const int numgrids=sizeof(shapes)/sizeof(DazShapeSpec *);
	const int STAGEX=5,STAGEY=5;
	const int TESTS=numgrids*STAGEX*STAGEY;
	int chosengrid;
	bool answergiven;
	
	if(dump && !gridsdumped) {
		for(chosengrid=0; chosengrid<numgrids; chosengrid++) {
			cout << endl << shapes[chosengrid]->GetName() << " Grid" << endl;
			for(t=0; t<10; t++) {
				for(r=0; r<10; r++) {
					static const char *const intensity[]={
						".",":","-","=","+","o","*","@","#","#",
					};
					cout << intensity[int(floor(shapes[chosengrid]->GetGrid(r,t)*((sizeof(intensity)/sizeof(char *))-1)))];
				}
				cout << endl;
			}
		}
		gridsdumped=true;
	}
	
	for(testix=0; (dump&&!dumpalltests)?(testix<numgrids):(testix<TESTS); testix++) {
		
		if(dump) {
			cout<<endl<<"Test #"<<testix<<":-"<<endl;
		}
		chosengrid=testix%numgrids;
		if(dump) {
			cout << "Chosen shape: " << shapes[chosengrid]->GetName() << endl;
		}
		step=0;
		posx=double((testix/numgrids)%STAGEX);
		posy=double((testix/numgrids)/STAGEX);
		
		net=org->net;
		net->flush();
		numnodes=((org->gnome)->nodes).size();
		thresh=numnodes*2;  //Max number of visits allowed per activation
		
		answergiven=false;
		
		do {
			step++;
			if(dump) {
				cout<<"Step "<<step<<": "<<posx<<","<<posy<<endl;
			}
			in[0]=shapes[chosengrid]->GetGrid(posx,posy);
			in[1]=shapes[chosengrid]->GetGrid(posx,posy-1.0);
			in[2]=shapes[chosengrid]->GetGrid(posx+1.0,posy);
			in[3]=shapes[chosengrid]->GetGrid(posx,posy+1.0);
			in[4]=shapes[chosengrid]->GetGrid(posx-1.0,posy);
			in[5]=1.0;	//bias
			net->load_sensors(in);
			
			//Activate the net
			//If it loops, exit returning only fitness of 1 step
			////NOTENOTENOTENOTE::: DAZ - I realised I ran the experiments with this
			////(apparently erroneous) line in force. It should probably be net->activate();
			////alone.
			if (!(net->activate())) return 1;
			
			//read outputs
			out_iter=net->outputs.begin();
			double moveleft=(*out_iter)->activation;
			out_iter++;
			double moveup=(*out_iter)->activation;
			out_iter++;
			double moveright=(*out_iter)->activation;
			out_iter++;
			double movedown=(*out_iter)->activation;
			out_iter++;
			bool answerknown=((*out_iter)->activation>0.5);
			
			posx+=moveright-moveleft;
			posy+=movedown-moveup;
			while(posx>=10.0) {posx-=10.0;}
			while(posy>=10.0) {posy-=10.0;}
			while(posx<0.0) {posx+=10.0;}
			while(posy<0.0) {posy+=10.0;}
			
			if(answerknown) {
				double max=-1000000.0;
				int answer=0;
				for(t=0; t<numgrids; t++) {
					out_iter++;
					if((*out_iter)->activation>max) {
						max=(*out_iter)->activation;
						answer=t;
					}
				}
				answergiven=true;
				if(dump) {
					cout << "My answer is " << shapes[answer]->GetName() << endl;
				}
				if(answer==chosengrid) {
					fitness+=100.0;
					if(dump) {
						cout << "Correct!" << endl;
					}
				} else {
					if(dump) {
						cout << "Wrong!" << endl;
					}
				}
				break;
			}
		} while(step<MAX_STEPS);
		if(dump && !answergiven) {
			cout << "Out of time." << endl;
		}
	}
#undef GETGRID
	
	fitness/=TESTS;
	
	if(!dump) {
		org->fitness = fitness;
	}
	
#ifndef NO_SCREEN_OUT
	cout<<"Org "<<(org->gnome)->genome_id<<" fitness: "<<org->fitness<<endl;
#endif
	
	//Decide if its a winner
	//	if (fitness>=100.0) {
	if(0) {
		org->winner=true;
		return true;
	}
	else {
		org->winner=false;
		return false;
	}
}

///////////////////////////////////////////////////////////////////
//Darren's Program Experiment

Population *dazprog_test(int gens)
{
    Population *pop;
    Genome *start_genome;
    char curword[20];
    int id;
	
    ostrstream *fnamebuf;
    int gen;
    int pause;
	
    int expcount;
    int status;
    int runs[NEAT::num_runs];
    int totalevals;
	
    ifstream iFile("dazprogstartgenes",ios::in);
	
    cout<<"START DAZ PROG EVOLUTION"<<endl;
	
    cout<<"Reading in the start genome"<<endl;
    //Read in the start Genome
    iFile>>curword;
    iFile>>id;
    cout<<"Reading in Genome id "<<id<<endl;
    start_genome=new Genome(id,iFile);
    iFile.close();
	
    //Run multiple experiments
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		
		cout<<"EXPERIMENT #"<<expcount<<endl;
		
		cout<<"Start Genome: "<<start_genome<<endl;
		
		//Spawn the Population
		cout<<"Spawning Population off Genome"<<endl;
		
		pop=new Population(start_genome,NEAT::pop_size);
		
		cout<<"Verifying Spawned Pop"<<endl;
		pop->verify();
		
		for (gen=1;gen<=gens;gen++) {
			cout<<"Generation "<<gen<<endl;
			
			fnamebuf=new ostrstream();
			(*fnamebuf)<<"gen_"<<gen<<ends;  //needs end marker
			
#ifndef NO_SCREEN_OUT
			cout<<"name of fname: "<<fnamebuf->str()<<endl;
#endif
			
			status=(dazprog_epoch(pop,gen,fnamebuf->str()));
			
			if (status) {
				runs[expcount]=status;
				gen=gens+1;
			}
			
			fnamebuf->clear();
			delete fnamebuf;
			
		}
		
    }
	
    totalevals=0;
    for(expcount=0;expcount<NEAT::num_runs;expcount++) {
		cout<<runs[expcount]<<endl;
		totalevals+=runs[expcount];
    }
    cout<<"Average evals: "<<totalevals/NEAT::num_runs<<endl;
	
    return pop;
}

int dazprog_epoch(Population *pop,int generation,char *filename) {
	list<Organism*>::iterator curorg,record;
	list<Species*>::iterator curspecies;
	
	bool win=false;
	int winnernum;
	
	//Evaluate each organism on a test
	for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
		if (dazprog_evaluate(*curorg,false,false)) win=true;
	}
	
	//Average and max their fitnesses for dumping to file and snapshot
	for(curspecies=(pop->species).begin();curspecies!=(pop->species).end();++curspecies) {
		
		//This experiment control routine issues commands to collect ave
		//and max fitness, as opposed to having the snapshot do it, 
		//because this allows flexibility in terms of what time
		//to observe fitnesses at
		
		(*curspecies)->compute_average_fitness();
		(*curspecies)->compute_max_fitness();
	}
	
	//Take a snapshot of the population, so that it can be
	//visualized later on
	if ((generation%1)==0)
		pop->snapshot();
	
	//Only print to file every print_every generations
	if  (win||
		((generation%(NEAT::print_every))==0))
		pop->print_to_file_by_species(filename);
	
	if (win) {
		for(curorg=(pop->organisms).begin();curorg!=(pop->organisms).end();++curorg) {
			if ((*curorg)->winner) {
				winnernum=((*curorg)->gnome)->genome_id;
				cout<<"WINNER IS #"<<((*curorg)->gnome)->genome_id<<endl;
				dazprog_evaluate(*curorg,true,true);
			}
		}    
	} else {
		double recfitness=-10000.0;
		for(curorg=(pop->organisms).begin(); curorg!=(pop->organisms).end(); curorg++) {
			if((*curorg)->fitness>recfitness) {
				record=curorg;
				recfitness=(*curorg)->fitness;
			}
		}
		dazprog_evaluate(*record,true,false);
	}
	
	//Create the next generation
	pop->epoch(generation);
	
	return 0;	
}

class DazProgInst {
public:
	enum OpCode {
		pushx,pop,addx,subx,mulx,divx,modx,pusharg,swap,dup
	};
	OpCode op;
	int x;
	static OpCode Random() {
		const static OpCode opc[]={
			pushx,pop,addx,subx,mulx,divx,modx,pusharg,swap,dup
		};
		return opc[rand()%(sizeof(opc)/sizeof(OpCode))];
	}
	void Print(ostream &out) {
		switch(op) {
		case pushx:	out << "PUSH " << x << endl;	break;
		case pop:	out << "POP" << endl;			break;
		case addx:	out << "ADD " << x << endl;		break;
		case subx:	out << "SUB " << x << endl;		break;
		case mulx:	out << "MUL " << x << endl;		break;
		case divx:	out << "DIV " << x << endl;		break;
		case modx:	out << "MOD " << x << endl;		break;
		case pusharg:	out << "PUSH ARG" << endl;	break;
		case swap:	out << "SWAP" << endl;			break;
		case dup:	out << "DUP" << endl;
		}
	}
	double Cost() {
		switch(op) {
		case pushx:	return 1.0;	break;
		case pop:	return 0.5;	break;
		case addx:	return 0.75;	break;
		case subx:	return 0.75;	break;
		case mulx:	return 0.5;	break;
		case divx:	return 0.25;	break;
		case modx:	return 0.25;	break;
		case pusharg:	return 0.25;	break;
		case swap:	return 0.25;	break;
		case dup:	return 0.25;	break;
		}
	}
};

class DazProg : public vector<DazProgInst> {
public:
	double Cost() {
		double cost=0.0;
		if(size()>0) {
			for(iterator it=begin(); it!=end(); it++) {
				cost+=it->Cost();
			}
		}
		return cost;
	}
	void Print(ostream &out) {
		if(size()>0) {
			for(iterator it=begin(); it!=end(); it++) {
				it->Print(out);
			}
		} else {
			out << "(empty)" << endl;
		}
	}
	void Randomise(int len) {
		clear();
		for(int t=0; t<len; t++) {
			DazProgInst inst;
			inst.op=DazProgInst::Random();
			inst.x=rand()%10;
			push_back(inst);
		}
	}
	//Run() returns true on success
	bool Run(int arg,int &result) {
		vector<int> stack;
		stack.push_back(arg);
		if(size()>0) {
			iterator it;
			for(it=begin(); it!=end(); it++) {
				switch(it->op) {
				case DazProgInst::pushx:
					stack.push_back(it->x);
					break;
				case DazProgInst::pusharg:
					stack.push_back(arg);
					break;
				case DazProgInst::pop:
					if(stack.size()<=0) {
						return false;
					}
					stack.pop_back();
					break;
				case DazProgInst::addx:
					if(stack.size()<=0) {
						return false;
					}
					stack[stack.size()-1]+=it->x;
					break;
				case DazProgInst::subx:
					if(stack.size()<=0) {
						return false;
					}
					stack[stack.size()-1]-=it->x;
					break;
				case DazProgInst::mulx:
					if(stack.size()<=0) {
						return false;
					}
					stack[stack.size()-1]*=it->x;
					break;
				case DazProgInst::divx:
					if(stack.size()<=0) {
						return false;
					}
					if(it->x==0) {
						return false;
					}
					stack[stack.size()-1]/=it->x;
					break;
				case DazProgInst::modx:
					if(stack.size()<=0) {
						return false;
					}
					if(it->x==0) {
						return false;
					}
					stack[stack.size()-1]%=it->x;
					break;
				case DazProgInst::swap:
					if(stack.size()<=1) {
						return false;
					}
					{
						int a=stack[stack.size()-1];
						stack[stack.size()-1]=stack[stack.size()-2];
						stack[stack.size()-2]=a;
					}
					break;
				case DazProgInst::dup:
					if(stack.size()<=0) {
						return false;
					}
					stack.push_back(stack[stack.size()-1]);
					break;
				}
			}
		}
		if(stack.size()>0) {
			result=stack[stack.size()-1];
			return true;
		}
		return false;
	}
};

bool dazprog_evaluate(Organism *org,bool dump,bool dumpalltests)
{
	Network *net;
	
	int numnodes;  /* Used to figure out how many nodes
	should be visited during activation */
	int thresh;  /* How many visits will be allowed before giving up 
	(for loop detection) */
	
	
	//INPUTS
	//0. Number=0-9 (mapped into 0.0-1.0)?
	//1. No number here?
	//2. cur instruction=PUSH x 
	//3. cur instruction=POP	
	//4. cur instruction=ADD x	
	//5. cur instruction=SUB x	
	//6. cur instruction=MUL x	
	//7. cur instruction=DIV x	
	//8. cur instruction=MOD x	
	//9. cur instruction=PUSHARG
	//10. cur instruction=SWAP	
	//11. cur instruction=DUP
	//12. cur inst x
	//13. bias
	
	//OUTPUTS
	//0. <=.25 = examine prev instruction
	//   .25-.5 = examine next instruction
	//   .5-.75 = modify instruction
	//   >.75 = view number at index x?
	//1. instruction=PUSH x (cost 1.0)
	//2. instruction=POP	(cost 0.5)
	//3. instruction=ADD x	(cost 0.75)
	//4. instruction=SUB x	(cost 0.75)
	//5. instruction=MUL x	(cost 0.5)
	//6. instruction=DIV x	(cost 0.25)
	//7. instruction=MOD x	(cost 0.25)
	//8. instruction=PUSHARG (cost 0.25)
	//9. instruction=SWAP	(cost 0.25)
	//10. instruction=DUP	(cost 0.25)
	//11. x=0-9 (mapped into 0.0-1.0)
	
	const int MAX_STEPS=20,NUMLENS=5,TESTS=NUMLENS;
	int testix;
	double in[20];
	double fitness=0.0;
	list<NNode*>::iterator out_iter;
	int curinst;
	
	static const int masterseq[]={
		1,3,5,7,9,2,4,6,8,0
	};

	for(testix=0; (dump&&!dumpalltests)?(testix<NUMLENS):(testix<TESTS); testix++) {
		int length=(testix%NUMLENS)+3;
		if(dump) {
			cout<<endl<<"Test #"<<testix<<" (length "<<length<<"):-"<<endl;
		}
		
		vector<int> seq;
		DazProg prog;
		prog.Randomise(5);
		curinst=0;
		int t,step=0,cursor=0;
		bool answergiven=false;
		for(t=0; t<length; t++) {
			//seq.push_back(rand()%10);
			seq.push_back(masterseq[t+(NUMLENS-1)-(testix%NUMLENS)]);
		}
		if(dump) {
			cout << "Chosen sequence:-" << endl;
			for(t=0; t<length; t++) {
				cout << "  " << seq[t];
			}
			cout << endl;
			cout << "Start routine:-" << endl;
			prog.Print(cout);
		}
		
		net=org->net;
		net->flush();
		numnodes=((org->gnome)->nodes).size();
		thresh=numnodes*2;  //Max number of visits allowed per activation
		
		do {
			step++;
			if(dump) {
				cout<<"Step "<<step<<": Looking @ seq["<< cursor <<"], prog[" << curinst <<"]: ";
			}
			in[0]=0.0;
			in[1]=0.0;
			{
				DazProgInst &cinst=prog[curinst];
				in[2]=(cinst.op==DazProgInst::pushx);
				in[3]=(cinst.op==DazProgInst::pop);
				in[4]=(cinst.op==DazProgInst::addx);
				in[5]=(cinst.op==DazProgInst::subx);
				in[6]=(cinst.op==DazProgInst::mulx);
				in[7]=(cinst.op==DazProgInst::divx);
				in[8]=(cinst.op==DazProgInst::modx);
				in[9]=(cinst.op==DazProgInst::pusharg);
				in[10]=(cinst.op==DazProgInst::swap);
				in[11]=(cinst.op==DazProgInst::dup);
				in[12]=(cinst.x/10.0);
			}
			in[13]=1.0;	//bias
			if((cursor>=0)&&(cursor<length)) {
				in[0]=double(seq[cursor])/10.0;
			} else {
				in[1]=1.0;	//"cursor out of range" signal
			}
			net->load_sensors(in);
			
			//Activate the net
			net->activate();
			
			//read outputs
			out_iter=net->outputs.begin();
			vector<double> outs;
			for(t=0; t<12; t++) {
				outs.push_back((*out_iter)->activation);
				out_iter++;
			}
			if(outs[0]<=.25) {
				if(curinst>0) {
					curinst--;
					if(dump) {
						cout << "To instruction #" << curinst << "." << endl;
					}
				} else {
					if(dump) {
						cout << "Bump (down)!" << endl;
					}
				}
			} else if((outs[0]>.25)&&(outs[0]<=.5)) {
				if(curinst<prog.size()-1) {
					curinst++;
					if(dump) {
						cout << "To instruction #" << curinst << "." << endl;
					}
				} else {
					if(dump) {
						cout << "Bump (up)!" << endl;
					}
				}
			} else if((outs[0]>.5)&&(outs[0]<=.75)) {
				//modify instruction
				int maxix=1;
				double maxval=-1000.0;
				for(t=1; t<=10; t++) {
					if(outs[t]>maxval) {
						maxval=outs[t];
						maxix=t;
					}
				}
				DazProgInst inst;
				switch(maxix) {
				case 1:	inst.op=DazProgInst::pushx;	break;
				case 2:	inst.op=DazProgInst::pop;	break;
				case 3:	inst.op=DazProgInst::addx;	break;
				case 4:	inst.op=DazProgInst::subx;	break;
				case 5:	inst.op=DazProgInst::mulx;	break;
				case 6:	inst.op=DazProgInst::divx;	break;
				case 7:	inst.op=DazProgInst::modx;	break;
				case 8:	inst.op=DazProgInst::pusharg;	break;
				case 9:	inst.op=DazProgInst::swap;	break;
				case 10:	inst.op=DazProgInst::dup;	break;
				}
				inst.x=int(outs[11]*10.0);
				prog[curinst]=inst;
				if(dump) {
					inst.Print(cout);
				}
			} else if(outs[0]>.75) {
				//move cursor
				cursor=int(outs[11]*10.0);
				if(dump) {
					cout << "Moved." << endl;
				}
			}
			if(step>=MAX_STEPS) {
				//done
				double error=0.0;
				double cost=prog.Cost();
				if(dump) {
					cout << "Program generated is:-" << endl;
					prog.Print(cout);
					cout << "Its cost is " << cost << endl;
				}
				for(t=0; t<length; t++) {
					int result;
					if(prog.Run(t,result)) {
						if(dump) {
							cout << t << ": Program=" << result << " (" << seq[t] << ")" << endl;
						}
						int diff=seq[t]-result;
						if(diff<0) {
							diff=-diff;
						}
						if(diff>10) {
							diff=10;
						}
						error+=diff*10.0;
					} else {
						if(dump) {
							cout << t << ": Program failed (" << seq[t] << ")" << endl;
						}
						error+=100.0;
					}
				}
				error/=length;
				error+=cost/10.0;
				if(error<0) {
					error=100.0;
				}
				if(error>100.0) {
					error=100.0;
				}
				fitness+=100.0-error;
				answergiven=true;
				break;
			}
		} while(step<MAX_STEPS);
		if(dump && !answergiven) {
			cout << "Out of time." << endl;
		}
	}
#undef GETGRID
	
	fitness/=testix;	//here, testix is the number of tests performed
	
	if(!dump) {
		org->fitness = fitness;
	}
	
#ifndef NO_SCREEN_OUT
	cout<<"Org "<<(org->gnome)->genome_id<<" fitness: "<<org->fitness<<endl;
#endif
	
	org->winner=false;
	return false;
}

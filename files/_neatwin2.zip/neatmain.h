extern double *testdoub;








#include <stdio.h>

#define INPUTS (13)
#define BIASES (1)
#define OUTPUTS (12)

main()
{
	int t,node=1;
	printf("genomestart 1\n"
			"trait 1 0.1 0 0 0 0 0 0 0\n");
	for(t=0; t<INPUTS; t++) {
		printf("node %d 0 1 1\n",node++);
	}
	for(t=0; t<BIASES; t++) {
		printf("node %d 0 1 3\n",node++);
	}
	for(t=0; t<OUTPUTS; t++) {
		printf("node %d 0 0 2\n",node++);
	}
	node=1;
	for(t=0; t<OUTPUTS; t++) {
		int r;
		for(r=0; r<INPUTS+BIASES; r++) {
			printf("gene 1 %d %d 0.0 0 %d 0 1\n",r+1,t+INPUTS+BIASES+1,node++);
		}
	}
	printf("genomeend 1\n");
}

#ifndef _GAMEMAIN_H_
#define _GAMEMAIN_H_

#include <math.h>			// Math Library Header File
#include <iostream>

#include "CPopulation.h"
#include "CParams.h"
#include "utils.h"
#include "differintegral.h"
#include "vectorMath.h"

using namespace std;



#endif

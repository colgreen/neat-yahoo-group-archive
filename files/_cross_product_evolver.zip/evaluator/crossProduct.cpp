
#include "crossProduct.h"

	int gen;
	int best;

void main()			// Window Show State
{

	cout << "generating random vectors." << endl;

	CGenome genome;
	genome.CreateFromFile("bestGenome.nn");

	CNeuralNet* m_brains = genome.CreatePhenotype();

	double FitnessScore = 0.0;

	vector<double> input;
	vector<double> output;

	double a[3], b[3], c[3];

	InitRand();
	for(int r = 0 ; r < 3 ; r++)
	{
		a[r] = RandomClamped();
		b[r] = RandomClamped();
	}
	getAngleDeg(a, b);//side effect is that vectors are normalized
	crossProduct( a, b, c);

	for( r = 0 ; r < 3 ; r++)
		cout << "a[" << r+1 << "] = " << a[r] << endl;
	cout << endl;
	for( r = 0 ; r < 3 ; r++)
		cout << "b[" << r+1 << "] = " << b[r] << endl;
	cout << endl;
	for( r = 0 ; r < 3 ; r++)
		cout << "c[" << r+1 << "] = " << c[r] << endl;
	cout << endl;

	input.clear();
	input.push_back(a[0]);
	input.push_back(a[1]);
	input.push_back(a[2]);
	input.push_back(b[0]);
	input.push_back(b[1]);
	input.push_back(b[2]);


	output = m_brains->Update( input , CNeuralNet::snapshot);
	for( r = 0 ; r < 3 ; r++)
		cout << "output[" << r+1 << "] = " << output[r] << endl;
	cout << endl;

	FitnessScore -= sqrt(pow(output[0] - c[0],2));
	FitnessScore -= sqrt(pow(output[1] - c[1],2));
	FitnessScore -= sqrt(pow(output[2] - c[2],2));

	cout << "Error: " << FitnessScore << endl;

	char t;
	cin >>t;

}//end WinMain()



#include "differintegral.h"
	
/****************************************************************
* This function returns the the qth derivative (or integral if
* q is negative) of the function contained in f, at point N.
* dt represents the step size of N.
* Notes: f must contain at least N points.
* It is assumed that index 0 represents the oldest data point.
****************************************************************/
double fractionalDerivative(float f[], int N, float q, float dt)
{
	float Numerator = N-q-1;
	float Denominator = N;
	double PartialSum = f[0];

	for (int index=1;index<N;index++)
	{
		PartialSum = f[index+1]+ PartialSum*(Numerator-index)/(Denominator-index);
	}

	return PartialSum/pow(dt,q);
}
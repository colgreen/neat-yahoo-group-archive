#ifndef _GAMEMAIN_H_
#define _GAMEMAIN_H_

#include <math.h>			// Math Library Header File
#include <iostream>

#include "CPopulation.h"
#include "CParams.h"
#include "utils.h"
#include "differintegral.h"
#include "vectorMath.h"

using namespace std;


	CParams g_params;				//loads parameter file

	int m_popSize;					//population size

	vector<CNeuralNet*> m_brains;	//collection of controllers

	vector<double> m_fitness;		//fitness values for population

	ofstream history;
	double m_bestFitness;
	double m_avgFitness;
	double error;
	int m_indexBest;

#endif

#include "CParams.h"


double CParams::dPi                       = 0;
double CParams::dHalfPi                   = 0;
double CParams::dTwoPi                    = 0;
int CParams::WindowWidth                  = 400;
int CParams::WindowHeight                 = 400;
int CParams::iNumInputs                   = 0;
int CParams::iNumOutputs                  = 0;
double CParams::dBias                     = -1;
int CParams::iPopSize                     = 0;
int CParams::iNumTicks                    = 0;
int CParams::iNumGens                    = 0;
double CParams::dCollisionDist            = 0;
double CParams::dCellSize                 = 0;
double CParams::dSigmoidResponse          = 1;
int CParams::iNumAddLinkAttempts          = 0;
int CParams::iNumTrysToFindLoopedLink     = 5;
int CParams::iNumTrysToFindOldLink        = 5;
double CParams::dYoungFitnessBonus        = 0;
int CParams::iYoungBonusAgeThreshhold     = 0;
double CParams::dSurvivalRate             = 0;
int CParams::InfoWindowWidth              = 400;
int CParams::InfoWindowHeight             = 400;
int CParams::iNumGensAllowedNoImprovement = 0;
int CParams::iMaxPermittedNeurons         = 0;
double CParams::dChanceAddLink            = 0;
double CParams::dChanceAddNode            = 0;
double CParams::dChanceAddRecurrentLink   = 0;
double CParams::dMutationRate             = 0;
double CParams::dMaxWeightPerturbation    = 0;
double CParams::dProbabilityWeightReplaced= 0;

double CParams::dActivationMutationRate   = 0;
double CParams::dMaxActivationPerturbation= 0;

double CParams::dHistoryMutationRate      = 0;
double CParams::dMaxHistoryPerturbation   = 0; 
int    CParams::iMaxHistoryLength         = 2;


double CParams::dCompatibilityThreshold   = 0;
int CParams::iNumBestSweepers             = 4;
int CParams::iOldAgeThreshold             = 0;
double CParams::dOldAgePenalty            = 0;
double CParams::dCrossoverRate            = 0;
int CParams::iMaxNumberOfSpecies          = 0;



//this function loads in the parameters from a given file name. Returns
//false if there is a problem opening the file.
bool CParams::LoadInParameters(char* szFileName)
{
  fstream grab(szFileName);

  //check file exists
  if (!grab)
  {
    return false;
  }

	char tempChar[255];
	string tempString;

	while( !grab.eof() )
	{
		if( ';' == grab.peek() || '\n' == grab.peek() || ' ' == grab.peek())
			grab.getline(tempChar,255,'\n');
		else
		{
			grab >> tempString;
			if( tempString == "iNumInputs" )
				grab >> iNumInputs;

			if( tempString == "iNumOutputs" )
				grab >> iNumOutputs;

			if( tempString == "iPopSize" )
				grab >> iPopSize;

			if( tempString == "iNumTicks" )
				grab >> iNumTicks;

			if( tempString == "iNumGens" )
				grab >> iNumGens;

			if( tempString == "dCellSize" )
				grab >> dCellSize;

			if( tempString == "iNumAddLinkAttempts" )
				grab >> iNumAddLinkAttempts;

			if( tempString == "dSurvivalRate" )
				grab >> dSurvivalRate;

			if( tempString == "iNumGensAllowedNoImprovement" )
				grab >> iNumGensAllowedNoImprovement;

			if( tempString == "iMaxPermittedNeurons" )
				grab >> iMaxPermittedNeurons;

			if( tempString == "dChanceAddLink" )
				grab >> dChanceAddLink;

			if( tempString == "dChanceAddNode" )
				grab >> dChanceAddNode;

			if( tempString == "dChanceAddRecurrentLink" )
				grab >> dChanceAddRecurrentLink;

			if( tempString == "dMutationRate" )
				grab >> dMutationRate;

			if( tempString == "dMaxWeightPerturbation" )
				grab >> dMaxWeightPerturbation;

			if( tempString == "dProbabilityWeightReplaced" )
				grab >> dProbabilityWeightReplaced;

			if( tempString == "dActivationMutationRate" )
				grab >> dActivationMutationRate;

			if( tempString == "dMaxActivationPerturbation" )
				grab >> dMaxActivationPerturbation;

			if( tempString == "dHistoryMutationRate" )
				grab >> dHistoryMutationRate;

			if( tempString == "dMaxHistoryPerturbation" )
				grab >> dMaxHistoryPerturbation;

			if( tempString == "iMaxHistoryLength" )
				grab >> iMaxHistoryLength;

			if( tempString == "dCompatibilityThreshold" )
				grab >> dCompatibilityThreshold;

			if( tempString == "iOldAgeThreshold" )
				grab >> iOldAgeThreshold;

			if( tempString == "dOldAgePenalty" )
				grab >> dOldAgePenalty;

			if( tempString == "dYoungFitnessBonus" )
				grab >> dYoungFitnessBonus;

			if( tempString == "iYoungBonusAgeThreshhold" )
				grab >> iYoungBonusAgeThreshhold;

			if( tempString == "dCrossoverRate" )
				grab >> dCrossoverRate;

			if( tempString == "iMaxNumberOfSpecies" )
				grab >> iMaxNumberOfSpecies;

		}
	}
	cout << "Grabbed Parameters" << endl;

	grab.close();


  return true;
}
 




  
  


#include "crossProduct.h"

	int gen;
	int best;

void main()			// Window Show State
{

	cout << "Search begun." << endl;
	g_params.Initialize();

	vector<double> FitnessScores;

	vector<double> input;
	vector<double> output;
	vector<double> a1, a2, a3, b1, b2, b3, c1, c2 , c3;

	InitRand();

	CPopulation pop(CParams::iPopSize,
					CParams::iNumInputs,
					CParams::iNumOutputs);

	m_brains = pop.CreatePhenotypes();

	history.open( "history.dat");
	history << "Population size:       " << CParams::iPopSize << endl;
	history << "Number of generations: " << CParams::iNumGens << endl;
	history << endl << "Gen " << "Best " << "Avg"<< endl;

	gen = 0;

	double length ;
	for(int r = 0 ; r < CParams::iNumTicks ; r++)
	{
		a1.push_back(RandomClamped());
		a2.push_back(RandomClamped());
		a3.push_back(RandomClamped());
		length = sqrt(a1[r]*a1[r] + a2[r]*a2[r] + a3[r]*a3[r]);
		a1[r] /= length;
		a2[r] /= length;
		a3[r] /= length;

		b1.push_back(RandomClamped());
		b2.push_back(RandomClamped());
		b3.push_back(RandomClamped());
		length = sqrt(b1[r]*b1[r] + b2[r]*b2[r] + b3[r]*b3[r]);
		b1[r] /= length;
		b2[r] /= length;
		b3[r] /= length;
		
		c1.push_back( a2[r]*b3[r] - a3[r]*b2[r]);
		c2.push_back( a3[r]*b1[r] - a1[r]*b3[r]);
		c3.push_back( a1[r]*b2[r] - a2[r]*b1[r]);
	}

	input.clear();
	input.push_back(0);
	input.push_back(0);
	input.push_back(0);
	input.push_back(0);
	input.push_back(0);
	input.push_back(0);

	for( int g = 0 ; g < CParams::iNumGens ; g++ )
	{
		cout << "Generation " << g;
		m_bestFitness = -1e9;
		m_avgFitness = 0;
		FitnessScores.clear();

		for(int i = 0; i < CParams::iPopSize ; i++)
		{
			FitnessScores.push_back(0);

			for( r = 0 ; r < CParams::iNumTicks ; r++)
			{
				input[0] = a1[r]; input[1] = a2[r]; input[2] = a3[r];
				input[3] = b1[r]; input[4] = b2[r]; input[2] = b3[r];

				output = m_brains[i]->Update( input , CNeuralNet::snapshot);
				
				FitnessScores[i] -= sqrt(pow(output[0] - c1[r],2));
				FitnessScores[i] -= sqrt(pow(output[1] - c2[r],2));
				FitnessScores[i] -= sqrt(pow(output[2] - c3[r],2));
			}

			if(FitnessScores[i] > m_bestFitness) 
				m_bestFitness = FitnessScores[i];

			m_avgFitness += FitnessScores[i]/CParams::iPopSize;
		}

		cout << "  Best: " << m_bestFitness << "  Average:  " << m_avgFitness << endl;
		m_brains = pop.Epoch(FitnessScores);

		history << g << "	" << m_bestFitness << "	" << m_avgFitness << endl;

		gen++;

		pop.WriteGenome("bestGenome.nn", best);
	}


}//end WinMain()



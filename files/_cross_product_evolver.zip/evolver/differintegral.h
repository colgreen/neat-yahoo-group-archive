#ifndef _DIFFERINTEGRAL_H_
#define _DIFFERINTEGRAL_H_

#include "math.h"

#define pi 3.1415962

double fractionalDerivative(float f[],int N, float q, float dt);

#endif

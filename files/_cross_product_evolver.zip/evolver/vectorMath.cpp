
#include "vectorMath.h"

double getAngleDeg(double* a, double* b)
{
	//normalization
	double length = sqrt(a[0]*a[0] + a[1]*a[1] + a[2]*a[2]);
	a[0] /= length;
	a[1] /= length;
	a[2] /= length;

	length = sqrt(b[0]*b[0] + b[1]*b[1] + b[2]*b[2]);
	b[0] /= length;
	b[1] /= length;
	b[2] /= length;

	//arccos of the dot product gives angle
	float angle = acos(a[0]*b[0] + a[1]*b[1] + a[2]*b[2]);

	angle *= 180.0/3.14159; //convert to degrees

	return angle;
}

void crossProduct(double* a, double* b, double* c)
{
		c[0] = a[1]*b[2] - a[2]*b[1];
		c[1] = a[2]*b[0] - a[0]*b[2];
		c[2] = a[0]*b[1] - a[1]*b[0];
}
#ifndef _VECTORMATH_H_
#define _VECTORMATH_H_

#include <math.h>			// Math Library Header File

//returns the angle between vectors a and b
double getAngleDeg(double* a, double* b);

//returns the cross product of a into b, and stores it in c
void crossProduct(double* a, double* b, double* c);

#endif
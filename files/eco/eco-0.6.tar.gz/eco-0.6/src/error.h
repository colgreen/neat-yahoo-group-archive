#ifndef __ERROR_H__
#define __ERROR_H__

#include <stdio.h>
#include <assert.h>
#include <errno.h>
#include <string.h>

/* #define TRACE(ARGS...) while (0) */
/* #define ERRNO(ARGS...) while (0) */
/* #define DEBUG(ARGS...) while (0) */

#define _PRINT(TYPE, XTRA, ARGS...) \
do { \
	fprintf(stdout, TYPE ":%s:%s():%d", __FILE__, __FUNCTION__, __LINE__); \
	fprintf(stdout, ":%s", XTRA); \
	fprintf(stdout, ":" ARGS); \
	fprintf(stdout, "\n"); \
} while (0)

#define TRACE(ARGS...) _PRINT("TRACE", "", ARGS);

#define ERRNO(ARGS...) _PRINT("ERRNO", strerror(errno), ARGS)

#define DEBUG(ARGS...) _PRINT("DEBUG", "", ARGS)

#define INFO(ARGS...) _PRINT("INFO", "", ARGS)

#define WARN(ARGS) _PRINT("WARN", "", ARGS)

#define CRIT(ARGS) _PRINT("CRIT", "", ARGS)

#define ASSERT(ARGS) assert(ARGS);

#endif /* __ERROR_H__ */

/* Credits to Richard Sutton & Charles Anderson for the original
 * implementation of the cart pole code. */

#define _SVID_SOURCE

#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "neat.h"

/* TODO: recur?!? */

#define _XOR_NRUNS	100
#define _XOR_NGENS	100
#define _XOR_NORGS	100
#define _XOR_NINPUTS	3
#define _XOR_NOUTPUTS	1
#define _XOR_NRECUR	0

#define _POLE1_NRUNS	 100
#define _POLE1_NGENS	 100
#define _POLE1_NORGS	 100
#define _POLE1_NINPUTS	 5
#define _POLE1_NOUTPUTS	 2
#define _POLE1_NRECUR	 0
#define _POLE1_MAXSTEPS  100000

#define _CART_GRAVITY        9.8
#define _CART_MASS_CART      1
#define _CART_MASS_POLE     .1
#define _CART_MASS_TOT      (_CART_MASS_CART + _CART_MASS_POLE)
#define _CART_POLE_LEN2     .5
#define _CART_POLEMASS_LEN  (_CART_POLE_LEN2 * _CART_MASS_POLE)
#define _CART_FORCE_MAG	    10
#define _CART_TAU           .02
#define _CART_DEGREES_12    .20943951

int time_alive_min = 0;

void _cart_pole(int action, float *x, float *xdot, float *theta,
		float *thetadot)
{
	float xacc, thetaacc, force, ctheta, stheta, tmp;

	force = action > 0 ? _CART_FORCE_MAG : -_CART_FORCE_MAG;

	ctheta = cos(*theta);
	stheta = sin(*theta);

	tmp = (force + _CART_POLEMASS_LEN * *thetadot * *thetadot * stheta) /
	      _CART_MASS_TOT;
	
	thetaacc = (_CART_GRAVITY * stheta - tmp * ctheta) /
		   (_CART_POLE_LEN2 * (4. / 3 -
				       _CART_MASS_POLE * ctheta * ctheta /
				       _CART_MASS_TOT));

	xacc = tmp - _CART_POLEMASS_LEN * thetaacc * ctheta / _CART_MASS_TOT;

	*x += _CART_TAU * *xdot;
	*xdot += _CART_TAU * xacc;
	*theta += _CART_TAU * *thetadot;
	*thetadot += _CART_TAU * thetaacc;
}

int _pole1_eval(int popid, int orgid)
{
	float x, xdot, theta, thetadot;
	const float *out;
	float in[5], degrees = _CART_DEGREES_12;
	int steps = 0;

	x = (lrand48() % 4800) / 1000. - 2.4;
	xdot = (lrand48() % 2000) / 1000. - 1;
	theta = (lrand48() % 400) / 1000. - .2;
	thetadot = (lrand48() % 3000) / 1000. - 1.5;

	while (steps < _POLE1_MAXSTEPS) {
		in[0] = 1;
		in[1] = (x + 2.4) / 4.8;
		in[2] = (xdot + .75) / 1.5;
		in[3] = (theta + degrees) / .41;
		in[4] = (thetadot + 1.) / 2.;

		out = neat_activate(popid, orgid, in);

		_cart_pole(out[0] <= out[1], &x, &xdot, &theta, &thetadot);

		if (fabs(x) > 2.4 || fabs(theta) > degrees)
			break;

		steps++;
	}

	neat_fitness_set(popid, orgid, steps);

	return steps == _POLE1_MAXSTEPS;
}

int _xor_eval(int popid, int orgid)
{
	int i;
	float out[4], esum;
	float in[12] = { 1, 0, 0,
			 1, 0, 1,
			 1, 1, 0,
			 1, 1, 1 };

	for (i = 0; i < 4; i++) {
		out[i] = *neat_activate(popid, orgid, &in[3 * i]);
		neat_flush(popid, orgid);
	}

	esum = fabs(out[0]) + fabs(1 - out[1]) + fabs(1 - out[2]) +
	       fabs(out[3]);

	neat_fitness_set(popid, orgid, pow(4 - esum, 2));

	return out[0] < .5 && out[1] >= .5 && out[2] >= .5 && out[3] < .5;
}

void _test(int norgs, int ninputs, int noutputs, int nrecur,
	   int nruns, int ngens, int (*eval)(int, int))
{
	int run, gen, org, popid, wnodes, wgenes;
	int nwins = 0, tgens = 0, tevals = 0, tnodes = 0, tgenes = 0;

	printf("nruns:%d ngens:%d norgs:%d", nruns, ngens, norgs);
	fflush(stdout);

	for (run = 0; run < nruns; run++) {
		popid = neat_create(norgs, ninputs, noutputs, 0, nrecur, 1);

		for (gen = 1; gen <= ngens; gen++) {
			for (org = 0; org < norgs; org++) {
				if (!eval(popid, org))
					continue;
				/* winner */
				nwins++;
				neat_info_get(popid, org, &wnodes, &wgenes);
				tgens += gen;
				tevals += norgs * (gen - 1) + org + 1;
				tnodes += wnodes;
				tgenes += wgenes;
				goto _next_run;
			}
			neat_epoch(popid, gen);
		}
_next_run:
		neat_destroy(popid);
	}

	printf(" nwins:%d", nwins);

	if (nwins == 0)
		goto _done;

	printf(" agens:%.2f aevals:%.2f anodes:%.2f agenes:%.2f",
	       (double)tgens / nwins, (double)tevals / nwins,
	       (double)tnodes / nwins, (double)tgenes / nwins);
_done:
	printf("\n");
}

int main(int argc, char **argv)
{
	srand(time(NULL));

	printf("XOR ");
	_test(_XOR_NORGS, _XOR_NINPUTS, _XOR_NOUTPUTS, _XOR_NRECUR,
	      _XOR_NRUNS, _XOR_NGENS, _xor_eval);

	printf("POLE1 ");
	_test(_POLE1_NORGS, _POLE1_NINPUTS, _POLE1_NOUTPUTS, _POLE1_NRECUR,
	      _POLE1_NRUNS, _POLE1_NGENS, _pole1_eval);

	return 0;
}

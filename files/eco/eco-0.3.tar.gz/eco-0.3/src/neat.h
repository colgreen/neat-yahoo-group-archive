#ifndef __NEAT_H__
#define __NEAT_H__

#include <stdio.h>

int neat_create(int size, int ninputs, int noutputs, double geneprob);

int neat_create_from_file(int size, int ninputs, int noutputs, FILE *file);

void neat_destroy(int popid);

void neat_print(int popid, int orgid, FILE *file);

const double * neat_activate(int popid, int orgid, const double *inputs);

void neat_flush(int popid, int orgid);

int neat_evolve(int popid);

void neat_epoch(int popid, int generation);

double neat_fitness_get(int popid, int orgid);

void neat_fitness_set(int popid, int orgid, double fitness);

#endif /* __NEAT_H__ */

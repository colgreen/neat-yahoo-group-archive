/* Credits to Kenneth O. Stanley for the rtNEAT.1.0 C++ implementation.
 * Reading that code helped me understand and implement the NEAT algorithm. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>

#include "neat.h"
#include "error.h"

#define _MAX_POPS      32
#define _SIGMOID_SLOPE 4.924273

/* params default values */
#define _MUT_PROB_ADD_NODE        .1
#define _MUT_PROB_ADD_GENE        .1
#define _MUT_PROB_GENE_WEIGHTS    .9
#define _MUT_PROB_TOGGLE_ENABLE   .1
#define _MUT_PROB_RECURRENT	  .1
#define _MUT_WEIGHT_RATE          1
#define _MUT_WEIGHT_POWER         1
#define _MUT_TRIES_NEW_NODE       20
#define _MUT_TRIES_NEW_GENE       20
#define _MUT_TRIES_TOGGLE_ENABLE  20
#define _MATE_PROB_MATE_ONLY      .2
#define _MATE_PROB_MUT_ONLY       .25
#define _MATE_PROB_MULTIPOINT     .6
#define _MATE_PROB_MULTIPOINT_AVG .4
#define _MATE_PROB_INTERSPECIES   .01
#define _CMP_COEFF_DISJOINT	  1
#define _CMP_COEFF_EXCESS	  1
#define _CMP_COEFF_MUTDIFF	  3
#define _CMP_THRESH		  3
#define _AGE_DROP		  15
#define _AGE_SIGNIFICANCE	  1
#define _SURVIVAL_THRESH	  .2
#define _SPECIES_NTARGETS	  10


#define _MAX(A, B) ((A) > (B) ? (A) : (B))
#define _MIN(A, B) ((A) < (B) ? (A) : (B))

#define _NIDX_IS_BIAS(IDX) ((IDX) == 0)
#define _NIDX_IS_INPUT(IDX) ((IDX) < genome->pop->ninputs)
#define _NIDX_IS_OUTPUT(IDX) (((IDX) < genome->pop->ninputs + \
				       genome->pop->noutputs) && \
			     ((IDX) >= genome->pop->ninputs))
#define _NIDX_IS_HIDDEN(IDX) ((IDX) >= genome->pop->ninputs + \
				       genome->pop->noutputs)

#define _PARAMS_WRITE(VAR, FMT) \
fprintf(file, "%-25s "FMT"\n", #VAR, pops[popid]->VAR)
#define _PARAMS_WRITEF(VAR) _PARAMS_WRITE(VAR, "%f")
#define _PARAMS_WRITEI(VAR) _PARAMS_WRITE(VAR, "%d")

#define _PARAMS_READ(VAR, FMT) \
do { \
	fgetpos(file, &pos); \
	if (fscanf(file, #VAR" "FMT"\n", &pops[popid]->VAR) != 1) { \
		fsetpos(file, &pos); \
		return -1; \
	} \
} while (0)
#define _PARAMS_READF(VAR) _PARAMS_READ(VAR, "%f")
#define _PARAMS_READI(VAR) _PARAMS_READ(VAR, "%d")


int npops = 0;
struct _population ** pops = NULL;

extern int time_alive_min;

struct _op
{
	float *ptr;
	double val;
};

struct _node
{
	int id;
	int gene_split;
};

struct _link
{
	int id;
	int snode;
	int enode;
	int recurrent;
};

struct _gene
{
	struct _link *link;

	int sidx;
	int eidx;

	float weight;
	int enable;
};

struct _genome
{
	struct _population *pop;

	int nnodes;
	struct _node **nodes;

	int ngenes;
	struct _gene **genes;

	int nops;
	struct _op *ops;

	float *activations;
};

struct _organism
{
	double fitness;

	int time_alive;

	struct _genome *genome;
	struct _species *species;
};

struct _species
{
	double fitness_max_ever;

	int age;
	int age_imp;

	int norgs;
	struct _organism **orgs;
};

struct _population
{
	int ninputs;
	int noutputs;
	int nrecurrent;

	int node_cur;
	int nnodes;
	int mnodes;
	struct _node **nodes;

	int link_cur;
	int nlinks;
	int mlinks;
	struct _link **links;

	int norgs;
	struct _organism **orgs;

	int nspecies;
	struct _species **species;

	/* params */
	float mate_prob_mate_only;
	float mate_prob_mut_only;
	float mate_prob_multipoint;
	float mate_prob_multipoint_avg;
	float mate_prob_interspecies;
	float mut_prob_add_node;
	float mut_prob_add_gene;
	float mut_prob_gene_weights;
	float mut_prob_toggle_enable;
	float mut_prob_recurrent;
	float mut_weight_rate;
	float mut_weight_power;
	int mut_tries_new_node;
	int mut_tries_new_gene;
	int mut_tries_toggle_enable;
	float cmp_coeff_disjoint;
	float cmp_coeff_excess;
	float cmp_coeff_mutdiff;
	float cmp_thresh;
	int age_drop;
	float age_significance;
	float survival_thresh;
	int species_ntargets;
};


int _genome_insert_node(struct _genome *genome, struct _node *node);
void _genome_insert_gene(struct _genome *genome, struct _gene *gene);
void _population_speciate(struct _population *pop, struct _organism *org,
			  struct _species *mspc, struct _species *dspc);
struct _node * _population_get_node(struct _population *pop, int id,
				    int gene_split);
struct _link * _population_get_link(struct _population *pop, int id,
				    int snode, int enode, int recurrent);


/* MISC */

double _ranf(void)
{
        return rand() / (double) RAND_MAX;
}

double _gaussrand(void)
{
	static int flip = 0;
	static double y2;
	double x1, x2, y1, w;

	flip = !flip;
	if (flip) {
		do {
			x1 = 2 * _ranf() - 1;
			x2 = 2 * _ranf() - 1;
			w = x1 * x1 + x2 * x2;
		} while ((w >= 1) || (w == 0));
		w = sqrt(-2 * log(w) / w);
		y1 = x1 * w;
		y2 = x2 * w;
		return y1;
	} else
		return y2;
 }

int _randposneg(void)
{
	return rand() % 2 ? 1 : -1;
}

double _sigmoid(double t)
{
	return 1 / (1 + exp(-t));
}


/* NODE */

struct _node * _node_create(int id, int gene_split)
{
	struct _node *node;

	node = malloc(sizeof(struct _node));
	ASSERT(node);

	node->id = id;
	node->gene_split = gene_split;

	return node;
}

struct _node * _node_create_dup(const struct _node *node)
{
	ASSERT(node);

	return _node_create(node->id, node->gene_split);
}

struct _node * _node_create_from_file(FILE *file, struct _population *pop)
{
	struct _node *node;
	int id, gene_split;
	fpos_t pos;

	ASSERT(file);

	fgetpos(file, &pos);
	if (fscanf(file, "node %d %d\n", &id, &gene_split) != 2) {
		fsetpos(file, &pos);
		return NULL;
	}

	node = _population_get_node(pop, id, gene_split);
	ASSERT(node);

	return _node_create_dup(node);
}

void _node_destroy(struct _node *node)
{
	ASSERT(node);

	free(node);
}

void _node_print(const struct _node *node, FILE *file)
{
	ASSERT(node);
	ASSERT(file);

	fprintf(file, "node %8d %8d\n", node->id, node->gene_split);
}


/* LINK */

struct _link * _link_create(int id, int snode, int enode, int recurrent)
{
	struct _link *link;

	link = malloc(sizeof(struct _link));
	ASSERT(link);

	link->id = id;
	link->snode = snode;
	link->enode = enode;
	link->recurrent = recurrent;

	return link;
}

void _link_destroy(struct _link *link)
{
	ASSERT(link);

	free(link);
}


/* GENE */

struct _gene * _gene_create(struct _link *link, int sidx, int eidx,
			    float weight, int enable)
{
	struct _gene *gene;

	ASSERT(link);

	gene = malloc(sizeof(struct _gene));
	ASSERT(gene);

	gene->link = link;
	gene->sidx = sidx;
	gene->eidx = eidx;
	gene->weight = weight;
	gene->enable = enable;

	return gene;
}

struct _gene * _gene_create_dup(const struct _gene *gene)
{
	ASSERT(gene);

	return _gene_create(gene->link, gene->sidx, gene->eidx,
			    gene->weight, gene->enable);
}

struct _gene * _gene_create_from_file(FILE *file, struct _population *pop,
				      const struct _genome *genome)
{
	int id, sidx, eidx, recurrent, enable;
	float weight;
	struct _link *link;
	fpos_t pos;

	ASSERT(file);

	fgetpos(file, &pos);
	if (fscanf(file, "gene %d %d %d %d %d %f\n", &id, &sidx,
		   &eidx, &recurrent, &enable, &weight) != 6) {
		fsetpos(file, &pos);
		return NULL;
	}

	link = _population_get_link(pop, id,
				    genome->nodes[sidx]->id,
				    genome->nodes[eidx]->id, recurrent);
	ASSERT(link);

	return _gene_create(link, sidx, eidx, weight, enable);
}

void _gene_destroy(struct _gene *gene)
{
	ASSERT(gene);

	free(gene);
}

void _gene_print(const struct _gene *gene, FILE *file)
{
	ASSERT(gene);
	ASSERT(file);

	fprintf(file, "gene %8d %8d %8d %8d %8d    %9f\n",
		gene->link->id, gene->sidx, gene->eidx,
		gene->link->recurrent, gene->enable, gene->weight);
}


/* GENOME */

void _genome_init(struct _genome *genome, struct _population *pop,
		  int maxnodes, int maxgenes)
{
	ASSERT(genome);
	ASSERT(pop);

	genome->pop = pop;

	genome->nnodes = 0;
	genome->ngenes = 0;
	genome->nops = 0;
	genome->ops = NULL;
	genome->activations = NULL;

	genome->nodes = malloc((maxnodes + 1) * sizeof(struct _node *));
	ASSERT(genome->nodes);

	genome->genes = malloc((maxgenes + 3) * sizeof(struct _gene *));
	ASSERT(genome->genes);
}

struct _genome * _genome_create(struct _population *pop, double geneprob,
				int maxnodes, int maxgenes)
{
	struct _genome * genome;
	struct _node *node;
	struct _gene *gene;
	struct _link *link;
	int i, s, e, id, ni, no;
	float weight;

	ASSERT(pop);

	ni = pop->ninputs;
	no = pop->noutputs;

	genome = malloc(sizeof(struct _genome));
	ASSERT(genome);

	_genome_init(genome, pop, maxnodes, maxgenes);

	for (i = 0; i < ni + no; i++) {
		id = 1 + i;
		node = _population_get_node(pop, id, -id);
		ASSERT(node);
		_genome_insert_node(genome, _node_create_dup(node));
	}

	if (geneprob == 0)
		return genome;

	for (e = ni; e < ni + no; e++) {
		for (s = 0; s < ni; s++) {
			if (_ranf() > geneprob)
				continue;

			weight = _randposneg() * _ranf();

			link = _population_get_link(pop, 0, 1 + s, 1 + e, 0);
			ASSERT(link);

			gene = _gene_create(link, s, e, weight, 1);
			ASSERT(gene);

			_genome_insert_gene(genome, gene);
		}
	}

	return genome;
}

struct _genome * _genome_create_from_file(struct _population *pop, FILE *file)
{
	struct _genome * genome;
	struct _node *node;
	struct _gene *gene;
	int nnodes, ngenes;
	fpos_t pos;

	ASSERT(file);

	fgetpos(file, &pos);
	if (fscanf(file, "genome %d %d\n", &nnodes, &ngenes) != 2) {
		fsetpos(file, &pos);
		return NULL;
	}

	genome = malloc(sizeof(struct _genome));
	ASSERT(genome);

	_genome_init(genome, pop, nnodes, ngenes);

	while ((node = _node_create_from_file(file, pop)))
		_genome_insert_node(genome, node);
	ASSERT(genome->nnodes == nnodes);

	while ((gene = _gene_create_from_file(file, pop, genome)))
		_genome_insert_gene(genome, gene);
	ASSERT(genome->ngenes == ngenes);

	return genome;
}

struct _genome * _genome_create_dup(const struct _genome *genome)
{
	struct _genome *dup;
	int i;

	ASSERT(genome);

	dup = malloc(sizeof(struct _genome));
	ASSERT(dup);

	_genome_init(dup, genome->pop, genome->nnodes, genome->ngenes);

	for (i = 0; i < genome->nnodes; i++)
		_genome_insert_node(dup, _node_create_dup(genome->nodes[i]));

	for (i = 0; i < genome->ngenes; i++)
		_genome_insert_gene(dup, _gene_create_dup(genome->genes[i]));

	return dup;
}

void _genome_destroy(struct _genome *genome)
{
	int i;

	ASSERT(genome);

	for (i = 0; i < genome->nnodes; i++)
		_node_destroy(genome->nodes[i]);
	free(genome->nodes);

	for (i = 0; i < genome->ngenes; i++)
		_gene_destroy(genome->genes[i]);
	free(genome->genes);

	if (genome->ops)
		free(genome->ops);

	if (genome->activations)
		free(genome->activations);

	free(genome);
}

void _genome_print(const struct _genome *genome, FILE *file)
{
	int i;

	ASSERT(genome);
	ASSERT(file);

	fprintf(file, "genome %d %d\n", genome->nnodes, genome->ngenes);

	for (i = 0; i < genome->nnodes; i++)
		_node_print(genome->nodes[i], file);

	for (i = 0; i < genome->ngenes; i++)
		_gene_print(genome->genes[i], file);
}

void _genome_flush(struct _genome *genome)
{
	int i;

	ASSERT(genome);

	for (i = 0; i < (1 + genome->pop->nrecurrent) * genome->nnodes; i++)
		genome->activations[i] = 0;
}

void _genome_codegen(struct _genome *genome, int nidx, int off, int nin)
{
	struct _gene **genes = genome->genes;
	struct _op *op;
	int i;

	ASSERT(genome);

	/* store dst pointer for the summation, and number of incoming */
	op = &genome->ops[genome->nops];
	op->ptr = genome->activations + nidx;
	op->val = nin;
	op++;

	/* set up the summation operations for this node */
	for (i = off; i < genome->ngenes && genes[i]->eidx == nidx; i++) {
		if (!genes[i]->enable)
			continue;
		op->ptr = genome->activations + genes[i]->sidx +
			  genes[i]->link->recurrent * genome->nnodes;
		op->val = genes[i]->weight;
		op++;
	}

	genome->nops += 1 + nin;
}

void _genome_pre_traverse(struct _genome *genome, char *visited, int *inoff)
{
	int i, eidx, oeidx = -1;

	ASSERT(genome);
	ASSERT(visited);
	ASSERT(inoff);

	memset(visited, 0, genome->nnodes);

	/* build offsets to start of new enodes in sorted gene array */
	for (i = 0; i < genome->ngenes; i++) {
		eidx = genome->genes[i]->eidx;
		if (eidx != oeidx) {
			inoff[eidx] = i;
			oeidx = eidx;
		}
	}
}

int _genome_traverse(struct _genome *genome, int nidx,
		     char *visited, int *inoff, int *nodes, int *nnodes,
		     void (*_codegen)(struct _genome *, int, int, int))
{
	int i, nin = 0;

	ASSERT(genome);
	ASSERT(visited);

	if (_NIDX_IS_INPUT(nidx))
		return 0;

	if (visited[nidx])
		return visited[nidx] == 1;
	visited[nidx] = 1;

	/* traverse deeper into the graph */
	for (i = inoff[nidx]; i < genome->ngenes &&
				  genome->genes[i]->eidx == nidx; i++) {
		if (!genome->genes[i]->enable)
			/* skip disabled genes */
			continue;
		if (nodes && genome->genes[i]->link->recurrent)
			/* store recurrent start nodes for later processing */
			nodes[(*nnodes)++] = genome->genes[i]->sidx;
		else if (_genome_traverse(genome, genome->genes[i]->sidx,
					  visited, inoff, nodes, nnodes,
					  _codegen))
			/* loop */
			return 1;
		nin++;
	}

	if (_codegen && nin > 0)
		_codegen(genome, nidx, inoff[nidx], nin);

	visited[nidx] = 2;

	return 0;
}

int _genome_has_loop(struct _genome *genome)
{
	int i, nnodes = 0, nodes[genome->pop->noutputs + genome->ngenes];
	int inoff[genome->nnodes];
	char visited[genome->nnodes];

	ASSERT(genome);

	_genome_pre_traverse(genome, visited, inoff);

	/* start from outputs */
	for (i = 0; i < genome->pop->noutputs; i++)
		nodes[nnodes++] = genome->pop->ninputs + i;

	for (i = 0; i < nnodes; i++)
		if (_genome_traverse(genome, nodes[i], visited, inoff,
				     nodes, &nnodes, NULL))
			/* loop */
			return 1;
	return 0;
}

int _genome_is_loop(struct _genome *genome, int sidx, int eidx)
{
	int inoff[genome->nnodes], loop;
	char visited[genome->nnodes];

	ASSERT(genome);

	_genome_pre_traverse(genome, visited, inoff);

	loop = _genome_traverse(genome, sidx, visited, inoff, NULL, NULL, NULL);
	/* TODO: loop?!? */

	return visited[eidx] || loop;
}

void _genome_genesis(struct _genome *genome)
{
	int loop, i, nnodes = 0, nodes[genome->pop->noutputs + genome->ngenes];
	int inoff[genome->nnodes];
	char visited[genome->nnodes];

	ASSERT(genome);

	genome->ops = malloc((genome->ngenes + genome->nnodes -
			      genome->pop->ninputs) * sizeof(struct _op));
	ASSERT(genome->ops);

	genome->activations = malloc((1 + genome->pop->nrecurrent) *
				     genome->nnodes * sizeof(float));
	ASSERT(genome->activations);
	_genome_flush(genome);

	_genome_pre_traverse(genome, visited, inoff);

	/* start from outputs */
	for (i = 0; i < genome->pop->noutputs; i++)
		nodes[nnodes++] = genome->pop->ninputs + i;

	for (i = 0; i < nnodes; i++) {
		loop = _genome_traverse(genome, nodes[i], visited, inoff,
					nodes, &nnodes, _genome_codegen);
		ASSERT(!loop);
	}
}

const float * _genome_activate(struct _genome *genome, const float *inputs)
{
	struct _op *op;
	float *dst, sum;
	int n, nin;

	ASSERT(genome);
	ASSERT(inputs);

	/* TODO: optimize */
	memmove(genome->activations + genome->nnodes,
		genome->activations,
		genome->pop->nrecurrent * genome->nnodes * sizeof(float));
	memcpy(genome->activations, inputs,
	       genome->pop->ninputs * sizeof(float));

	/* evaluate activation operations */
	op = genome->ops;
	while (op < genome->ops + genome->nops) {
		dst = op->ptr;
		nin = op->val;
		op++;
		for (n = 0, sum = 0; n < nin; n++, op++)
			sum += *op->ptr * op->val;
		*dst = _sigmoid(sum * _SIGMOID_SLOPE);
	}
	ASSERT(op == genome->ops + genome->nops);

	/* return pointer to start of outputs */
	return genome->activations + genome->pop->ninputs;
}

double _genome_cmp(const struct _genome *genome, const struct _genome *cmp,
		   const struct _population *pop)
{
	struct _gene *g1, *g2;
	double difftot = 0;
	int excess = 0, disjoint = 0, matching = 0;
	int i, j;

	ASSERT(genome);
	ASSERT(cmp);
	ASSERT(pop);

	i = 0;
	j = 0;
	while ((i != genome->ngenes) || (j != cmp->ngenes)) {
		if (i == genome->ngenes) {
			excess++;
			j++;
			continue;
		}
		if (j == cmp->ngenes) {
			excess++;
			i++;
			continue;
		}
		g1 = genome->genes[i];
		g2 = cmp->genes[j];
		if (g2->link->enode < g1->link->enode) {
			disjoint++;
			j++;
			continue;
		}
		if (g1->link->enode < g2->link->enode) {
			disjoint++;
			i++;
			continue;
		}
		/* same enode */
		if (g2->link->id < g1->link->id) {
			disjoint++;
			j++;
			continue;
		}
		if (g1->link->id < g2->link->id) {
			disjoint++;
			i++;
			continue;
		}
		/* same gene */
		difftot += fabs(g1->weight - g2->weight);
		matching++;
		i++;
		j++;
	}

	matching = matching ? matching : 1;

	return (pop->cmp_coeff_disjoint * disjoint +
		pop->cmp_coeff_excess * excess +
		pop->cmp_coeff_mutdiff * difftot / matching);
}

struct _node * _genome_find_node(const struct _genome *genome, int id)
{
	int i;

	ASSERT(genome);

	for (i = 0; i < genome->nnodes; i++)
		if (genome->nodes[i]->id == id)
			return genome->nodes[i];

	return NULL;
}

struct _gene * _genome_find_gene(const struct _genome *genome,
				 int snode, int enode, int recurrent)
{
	struct _gene *g;
	int i;

	ASSERT(genome);

	for (i = 0; i < genome->ngenes; i++) {
		g = genome->genes[i];
		if (g->link->snode == snode &&
		    g->link->enode == enode &&
		    g->link->recurrent == recurrent)
			return g;
	}

	return NULL;
}

int _genome_insert_node(struct _genome *genome, struct _node *node)
{
	int i, j;

	ASSERT(genome);
	ASSERT(node);

	if (genome->nnodes == 0 ||
	    node->id > genome->nodes[genome->nnodes - 1]->id) {
		/* add last */
		genome->nodes[genome->nnodes] = node;
		return genome->nnodes++;
	}
	for (i = 0; i < genome->nnodes; i++) {
		ASSERT(node->id != genome->nodes[i]->id);
		if (node->id < genome->nodes[i]->id) {
			/* fix indexes of tail */
			for (j = 0; j < genome->ngenes; j++) {
				if (genome->genes[j]->sidx >= i)
					genome->genes[j]->sidx++;
				if (genome->genes[j]->eidx >= i)
					genome->genes[j]->eidx++;
			}
			/* insert */
			memmove(&genome->nodes[i + 1], &genome->nodes[i],
				(genome->nnodes - i) * sizeof(struct _node *));
			genome->nodes[i] = node;
			genome->nnodes++;
			return i;
		}
	}
	ASSERT(NULL);
	return -1;
}

void _genome_insert_gene(struct _genome *genome, struct _gene *gene)
{
	struct _gene **genes = genome->genes;
	struct _link *link = gene->link;
	int i, j;

	ASSERT(genome);
	ASSERT(gene);

	if ((genome->ngenes == 0) ||
	    (link->enode > genes[genome->ngenes - 1]->link->enode) ||
	    (link->enode == genes[genome->ngenes - 1]->link->enode &&
	     link->id > genes[genome->ngenes - 1]->link->id)) {
		/* add last */
		genes[genome->ngenes++] = gene;
		return;
	}
	for (i = 0; i < genome->ngenes; i++) {
		ASSERT(link->id != genes[i]->link->id);

		if (link->enode > genes[i]->link->enode)
			continue;

		if (link->enode == genes[i]->link->enode &&
		    link->id > genes[i]->link->id) {
			continue;
		}

		/* insert */
		memmove(&genome->genes[i + 1], &genome->genes[i],
			(genome->ngenes - i) * sizeof(struct _gene *));
		genome->genes[i] = gene;
		genome->ngenes++;
		return;
	}
}

void _genome_mutate_add_node(struct _genome *genome, struct _population *pop)
{
	struct _node *node;
	struct _gene *gene1, *gene2, *g = NULL;
	struct _link *link1, *link2;
	int i, j, nidx;

	ASSERT(genome);
	ASSERT(pop);

	if (genome->ngenes == 0)
		return;

	for (i = 0; i < pop->mut_tries_new_node; i++) {
		/* random gene */
		g = genome->genes[rand() % genome->ngenes];

		/* try again if we have this split */
		for (j = 0; j < genome->nnodes; j++)
			if (genome->nodes[j]->gene_split == g->link->id)
				break;
		if (j != genome->nnodes)
			continue;

		if (g->enable && !g->link->recurrent && !_NIDX_IS_BIAS(g->sidx))
			break;
	}

	if (i == pop->mut_tries_new_node)
		return;

	node = _population_get_node(pop, 0, g->link->id);
	ASSERT(node);

	nidx = _genome_insert_node(genome, _node_create_dup(node));

	link1 = _population_get_link(pop, 0, g->link->snode, node->id, 0);
	ASSERT(link1);

	link2 = _population_get_link(pop, 0, node->id, g->link->enode, 0);
	ASSERT(link2);

	gene1 = _gene_create(link1, g->sidx, nidx, 1, 1);
	ASSERT(gene1);

	gene2 = _gene_create(link2, nidx, g->eidx, .3 * g->weight, 1);
	ASSERT(gene2);

	_genome_insert_gene(genome, gene1);
	_genome_insert_gene(genome, gene2);

	g->enable = 0;
}

void _genome_mutate_add_gene(struct _genome *genome, struct _population *pop)
{
	struct _gene *gene;
	struct _node *snode = NULL, *enode = NULL;
	struct _link *link;
	float weight;
	int i, rnd, rec, sidx = -1, eidx = -1;

	ASSERT(genome);
	ASSERT(genome->nnodes >= 2);
	ASSERT(pop);

	rec = pop->nrecurrent ? (_ranf() <= pop->mut_prob_recurrent) *
				(1 + rand() % pop->nrecurrent) : 0;

	for (i = 0; i < pop->mut_tries_new_gene; i++) {
		/* snode */
		sidx = rand() % genome->nnodes;
		snode = genome->nodes[sidx];

		if (rec && _NIDX_IS_BIAS(sidx))
			continue;

		/* enode */
		eidx = pop->ninputs + rand() % (genome->nnodes - pop->ninputs);
		enode = genome->nodes[eidx];

		if (!rec && _genome_is_loop(genome, sidx, eidx))
			continue;

		if (!_genome_find_gene(genome, snode->id, enode->id, rec))
			break;
	}
	ASSERT(sidx != -1 && eidx != -1);

	if (i == pop->mut_tries_new_gene)
		return;

	weight = _randposneg() * _ranf();

	link = _population_get_link(pop, 0, snode->id, enode->id, rec);
	ASSERT(link);

	gene = _gene_create(link, sidx, eidx, weight, 1);
	ASSERT(gene);

	_genome_insert_gene(genome, gene);
}

void _genome_mutate_gene_weights(struct _genome *genome,
				 const struct _population *pop)
{
	double gauss, cgauss, randnum, randchoice;
	struct _gene *g;
	int i;

	ASSERT(genome);
	ASSERT(pop);

	for (i = 0; i < genome->ngenes; i++) {
		if (_ranf() <= .5) {
			gauss = .3;
			cgauss = .1;
		} else if (genome->ngenes >= 10 && i > .8 * genome->ngenes) {
			gauss = .5;
			cgauss = .3;
		} else if (_ranf() <= .5) {
			gauss = 1 - pop->mut_weight_rate;
			cgauss = 1 - pop->mut_weight_rate - .1;
		} else {
			gauss = 1 - pop->mut_weight_rate;
			cgauss = 1 - pop->mut_weight_rate;
		}
		randnum = _randposneg() *_ranf() * pop->mut_weight_power;
		randchoice = _ranf();

		g = genome->genes[i];
		if (randchoice > gauss)
			g->weight += randnum;
		else if (randchoice > cgauss)
			g->weight = randnum;
		/*if (g->weight > 3)
			g->weight = 3;
		else if (g->weight < -3)
			g->weight = -3;*/
	}
}

void _genome_mutate_toggle_enable(struct _genome *genome,
				  const struct _population *pop)
{
	struct _gene *g;
	int i;

	ASSERT(genome);

	if (genome->ngenes == 0)
		return;

	for (i = 0; i < pop->mut_tries_toggle_enable; i++) {
		g = genome->genes[rand() % genome->ngenes];

		if (!g->enable) {
			if (_genome_is_loop(genome, g->sidx, g->eidx))
				continue;
			g->enable = 1;
			break;
		}

		g->enable = 0;
		break;
	}
}

void _genome_mutate(struct _genome *genome, struct _population *pop)
{
	ASSERT(genome);
	ASSERT(pop);

	/* TODO: fix prob==0 bug */
	if (_ranf() <= pop->mut_prob_add_node)
		_genome_mutate_add_node(genome, pop);

	if (_ranf() <= pop->mut_prob_add_gene)
		_genome_mutate_add_gene(genome, pop);

	if (_ranf() <= pop->mut_prob_gene_weights)
		_genome_mutate_gene_weights(genome, pop);

	if (_ranf() <= pop->mut_prob_toggle_enable)
		_genome_mutate_toggle_enable(genome, pop);
}

struct _genome * _genome_mate_mp(struct _genome *gnm1, struct _genome *gnm2,
				 struct _population *pop, int avg)
{
	struct _gene *gene, *g1, *g2;
	struct _node *n1, *n2, *node;
	struct _genome *genome;
	int i, j, idx1[gnm1->nnodes], idx2[gnm2->nnodes];

	ASSERT(gnm1);
	ASSERT(gnm2);
	ASSERT(pop);

	genome = _genome_create(pop, 0,
				gnm1->nnodes + gnm2->nnodes -
				pop->ninputs - pop->noutputs,
				gnm1->ngenes + gnm2->ngenes);
	/* nodes */
	for (i = 0; i < pop->ninputs + pop->noutputs; i++)
		idx1[i] = idx2[i] = i;
	j = i;
	while ((i != gnm1->nnodes) || (j != gnm2->nnodes)) {
		if (i == gnm1->nnodes) {
			node = _node_create_dup(gnm2->nodes[j]);
			idx2[j] = _genome_insert_node(genome, node);
			j++;
			continue;
		}
		if (j == gnm2->nnodes) {
			node = _node_create_dup(gnm1->nodes[i]);
			idx1[i] = _genome_insert_node(genome, node);
			i++;
			continue;
		}
		n1 = gnm1->nodes[i];
		n2 = gnm2->nodes[j];
		if (n2->id < n1->id) {
			node = _node_create_dup(n2);
			idx2[j] = _genome_insert_node(genome, node);
			j++;
			continue;
		}
		if (n1->id < n2->id) {
			node = _node_create_dup(n1);
			idx1[i] = _genome_insert_node(genome, node);
			i++;
			continue;
		}
		/* same node */
		node = _node_create_dup(n1);
		idx1[i] = idx2[j] = _genome_insert_node(genome, node);
		i++;
		j++;
	}

	/* genes */
	i = j = 0;
	while ((i != gnm1->ngenes) || (j != gnm2->ngenes)) {
		if (i == gnm1->ngenes) {
			gene = _gene_create_dup(gnm2->genes[j]);
			gene->sidx = idx2[gene->sidx];
			gene->eidx = idx2[gene->eidx];
			_genome_insert_gene(genome, gene);
			j++;
			continue;
		}
		if (j == gnm2->ngenes) {
			gene = _gene_create_dup(gnm1->genes[i]);
			gene->sidx = idx1[gene->sidx];
			gene->eidx = idx1[gene->eidx];
			_genome_insert_gene(genome, gene);
			i++;
			continue;
		}
		g1 = gnm1->genes[i];
		g2 = gnm2->genes[j];
		if (g2->link->enode < g1->link->enode) {
			gene = _gene_create_dup(g2);
			gene->sidx = idx2[gene->sidx];
			gene->eidx = idx2[gene->eidx];
			_genome_insert_gene(genome, gene);
			j++;
			continue;
		}
		if (g1->link->enode < g2->link->enode) {
			gene = _gene_create_dup(g1);
			gene->sidx = idx1[gene->sidx];
			gene->eidx = idx1[gene->eidx];
			_genome_insert_gene(genome, gene);
			i++;
			continue;
		}
		/* same enode */
		if (g2->link->id < g1->link->id) {
			gene = _gene_create_dup(g2);
			gene->sidx = idx2[gene->sidx];
			gene->eidx = idx2[gene->eidx];
			_genome_insert_gene(genome, gene);
			j++;
			continue;
		}
		if (g1->link->id < g2->link->id) {
			gene = _gene_create_dup(g1);
			gene->sidx = idx1[gene->sidx];
			gene->eidx = idx1[gene->eidx];
			_genome_insert_gene(genome, gene);
			i++;
			continue;
		}
		/* same gene */
		ASSERT(idx1[g1->sidx] == idx2[g2->sidx]);
		ASSERT(idx1[g1->eidx] == idx2[g2->eidx]);
		if (avg)
			gene = _gene_create(g1->link, 0, 0,
					    (g1->weight + g2->weight) / 2,
					    g1->enable || g2->enable);
		else if (_ranf() <= .5)
			gene = _gene_create_dup(g1);
		else
			gene = _gene_create_dup(g2);
		gene->sidx = idx1[g1->sidx];
		gene->eidx = idx1[g1->eidx];
		_genome_insert_gene(genome, gene);
		i++;
		j++;
	}

	return genome;
}

struct _genome * _genome_mate(struct _genome *mom, struct _genome *dad,
			      struct _population *pop)
{
	struct _genome *genome;

	ASSERT(mom);
	ASSERT(dad);
	ASSERT(pop);

	if (_ranf() <= pop->mate_prob_multipoint)
		genome = _genome_mate_mp(mom, dad, pop, 0);
	else if (_ranf() <= pop->mate_prob_multipoint_avg)
		genome = _genome_mate_mp(mom, dad, pop, 1);
	else
		/* TODO: _genome_mate_sp() */
		genome = _genome_create_dup(mom);

	if (_genome_has_loop(genome)) {
		/* _genome_mate_mp() can make loops, get rid of those genomes */
		_genome_destroy(genome);
		genome = _genome_create_dup(mom);
		goto _mutate;
	}

	if ((mom == dad) || (_ranf() > pop->mate_prob_mate_only) ||
	    (_genome_cmp(mom, dad, pop) == 0))
_mutate:
		_genome_mutate(genome, pop);

	return genome;
}


/* ORGANISM */

void _organism_init(struct _organism *org, struct _genome *genome)
{
	ASSERT(org);
	ASSERT(genome);

	org->genome = genome;
	org->fitness = 0;
	org->time_alive = 0;
	org->species = NULL;

	_genome_genesis(genome);
}

struct _organism * _organism_create(struct _genome *genome)
{
	struct _organism *org;

	ASSERT(genome);

	org = malloc(sizeof(struct _organism));
	ASSERT(org);

	_organism_init(org, genome);

	return org;
}

void _organism_destroy(struct _organism *org)
{
	ASSERT(org);

	_genome_destroy(org->genome);

	free(org);
}

int _organism_sort_greatest_fitness_first(const void *a, const void *b)
{
	double f1, f2;

	f1 = (*((const struct _organism **)a))->fitness;
	f2 = (*((const struct _organism **)b))->fitness;

	if (f1 < f2)
		return 1;
	else if (f1 == f2)
		return 0;
	else
		return -1;
}


/* SPECIES */

struct _species * _species_create(int maxsize)
{
	struct _species *species;

	species = malloc(sizeof(struct _species));
	ASSERT(species);

	species->orgs = malloc(2 * maxsize * sizeof(struct _organism *));
	ASSERT(species->orgs);

	species->norgs = 0;
	species->fitness_max_ever = 0;

	species->age = 0;
	species->age_imp = 0;

	return species;
}

void _species_destroy(struct _species *species)
{
	ASSERT(species);

	free(species->orgs);

	free(species);
}

int _species_add_org(struct _species *species, struct _organism *org)
{
	ASSERT(species);
	ASSERT(org);

	species->orgs[species->norgs++] = org;
	org->species = species;

	return species->norgs;
}

int _species_remove_org(struct _species *species, struct _organism *org)
{
	int i;

	ASSERT(species);
	ASSERT(org);

	for (i = 0; i < species->norgs; i++) {
		if (species->orgs[i] == org) {
			memmove(&species->orgs[i], &species->orgs[i + 1],
				sizeof(struct _organism *) *
				(species->norgs - (i + 1)));
			return --species->norgs;
		}
	}

	return species->norgs;
}

void _species_adjust_fitness(struct _species *species, int obliterate,
			     const struct _population *pop)
{
	struct _organism *org;
	int i;

	ASSERT(species);
	ASSERT(pop);

	for (i = 0; i < species->norgs; i++) {
		org = species->orgs[i];

		if ((species->age >= species->age_imp + pop->age_drop) ||
		    obliterate)
			org->fitness *= .01;

		if (species->age <= 10)
			org->fitness *= pop->age_significance;

		org->fitness /= species->norgs;
	}
}

struct _organism * _species_choose_dad(struct _species *species,
				       struct _organism **orgs, int norgs,
				       struct _population *pop)
{
	struct _species *randspecies;
	struct _organism *dad;
	int i, tries;
	double rnd;

	ASSERT(species);
	ASSERT(orgs);
	ASSERT(norgs > 0);
	ASSERT(pop);

	if (_ranf() <= pop->mate_prob_interspecies) {
		tries = 5;
		randspecies = species;
		while ((randspecies == species) && tries--) {
			rnd = _gaussrand() / 4;
			rnd = _MAX(0, rnd);
			rnd = _MIN(1, rnd);
			i = rnd * (pop->nspecies - 1);
			ASSERT((i >= 0) && (i < pop->nspecies));
			randspecies = pop->species[i];
		}
		dad = randspecies->orgs[0];
	} else 
		dad = orgs[rand() % norgs];

	return dad;
}

int _species_sort_greatest_org_fitness_first(const void *a, const void *b)
{
	double f1, f2;

	f1 = (*((const struct _species **)a))->orgs[0]->fitness;
	f2 = (*((const struct _species **)b))->orgs[0]->fitness;

	if (f1 < f2)
		return 1;
	else if (f1 == f2)
		return 0;
	else
		return -1;
}


/* POPULATION */

void _population_init(struct _population *pop, int norgs,
		      int ninputs, int noutputs, int nrecurrent)
{
	ASSERT(pop);

	pop->norgs = norgs;
	pop->ninputs = ninputs;
	pop->noutputs = noutputs;
	pop->nrecurrent = nrecurrent;

	pop->nspecies = 0;
	pop->node_cur = 1;
	pop->nnodes = 0;
	pop->mnodes = ninputs + noutputs;
	pop->link_cur = 1;
	pop->nlinks = 0;
	pop->mlinks = ninputs * noutputs;

	pop->mut_prob_add_node = _MUT_PROB_ADD_NODE;
	pop->mut_prob_add_gene = _MUT_PROB_ADD_GENE;
	pop->mut_prob_gene_weights = _MUT_PROB_GENE_WEIGHTS;
	pop->mut_prob_toggle_enable = _MUT_PROB_TOGGLE_ENABLE;
	pop->mut_prob_recurrent = _MUT_PROB_RECURRENT;
	pop->mut_weight_rate = _MUT_WEIGHT_RATE;
	pop->mut_weight_power = _MUT_WEIGHT_POWER;
	pop->mut_tries_new_node = _MUT_TRIES_NEW_NODE;
	pop->mut_tries_new_gene = _MUT_TRIES_NEW_GENE;
	pop->mut_tries_toggle_enable = _MUT_TRIES_TOGGLE_ENABLE;
	pop->mate_prob_mate_only = _MATE_PROB_MATE_ONLY;
	pop->mate_prob_mut_only = _MATE_PROB_MUT_ONLY;
	pop->mate_prob_multipoint = _MATE_PROB_MULTIPOINT;
	pop->mate_prob_multipoint_avg = _MATE_PROB_MULTIPOINT_AVG;
	pop->mate_prob_interspecies = _MATE_PROB_INTERSPECIES;
	pop->cmp_coeff_disjoint = _CMP_COEFF_DISJOINT;
	pop->cmp_coeff_excess = _CMP_COEFF_EXCESS;
	pop->cmp_coeff_mutdiff = _CMP_COEFF_MUTDIFF;
	pop->cmp_thresh = _CMP_THRESH;
	pop->age_drop = _AGE_DROP;
	pop->age_significance = _AGE_SIGNIFICANCE;
	pop->survival_thresh = _SURVIVAL_THRESH;
	pop->species_ntargets = _SPECIES_NTARGETS;

	pop->nodes = malloc(pop->mnodes * sizeof(struct _node *));
	ASSERT(pop->nodes);

	pop->links = malloc(pop->mlinks * sizeof(struct _link *));
	ASSERT(pop->links);

	pop->species = malloc(2 * norgs * sizeof(struct _species *));
	ASSERT(pop->species);

	pop->orgs = malloc(norgs * sizeof(struct _organism *));
	ASSERT(pop->orgs);
}

struct _population * _population_create(int norgs, int ninputs, int noutputs,
					int nrecurrent, double geneprob)
{
	struct _genome *genome;
	struct _population *pop;
	struct _organism *org;
	int i;

	pop = malloc(sizeof(struct _population));
	ASSERT(pop);

	_population_init(pop, norgs, ninputs, noutputs, nrecurrent);

	for (i = 0; i < norgs; i++) {
		genome = _genome_create(pop, geneprob,
					ninputs + noutputs, ninputs * noutputs);
		ASSERT(genome);

		org = _organism_create(genome);
		ASSERT(org);

		_population_speciate(pop, org, NULL, NULL);

		pop->orgs[i] = org;
	}

	return pop;
}

struct _population * _population_create_from_file(FILE *file)
{
	struct _genome *genome;
	struct _population *pop;
	struct _organism *org;
	int size, ninputs, noutputs, nrecurrent, i;
	fpos_t pos;

	ASSERT(file);

	pop = malloc(sizeof(struct _population));
	ASSERT(pop);

	fgetpos(file, &pos);
	if (fscanf(file, "population %d %d %d %d\n",
		   &size, &ninputs, &noutputs, &nrecurrent) != 4) {
		fsetpos(file, &pos);
		return NULL;
	}

	_population_init(pop, size, ninputs, noutputs, nrecurrent);

	for (i = 0; i < size; i++) {
		genome = _genome_create_from_file(pop, file);
		ASSERT(genome);

		org = _organism_create(genome);
		ASSERT(org);

		_population_speciate(pop, org, NULL, NULL);

		pop->orgs[i] = org;
	}
	ASSERT(i == size);

	return pop;
}

void _population_destroy(struct _population *pop)
{
	int i;

	ASSERT(pop);

	for (i = 0; i < pop->norgs; i++)
		_organism_destroy(pop->orgs[i]);

	for (i = 0; i < pop->nspecies; i++)
		_species_destroy(pop->species[i]);

	for (i = 0; i < pop->nnodes; i++)
		_node_destroy(pop->nodes[i]);
	free(pop->nodes);

	for (i = 0; i < pop->nlinks; i++)
		_link_destroy(pop->links[i]);
	free(pop->links);

	free(pop->species);
	free(pop->orgs);
	free(pop);
}

struct _node * _population_get_node(struct _population *pop, int id,
				    int gene_split)
{
	struct _node *node = NULL;
	int i;

	for (i = 0; i < pop->nnodes; i++) {
		node = pop->nodes[i];
		if (node->gene_split == gene_split)
			break;
	}
	if (i == pop->nnodes) {
		/* not found */
		node = _node_create(id ? id : pop->node_cur++, gene_split);
		if (pop->nnodes == pop->mnodes) {
			/* grow mem */
			pop->mnodes *= 2;
			pop->nodes = realloc(pop->nodes, pop->mnodes *
					     sizeof(struct _node *));
			ASSERT(pop->nodes);
		}
		pop->nodes[pop->nnodes++] = node;
		if (pop->node_cur <= id)
			pop->node_cur = id + 1;
	}

	return node;
}

struct _link * _population_get_link(struct _population *pop, int id,
				    int snode, int enode, int recurrent)
{
	struct _link *link = NULL;
	int i;

	for (i = 0; i < pop->nlinks; i++) {
		link = pop->links[i];
		if ((link->snode == snode) &&
		    (link->enode == enode) &&
		    (link->recurrent == recurrent))
			break;
	}
	if (i == pop->nlinks) {
		/* not found */
		link = _link_create(id ? id : pop->link_cur++,
				    snode, enode, recurrent);
		if (pop->nlinks == pop->mlinks) {
			/* grow mem */
			pop->mlinks *= 2;
			pop->links = realloc(pop->links, pop->mlinks *
					     sizeof(struct _link *));
			ASSERT(pop->links);
		}
		pop->links[pop->nlinks++] = link;
		if (pop->link_cur <= id)
			pop->link_cur = id + 1;
	}

	return link;
}

void _population_sort_species(struct _population *pop)
{
	int i;

	ASSERT(pop);

	for (i = 0; i < pop->nspecies; i++)
		qsort(pop->species[i]->orgs, pop->species[i]->norgs,
		      sizeof(struct _organism *),
		      _organism_sort_greatest_fitness_first);

	qsort(pop->species, pop->nspecies, sizeof(struct _species *),
	      _species_sort_greatest_org_fitness_first);
}

int _population_add_species(struct _population *pop,
			    struct _species *species)
{
	ASSERT(pop);
	ASSERT(species);

	pop->species[pop->nspecies++] = species;

	return pop->nspecies;
}

int _population_remove_species(struct _population *pop,
			       struct _species *species)
{
	int i;

	ASSERT(pop);
	ASSERT(species);

	for (i = 0; i < pop->nspecies; i++) {
		if (pop->species[i] == species) {
			memmove(&pop->species[i], &pop->species[i + 1],
				(pop->nspecies - (i + 1)) *
				sizeof(struct _species *));
			return --pop->nspecies;
		}
	}

	return pop->nspecies;
}

void _population_switch_species(struct _population *pop, struct _organism *org,
				struct _species *ospecies,
				struct _species *nspecies)
{
	ASSERT(pop);
	ASSERT(org);
	ASSERT(ospecies);
	ASSERT(nspecies);

	if (_species_remove_org(ospecies, org) == 0) {
		_population_remove_species(pop, ospecies);
		_species_destroy(ospecies);
	}
	_species_add_org(nspecies, org);
}

void _population_reassign_species(struct _population *pop,
				  struct _organism *org)
{
	struct _species *spc;
	int i;

	ASSERT(pop);
	ASSERT(org);

	/* TODO: safe */
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		ASSERT(spc->norgs > 0);

		if ((spc != org->species) &&
		    (_genome_cmp(spc->orgs[0]->genome, org->genome, pop) <
		     pop->cmp_thresh)) {
			_population_switch_species(pop, org, org->species, spc);
			return;
		}
	}

	spc = _species_create(pop->norgs);
	ASSERT(spc);

	_population_add_species(pop, spc);
	_population_switch_species(pop, org, org->species, spc);
}

struct _species * _population_choose_parent_species(struct _population *pop)
{
	struct _species *spc;
	struct _organism *org;
	double spin, marble, tot, avgfit[pop->nspecies], avgtot = 0;
	int i, j, neligs;

	ASSERT(pop);
	ASSERT(pop->nspecies > 0);

	/* calculate average fitness for each species */
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		tot = 0;
		neligs = 0;
		for (j = 0; j < spc->norgs; j++) {
			org = spc->orgs[j];
			if (org->time_alive >= time_alive_min) {
				tot += org->fitness;
				neligs++;
			}
		}
		avgfit[i] = neligs ? tot / neligs : 0;
		avgtot += avgfit[i];
	}

	/* spinning the wheel */
	spc = pop->species[0];
	spin = avgfit[0];
	marble = _ranf() * avgtot;
	for (i = 1; (i < pop->nspecies) && (spin < marble); i++) {
		spc = pop->species[i];
		spin += avgfit[i];
	}

	return spc;
}

void _population_speciate(struct _population *pop, struct _organism *org,
			  struct _species *mspc, struct _species *dspc)
{
	struct _species *spc = NULL;
	int i;

	ASSERT(pop);
	ASSERT(org);

	spc = mspc;
	if (spc && _genome_cmp(spc->orgs[0]->genome, org->genome, pop) <
		   pop->cmp_thresh)
		goto _match;

	spc = dspc;
	if (spc && _genome_cmp(spc->orgs[0]->genome, org->genome, pop) <
		   pop->cmp_thresh)
		goto _match;

	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		ASSERT(spc->norgs > 0);

		if (spc != mspc && spc != dspc &&
		    _genome_cmp(spc->orgs[0]->genome, org->genome, pop) <
		    pop->cmp_thresh)
			break;
	}
	if (i == pop->nspecies) {
		ASSERT(pop->nspecies < 2 * pop->norgs);

		spc = _species_create(pop->norgs);
		ASSERT(spc);

		_population_add_species(pop, spc);
	}
_match:
	_species_add_org(spc, org);
}

int _population_worst(struct _population *pop)
{
	struct _organism *org, *worst = NULL;
	struct _species *species;
	/* TODO: minfit */
	double avgfit, minfit = (1 << 20);
	int i, worstid = -1;

	for (i = 0; i < pop->norgs; i++) {
		org = pop->orgs[i];
		avgfit = org->fitness / org->species->norgs;
		if ((avgfit < minfit) && (org->time_alive >= time_alive_min)) {
			minfit = avgfit;
			worst = org;
			worstid = i;
		}
	}

	if (worst) {
		species = worst->species;
		if (_species_remove_org(species, worst) == 0) {
			_population_remove_species(pop, species);
			_species_destroy(species);
		}
	}

	return worstid;
}

void _population_reproduce(struct _population *pop, struct _species *species,
			   int noffs, struct _organism **children,
			   int *nchildren, struct _species **mspc,
			   struct _species **dspc)
{
	struct _organism *mom, *dad, *org, *child;
	struct _genome *genome;
	int i;

	ASSERT(pop);
	ASSERT(species);
	ASSERT(noffs >= 0);
	ASSERT(species->norgs > 0);
	ASSERT(children);
	ASSERT(nchildren);

	for (i = 0; i < noffs; i++) {
		mspc[*nchildren] = species;
		dspc[*nchildren] = NULL;
		if ((i == 0) && (noffs > 5)) {
			/* clone champ */
			genome = _genome_create_dup(species->orgs[0]->genome);
		} else if ((species->norgs == 1) ||
			   (_ranf() <= pop->mate_prob_mut_only)) {
			/* mutate */
			org = species->orgs[rand() % species->norgs];
			genome = _genome_create_dup(org->genome);
			_genome_mutate(genome, pop);
		} else {
			/* mate */
			mom = species->orgs[rand() % species->norgs];
			dad = _species_choose_dad(species, species->orgs,
						  species->norgs, pop);
			genome = _genome_mate(mom->genome, dad->genome, pop);
			dspc[*nchildren] = dad->species;
		}
		child = _organism_create(genome);
		children[(*nchildren)++] = child;
	}
}

void _population_reproduce_one(struct _population *pop, int worstid)
{
	struct _organism *mom, *dad, *child, *eligs[pop->norgs];
	struct _species *pspc;
	struct _genome *genome;
	int i, poolsize, neligs = 0;

	ASSERT(pop);
	ASSERT(pop->norgs > 0);
	ASSERT(worstid >= 0);

	pspc = _population_choose_parent_species(pop);

	for (i = 0; i < pspc->norgs; i++)
		if (pspc->orgs[i]->time_alive >= time_alive_min)
			eligs[neligs++] = pspc->orgs[i];

	if (neligs == 0) {
		neligs = pspc->norgs;
		memcpy(eligs, pspc->orgs, neligs * sizeof(struct _organism *));
	}

	poolsize = _MAX(1, neligs * pop->survival_thresh);

	mom = eligs[rand() % poolsize];

	if ((_ranf() <= pop->mate_prob_mut_only) || (poolsize == 1)) {
		genome = _genome_create_dup(mom->genome);
		_genome_mutate(genome, pop);
	} else {
		dad = _species_choose_dad(pspc, eligs, poolsize, pop);
		genome = _genome_mate(mom->genome, dad->genome, pop);
	}
	child = pop->orgs[worstid];
	_genome_destroy(child->genome);
	_organism_init(child, genome);
	_population_speciate(pop, child, NULL, NULL);
}

int _population_evolve(struct _population *pop)
{
	int i, worstid, nspc;

	worstid = _population_worst(pop);

	if (worstid < 0)
		return -1;

	_population_sort_species(pop);

	_population_reproduce_one(pop, worstid);

	/* TODO: investigate :) */
	nspc = pop->nspecies;
	if (nspc < pop->species_ntargets)
		pop->cmp_thresh *= .95;
	else if (nspc > pop->species_ntargets)
		pop->cmp_thresh *= 1.05;
	pop->cmp_thresh = _MAX(.3, pop->cmp_thresh);

	for (i = 0; i < pop->norgs; i++)
		_population_reassign_species(pop, pop->orgs[i]);

	return worstid;
}

void _population_epoch(struct _population *pop, int generation)
{
	struct _species *spc, *mspc[pop->norgs], *dspc[pop->norgs];
	struct _organism *org, *children[pop->norgs];
	double sfit_tot, pfit_tot = 0;
	int obliterate = -1, noffstot = 0, nchildren = 0;
	int i, j, noffs[pop->nspecies];

	ASSERT(pop);

	for (i = 0; i < pop->nspecies; i++)
		pop->species[i]->age++;

	/* sort the organisms within the species, and the species */
	_population_sort_species(pop);

	/* see which species to punish extra hard */
	/*if ((generation % 30) == 0)
		for (i = pop->nspecies - 1; i >= 0; i--)
			if (pop->species[i]->age >= 20) {
				obliterate = i;
				break;
			}
	*/

	/* adjust fitness */
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		/* TODO: fitness before or after adjustment?!? */
		if (spc->orgs[0]->fitness > spc->fitness_max_ever) {
			spc->fitness_max_ever = spc->orgs[0]->fitness;
			spc->age_imp = spc->age;
		}
		_species_adjust_fitness(spc, obliterate == i, pop);
	}

	/* sort species using adjusted fitness from first organism */
	qsort(pop->species, pop->nspecies, sizeof(struct _species *),
	      _species_sort_greatest_org_fitness_first);

	/* calculate number of offsprings for each species */
	for (i = 0; i < pop->norgs; i++)
		pfit_tot += pop->orgs[i]->fitness;
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		sfit_tot = 0;
		for (j = 0; j < spc->norgs; j++)
			sfit_tot += spc->orgs[j]->fitness;
		if (pfit_tot == 0)
			noffs[i] = pop->norgs / pop->nspecies;
		else
			noffs[i] = pop->norgs * sfit_tot / pfit_tot;
		noffstot += noffs[i];
	}
	ASSERT(noffstot <= pop->norgs);
	/* give the fractional children to best species */
	noffs[0] += pop->norgs - noffstot;

	/* eliminate organisms that are not allowed to reproduce */
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		spc->norgs = _MAX(1, spc->norgs * pop->survival_thresh);
	}

	/* reproduce */
	for (i = 0; i < pop->nspecies; i++)
		_population_reproduce(pop, pop->species[i], noffs[i],
				      children, &nchildren, mspc, dspc);
	ASSERT(nchildren == pop->norgs);

	/* speciate children */
	for (i = 0; i < nchildren; i++)
		_population_speciate(pop, children[i], mspc[i], dspc[i]);

	/* remove old organisms */
	for (i = 0; i < pop->norgs; i++) {
		org = pop->orgs[i];
		spc = org->species;
		_species_remove_org(spc, org);
		_organism_destroy(org);
	}

	/* remove empty species */
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		if (spc->norgs == 0) {
			_population_remove_species(pop, spc);
			_species_destroy(spc);
			i--;
		}
	}

	/* transfer children to main array */
	memcpy(pop->orgs, children, nchildren * sizeof(struct _organism *));
}

void _population_print(const struct _population *pop, FILE *file)
{
	int i;

	ASSERT(pop);
	ASSERT(file);

	fprintf(file, "population %d %d %d %d\n",
		pop->norgs, pop->ninputs, pop->noutputs, pop->nrecurrent);

	for (i = 0; i < pop->norgs; i++)
		_genome_print(pop->orgs[i]->genome, file);
}


/* NEAT */

void _neat_init(void)
{
	/* TODO */
	if (pops == NULL)
		pops = malloc(_MAX_POPS * sizeof(struct _pops *));

	ASSERT(npops < _MAX_POPS);
}

int neat_create(int norganisms, int ninputs, int noutputs, int nhidden,
		int nrecurrent, double geneprob)
{
	ASSERT(norganisms > 0);
	ASSERT(ninputs > 0);
	ASSERT(noutputs > 0);
	/* TODO: fix nhidden */
	ASSERT(nhidden == 0);
	ASSERT(nrecurrent >= 0);
	ASSERT(geneprob >= 0);

	_neat_init();

	pops[npops] = _population_create(norganisms, ninputs, noutputs,
					 nrecurrent, geneprob);

	return npops++;
}

int neat_create_from_file(FILE *file)
{
	ASSERT(file);

	_neat_init();

	pops[npops] = _population_create_from_file(file);

	return npops++;
}

void neat_destroy(int popid)
{
	_population_destroy(pops[popid]);

	if (--npops == 0) {
		free(pops);
		pops = NULL;
	}
}

void neat_print(int popid, FILE *file)
{
	ASSERT(popid >= 0);
	ASSERT(file);

	_population_print(pops[popid], file);
}

const float * neat_activate(int popid, int orgid, const float *inputs)
{
	struct _organism *org;

	ASSERT(inputs);

	org = pops[popid]->orgs[orgid];

	org->time_alive += 1;

	return _genome_activate(org->genome, inputs);
}

void neat_flush(int popid, int orgid)
{
	struct _organism *org;

	org = pops[popid]->orgs[orgid];

	_genome_flush(org->genome);
}

int neat_evolve(int popid)
{
	return _population_evolve(pops[popid]);
}

void neat_epoch(int popid, int generation)
{
	_population_epoch(pops[popid], generation);
}

int neat_info_get(int popid, int orgid, int *nnodes, int *ngenes)
{
	struct _genome *genome;

	ASSERT(popid < npops);
	ASSERT(orgid < pops[popid]->norgs);
	ASSERT(nnodes);
	ASSERT(ngenes);

	genome = pops[popid]->orgs[orgid]->genome;
	*nnodes = genome->nnodes;
	*ngenes = genome->ngenes;

	return 0;
}

double neat_fitness_get(int popid, int orgid)
{
	ASSERT(popid < npops);
	ASSERT(orgid < pops[popid]->norgs);

	return pops[popid]->orgs[orgid]->fitness;
}

void neat_fitness_set(int popid, int orgid, double fitness)
{
	ASSERT(popid < npops);
	ASSERT(orgid < pops[popid]->norgs);

	pops[popid]->orgs[orgid]->fitness = fitness;
}

int neat_params_read(int popid, FILE *file)
{
	fpos_t pos;

	ASSERT(popid < npops);
	ASSERT(file);

	_PARAMS_READF(mut_prob_add_node);
	_PARAMS_READF(mut_prob_add_gene);
	_PARAMS_READF(mut_prob_gene_weights);
	_PARAMS_READF(mut_prob_toggle_enable);
	_PARAMS_READF(mut_prob_recurrent);
	_PARAMS_READF(mut_weight_rate);
	_PARAMS_READF(mut_weight_power);
	_PARAMS_READI(mut_tries_new_node);
	_PARAMS_READI(mut_tries_new_gene);
	_PARAMS_READI(mut_tries_toggle_enable);
	_PARAMS_READF(mate_prob_mate_only);
	_PARAMS_READF(mate_prob_mut_only);
	_PARAMS_READF(mate_prob_multipoint);
	_PARAMS_READF(mate_prob_multipoint_avg);
	_PARAMS_READF(mate_prob_interspecies);
	_PARAMS_READF(cmp_coeff_disjoint);
	_PARAMS_READF(cmp_coeff_excess);
	_PARAMS_READF(cmp_coeff_mutdiff);
	_PARAMS_READF(cmp_thresh);
	_PARAMS_READI(age_drop);
	_PARAMS_READF(age_significance);
	_PARAMS_READF(survival_thresh);
	_PARAMS_READI(species_ntargets);

	return 0;
}

int neat_params_write(int popid, FILE *file)
{
	ASSERT(popid < npops);
	ASSERT(file);

	_PARAMS_WRITEF(mut_prob_add_node);
	_PARAMS_WRITEF(mut_prob_add_gene);
	_PARAMS_WRITEF(mut_prob_gene_weights);
	_PARAMS_WRITEF(mut_prob_toggle_enable);
	_PARAMS_WRITEF(mut_prob_recurrent);
	_PARAMS_WRITEF(mut_weight_rate);
	_PARAMS_WRITEF(mut_weight_power);
	_PARAMS_WRITEI(mut_tries_new_node);
	_PARAMS_WRITEI(mut_tries_new_gene);
	_PARAMS_WRITEI(mut_tries_toggle_enable);
	_PARAMS_WRITEF(mate_prob_mate_only);
	_PARAMS_WRITEF(mate_prob_mut_only);
	_PARAMS_WRITEF(mate_prob_multipoint);
	_PARAMS_WRITEF(mate_prob_multipoint_avg);
	_PARAMS_WRITEF(mate_prob_interspecies);
	_PARAMS_WRITEF(cmp_coeff_disjoint);
	_PARAMS_WRITEF(cmp_coeff_excess);
	_PARAMS_WRITEF(cmp_coeff_mutdiff);
	_PARAMS_WRITEF(cmp_thresh);
	_PARAMS_WRITEI(age_drop);
	_PARAMS_WRITEF(age_significance);
	_PARAMS_WRITEF(survival_thresh);
	_PARAMS_WRITEI(species_ntargets);

	return 0;
}

int neat_params_set(int popid,
		    float mut_prob_add_node,
		    float mut_prob_add_gene,
		    float mut_prob_gene_weights,
		    float mut_prob_toggle_enable,
		    float mut_prob_recurrent,
		    float mut_weight_rate,
		    float mut_weight_power,
		    int mut_tries_new_node,
		    int mut_tries_new_gene,
		    int mut_tries_toggle_enable,
		    float mate_prob_mate_only,
		    float mate_prob_mut_only,
		    float mate_prob_multipoint,
		    float mate_prob_multipoint_avg,
		    float mate_prob_interspecies,
		    float cmp_coeff_disjoint,
		    float cmp_coeff_excess,
		    float cmp_coeff_mutdiff,
		    float cmp_thresh,
		    int age_drop,
		    float age_significance,
		    float survival_thresh,
		    int species_ntargets)
{
	ASSERT(popid < npops);

	pops[popid]->mut_prob_add_node = mut_prob_add_node;
	pops[popid]->mut_prob_add_gene = mut_prob_add_gene;
	pops[popid]->mut_prob_gene_weights = mut_prob_gene_weights;
	pops[popid]->mut_prob_toggle_enable = mut_prob_toggle_enable;
	pops[popid]->mut_prob_recurrent = mut_prob_recurrent;
	pops[popid]->mut_weight_rate = mut_weight_rate;
	pops[popid]->mut_weight_power = mut_weight_power;
	pops[popid]->mut_tries_new_node = mut_tries_new_node;
	pops[popid]->mut_tries_new_gene = mut_tries_new_gene;
	pops[popid]->mut_tries_toggle_enable = mut_tries_toggle_enable;
	pops[popid]->mate_prob_mate_only = mate_prob_mate_only;
	pops[popid]->mate_prob_mut_only = mate_prob_mut_only;
	pops[popid]->mate_prob_multipoint = mate_prob_multipoint;
	pops[popid]->mate_prob_multipoint_avg = mate_prob_multipoint_avg;
	pops[popid]->mate_prob_interspecies = mate_prob_interspecies;
	pops[popid]->cmp_coeff_disjoint = cmp_coeff_disjoint;
	pops[popid]->cmp_coeff_excess = cmp_coeff_excess;
	pops[popid]->cmp_coeff_mutdiff = cmp_coeff_mutdiff;
	pops[popid]->cmp_thresh = cmp_thresh;
	pops[popid]->age_drop = age_drop;
	pops[popid]->age_significance = age_significance;
	pops[popid]->survival_thresh = survival_thresh;
	pops[popid]->species_ntargets = species_ntargets;

	return 0;
}

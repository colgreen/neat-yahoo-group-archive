#ifdef _WIN32
#include <windows.h>
#endif
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <signal.h>
#include <time.h>
#include <math.h>
#include <GL/glut.h>

#include "neat.h"
#include "map.h"
#include "unit.h"
#include "avg.h"
#include "list.h"
#include "error.h"

#define _PI		3.14159265358979323846
#define _2PI		(2 * _PI)

#define _NDIST		6
#define _MDIST		60

#define _NPOPS		4
#define _NUNITS		50
#define _TIME_ALIVE_MIN 2000
#define _TIME_ALIVE_MAX 40000

#define _IFUN(N, V)  _fin(&in, N, V)
#define _OFUN(N)     _fout(&out, N)
#define _NI_BIAS     1
#define _NI_LANGLE   1
#define _NI_MANGLE   0
#define _NI_TANGLE   0
#define _NI_MSPEED   0
#define _NI_LIGHTD   0
#define _NI_RAY      1
#define _NO_THRUST   1
#define _NO_TANGLE   1

#define _NINPUTS     (_NI_BIAS + _NI_LANGLE + _NI_MANGLE + _NI_TANGLE + \
		      _NI_MSPEED + _NI_LIGHTD + _NDIST * _NI_RAY)
#define _NOUTPUTS    (_NO_THRUST + _NO_TANGLE)
#define _NHIDDEN     0
#define _NRECURRENT  0
#define _GENEPROB    1

#define _NTRACES	100
#define _UNIT_TANGLE    (16 * _PI / 180)
#define _UNIT_MAXSPEED  1
#define _UNIT_THRUST    .03
#define _UNIT_GRAVITY	.02

#define _LIGHT_MOVERAYS 16
#define _LIGHT_SPEED	.5
#define _MAPW		(32 * 16)
#define _MAPH		(32 * 10)
#define _MAPZ		.99

#define _NESTS_PERCENT 10
#define _NESTS_SIZE    4

#define _FILENAME_MAP    "world.map"
#define _FILENAME_POPS   "pops.gnm"
#define _FILENAME_PARAMS "eco.prm"

#define _MAX(A, B) ((A) > (B) ? (A) : (B))
#define _MIN(A, B) ((A) < (B) ? (A) : (B))

#define _COL(C) ((C) >> 16 & 0xFF) / 255.,\
		((C) >> 8 & 0xFF) / 255., \
		((C) & 0xFF) / 255. 

#define _DBGSTRLEN 1024

int time_alive_min = _TIME_ALIVE_MIN;
int time_evolve_step = _MAX(1, _TIME_ALIVE_MIN / (.5 * _NUNITS));
int oclock = 0, tickspersecs = 0, ticks = 0;

int spawno = 0, spawnr = 0, pause = 0, wolf = 1;
int plot_champ = 0, plot_traces = 1, plot_radar = 0, plot_dbg = 0;
struct avg *avgcrash, *avgfit;

int tx, ty, move = 0;
double width, height, mapz = _MAPZ;
double mapx, mapy, mapu, mapv;

double lightx, lighty;
int lightmove = 0, lightauto = 1;

int selected = -1;

char dbgstr[_DBGSTRLEN];
int nests[] = { _NESTS_PERCENT, _NESTS_PERCENT,
		100 - _NESTS_PERCENT, _NESTS_PERCENT,
		100 - _NESTS_PERCENT, 100 - _NESTS_PERCENT,
		_NESTS_PERCENT, 100 - _NESTS_PERCENT };

int cols[] = { 0x00FFFF, 0xFF00FF, 0x00FF00, 0xFFFF00 };

struct unit *units[_NPOPS][_NUNITS];
struct map *map;

void _free_world(void);


/* IN & OUT */

void _fin(float **in, int nin, float val)
{
	if (nin) {
		**in = val;
		(*in)++;
	}
}

float _fout(float **out, int nout)
{
	float res = 0;
	if (nout) {
		res = **out;
		(*out)++;
	}
	return res;
}

void _bin(float **in, int nin, float val)
{
	unsigned int ival;
	int i;
	val = _MIN(.999999, val);
	val = _MAX(0, val);
	ival = val * pow(2, nin);
	for (i = 0; i < nin; i++) {
		**in = (ival & 1);
		ival >>= 1;
		(*in)++;
	}
}

float _bout(float **out, int nout)
{
	unsigned int ival = 0;
	int i;
	for (i = 0; i < nout; i++) {
		ival |= (unsigned int)(**out > .5);
		(*out)++;
		ival <<= 1;
	}
	return (ival >> 1) / (pow(2, nout) - 1);
}


/* MISC */

void _signal(int sig)
{
	if (sig == SIGINT) {
		_free_world();
		exit(0);
	}
}

double _angle(double a)
{
	float f;
	int n;
	if (fabs(a) < 0.00001)
		a = 0;
	n = (a + _2PI) / _2PI;
	f = (a + _2PI) - n * _2PI;

	return f / _2PI;
}

void _screen_to_map(int x, int y, double *mx, double *my)
{
	double min, dx, dy;
	min = _MIN(width / map->width, height / map->height);

	dx = x - width / 2;
	dy = y - height / 2;
	dx /= mapz * width;
	dy /= mapz * height;
	dx -= mapx / width;
	dy -= mapy / height;
	*mx = (dx * (width / map->width) / min + .5) * map->width;
	*my = (dy * (height / map->height) / min + .5) * map->height;
}

void _cartesian_to_polar(double x, double y, double *angle, double *radius)
{
	*angle = atan2(y, x);
	*radius = sqrt(x * x + y * y);
}

int _get_champ(int pop)
{
	int u, champ = -1;
	double fit, maxfit = -1;

	for (u = 0; u < _NUNITS; u++) {
		fit = neat_fitness_get(pop, u);
		if (fit >= maxfit) {
			maxfit = fit;
			champ = u;
		}
	}

	return champ;
}


/* EVAL */

void _eval_light(void)
{
	int i, n;
	double dx, dy;
	static double langle = 0;

	if (!lightauto)
		return;

	for (n = 0; n < 100; n++) {
		langle += ((rand() % 16) - 8) * _PI / 180;
		if (langle < 0)
			langle += _2PI;
		if (langle > _2PI)
			langle -= _2PI;

		dx = lightx + _LIGHT_SPEED * cos(langle);
		dy = lighty + _LIGHT_SPEED * sin(langle);

		for (i = 0; i < _LIGHT_MOVERAYS; i++)
			if (map_collisioni(map, NULL, 2, dx, dy,
					   i * _2PI / _LIGHT_MOVERAYS))
				break;
		if (i == _LIGHT_MOVERAYS) {
			lightx = dx;
			lighty = dy;
			break;
		}
	}
}

double _eval_unit(int pop, int org, int *ncrashes)
{
	int i, nest;
	double fit, fx, fy, ox, oy, movedist;
	double lightdist, lightangle;
	float inputs[_NINPUTS], *in, *out, dist;
	struct unit *unit;

	unit = units[pop][org];
	fit = neat_fitness_get(pop, org);

	if (unit->age++ == _TIME_ALIVE_MAX)
		goto _spawn;

	_cartesian_to_polar(unit->xpos - lightx, unit->ypos - lighty,
			    &lightangle, &lightdist);

	in = inputs;
	_IFUN(_NI_BIAS, 1);
	_IFUN(_NI_LANGLE, _angle(unit->tangle - lightangle));
	_IFUN(_NI_MANGLE, _angle(unit->tangle - unit->mangle));
	_IFUN(_NI_TANGLE, _angle(unit->tangle));
	_IFUN(_NI_MSPEED, unit->mspeed / _UNIT_MAXSPEED);
	_IFUN(_NI_LIGHTD, lightdist / 100);

	for (i = 0; i < _NDIST; i++) {
		map_collisioni(map, &dist, _MDIST,
			       unit->xpos, unit->ypos,
			       unit->tangle + _2PI * i / _NDIST);
		_IFUN(_NI_RAY, dist / _MDIST);
	}

	out = (float *)neat_activate(pop, org, inputs);

	unit->thrust = _OFUN(_NO_THRUST);
	unit->tangle += (_OFUN(_NO_TANGLE) - .5) * _UNIT_TANGLE;

	fx = unit->mspeed * cos(unit->mangle) +
	     _UNIT_THRUST * unit->thrust * cos(unit->tangle);
	fy = unit->mspeed * sin(unit->mangle) +
	     _UNIT_THRUST * unit->thrust * sin(unit->tangle) + _UNIT_GRAVITY;
	_cartesian_to_polar(fx, fy, &unit->mangle, &unit->mspeed);
	/*unit->mspeed -= unit->mspeed * unit->mspeed / 200;
	unit->mspeed = _MAX(0, unit->mspeed);*/
	unit->mspeed = _MIN(unit->mspeed, _UNIT_MAXSPEED);

	if (map_collisioni(map, &dist, unit->mspeed,
			   unit->xpos, unit->ypos, unit->mangle)) {
		(*ncrashes)++;
		fit *= .5;
_spawn:
		nest = (pop + spawno + spawnr * rand()) % _NESTS_SIZE;
		unit_spawn(unit, nests[2 * nest], nests[2 * nest + 1]);
		neat_flush(pop, org);
		goto _done;
	}
	ox = unit->xpos;
	oy = unit->ypos;
	unit_move(unit);
	movedist = sqrt((unit->xpos - ox) * (unit->xpos - ox) +
			(unit->ypos - oy) * (unit->ypos - oy));
	fit *= .999;
	fit += exp(-lightdist);
_done:
	neat_fitness_set(pop, org, fit);

	return fit;
}

void _eval(void)
{
	static int oticks = 0;
	int ncrashes, clock;
	struct unit *unit;
	int w, t, u, worstid, nest;
	double fittot;

	for (w = 0; w < wolf; w++) {
		ticks++;
		ncrashes = 0;
		fittot = 0;
		for (t = 0; t < _NPOPS; t++) {
			for (u = 0; u < _NUNITS; u++)
				fittot += _eval_unit(t, u, &ncrashes);
			if ((ticks % time_evolve_step) == 0) {
				worstid = neat_evolve(t);
				if (worstid >= 0) {
					unit = units[t][worstid];
					nest = (t + spawno + spawnr * rand()) %
						_NESTS_SIZE;
					unit_spawn(unit, nests[2 * nest],
						   nests[2 * nest + 1]);
				}
			}
		}

		clock = time(NULL);
		if (clock - oclock >= 5) {
			tickspersecs = (ticks - oticks) / (clock - oclock);
			oclock = clock;
			oticks = ticks;
		}

		/* debug info */
		avg_add(avgcrash, ncrashes, ticks);
		avg_add(avgfit, fittot, ticks);
		snprintf(dbgstr, _DBGSTRLEN,
			 "%8d  %4d" \
			 "    ac : %.2f : %.2f : %.2f" \
			 "    af : %.2f : %.2f : %.2f\n", ticks, tickspersecs,
			 avgcrash->savg0, avgcrash->savg1, avgcrash->savg2,
			 avgfit->savg0, avgfit->savg1, avgfit->savg2);

		_eval_light();
	}
}

void _gl_eval(void)
{
	_eval();

	if (pause)
		glutIdleFunc(NULL);

	glutPostRedisplay();
}


/* DRAW */

void _draw_light(void)
{
	glPushMatrix();
	glTranslatef(lightx, lighty, 0);
	glColor3f(0, 0, 1);
	glBegin(GL_QUADS);
	        glVertex2f(-1, -1);
		glVertex2f(1, -1);
		glVertex2f(1, 1);
		glVertex2f(-1, 1);
	glEnd();
	glPopMatrix();
}

void _draw_dbg(void)
{
	int i = 0;
	int slen = strlen(dbgstr);

	glColor3f(1, 1, 1);
	glRasterPos2d(-.95, -.95);
	while (i++ < slen)
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, dbgstr[i]);
}

void _draw_champ(void)
{
	int i, t, champ;
	struct unit *unit;
	double xpos, ypos, angle;
	float dist;

	for (t = 0; t < _NPOPS; t++) {
		champ = _get_champ(t);
		ASSERT(champ >= 0);

		unit = units[t][champ];
		ASSERT(unit);

		xpos = unit->xpos;
		ypos = unit->ypos;

		glColor3f(_COL(cols[t]));

		/* circle */
		if (plot_champ) {
			glBegin(GL_LINE_LOOP);
			for (i = 0; i < 16; i++) {
				angle = _2PI * i / 16;
				glVertex2d(xpos + 6 * cos(angle),
					   ypos + 6 * sin(angle));
			}
			glEnd();
		}

		/* radar */
		if (plot_radar) {
			for (i = 0; i < _NDIST; i++) {
				angle = unit->tangle + _2PI * i / _NDIST;

				map_collisioni(map, &dist, _MDIST,
					       xpos, ypos, angle);

				glBegin(GL_LINES);
					glVertex2d(xpos, ypos);
					glVertex2d(xpos + dist * cos(angle),
						   ypos + dist * sin(angle));
				glEnd();
			}
		}
	}
}

void _draw_selected(void)
{
	double angle, xpos, ypos;
	int i;

	if (selected >= 0 && selected <= 9) {
		xpos = nests[2 * selected];
		ypos = nests[2 * selected + 1];
		glColor3f(_COL(cols[selected]));
		glBegin(GL_LINE_LOOP);
		for (i = 0; i < 16; i++) {
			angle = _2PI * i / 16;
			glVertex2d(xpos + 20 * cos(angle),
				   ypos + 20 * sin(angle));
		}
		glEnd();
	}
}


/* GLUT */

void _display(void)
{
	int u, t;
	double min;

	min = _MIN(width / map->width, height / map->height);

	glMatrixMode(GL_TEXTURE);
	glPushMatrix();
	glScalef((double)map->width / map->texw,
		 (double)map->height / map->texh, 1);
	glTranslatef(.5, .5, 0);
	glScalef(width / (min * map->width),
		 height / (min * map->height), 1);
	glTranslatef(-mapx / width, mapy / height, 0);
	glScalef(1 / mapz, 1 / mapz, 1);
	glTranslatef(-.5, -.5, 0);

	map_draw(map);

	glMatrixMode(GL_TEXTURE);
	glPopMatrix();

	if (plot_dbg)
		_draw_dbg();

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glScalef(2 * min * mapz / width, -2 * min * mapz / height, 1);
	glTranslatef(-.5 * map->width + mapx / min,
		     -.5 * map->height + mapy / min, 0);

	_draw_selected();

	_draw_light();

	if (plot_champ || plot_radar)
		_draw_champ();

	for (t = 0; t < _NPOPS; t++)
		for (u = 0; u < _NUNITS; u++)
			unit_draw(units[t][u], plot_traces, _COL(cols[t]));

	if (map->wall)
		map_wall(map);

	glPopMatrix();

	glutSwapBuffers();
}

void _reshape(int w, int h)
{
	width = w;
	height = h;
	glViewport(0, 0, width, height);
}

void _motion(int x, int y)
{
	double mx, my;

	if (map->wall) {
		_screen_to_map(x, y, &mx, &my);
		_cartesian_to_polar(mx - map->wx, my - map->wy,
				    &map->wa, &map->wr);
	} else if (move) {
		mapx = mapu + (x - tx) / mapz;
		mapy = mapv + (y - ty) / mapz;
	} else if (lightmove)
		_screen_to_map(x, y, &lightx, &lighty);

	glutPostRedisplay();
}

void _mouse(int button, int state, int x, int y)
{
	int mod;

	mod = glutGetModifiers();

	if (state == GLUT_UP) {
		switch (button) {
		case GLUT_MIDDLE_BUTTON:
			break;
		case GLUT_RIGHT_BUTTON:
			if (!(mod & GLUT_ACTIVE_SHIFT)) {
				lightmove = 0;
				break;
			}
			/* FALL */
		case GLUT_LEFT_BUTTON:
			if (mod & GLUT_ACTIVE_SHIFT) {
				map->wall = 2;
				glutPostRedisplay();
			} else {
				mapu = mapx;
				mapv = mapy;
				move = 0;
			}
			break;
		}
	}

	if (state == GLUT_DOWN) {
		switch (button) {
		case GLUT_MIDDLE_BUTTON:
			break;
		case GLUT_RIGHT_BUTTON:
			if (mod & GLUT_ACTIVE_SHIFT)
				map->erase = 1;
			else {
				_screen_to_map(x, y, &lightx, &lighty);
				lightmove = 1;
				glutPostRedisplay();
				break;
			}
			/* FALL */
		case GLUT_LEFT_BUTTON:
			if (mod & GLUT_ACTIVE_SHIFT) {
				map->wall = 1;
				_screen_to_map(x, y, &map->wx, &map->wy);
				map->wa = 0;
				map->wr = 0;
				glutPostRedisplay();
			} else {
				tx = x;
				ty = y;
				move = 1;
			}
			break;
		case 3:
			/* WHEEL_UP */
			mapz = _MIN(5, mapz + .1);
			glutPostRedisplay();
			break;
		case 4:
			/* WHEEL_DOWN */
			mapz = _MAX(.3, mapz - .1);
			glutPostRedisplay();
			break;
		default:
			TRACE("%x", button);
			break;
		}
	}
}

void _keyboard(unsigned char key, int x, int y)
{
	FILE *file;
	int t, i;

	switch (key) {
	case ' ':
		if (pause)
			glutIdleFunc(_gl_eval);
		break;
	case '+':
		mapz = _MIN(5, mapz + .1);
		glutPostRedisplay();
		break;
	case '-':
		mapz = _MAX(.3, mapz - .1);
		glutPostRedisplay();
		break;
	/*case '1': case '2': case '3': case '4': case '5':
	case '6': case '7': case '8': case '9':
		selected = key - '1';
		break;*/
	case 'c':
		plot_champ = !plot_champ;
		glutPostRedisplay();
		break;
	case 'd':
		plot_dbg = !plot_dbg;
		glutPostRedisplay();
		break;
	case 'e':
		for (i = 0; i < _NPOPS; i++)
			neat_epoch(i, 1);
		break;
	case 'f':
		mapz = _MAPZ;
		mapx = 0;
		mapy = 0;
		mapu = 0;
		mapv = 0;
		glutPostRedisplay();
		break;
	case 'm':
		lightauto = !lightauto;
		break;
	case 'p':
		pause = !pause;
		if (pause)
			glutIdleFunc(NULL);
		else
			glutIdleFunc(_gl_eval);
		break;
	case 'q':
		_free_world();
		exit(0);
		break;
	case 'r':
		plot_radar = !plot_radar;
		glutPostRedisplay();
		break;
	case 's':
		INFO("Saving %s", _FILENAME_MAP);
		file = fopen(_FILENAME_MAP, "w");
		ASSERT(file);
		map_write(map, file);
		fclose(file);

		INFO("Saving %s", _FILENAME_POPS);
		file = fopen(_FILENAME_POPS, "w");
		ASSERT(file);
		for (t = 0; t < _NPOPS; t++)
			neat_print(t, file);
		fclose(file);
		break;
	case 't':
		plot_traces = !plot_traces;
		glutPostRedisplay();
		break;
	case 'u':
		map->erase = 1;
		map->wall = 2;
		map->dirty = 1;
		glutPostRedisplay();
		break;
	case 'v':
		spawnr = !spawnr;
		break;
	case 'w':
		switch (wolf) {
		case 100:
			wolf = 10;
			break;
		case 10:
			wolf = 1;
			break;
		case 1:
			wolf = 100;
			break;
		}
		break;
	case 'x':
		spawno = (spawno + 1) % _NESTS_SIZE;
		break;
	case 'z':
		spawno = (spawno - 1 + _NPOPS) % _NESTS_SIZE;
		break;
	}
}


/* INIT */

void _free_world(void)
{
	int t, u;

	for (t = 0; t < _NPOPS; t++) {
		for (u = 0; u < _NUNITS; u++)
			unit_destroy(units[t][u]);
		neat_destroy(t);
	}

	avg_destroy(avgcrash);
	avg_destroy(avgfit);

	map_destroy(map);
}

void _init_world(void)
{
	int u, t, i;
	FILE *file;

	if ((file = fopen(_FILENAME_POPS, "r"))) {
		INFO("Loading %s", _FILENAME_POPS);
		for (t = 0; t < _NPOPS; t++)
			neat_create_from_file(file);
		fclose(file);
	} else {
		for (t = 0; t < _NPOPS; t++)
			neat_create(_NUNITS, _NINPUTS, _NOUTPUTS, _NHIDDEN,
				    _NRECURRENT, _GENEPROB);
	}

	if ((file = fopen(_FILENAME_MAP, "r"))) {
		INFO("Loading %s", _FILENAME_MAP);
		map = map_create_from_file(file);
		fclose(file);
	} else
		map = map_create(_MAPW, _MAPH);

	for (t = 0; t < _NPOPS; t++) {
		if ((file = fopen(_FILENAME_PARAMS, "r"))) {
			INFO("Loading %s", _FILENAME_PARAMS);
			neat_params_read(t, file);
			fclose(file);
		}
	}

	lightx = map->width / 2;
	lighty = map->height / 2;

	for (i = 0; i < _NESTS_SIZE; i++) {
		nests[2 * i] *= map->width / 100.;
		nests[2 * i + 1] *= map->height / 100.;
	}

	for (t = 0; t < _NPOPS; t++) {
		for (u = 0; u < _NUNITS; u++) {
			units[t][u] = unit_create(_NTRACES);
			unit_spawn(units[t][u], nests[2 * t], nests[2 * t + 1]);
		}
	}

	avgcrash = avg_create(1000, 5000, 15000);
	avgfit = avg_create(1000, 5000, 15000);
}

int main(int argc, char **argv)
{
	signal(SIGINT, _signal);

	if (argc == 2) {
		wolf = atoi(argv[1]);
		_init_world();
		_eval();
		_free_world();
		exit(0);
	}

	srand(time(NULL));

	_init_world();
	glutInit(&argc, argv);
	glutInitWindowSize(800, 600);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutCreateWindow("eco");
	glutDisplayFunc(_display);
	glutReshapeFunc(_reshape);
	glutKeyboardFunc(_keyboard);
	glutMouseFunc(_mouse);
	glutMotionFunc(_motion);
	glutIdleFunc(_gl_eval);
	glutMainLoop();

	return 0;
}

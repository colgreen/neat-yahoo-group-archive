#ifndef __UNIT_H__
#define __UNIT_H__

struct unit
{
	int age;

	double xpos;
	double ypos;

	double mangle;
	double mspeed;

	double tangle;
	double thrust;

	int ntraces;
	int otraces;
	float *traces;
	float *colors;
};

struct unit * unit_create(int ntraces);

void unit_destroy(struct unit *unit);

void unit_spawn(struct unit *unit, double xpos, double ypos);

void unit_move(struct unit *unit);

void unit_draw(struct unit *unit, int dtraces, int r, int g, int b);

#endif /* __UNIT_H__ */

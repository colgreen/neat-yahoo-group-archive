#ifndef __NEAT_H__
#define __NEAT_H__

#include <stdio.h>

int neat_create(int norganisms, int ninputs, int noutputs, int nhidden,
		int nrecurrent, double geneprob);

int neat_create_from_file(FILE *file);

void neat_destroy(int popid);

void neat_print(int popid, FILE *file);

const float * neat_activate(int popid, int orgid, const float *inputs);

void neat_flush(int popid, int orgid);

int neat_evolve(int popid);

void neat_epoch(int popid, int generation);

int neat_info_get(int popid, int orgid, int *nnodes, int *ngenes);

double neat_fitness_get(int popid, int orgid);

void neat_fitness_set(int popid, int orgid, double fitness);

int neat_params_write(int popid, FILE *file);

int neat_params_read(int popid, FILE *file);

int neat_params_set(int popid,
		    float mut_prob_add_node,
		    float mut_prob_add_gene,
		    float mut_prob_gene_weights,
		    float mut_prob_toggle_enable,
		    float mut_prob_recurrent,
		    float mut_weight_rate,
		    float mut_weight_power,
		    int mut_tries_new_node,
		    int mut_tries_new_gene,
		    int mut_tries_toggle_enable,
		    float mate_prob_mate_only,
		    float mate_prob_mut_only,
		    float mate_prob_multipoint,
		    float mate_prob_multipoint_avg,
		    float mate_prob_interspecies,
		    float cmp_coeff_disjoint,
		    float cmp_coeff_excess,
		    float cmp_coeff_mutdiff,
		    float cmp_thresh,
		    int age_drop,
		    float age_significance,
		    float survival_thresh,
		    int species_ntargets);

#endif /* __NEAT_H__ */

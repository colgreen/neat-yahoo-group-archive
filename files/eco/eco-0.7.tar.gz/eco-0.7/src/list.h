/* Credits to the people programming 'include/linux/list.h' in the
 * linux kernel source tree. This code is a subset reimplementation. */

#ifndef __LIST_H__
#define __LIST_H__

#include <stddef.h>

struct list
{
	struct list *prev, *next;
};

static void _list_add(struct list *elem, struct list *prev, struct list *next)
{
	next->prev = elem;
	elem->next = next;
	elem->prev = prev;
	prev->next = elem;
}

static void _list_del(struct list *prev, struct list *next)
{
	next->prev = prev;
	prev->next = next;
}

static void list_init(struct list *head)
{
	head->prev = head;
	head->next = head;
}

static void list_del(struct list *elem)
{
	_list_del(elem->prev, elem->next);
}

static void list_add(struct list *head, struct list *elem)
{
	_list_add(elem, head, head->next);
}

static void list_insert(struct list *head, struct list *elem)
{
	_list_add(elem, head->prev, head);
}

#define list_entry(ELEM, TYPE, MEMBER) \
	((TYPE *)((char *)(ELEM) - offsetof(TYPE, MEMBER)))

#define list_for_each(HEAD, POS) \
	for (POS = (HEAD)->next; POS != (HEAD); POS = POS->next)

#define list_for_each_safe(HEAD, POS, TMP) \
	for (POS = (HEAD)->next, TMP = POS->next; POS != (HEAD); \
	     POS = TMP, TMP = POS->next)

#define list_first(HEAD) \
	(HEAD)->next

#endif /* __LIST_H__ */

#include <stdlib.h>
#include <GL/gl.h>
#include <math.h>

#include "unit.h"
#include "error.h"

#define _PI 3.14159265358979323846

struct unit * unit_create(int ntraces)
{
	struct unit *unit;

	unit = malloc(sizeof(struct unit));
	ASSERT(unit);

	unit->ntraces = ntraces;
	unit->otraces = 0;
	unit->traces = calloc(ntraces, 2 * sizeof(float));
	unit->colors = NULL;

	return unit;
}

void unit_destroy(struct unit *unit)
{
	ASSERT(unit);

	if (unit->colors)
		free(unit->colors);
	free(unit->traces);
	free(unit);
}

void unit_spawn(struct unit *unit, double xpos, double ypos)
{
	unit->xpos = xpos;
	unit->ypos = ypos;
	unit->mspeed = 0;
	unit->mangle = 0;
	unit->tangle = (rand() % 360) * _PI / 180;
}

void unit_move(struct unit *unit)
{
	ASSERT(unit);

	unit->xpos += unit->mspeed * cos(unit->mangle);
	unit->ypos += unit->mspeed * sin(unit->mangle);

	unit->traces[2 * unit->otraces] = unit->xpos;
	unit->traces[2 * unit->otraces + 1] = unit->ypos;
	unit->otraces = (unit->otraces + 1) % unit->ntraces;
}

void unit_draw(struct unit *unit, int dtraces, int r, int g, int b)
{
	int i;

	ASSERT(unit);
	
	glPushMatrix();
	glTranslatef(unit->xpos, unit->ypos, 0);
	glRotatef(unit->tangle * 180 / _PI + 90, 0, 0, 1);
	glColor3f(r, g, b);
	glBegin(GL_TRIANGLES);
	        glVertex2f(0, -.5);
		glVertex2f(.3, .5);
		glVertex2f(-.3, .5);
	glEnd();

	glColor3d(0xaa / 255., 0, 0);
	glBegin(GL_TRIANGLES);
		glVertex2f(0, .5);
		glVertex2f(.5, .5 + 2 * unit->thrust);
		glVertex2f(-.5, .5 +  2 * unit->thrust);
	glEnd();
	glPopMatrix();

	if (!unit->colors) {
		unit->colors = malloc(sizeof(float) * 3 * unit->ntraces);
		for (i = 0; i < unit->ntraces; i++) {
			unit->colors[3 * i + 0] =  r * (float)i / unit->ntraces;
			unit->colors[3 * i + 1] =  g * (float)i / unit->ntraces;
			unit->colors[3 * i + 2] =  b * (float)i / unit->ntraces;
		}
	}	

	if (dtraces) {
		glPointSize(4);

		glEnableClientState(GL_COLOR_ARRAY);
		glEnableClientState(GL_VERTEX_ARRAY);

		glColorPointer(3, GL_FLOAT, 0, unit->colors +
			       3 * (unit->ntraces - unit->otraces));
		glVertexPointer(2, GL_FLOAT, 0, unit->traces);
		glDrawArrays(GL_POINTS, 0, unit->otraces);

		glColorPointer(3, GL_FLOAT, 0, unit->colors);
		glVertexPointer(2, GL_FLOAT, 0,
				unit->traces + 2 * unit->otraces);
		glDrawArrays(GL_POINTS, 0, unit->ntraces - unit->otraces);

		glDisableClientState(GL_COLOR_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
	}
}

#ifndef __MAP_H__
#define __MAP_H__

struct map
{
	int width;
	int height;
	int dirty;
	int erase;

	int texw;
	int texh;
	int wall;

	double wx;
	double wy;
	double wr;
	double wa;

	GLuint tex;

	char *map;
};

struct map * map_create(int width, int height);

void map_destroy(struct map *map);

void map_write(struct map *map, FILE *file);

void map_read(struct map *map, FILE *file);

void map_draw(struct map *map);

void map_wall(struct map *map);

int map_collisioni(struct map *map, double *dist, double radius,
		   double xp, double yp, double angle);

int map_collisionf(struct map *map, double *dist, double radius,
		   double xp, double yp, double angle);

#endif /* __MAP_H__ */

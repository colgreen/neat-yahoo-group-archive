#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glut.h>

#include "map.h"
#include "error.h"

#define _MAP_WALL   (char)1
#define _MAP(X, Y)  map->map[(Y) * map->width + (X)]

void _gl_plot(struct map *map, int x, int y)
{
	glVertex2i(x, y);
}

void _map_plot(struct map *map, int x, int y)
{
	if ((x >= 2) && (x < map->width - 2) &&
	    (y >= 2) && (y < map->height - 2))
		map->map[y * map->width + x] = map->erase ? 0 : _MAP_WALL;
}

void _border(struct map *map)
{
	int i;

	ASSERT(map);

	/* two pixels border */
	for (i = 0; i < map->width; i++) {
		_MAP(i, 0) = _MAP_WALL;
		_MAP(i, 1) = _MAP_WALL;
		_MAP(i, map->height - 1) = _MAP_WALL;
		_MAP(i, map->height - 2) = _MAP_WALL;
	}
	for (i = 0; i < map->height; i++) {
		_MAP(0, i) = _MAP_WALL;
		_MAP(1, i) = _MAP_WALL;
		_MAP(map->width - 1, i) = _MAP_WALL;
		_MAP(map->width - 2, i) = _MAP_WALL;
	}
}

void _tex_gen(struct map *map)
{
	int x, y;
	GLint vp[4];

	ASSERT(map);

	glGetIntegerv(GL_VIEWPORT, vp);
	glViewport(0, 0, map->width, map->height);

	glClearColor(0, 0, 0, 0);
	glClear(GL_COLOR_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glTranslatef(-1, 1, 0);
	glScalef(2. / map->width, -2. / map->height, 1);

	glColor3f(.4, .4, .4);
	glBegin(GL_QUADS);
	for (y = 0; y < map->height; y++) {
		for (x = 0; x < map->width; x++) {
			switch (_MAP(x, y)) {
			case _MAP_WALL:
				glVertex2f(x, y);
				glVertex2f(x + 1, y);
				glVertex2f(x + 1, y + 1);
				glVertex2f(x, y + 1);
				break;
			}
		}
	}
	glEnd();
	glPopMatrix();

	glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 0, 0,
			 map->texw, map->texh, 0);

	glViewport(vp[0], vp[1], vp[2], vp[3]);

	map->dirty = 0;
}

void _line(struct map *map, double xp, double yp, double angle, double radius,
	   void (*plot)(struct map *map, int, int), int safe)
{
	int x, y, xs, ys, xe, ye, dx, dy, e, st;

	xs = xp;
	ys = yp;
	xe = xp + radius * cos(angle);
	ye = yp + radius * sin(angle);
	dx = xe - xs;
	dy = ye - ys;
	x = xs;
	y = ys;

	if (abs(dx) >= abs(dy)) {
		st = ys <= ye ? 1 : -1;
		dy = abs(dy);
		e = dx >> 1;
		if (xs <= xe) {
			while (x <= xe) {
				plot(map, x, y);
				e -= dy;
				if (e < 0) {
					e += dx;
					y += st;
					if (safe)
						plot(map, x, y);
				}
				x += 1;
			}
		} else {
			e = -e;
			while (x >= xe) {
				plot(map, x, y);
				e -= dy;
				if (e <= 0) {
					e -= dx;
					y += st;
					if (safe)
						plot(map, x, y);
				}
				x -= 1;
			}
		}
	} else {
		st = xs <= xe ? 1 : -1;
		dx = abs(dx);
		e = dy >> 1;
		if (ys <= ye) {
			while (y <= ye) {
				plot(map, x, y);
				e -= dx;
				if (e < 0) {
					e += dy;
					x += st;
					if (safe)
						plot(map, x, y);
				}
				y += 1;
			}
		} else {
			e = -e;
			while (y >= ye) {
				plot(map, x, y);
				e -= dx;
				if (e <= 0) {
					e -= dy;
					x += st;
					if (safe)
						plot(map, x, y);
				}
				y -= 1;
			}
		}
	}
}

struct map * map_create(int width, int height)
{
	struct map *map;

	map = malloc(sizeof(struct map));
	ASSERT(map);

	map->width = width;
	map->height = height;
	map->erase = 0;
	map->map = calloc(width * height, sizeof(char));
	ASSERT(map->map);

	_border(map);

	glGenTextures(1, &map->tex);

	map->texw = 256;
	map->texh = 256;
	map->dirty = 1;

	return map;
}

void map_destroy(struct map *map)
{
	ASSERT(map);

	free(map->map);
}

void map_write(struct map *map, FILE *file)
{
	int x, y;

	ASSERT(map);
	ASSERT(file);

	fprintf(file, "%d %d\n", map->width, map->height);
	for (y = 0; y < map->height; y++) {
		for (x = 0; x < map->width; x++) {
			fprintf(file, "%d", _MAP(x, y));
			if (x != map->width - 1)
				fprintf(file, " ");
		}
		fprintf(file, "\n");
	}
}

void map_read(struct map *map, FILE *file)
{
	int x, y, m;

	ASSERT(map);
	ASSERT(file);

	fscanf(file, "%d %d\n", &map->width, &map->height);
	for (y = 0; y < map->height; y++) {
		for (x = 0; x < map->width; x++) {
			fscanf(file, "%d", &m);
			_MAP(x, y) = (char)m;
			if (x != map->width - 1)
				fscanf(file, " ");
		}
		fscanf(file, "\n");
	}
	map->dirty = 1;
}

void map_draw(struct map *map)
{
	glBindTexture(GL_TEXTURE_2D, map->tex);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
#ifndef _WIN32
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
#endif
	if (map->dirty)
		_tex_gen(map);

	glColor3f(1, 1, 1);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2f(0, 0);

		glTexCoord2f(1, 0);
		glVertex2f(1, 0);

		glTexCoord2f(1, 1);
		glVertex2f(1, 1);

		glTexCoord2f(0, 1);
		glVertex2f(0, 1);
	glEnd();
	glDisable(GL_TEXTURE_2D);
}

void map_wall(struct map *map)
{
	ASSERT(map);

	glColor3f(1, 0, 1);
	glBegin(GL_LINES);
		glVertex2d(map->wx, map->wy);
		glVertex2d(map->wx + map->wr * cos(map->wa),
			   map->wy + map->wr * sin(map->wa));
	glEnd();

	glPushMatrix();
	glTranslatef(.5, .5, 0);
	glPointSize(4);
	glBegin(GL_POINTS);
		_line(map, map->wx, map->wy, map->wa, map->wr, _gl_plot, 1);
	glEnd();
	glPopMatrix();

	if (map->wall == 2) {
		_line(map, map->wx, map->wy, map->wa, map->wr, _map_plot, 1);
		glutPostRedisplay();
		map->wall = 0;
		map->erase = 0;
		map->dirty = 1;
	}
}

int map_collisionf(struct map *map, double *dist, double radius,
		   double xp, double yp, double angle)
{
	double x, y, r, dx, dy, dr;
	int ret = 0;

	dx = cos(angle);
	dy = sin(angle);
	dr = sqrt(dx * dx + dy * dy);

	x = xp;
	y = yp;
	r = 0;
	while (r < radius) {
		if ((ret = map->map[(int)y * map->width + (int)x]))
			break;
		x += dx;
		y += dy;
		r += dr;
	}

	if (dist)
		*dist = r;

	return ret; 
}

int map_collisioni(struct map *map, double *dist, double radius, double xp,
		   double yp, double angle)
{
	int x, y, xs, ys, xe, ye, dx, dy, xa, ya, e, ret = -1;
	int mapw, maph;
	char *m;

	mapw = map->width;
	maph = map->height;

	xs = xp;
	ys = yp;
	xe = xp + radius * cos(angle);
	ye = yp + radius * sin(angle);
	dx = xe - xs;
	dy = ye - ys;
	x = xs;
	y = ys * mapw;

	if (abs(dx) >= abs(dy)) {
		ya = ys <= ye ? mapw : -mapw;
		dy = abs(dy);
		e = dx >> 1;
		m = map->map + y;
		if (xs <= xe) {
			while (x <= xe) {
				if ((ret = m[x]))
					break;
				e -= dy;
				if (e < 0) {
					e += dx;
					m += ya;
				}
				x += 1;
			}
		} else {
			e = -e;
			while (x >= xe) {
				if ((ret = m[x]))
					break;
				e -= dy;
				if (e <= 0) {
					e -= dx;
					m += ya;
				}
				x -= 1;
			}
		}
		y = (m - map->map) / mapw;
	} else {
		xa = xs <= xe ? 1 : -1;
		dx = abs(dx);
		e = dy >> 1;
		m = map->map + x;
		if (ys <= ye) {
			ye *= mapw;
			while (y <= ye) {
				if ((ret = m[y]))
					break;
				e -= dx;
				if (e < 0) {
					e += dy;
					m += xa;
				}
				y += mapw;
			}
		} else {
			ye *= mapw;
			e = -e;
			while (y >= ye) {
				if ((ret = m[y]))
					break;
				e -= dx;
				if (e <= 0) {
					e -= dy;
					m += xa;
				}
				y -= mapw;
			}
		}
		x = (m - map->map);
		y /= mapw;
	}

	if (dist)
		*dist = sqrt((x - xs) * (x - xs) + (y - ys) * (y - ys));

	return ret; 
}

#include <stdlib.h>

#include "avg.h"
#include "error.h"

struct avg * avg_create(int navg0, int navg1, int navg2)
{
	struct avg *avg;

	avg = malloc(sizeof(struct avg));
	ASSERT(avg);

	avg->navg0 = navg0;
	avg->navg1 = navg1;
	avg->navg2 = navg2;

	avg->savg0 = 0;
	avg->savg1 = 0;
	avg->savg2 = 0;

	avg->avg0 = calloc(navg0, sizeof(float));
	avg->avg1 = calloc(navg1, sizeof(float));
	avg->avg2 = calloc(navg2, sizeof(float));

	return avg;
}

void avg_destroy(struct avg *avg)
{
	ASSERT(avg);

	free(avg->avg0);
	free(avg->avg1);
	free(avg->avg2);
}

void avg_add(struct avg *avg, float val, int time)
{
	avg->savg0 += val / avg->navg0 - avg->avg0[time % avg->navg0];
	avg->avg0[time % avg->navg0] = val / avg->navg0;

	avg->savg1 += val / avg->navg1 - avg->avg1[time % avg->navg1];
	avg->avg1[time % avg->navg1] = val / avg->navg1;

	avg->savg2 += val / avg->navg2 - avg->avg2[time % avg->navg2];
	avg->avg2[time % avg->navg2] = val / avg->navg2;
}

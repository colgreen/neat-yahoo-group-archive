#ifndef __AVG_H__
#define __AVG_H__

struct avg
{
	int navg0;
	int navg1;
	int navg2;
	float *avg0;
	float *avg1;
	float *avg2;
	float savg0;
	float savg1;
	float savg2;
};

struct avg * avg_create(int navg0, int navg1, int navg2);

void avg_destroy(struct avg *avg);

void avg_add(struct avg *avg, float val, int time);

#endif /* __AVG_H__ */

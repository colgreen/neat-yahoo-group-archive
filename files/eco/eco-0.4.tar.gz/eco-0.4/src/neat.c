#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>
#include "neat.h"
#include "list.h"
#include "error.h"


#define _NODE_BIAS   1
#define _NODE_INPUT  2
#define _NODE_OUTPUT 3
#define _NODE_HIDDEN 4

#define _MAX_POPS      32
#define _NTSPECIES     4
#define _COMPAT_START  100
#define _SIGMOID_SLOPE 4.924273

#define _NODEP(H) list_entry(H, struct _node, headp)
#define _NODEG(H) list_entry(H, struct _node, headg)
#define _LINK(H) list_entry(H, struct _link, head)
#define _GENE(H) list_entry(H, struct _gene, head)

#define _NODE_IS_BIAS(ID) ((ID) == 1)
#define _NODE_IS_INPUT(ID) ((ID) <= genome->ninputs)
#define _NODE_IS_OUTPUT(ID) (((ID) <= genome->ninputs + genome->noutputs) && \
			     ((ID) > genome->ninputs))
#define _NODE_IS_HIDDEN(ID) ((ID > genome->ninputs + genome->noutputs))

#define _MAX(A, B) ((A) > (B) ? (A) : (B))
#define _MIN(A, B) ((A) < (B) ? (A) : (B))


int npops = 0;
struct _population ** pops = NULL;

extern int time_alive_min;
int newnode_tries = 20;
int newgene_tries = 20;

int age_drop = 15;
double age_significance = 1;

double survival_thresh = .2;

double disjoint_coeff = 1;
double excess_coeff = 1;
double mutdiff_coeff = 3;

double mutate_add_node_prob = .1;
double mutate_add_gene_prob = .1;
double mutate_gene_weights_prob = .9;
double mutate_recurrent_prob = .1;
double mutate_weight_rate = 1;
double mutate_weight_power = 1;

double mate_only_prob = .2;
double mate_mut_only_prob = .25;
double mate_multipoint_prob = .6;
double mate_multipoint_avg_prob = .4;
double mate_interspecies_prob = .01;


struct _op
{
	float *ptr;
	double val;
};

struct _node
{
	int id;
	int gene_orig;
	int type;

	struct list headg;
	struct list headp;
};

struct _link
{
	int id;
	int snode;
	int enode;

	struct list head;
};

struct _gene
{
	struct _link *link;

	double weight;
	int recurrent;

	struct list head;
};

struct _genome
{
	int ninputs;
	int noutputs;

	int nnodes;
	struct list nodes;

	int ngenes;
	struct list genes;

	int nops;
	struct _op *ops;

	float *activations;
};

struct _organism
{
	double fitness;

	int time_alive;

	struct _genome *genome;
	struct _species *species;
};

struct _species
{
	double fitness_max_ever;

	int age;
	int age_imp;

	int norgs;
	struct _organism **orgs;
};

struct _population
{
	int node_cur;
	struct list nodes;

	int link_cur;
	struct list links;

	int norgs;
	struct _organism **orgs;

	int nspecies;
	struct _species **species;

	double compat_threshold;
};


void _genome_insert_node(struct _genome *genome, struct _node *node);
void _genome_insert_gene(struct _genome *genome, struct _gene *gene);
void _population_speciate(struct _population *pop, struct _organism *org);
struct _link * _population_get_link(struct _population *pop, int id,
				    int snode, int enode);
struct _node * _population_get_node(struct _population *pop, int id,
				    int gene_orig, int type);


/* MISC */

double _ranf(void)
{
        return rand() / (double) RAND_MAX;
}

double _gaussrand(void)
{
	static int flip = 0;
	static double y2;
	double x1, x2, y1, w;

	flip = !flip;
	if (flip) {
		do {
			x1 = 2 * _ranf() - 1;
			x2 = 2 * _ranf() - 1;
			w = x1 * x1 + x2 * x2;
		} while ((w >= 1) || (w == 0));
		w = sqrt(-2 * log(w) / w);
		y1 = x1 * w;
		y2 = x2 * w;
		return y1;
	} else
		return y2;
 }

int _randposneg(void)
{
	return rand() % 2 ? 1 : -1;
}

double _sigmoid(double t)
{
	return 1 / (1 + exp(-t));
}


/* NODE */

struct _node * _node_create(int id, int gene_orig, int type)
{
	struct _node *node;

	node = malloc(sizeof(struct _node));
	ASSERT(node);

	node->id = id;
	node->gene_orig = gene_orig;
	node->type = type;

	return node;
}

struct _node * _node_create_dup(const struct _node *node)
{
	ASSERT(node);

	return _node_create(node->id, node->gene_orig, node->type);
}

struct _node * _node_create_from_file(FILE *file, struct _population *pop)
{
	struct _node *node;
	int id, gene_orig, type;
	fpos_t pos;

	ASSERT(file);

	fgetpos(file, &pos);
	if (fscanf(file, "node %d %d %d\n", &id, &gene_orig, &type) != 3) {
		fsetpos(file, &pos);
		return NULL;
	}

	node = _population_get_node(pop, id, gene_orig, type);
	ASSERT(node);

	return _node_create_dup(node);
}

void _node_destroy(struct _node *node)
{
	ASSERT(node);

	free(node);
}

void _node_print(const struct _node *node, FILE *file)
{
	ASSERT(node);
	ASSERT(file);

	fprintf(file, "node %8d %8d %8d\n",
		node->id, node->gene_orig, node->type);
}


/* LINK */

struct _link * _link_create(int id, int snode, int enode)
{
	struct _link *link;

	link = malloc(sizeof(struct _link));
	ASSERT(link);

	link->id = id;
	link->snode = snode;
	link->enode = enode;

	return link;
}

void _link_destroy(struct _link *link)
{
	ASSERT(link);

	free(link);
}


/* GENE */

struct _gene * _gene_create(struct _link *link, double weight, int recurrent)
{
	struct _gene *gene;

	ASSERT(link);

	gene = malloc(sizeof(struct _gene));
	ASSERT(gene);

	gene->link = link;
	gene->weight = weight;
	gene->recurrent = recurrent;

	return gene;
}

struct _gene * _gene_create_dup(const struct _gene *gene)
{
	ASSERT(gene);

	return _gene_create(gene->link, gene->weight, gene->recurrent);
}

struct _gene * _gene_create_from_file(FILE *file, struct _population *pop)
{
	int id, snode, enode, recurrent;
	double weight;
	struct _link *link;
	fpos_t pos;

	ASSERT(file);

	fgetpos(file, &pos);
	if (fscanf(file, "gene %d %d %d %lf %d\n", &id, &snode,
		   &enode, &weight, &recurrent) != 5) {
		fsetpos(file, &pos);
		return NULL;
	}

	link = _population_get_link(pop, id, snode, enode);
	ASSERT(link);

	return _gene_create(link, weight, recurrent);
}

void _gene_destroy(struct _gene *gene)
{
	ASSERT(gene);

	free(gene);
}

void _gene_print(const struct _gene *gene, FILE *file)
{
	ASSERT(gene);
	ASSERT(file);

	fprintf(file, "gene %8d %8d %8d    %9lf %d\n",
		gene->link->id, gene->link->snode, gene->link->enode,
		gene->weight, gene->recurrent);
}

int _gene_sort_lowest_enode_first(const void *a, const void *b)
{
	int e1, e2;

	e1 = (*((const struct _gene **)a))->link->enode;
	e2 = (*((const struct _gene **)b))->link->enode;

	if (e1 > e2)
		return 1;
	else if (e1 == e2)
		return 0;
	else
		return -1;
}


/* GENOME */

void _genome_init(struct _genome *genome, int ninputs, int noutputs,
		  int nnodes, int ngenes)
{
	ASSERT(genome);

	genome->ninputs = ninputs;
	genome->noutputs = noutputs;
	genome->nnodes = nnodes;
	genome->ngenes = ngenes;
	genome->nops = 0;
	genome->ops = NULL;
	genome->activations = NULL;

	list_init(&genome->nodes);
	list_init(&genome->genes);
}

struct _genome * _genome_create(int ninputs, int noutputs, int nhidden,
				double geneprob, struct _population *pop)
{
	struct _genome * genome;
	struct _node *node;
	struct _gene *gene;
	struct _link *link;
	int i, s, e, id;
	double weight;

	ASSERT(pop);

	genome = malloc(sizeof(struct _genome));
	ASSERT(genome);

	_genome_init(genome, ninputs, noutputs, 0, 0);

	for (i = 0; i < ninputs + noutputs + nhidden; i++) {
		id = i + 1;
		if (i == 0)
			node = _population_get_node(pop, id, -id, _NODE_BIAS);
		else if (i < ninputs)
			node = _population_get_node(pop, id, -id, _NODE_INPUT);
		else if (i < ninputs + noutputs)
			node = _population_get_node(pop, id, -id, _NODE_OUTPUT);
		else 
			node = _population_get_node(pop, id, -id, _NODE_HIDDEN);
		ASSERT(node);
		_genome_insert_node(genome, _node_create_dup(node));
	}

	if (geneprob == 0)
		return genome;

	/* TODO: */
	for (e = ninputs; e < ninputs + noutputs + nhidden; e++) {
		for (s = 0; s < ninputs + noutputs + nhidden; s++) {
			if ((s >= e) ||
			    ((s >= ninputs) && (s < ninputs + noutputs)))
				continue;
			if (_ranf() > geneprob)
				continue;

			weight = _randposneg() * _ranf();

			link = _population_get_link(pop, 0, s + 1, e + 1);
			ASSERT(link);

			gene = _gene_create(link, weight, 0);
			ASSERT(gene);

			_genome_insert_gene(genome, gene);
		}
	}

	return genome;
}

struct _genome * _genome_create_from_file(int ninputs, int noutputs,
					  struct _population *pop, FILE *file)
{
	struct _genome * genome;
	struct _node *node;
	struct _gene *gene;
	fpos_t pos;

	ASSERT(file);

	fgetpos(file, &pos);
	if (fscanf(file, "genome\n") != 0) {
		fsetpos(file, &pos);
		return NULL;
	}

	genome = malloc(sizeof(struct _genome));
	ASSERT(genome);

	_genome_init(genome, ninputs, noutputs, 0, 0);

	while ((node = _node_create_from_file(file, pop)))
		_genome_insert_node(genome, node);

	while ((gene = _gene_create_from_file(file, pop)))
		_genome_insert_gene(genome, gene);

	return genome;
}

struct _genome * _genome_create_dup(const struct _genome *genome)
{
	struct list *h;
	struct _genome *dup;

	ASSERT(genome);

	dup = malloc(sizeof(struct _genome));
	ASSERT(dup);

	_genome_init(dup, genome->ninputs, genome->noutputs, 0, 0);

	list_for_each(&genome->nodes, h)
		_genome_insert_node(dup, _node_create_dup(_NODEG(h)));

	list_for_each(&genome->genes, h)
		_genome_insert_gene(dup, _gene_create_dup(_GENE(h)));

	return dup;
}

void _genome_destroy(struct _genome *genome)
{
	struct list *h, *s;
	struct _gene *g;
	struct _node *n;

	ASSERT(genome);

	list_for_each_safe(&genome->nodes, h, s) {
		n = _NODEG(h);
		list_del(h);
		_node_destroy(n);
	}

	list_for_each_safe(&genome->genes, h, s) {
		g = _GENE(h);
		list_del(h);
		_gene_destroy(g);
	}

	if (genome->ops)
		free(genome->ops);

	if (genome->activations)
		free(genome->activations);

	free(genome);
}

void _genome_print(const struct _genome *genome, FILE *file)
{
	struct _gene *g;
	struct _node *n;
	struct list *h;

	ASSERT(genome);
	ASSERT(file);

	fprintf(file, "genome\n");

	list_for_each(&genome->nodes, h) {
		n = _NODEG(h);
		_node_print(n, file);
	}

	list_for_each(&genome->genes, h) {
		g = _GENE(h);
		_gene_print(g, file);
	}
}

int _genome_index(const struct _genome *genome, int node)
{
	struct list *h;
	int index = 0;

	ASSERT(node > 0);

	if (node <= genome->ninputs + genome->noutputs)
		return node - 1;

	list_for_each(&genome->nodes, h) {
		if (_NODEG(h)->id == node)
			break;
		index++;
	}
	ASSERT(index < genome->nnodes);

	return index;
}

void _genome_rec_traverse(struct _genome *genome, int node,
			  struct _gene **genes, int *visited)
{
	int idx, i = 0;

	ASSERT(genome);
	ASSERT(genes);
	ASSERT(visited);

	if (_NODE_IS_INPUT(node))
		return;

	idx = _genome_index(genome, node);
	if (visited[idx])
		return;
	visited[idx] = 1;

	while (genes[i] && genes[i]->link->enode != node)
		i++;

	while (genes[i] && genes[i]->link->enode == node) {
		if (!genes[i]->recurrent)
			_genome_rec_traverse(genome, genes[i]->link->snode,
					     genes, visited);
		i++;
	}
}

int _genome_is_recurrent(struct _genome *genome, int snode, int enode)
{
	struct _gene *genes[genome->ngenes + 1];
	int visited[genome->nnodes], i = 0;
	struct list *h;

	ASSERT(genome);

	list_for_each(&genome->genes, h)
		genes[i++] = _GENE(h);
	genes[i] = NULL;
	qsort(genes, genome->ngenes, sizeof(struct _gene *),
	      _gene_sort_lowest_enode_first);

	memset(visited, 0, sizeof(int) * genome->nnodes);

	_genome_rec_traverse(genome, snode, genes, visited);

	return visited[_genome_index(genome, enode)];
}

void _genome_gen_traverse(struct _genome *genome, int node,
			  struct _gene **genes, int *visited)
{
	struct _op *op;
	int j, idx, snode, i = 0;

	ASSERT(genome);
	ASSERT(genes);
	ASSERT(visited);

	if (_NODE_IS_INPUT(node))
		return;

	idx = _genome_index(genome, node);
	if (visited[idx])
		return;
	visited[idx] = 1;

	/* search for start of the incoming genes in sorted gene array */
	while (genes[i] && genes[i]->link->enode != node)
		i++;
	j = i;

	/* traverse deeper into the graph */
	while (genes[i] && genes[i]->link->enode == node) {
		if (!genes[i]->recurrent)
			_genome_gen_traverse(genome, genes[i]->link->snode,
					     genes, visited);
		i++;
	}

	/* store dst pointer for the summation, and number of incoming */
	op = &genome->ops[genome->nops];
	op->ptr = genome->activations + _genome_index(genome, node);
	op->val = i - j;
	op++;

	/* set up the summation operations for this node */
	i = j;
	while (genes[i] && genes[i]->link->enode == node) {
		snode = genes[i]->link->snode;
		op->ptr = genome->activations + _genome_index(genome, snode) +
			  genes[i]->recurrent * genome->nnodes;
		op->val = genes[i]->weight;
		op++;
		i++;
	}

	genome->nops += 1 + i - j;
}

void _genome_genesis(struct _genome *genome)
{
	struct _gene *g, *genes[genome->ngenes + 1];
	int i, visited[genome->nnodes];
	struct list *h;

	ASSERT(genome);

	genome->ops = malloc((genome->ngenes + genome->nnodes -
			      genome->ninputs) * sizeof(struct _op));
	ASSERT(genome->ops);

	genome->activations = calloc(sizeof(float), 2 * genome->nnodes);
	ASSERT(genome->activations);

	i = 0;
	list_for_each(&genome->genes, h)
		genes[i++] = _GENE(h);
	genes[i] = NULL;
	qsort(genes, genome->ngenes, sizeof(struct _gene *),
	      _gene_sort_lowest_enode_first);

	/* traverse graph starting from outputs */
	memset(visited, 0, sizeof(int) * genome->nnodes);
	for (i = 0; i < genome->noutputs; i++)
		_genome_gen_traverse(genome, genome->ninputs + i + 1,
				     genes, visited);

	for (i = genome->ninputs; i < genome->nnodes; i++)
		ASSERT(visited[i]);
}

const float * _genome_activate(struct _genome *genome, const float *inputs)
{
	struct _op *op;
	float *dst, sum;
	int n, nin;

	ASSERT(genome);
	ASSERT(inputs);

	memcpy(genome->activations + genome->nnodes, genome->activations,
	       genome->nnodes * sizeof(float));
	memcpy(genome->activations, inputs, genome->ninputs * sizeof(float));

	/* traverse the activation operations */
	op = genome->ops;
	while (op < genome->ops + genome->nops) {
		dst = op->ptr;
		nin = op->val;
		op++;
		for (n = 0, sum = 0; n < nin; n++, op++)
			sum += *op->ptr * op->val;
		*dst = _sigmoid(sum * _SIGMOID_SLOPE);
	}
	ASSERT(op == genome->ops + genome->nops);

	/* return pointer to start of outputs */
	return genome->activations + genome->ninputs;
}

double _genome_compat(const struct _genome *genome,
		      const struct _genome *compat)
{
	struct list *h1, *h2;
	struct _gene *g1, *g2;
	double difftot = 0;
	int excess = 0, disjoint = 0, matching = 0;

	ASSERT(genome);
	ASSERT(compat);

	h1 = genome->genes.next;
	h2 = compat->genes.next;

	while ((h1 != &genome->genes) || (h2 != &compat->genes)) {
		if (h1 == &genome->genes) {
			excess++;
			h2 = h2->next;
			continue;
		}
		if (h2 == &compat->genes) {
			excess++;
			h1 = h1->next;
			continue;
		}
		g1 = _GENE(h1);
		g2 = _GENE(h2);
		if (g1->link->id < g2->link->id) {
			disjoint++;
			h1 = h1->next;
			continue;
		}
		if (g2->link->id < g1->link->id) {
			disjoint++;
			h2 = h2->next;
			continue;
		}
		difftot += fabs(g1->weight - g2->weight);
		matching++;
		h1 = h1->next;
		h2 = h2->next;
	}

	matching = matching ? matching : 1;

	return (disjoint_coeff * disjoint + excess_coeff * excess +
		mutdiff_coeff * difftot / matching);
}

void _genome_flush(struct _genome *genome)
{
	int i;

	ASSERT(genome);

	for (i = 0; i < 2 * genome->nnodes; i++)
		genome->activations[i] = 0;
}

struct _node * _genome_find_node(const struct _genome *genome, int id)
{
	struct _node *n;
	struct list *h;

	ASSERT(genome);

	list_for_each(&genome->nodes, h) {
		n = _NODEG(h);
		if (n->id == id)
			return n;
	}

	return NULL;
}

struct _gene * _genome_find_gene(const struct _genome *genome,
				 int snode, int enode)
{
	struct _gene *g;
	struct list *h;

	ASSERT(genome);

	list_for_each(&genome->genes, h) {
		g = _GENE(h);
		if ((g->link->snode == snode) && (g->link->enode == enode))
			return g;
	}

	return NULL;
}

void _genome_insert_node(struct _genome *genome, struct _node *node)
{
	struct list *h;

	ASSERT(genome);
	ASSERT(node);

	if ((genome->ngenes > 0) &&
	    (node->id > _NODEG(genome->nodes.prev)->id))
		h = &genome->nodes;
	else {
		list_for_each(&genome->nodes, h) {
			ASSERT(_NODEG(h)->id != node->id);
			if (_NODEG(h)->id > node->id)
				break;
		}
	}
	list_insert(h, &node->headg);
	genome->nnodes++;
}

void _genome_insert_gene(struct _genome *genome, struct _gene *gene)
{
	struct list *h;

	ASSERT(genome);
	ASSERT(gene);

	if ((genome->ngenes > 0) &&
	    (gene->link->id > _GENE(genome->genes.prev)->link->id))
		h = &genome->genes;
	else {
		list_for_each(&genome->genes, h) {
			ASSERT(_GENE(h)->link->id != gene->link->id);
			if (_GENE(h)->link->id > gene->link->id)
				break;
		}
	}
	list_insert(h, &gene->head);
	genome->ngenes++;
}

void _genome_mutate_add_node(struct _genome *genome, struct _population *pop)
{
	struct list *h;
	struct _node *node, *n;
	struct _gene *gene1, *gene2, *g = NULL;
	struct _link *link1, *link2;
	int i, rnd;

	ASSERT(genome);
	ASSERT(pop);

	if (genome->ngenes == 0)
		return;

	for (i = 0; i < newnode_tries; i++) {
		/* try random gene */
		rnd = rand() % genome->ngenes;
		list_for_each(&genome->genes, h) {
			g = _GENE(h);
			if (rnd-- == 0)
				break;
		}
		ASSERT(h != &genome->genes);

		/* try again if we have this split */
		list_for_each(&genome->nodes, h) {
			n = _NODEG(h);
			if (n->gene_orig == g->link->id)
				break;
		}

		if (h == &genome->nodes &&
		    !g->recurrent && !_NODE_IS_BIAS(g->link->snode))
			break;
	}

	if (i == newnode_tries)
		return;

	node = _population_get_node(pop, 0, g->link->id, _NODE_HIDDEN);
	ASSERT(node);

	link1 = _population_get_link(pop, 0, g->link->snode, node->id);
	ASSERT(link1);

	link2 = _population_get_link(pop, 0, node->id, g->link->enode);
	ASSERT(link2);

	gene1 = _gene_create(link1, 1, 0);
	ASSERT(gene1);

	gene2 = _gene_create(link2, .3 * g->weight, 0);
	ASSERT(gene2);

	_genome_insert_gene(genome, gene1);
	_genome_insert_gene(genome, gene2);
	_genome_insert_node(genome, _node_create_dup(node));

	g->weight = 0;
}

void _genome_mutate_add_gene(struct _genome *genome, struct _population *pop)
{
	struct list *h;
	struct _gene *gene;
	struct _node *snode = NULL, *enode = NULL;
	struct _link *link;
	double weight;
	int i, rnd, rec;

	ASSERT(genome);
	ASSERT(genome->nnodes >= 2);
	ASSERT(pop);

	for (i = 0; i < newgene_tries; i++) {
		rnd = rand() % (genome->nnodes - genome->ninputs);
		list_for_each(&genome->nodes, h) {
			enode = _NODEG(h);
			if (!_NODE_IS_INPUT(enode->id) && (rnd-- == 0))
				break;
		}
		ASSERT(h != &genome->nodes);

		rnd = rand() % genome->nnodes;
		list_for_each(&genome->nodes, h) {
			snode = _NODEG(h);
			if (rnd-- == 0)
				break;
		}
		ASSERT(h != &genome->nodes);

		if (!_genome_find_gene(genome, snode->id, enode->id))
			break;
	}

	if (i == newgene_tries)
		return;

	rec = _genome_is_recurrent(genome, snode->id, enode->id) ||
	      _ranf() <= mutate_recurrent_prob;

	weight = _randposneg() * _ranf();

	link = _population_get_link(pop, 0, snode->id, enode->id);
	ASSERT(link);

	gene = _gene_create(link, weight, rec);
	ASSERT(gene);

	_genome_insert_gene(genome, gene);
}

void _genome_mutate_gene_weights(struct _genome *genome)
{
	double gauss, cgauss, randnum, randchoice;
	struct list *h;
	struct _gene *g;
	int n = 0;

	ASSERT(genome);

	list_for_each(&genome->genes, h) {
		g = _GENE(h);
		if (_ranf() <= .5) {
			gauss = .3;
			cgauss = .1;
		} else if ((genome->ngenes >= 10) &&
			   (n > .8 * genome->ngenes)) {
			gauss = .5;
			cgauss = .3;
		} else {
			if (_ranf() <= .5) {
				gauss = 1 - mutate_weight_rate;
				cgauss = 1 - mutate_weight_rate - .1;
			} else {
				gauss = 1 - mutate_weight_rate;
				cgauss = 1 - mutate_weight_rate;
			}
		}

		randnum = _randposneg() *_ranf() * mutate_weight_power;
		randchoice = _ranf();

		if (randchoice > gauss)
			g->weight += randnum;
		else if (randchoice > cgauss)
			g->weight = randnum;

		/*if (g->weight > 3)
			g->weight = 3;
		else if (g->weight < -3)
			g->weight = -3;*/

		n++;
	}
}

void _genome_mutate(struct _genome *genome, struct _population *pop)
{
	ASSERT(genome);
	ASSERT(pop);

	/* TODO: fix prob==0 bug */
	if (_ranf() <= mutate_add_node_prob)
		_genome_mutate_add_node(genome, pop);

	if (_ranf() <= mutate_add_gene_prob)
		_genome_mutate_add_gene(genome, pop);

	if (_ranf() <= mutate_gene_weights_prob)
		_genome_mutate_gene_weights(genome);
}

void _genome_add_structure(struct _genome *genome, const struct _gene *gene,
	  		   const struct _genome *sgenome)
{
	struct _gene *ngene;
	struct _node *snode, *enode;
	int s, e;

	s = gene->link->snode;
	e = gene->link->enode;

	if (!_genome_find_gene(genome, s, e)) {
		if (!(snode = _genome_find_node(genome, s))) {
			snode = _genome_find_node(sgenome, s);
			_genome_insert_node(genome, _node_create_dup(snode));
		}
		if (!(enode = _genome_find_node(genome, e))) {
			enode = _genome_find_node(sgenome, e);
			_genome_insert_node(genome, _node_create_dup(enode));
		}
		ngene = _gene_create_dup(gene);
		_genome_insert_gene(genome, ngene);

		/* make sure recurrent flag is correct */
		if (!ngene->recurrent &&
		    _genome_is_recurrent(genome, s, e))
			ngene->recurrent = 1;
	}
}

struct _genome * _genome_mate_mp(struct _genome *genome1,
				 struct _genome *genome2, int avg,
				 struct _population *pop)
{
	struct _gene *gene, *g1, *g2;
	struct list *h1, *h2;
	struct _genome *genome;

	ASSERT(genome1);
	ASSERT(genome2);

	genome = _genome_create(genome1->ninputs, genome1->noutputs, 0, 0, pop);

	h1 = genome1->genes.next;
	h2 = genome2->genes.next;

	while ((h1 != &genome1->genes) || (h2 != &genome2->genes)) {
		if (h1 == &genome1->genes) {
			_genome_add_structure(genome, _GENE(h2), genome2);
			h2 = h2->next;
			continue;
		}
		if (h2 == &genome2->genes) {
			_genome_add_structure(genome, _GENE(h1), genome1);
			h1 = h1->next;
			continue;
		}
		g1 = _GENE(h1);
		g2 = _GENE(h2);
		if (g1->link->id < g2->link->id) {
			_genome_add_structure(genome, g1, genome1);
			h1 = h1->next;
			continue;
		}
		if (g2->link->id < g1->link->id) {
			_genome_add_structure(genome, g2, genome2);
			h2 = h2->next;
			continue;
		}
		/* same gene */
		if (avg) {
			gene = _gene_create(g1->link,
					    (g1->weight + g2->weight) / 2,
					    g1->recurrent && g2->recurrent);
			_genome_add_structure(genome, gene, genome1);
			_gene_destroy(gene);
		} else {
			if (_ranf() <= .5)
				_genome_add_structure(genome, g1, genome1);
			else
				_genome_add_structure(genome, g2, genome2);
		}
		h1 = h1->next;
		h2 = h2->next;
	}

	return genome;
}

struct _genome * _genome_mate(struct _genome *mom, struct _genome *dad,
			      struct _population *pop)
{
	struct _genome *genome;

	ASSERT(mom);
	ASSERT(dad);
	ASSERT(pop);

	if (_ranf() <= mate_multipoint_prob)
		genome = _genome_mate_mp(mom, dad, 0, pop);
	else
		genome = _genome_mate_mp(mom, dad, 1, pop);

	if ((mom == dad) || (_ranf() > mate_only_prob) ||
	    (_genome_compat(mom, dad) == 0))
		_genome_mutate(genome, pop);

	return genome;
}


/* ORGANISM */

void _organism_init(struct _organism *org, struct _genome *genome)
{
	ASSERT(org);
	ASSERT(genome);

	org->genome = genome;
	org->fitness = 0;
	org->time_alive = 0;
	org->species = NULL;

	_genome_genesis(genome);
}

struct _organism * _organism_create(struct _genome *genome)
{
	struct _organism *org;

	ASSERT(genome);

	org = malloc(sizeof(struct _organism));
	ASSERT(org);

	_organism_init(org, genome);

	return org;
}

void _organism_destroy(struct _organism *org)
{
	ASSERT(org);

	_genome_destroy(org->genome);

	free(org);
}

int _organism_sort_greatest_fitness_first(const void *a, const void *b)
{
	double f1, f2;

	f1 = (*((const struct _organism **)a))->fitness;
	f2 = (*((const struct _organism **)b))->fitness;

	if (f1 < f2)
		return 1;
	else if (f1 == f2)
		return 0;
	else
		return -1;
}


/* SPECIES */

struct _species * _species_create(int size)
{
	struct _species *species;

	species = malloc(sizeof(struct _species));
	ASSERT(species);

	species->orgs = malloc(2 * size * sizeof(struct _organism *));
	ASSERT(species->orgs);

	species->norgs = 0;
	species->fitness_max_ever = 0;
	species->age = 0;
	species->age_imp = 0;

	return species;
}

void _species_destroy(struct _species *species)
{
	ASSERT(species);

	free(species->orgs);

	free(species);
}

int _species_add_org(struct _species *species, struct _organism *org)
{
	ASSERT(species);
	ASSERT(org);

	species->orgs[species->norgs++] = org;
	org->species = species;

	return species->norgs;
}

int _species_remove_org(struct _species *species, struct _organism *org)
{
	int i;

	ASSERT(species);
	ASSERT(org);

	for (i = 0; i < species->norgs; i++) {
		if (species->orgs[i] == org) {
			memmove(&species->orgs[i], &species->orgs[i + 1],
				sizeof(struct _organism *) *
				(species->norgs - (i + 1)));
			return --species->norgs;
		}
	}

	return species->norgs;
}

void _species_adjust_fitness(struct _species *species, int obliterate)
{
	struct _organism *org;
	int i;

	ASSERT(species);

	for (i = 0; i < species->norgs; i++) {
		org = species->orgs[i];

		if ((species->age >= species->age_imp + age_drop) || obliterate)
			org->fitness *= .01;

		if (species->age <= 10)
			org->fitness *= age_significance;

		org->fitness /= species->norgs;
	}
}

struct _organism * _species_choose_dad(struct _species *species,
				       struct _organism **orgs, int norgs,
				       struct _population *pop)
{
	struct _species *randspecies;
	struct _organism *dad;
	int i, tries;
	double rnd;

	ASSERT(species);
	ASSERT(orgs);
	ASSERT(norgs > 0);
	ASSERT(pop);

	if (_ranf() <= mate_interspecies_prob) {
		tries = 5;
		randspecies = species;
		while ((randspecies == species) && tries--) {
			rnd = _gaussrand() / 4;
			rnd = _MAX(0, rnd);
			rnd = _MIN(1, rnd);
			i = rnd * (pop->nspecies - 1);
			ASSERT((i >= 0) && (i < pop->nspecies));
			randspecies = pop->species[i];
		}
		dad = randspecies->orgs[0];
	} else 
		dad = orgs[rand() % norgs];

	return dad;
}

int _species_sort_greatest_org_fitness_first(const void *a, const void *b)
{
	double f1, f2;

	f1 = (*((const struct _species **)a))->orgs[0]->fitness;
	f2 = (*((const struct _species **)b))->orgs[0]->fitness;

	if (f1 < f2)
		return 1;
	else if (f1 == f2)
		return 0;
	else
		return -1;
}


/* POPULATION */

void _population_init(struct _population *pop, int size)
{
	ASSERT(pop);
	ASSERT(size > 0);

	pop->norgs = size;
	pop->nspecies = 0;
	pop->node_cur = 1;
	pop->link_cur = 1;

	pop->compat_threshold = _COMPAT_START;

	list_init(&pop->nodes);
	list_init(&pop->links);

	pop->species = malloc(2 * size * sizeof(struct _species *));
	ASSERT(pop->species);

	pop->orgs = malloc(size * sizeof(struct _organism *));
	ASSERT(pop->orgs);
}

struct _population * _population_create(int size, int ninputs, int noutputs,
					int nhidden, double geneprob)
{
	struct _genome *genome;
	struct _population *pop;
	struct _organism *org;
	int i;

	pop = malloc(sizeof(struct _population));
	ASSERT(pop);

	_population_init(pop, size);

	for (i = 0; i < size; i++) {
		genome = _genome_create(ninputs, noutputs, nhidden,
					geneprob, pop);
		ASSERT(genome);

		org = _organism_create(genome);
		ASSERT(org);

		_population_speciate(pop, org);
		pop->orgs[i] = org;
	}

	return pop;
}

struct _population * _population_create_from_file(int size, int ninputs,
						  int noutputs, FILE *file)
{
	struct _genome *genome;
	struct _population *pop;
	struct _organism *org;
	int i = 0;

	ASSERT(file);

	pop = malloc(sizeof(struct _population));
	ASSERT(pop);

	_population_init(pop, size);

	for (i = 0; i < size; i++) {
		genome = _genome_create_from_file(ninputs, noutputs, pop, file);
		ASSERT(genome);
		org = _organism_create(genome);
		_population_speciate(pop, org);
		pop->orgs[i] = org;
	}
	ASSERT(i == size);

	return pop;
}

void _population_destroy(struct _population *pop)
{
	struct list *h, *s;
	int i;

	ASSERT(pop);

	for (i = 0; i < pop->norgs; i++)
		_organism_destroy(pop->orgs[i]);

	for (i = 0; i < pop->nspecies; i++)
		_species_destroy(pop->species[i]);

	list_for_each_safe(&pop->nodes, h, s)
		free(_NODEP(h));

	list_for_each_safe(&pop->links, h, s)
		free(_LINK(h));

	free(pop->species);
	free(pop->orgs);
	free(pop);
}

struct _node * _population_get_node(struct _population *pop, int id,
				    int gene_orig, int type)
{
	struct list *h;
	struct _node *node;

	list_for_each(&pop->nodes, h) {
		node = _NODEP(h);
		if (node->gene_orig == gene_orig)
			break;
	}
	if (h == &pop->nodes) {
		node = _node_create(id ? id : pop->node_cur++,
				    gene_orig, type);
		list_add(&pop->nodes, &node->headp);
		if (pop->node_cur <= id)
			pop->node_cur = id + 1;
	}

	return node;
}

struct _link * _population_get_link(struct _population *pop, int id,
				    int snode, int enode)
{
	struct list *h;
	struct _link *link;

	list_for_each(&pop->links, h) {
		link = _LINK(h);
		if ((link->snode == snode) && (link->enode == enode))
			break;
	}
	if (h == &pop->links) {
		link = _link_create(id ? id : pop->link_cur++, snode, enode);
		list_add(&pop->links, &link->head);
		if (pop->link_cur <= id)
			pop->link_cur = id + 1;
	}

	return link;
}

void _population_sort_species(struct _population *pop)
{
	int i;

	ASSERT(pop);

	for (i = 0; i < pop->nspecies; i++)
		qsort(pop->species[i]->orgs, pop->species[i]->norgs,
		      sizeof(struct _organism *),
		      _organism_sort_greatest_fitness_first);

	qsort(pop->species, pop->nspecies, sizeof(struct _species *),
	      _species_sort_greatest_org_fitness_first);
}

int _population_add_species(struct _population *pop,
			    struct _species *species)
{
	ASSERT(pop);
	ASSERT(species);

	pop->species[pop->nspecies++] = species;

	return pop->nspecies;
}

int _population_remove_species(struct _population *pop,
			       struct _species *species)
{
	int i;

	ASSERT(pop);
	ASSERT(species);

	for (i = 0; i < pop->nspecies; i++) {
		if (pop->species[i] == species) {
			memmove(&pop->species[i], &pop->species[i + 1],
				(pop->nspecies - (i + 1)) *
				sizeof(struct _species *));
			return --pop->nspecies;
		}
	}

	return pop->nspecies;
}

void _population_switch_species(struct _population *pop, struct _organism *org,
				struct _species *ospecies,
				struct _species *nspecies)
{
	ASSERT(pop);
	ASSERT(org);
	ASSERT(ospecies);
	ASSERT(nspecies);

	if (_species_remove_org(ospecies, org) == 0) {
		_population_remove_species(pop, ospecies);
		_species_destroy(ospecies);
	}
	_species_add_org(nspecies, org);
}

void _population_reassign_species(struct _population *pop,
				  struct _organism *org)
{
	struct _species *s;
	struct _genome *g;
	int i;

	ASSERT(pop);
	ASSERT(org);

	/* TODO: safe */
	for (i = 0; i < pop->nspecies; i++) {
		s = pop->species[i];

		ASSERT(s->norgs > 0);

		g = s->orgs[0]->genome;
		if ((s != org->species) &&
		    (_genome_compat(g, org->genome) < pop->compat_threshold)) {
			_population_switch_species(pop, org, org->species, s);
			return;
		}
	}

	s = _species_create(pop->norgs);
	_population_add_species(pop, s);
	_population_switch_species(pop, org, org->species, s);
}

struct _species * _population_choose_parent_species(struct _population *pop)
{
	struct _species *spc;
	struct _organism *org;
	double spin, marble, tot, avgfit[pop->nspecies], avgtot = 0;
	int i, j, neligs;

	ASSERT(pop);
	ASSERT(pop->nspecies > 0);

	/* calculate average fitness for each species */
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		tot = 0;
		neligs = 0;
		for (j = 0; j < spc->norgs; j++) {
			org = spc->orgs[j];
			if (org->time_alive >= time_alive_min) {
				tot += org->fitness;
				neligs++;
			}
		}
		avgfit[i] = neligs ? tot / neligs : 0;
		avgtot += avgfit[i];
	}

	/* spinning the wheel */
	spc = pop->species[0];
	spin = avgfit[0];
	marble = _ranf() * avgtot;
	for (i = 1; (i < pop->nspecies) && (spin < marble); i++) {
		spc = pop->species[i];
		spin += avgfit[i];
	}

	return spc;
}

void _population_speciate(struct _population *pop, struct _organism *org)
{
	struct _species *s = NULL;
	struct _genome *g;
	int i;

	ASSERT(pop);
	ASSERT(org);

	for (i = 0; i < pop->nspecies; i++) {
		s = pop->species[i];
		ASSERT(s->norgs > 0);
		g = s->orgs[0]->genome;
		if (_genome_compat(g, org->genome) < pop->compat_threshold)
			break;
	}
	if (i == pop->nspecies) {
		ASSERT(pop->nspecies < 2 * pop->norgs);
		s = _species_create(pop->norgs);
		_population_add_species(pop, s);
	}

	ASSERT(s);

	_species_add_org(s, org);
}

int _population_worst(struct _population *pop)
{
	struct _organism *org, *worst = NULL;
	struct _species *species;
	/* TODO: minfit */
	double avgfit, minfit = (1 << 20);
	int i, worstid = -1;

	for (i = 0; i < pop->norgs; i++) {
		org = pop->orgs[i];
		avgfit = org->fitness / org->species->norgs;
		if ((avgfit < minfit) && (org->time_alive >= time_alive_min)) {
			minfit = avgfit;
			worst = org;
			worstid = i;
		}
	}

	if (worst) {
		species = worst->species;
		if (_species_remove_org(species, worst) == 0) {
			_population_remove_species(pop, species);
			_species_destroy(species);
		}
	}

	return worstid;
}

void _population_reproduce(struct _population *pop, struct _species *species,
			   int noffs, struct _organism **orgs, int *norgs)
{
	struct _organism *mom, *dad, *org, *child;
	struct _genome *genome;
	int i;

	ASSERT(pop);
	ASSERT(species);
	ASSERT(species->norgs > 0);
	ASSERT(orgs);
	ASSERT(norgs);

	for (i = 0; i < noffs; i++) {
		if ((i == 0) && (noffs > 5)) {
			/* clone champ */
			genome = _genome_create_dup(species->orgs[0]->genome);
		} else if ((_ranf() <= mate_mut_only_prob) ||
			   (species->norgs == 1)) {
			/* mutate */
			org = species->orgs[rand() % species->norgs];
			genome = _genome_create_dup(org->genome);
			_genome_mutate(genome, pop);
		} else {
			/* mate */
			mom = species->orgs[rand() % species->norgs];
			dad = _species_choose_dad(species, species->orgs,
						  species->norgs, pop);
			genome = _genome_mate(mom->genome, dad->genome, pop);
		}
		child = _organism_create(genome);
		orgs[(*norgs)++] = child;
	}
}

void _population_reproduce_one(struct _population *pop, int worstid)
{
	struct _organism *mom, *dad, *child, *eligs[pop->norgs];
	struct _species *pspc;
	struct _genome *genome;
	int i, poolsize, neligs = 0;

	ASSERT(pop);
	ASSERT(pop->norgs > 0);
	ASSERT(worstid >= 0);

	pspc = _population_choose_parent_species(pop);

	for (i = 0; i < pspc->norgs; i++)
		if (pspc->orgs[i]->time_alive >= time_alive_min)
			eligs[neligs++] = pspc->orgs[i];

	if (neligs == 0) {
		neligs = pspc->norgs;
		memcpy(eligs, pspc->orgs, neligs * sizeof(struct _organism *));
	}

	poolsize = _MAX(1, neligs * survival_thresh);

	mom = eligs[rand() % poolsize];

	if ((_ranf() <= mate_mut_only_prob) || (poolsize == 1)) {
		genome = _genome_create_dup(mom->genome);
		_genome_mutate(genome, pop);
	} else {
		dad = _species_choose_dad(pspc, eligs, poolsize, pop);
		genome = _genome_mate(mom->genome, dad->genome, pop);
	}
	child = pop->orgs[worstid];
	_genome_destroy(child->genome);
	_organism_init(child, genome);
	_population_speciate(pop, child);
}

int _population_evolve(struct _population *pop)
{
	int i, worstid, nspc;

	worstid = _population_worst(pop);

	if (worstid < 0)
		return -1;

	_population_sort_species(pop);

	_population_reproduce_one(pop, worstid);

	/* TODO: investigate :) */
	nspc = pop->nspecies;
	if (nspc < _NTSPECIES)
		pop->compat_threshold *= .95;
	else if (nspc > _NTSPECIES)
		pop->compat_threshold *= 1.05;
	pop->compat_threshold = _MAX(.3, pop->compat_threshold);

	for (i = 0; i < pop->norgs; i++)
		_population_reassign_species(pop, pop->orgs[i]);

	return worstid;
}

void _population_epoch(struct _population *pop, int generation)
{
	struct _species *spc;
	struct _organism *org, *children[pop->norgs];
	double sfit_tot, pfit_tot = 0;
	int obliterate = -1, noffstot = 0, nchildren = 0;
	int i, j, noffs[pop->nspecies];

	ASSERT(pop);

	for (i = 0; i < pop->nspecies; i++)
		pop->species[i]->age++;

	/* sort the organisms within the species, and the species */
	_population_sort_species(pop);

	/* see which species to punish extra hard */
	/*if ((generation % 30) == 0)
		for (i = pop->nspecies - 1; i >= 0; i--)
			if (pop->species[i]->age >= 20) {
				obliterate = i;
				break;
			}
	*/

	/* adjust fitness */
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		/* TODO: fitness before or after adjustment?!? */
		if (spc->orgs[0]->fitness > spc->fitness_max_ever) {
			spc->fitness_max_ever = spc->orgs[0]->fitness;
			spc->age_imp = spc->age;
		}
		_species_adjust_fitness(spc, obliterate == i);
	}

	/* sort species using adjusted fitness from first organism */
	qsort(pop->species, pop->nspecies, sizeof(struct _species *),
	      _species_sort_greatest_org_fitness_first);

	/* calculate number of offsprings for each species */
	for (i = 0; i < pop->norgs; i++)
		pfit_tot += pop->orgs[i]->fitness;
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		sfit_tot = 0;
		for (j = 0; j < spc->norgs; j++)
			sfit_tot += spc->orgs[j]->fitness;
		noffs[i] = pop->norgs * sfit_tot / pfit_tot;
		noffstot += noffs[i];
	}
	ASSERT(noffstot <= pop->norgs);
	/* give the fractional children to best species */
	noffs[0] += pop->norgs - noffstot;

	/* eliminate organisms that are not allowed to reproduce */
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		spc->norgs = _MAX(1, spc->norgs * survival_thresh);
	}

	/* reproduce */
	for (i = 0; i < pop->nspecies; i++)
		_population_reproduce(pop, pop->species[i], noffs[i],
				      children, &nchildren);
	ASSERT(nchildren == pop->norgs);

	/* speciate children */
	for (i = 0; i < nchildren; i++)
		_population_speciate(pop, children[i]);

	/* remove old organisms */
	for (i = 0; i < pop->norgs; i++) {
		org = pop->orgs[i];
		spc = org->species;
		_species_remove_org(spc, org);
		_organism_destroy(org);
	}

	/* remove empty species */
	for (i = 0; i < pop->nspecies; i++) {
		spc = pop->species[i];
		if (spc->norgs == 0) {
			_population_remove_species(pop, spc);
			_species_destroy(spc);
			i--;
		}
	}

	/* transfer children to main array */
	memcpy(pop->orgs, children, nchildren * sizeof(struct _organism *));
}


/* NEAT */

void _neat_init(void)
{
	/* TODO */
	if (pops == NULL)
		pops = malloc(_MAX_POPS * sizeof(struct _pops *));

	ASSERT(npops < _MAX_POPS);
}

int neat_create(int size, int ninputs, int noutputs, double geneprob)
{
	_neat_init();

	pops[npops] = _population_create(size, ninputs, noutputs, 0, geneprob);

	return npops++;
}

int neat_create_from_file(int size, int ninputs, int noutputs, FILE *file)
{
	ASSERT(size > 0);
	ASSERT(ninputs > 0);
	ASSERT(noutputs > 0);
	ASSERT(file);

	_neat_init();

	pops[npops] = _population_create_from_file(size, ninputs, noutputs,
						   file);

	return npops++;
}

void neat_destroy(int popid)
{
	_population_destroy(pops[popid]);

	if (--npops == 0) {
		free(pops);
		pops = NULL;
	}
}

void neat_print(int popid, int orgid, FILE *file)
{
	ASSERT(file);

	_genome_print(pops[popid]->orgs[orgid]->genome, file);
}

const float * neat_activate(int popid, int orgid, const float *inputs)
{
	struct _organism *org;

	ASSERT(inputs);

	org = pops[popid]->orgs[orgid];

	org->time_alive += 1;

	return _genome_activate(org->genome, inputs);
}

void neat_flush(int popid, int orgid)
{
	struct _organism *org;

	org = pops[popid]->orgs[orgid];

	_genome_flush(org->genome);
}

int neat_evolve(int popid)
{
	return _population_evolve(pops[popid]);
}

void neat_epoch(int popid, int generation)
{
	_population_epoch(pops[popid], generation);
}

double neat_fitness_get(int popid, int orgid)
{
	ASSERT(popid < npops);
	ASSERT(orgid < pops[popid]->norgs);

	return pops[popid]->orgs[orgid]->fitness;
}

void neat_fitness_set(int popid, int orgid, double fitness)
{
	ASSERT(popid < npops);
	ASSERT(orgid < pops[popid]->norgs);

	pops[popid]->orgs[orgid]->fitness = fitness;
}

#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "neat.h"

#define _XOR_NRUNS	100
#define _XOR_NGENS	100
#define _XOR_NORGANISMS	100
#define _XOR_NINPUTS	3
#define _XOR_NOUTPUTS	1
#define _XOR_NHIDDEN	0
#define _XOR_NRECURRENT 0
#define _XOR_GENEPROB	1

int time_alive_min = 0;

int _xor_eval(int popid, int orgid)
{
	int i;
	float out[4], esum;
	float in[12] = { 1, 0, 0,
			 1, 0, 1,
			 1, 1, 0,
			 1, 1, 1 };

	for (i = 0; i < 4; i++) {
		out[i] = *neat_activate(popid, orgid, &in[3 * i]);
		neat_flush(popid, orgid);
	}

	esum = fabs(out[0]) + fabs(1 - out[1]) + fabs(1 - out[2]) +
	       fabs(out[3]);

	neat_fitness_set(popid, orgid, pow(4 - esum, 2));

	if (out[0] < .5 && out[1] >= .5 && out[2] >= .5 && out[3] < .5)
		return 1;

	return 0;
}

int _xor_epoch(int popid, int gen, int *wnum, int *wnodes, int *wgenes)
{
	int i;

	for (i = 0; i < _XOR_NORGANISMS; i++) {
		if (_xor_eval(popid, i)) {
			/* winner */
			*wnum = i;
			neat_info_get(popid, i, wnodes, wgenes);
			return 1;
		}
	}

	neat_epoch(popid, gen);

	return 0;
}

void _xor_test(int ngens)
{
	int i, j, popid, wnum, wnodes, wgenes;
	int nwins = 0, tgens = 0, tevals = 0, tnodes = 0, tgenes = 0;

	printf("XOR  nruns:%d  ngens:%d  norgs:%d",
	       _XOR_NRUNS, _XOR_NGENS, _XOR_NORGANISMS);
	fflush(stdout);

	for (i = 0; i < _XOR_NRUNS; i++) {
		popid = neat_create(_XOR_NORGANISMS, _XOR_NINPUTS,
				    _XOR_NOUTPUTS, _XOR_NHIDDEN,
				    _XOR_NRECURRENT, _XOR_GENEPROB);

		for (j = 0; j < ngens; j++) {
			if (_xor_epoch(popid, j + 1, &wnum, &wnodes, &wgenes)) {
				/* winner */
				nwins++;
				tevals += _XOR_NORGANISMS * j + wnum + 1;
				tnodes += wnodes;
				tgenes += wgenes;
				tgens += j + 1;
				break;
			}
		}

		neat_destroy(popid);
	}

	printf("  nwins:%d", nwins);
	if (nwins == 0)
		goto _done;
	printf("  agens:%.2f  aevals:%.2f  anodes:%.2f  agenes:%.2f",
	       (double)tgens / nwins, (double)tevals / nwins,
	       (double)tnodes / nwins, (double)tgenes / nwins);
_done:
	printf("\n");
}

int main(int argc, char **argv)
{
	srand(time(NULL));

	_xor_test(_XOR_NGENS);

	return 0;
}

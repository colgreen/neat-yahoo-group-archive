#include "headers.h"

#define COMPLEX_MODEL

#define MASS 8.0
#define BRAIN_FORCE_SCALAR 1
#define FMAX 32 
#define PD_RATE 4.0

#define CTRNN_STEP_SIZE 0.02

double PI = 3.1415926535897932384626433832795;

#define JOINT_ANGLE_NORMALIZE 1.0
#define JOINT_SPEED_NORMALIZE 5
#define HEAD_HEIGHT_NORMALIZE 50
#define TORSO_HEIGHT_NORMALIZE 0.5
#define HEAD_VELOCITY_NORMALIZE 0.1
#define TORSO_VELOCITY_NORMALIZE 2.0

// Allowed force - 1.0 is MAX
//
#define NECK_FORCE_SCALAR 0.3
#define SHOULDER_FORCE_SCALAR 0.65
#define ELBOW_FORCE_SCALAR 0.5
#define HIP_FORCE_SCALAR 0.8
#define KNEE_FORCE_SCALAR 0.75
#define ANKLE_FORCE_SCALAR 0.4

// Masses
#define HEAD_MASS_SCALAR 0.3  
#define TORSO_MASS_SCALAR 1.0 
#define ARMS_MASS_SCALAR 0.4 
#define LEGS_MASS_SCALAR 0.6  
#define FEET_MASS_SCALAR 0.2  

#define PD_SPRING_CONST 4
#define PD_DAMPING_CONST 5

/* JOINT LIMITS! :::::

HIPS   - FORW/BACK: -PI/6 .. 3*PI/4
HIPS   - SIDES    : -PI/6 .. PI/6
KNEES  - FORW/BACK: -PI/2 .. 0
ANKLES - FORW/BACK: -PI/2 .. PI/6

*/

#define FEET

#define ACTIVATION_LOW_LIMIT -1
#define LOW_TRESHOLD  -0.4
#define HIGH_TRESHOLD 0.4


#define JOINT_LIMIT_HEAD_FORW_BACK_MIN (-::PI/2.0)
#define JOINT_LIMIT_HEAD_FORW_BACK_MAX (::PI/4.0)

#define JOINT_LIMIT_ARMS_FORW_BACK_MIN (-::PI/1.5)
#define JOINT_LIMIT_ARMS_FORW_BACK_MAX (::PI/1.5)
#define JOINT_LIMIT_ARMS_SIDES_MIN (-::PI/1.5)
#define JOINT_LIMIT_ARMS_SIDES_MAX (0)

#define JOINT_LIMIT_ELBOWS_FORW_BACK_MIN (0)
#define JOINT_LIMIT_ELBOWS_FORW_BACK_MAX (4*::PI/5)

#define JOINT_LIMIT_HIPS_FORW_BACK_MIN (-::PI/3.0)
#define JOINT_LIMIT_HIPS_FORW_BACK_MAX (::PI/2.0)
#define JOINT_LIMIT_HIPS_SIDES_MIN (0)//(-::PI/3.2)
#define JOINT_LIMIT_HIPS_SIDES_MAX (::PI/6)

#define JOINT_LIMIT_KNEES_FORW_BACK_MIN (-::PI/2.0)
#define JOINT_LIMIT_KNEES_FORW_BACK_MAX (0)

#define JOINT_LIMIT_ANKLES_FORW_BACK_MIN (-::PI/2.5)
#define JOINT_LIMIT_ANKLES_FORW_BACK_MAX (::PI/3.5)


#define HEAD_DIV 12.0
#define SHOULDERS_DIV 2.0
#define ELBOWS_DIV_X 1.0
#define ELBOWS_DIV_Y 6.0
#define HIPS_DIV 8.0
#define KNEES_DIV 4.0
#define ANKLES_DIV 4.0

void Human::SetInitialPosition()
{
	//position torso
	dBodySetPosition(torso->GetBodyID(), position.X, position.Y, position.Z);
	dBodySetForce(torso->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(torso->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(torso->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(torso->GetBodyID(), initialQuaternion);

#ifdef COMPLEX_MODEL
	//position head
	dReal headOffset = torso->GetYDimension()/2 + head->GetRadius() + torso->GetYDimension()/HEAD_DIV;
	dBodySetPosition(head->GetBodyID(), position.X, position.Y + headOffset, position.Z);
	dBodySetForce(head->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(head->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(head->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(head->GetBodyID(), initialQuaternion);

	//position upper arms
	dReal upperArmOffsetX = torso->GetXDimension()/2 + leftUpperArm->GetXDimension()/2 + leftUpperArm->GetXDimension()/SHOULDERS_DIV;
	dReal upperArmOffsetY = torso->GetYDimension()/2 - leftUpperArm->GetYDimension()/2;
	dBodySetPosition(leftUpperArm->GetBodyID(), position.X - upperArmOffsetX, position.Y + upperArmOffsetY, position.Z);
	dBodySetPosition(rightUpperArm->GetBodyID(), position.X + upperArmOffsetX, position.Y + upperArmOffsetY, position.Z);
	dBodySetForce(leftUpperArm->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(leftUpperArm->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(leftUpperArm->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(leftUpperArm->GetBodyID(), initialQuaternion);
	dBodySetForce(rightUpperArm->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(rightUpperArm->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(rightUpperArm->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(rightUpperArm->GetBodyID(), initialQuaternion);

	//position lower arms
	dReal lowerArmOffsetX = torso->GetXDimension()/2 + leftLowerArm->GetXDimension()/2 + leftLowerArm->GetXDimension()/ELBOWS_DIV_X;
	dReal lowerArmOffsetY = torso->GetYDimension()/2 - leftUpperArm->GetYDimension() - leftLowerArm->GetYDimension()/2 - leftLowerArm->GetYDimension()/ELBOWS_DIV_Y;
	dBodySetPosition(leftLowerArm->GetBodyID(), position.X - lowerArmOffsetX, position.Y + lowerArmOffsetY, position.Z);
	dBodySetPosition(rightLowerArm->GetBodyID(), position.X + lowerArmOffsetX, position.Y + lowerArmOffsetY, position.Z);
	dBodySetForce(leftLowerArm->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(leftLowerArm->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(leftLowerArm->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(leftLowerArm->GetBodyID(), initialQuaternion);
	dBodySetForce(rightLowerArm->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(rightLowerArm->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(rightLowerArm->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(rightLowerArm->GetBodyID(), initialQuaternion);
#endif

	//position upper legs
	dReal upperLegOffsetX = torso->GetXDimension()/2 - leftUpperLeg->GetXDimension()/2/* - leftUpperLeg->GetXDimension()/HIPS_DIV*/;
	dReal upperLegOffsetY = -torso->GetYDimension()/2 - leftUpperLeg->GetYDimension()/2 - leftUpperLeg->GetYDimension()/HIPS_DIV;
	dBodySetPosition(leftUpperLeg->GetBodyID(), position.X - upperLegOffsetX - LEGS_ADJUST, position.Y + upperLegOffsetY, position.Z);
	dBodySetPosition(rightUpperLeg->GetBodyID(), position.X + upperLegOffsetX + LEGS_ADJUST, position.Y + upperLegOffsetY, position.Z);
	dBodySetForce(leftUpperLeg->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(leftUpperLeg->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(leftUpperLeg->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(leftUpperLeg->GetBodyID(), initialQuaternion);
	dBodySetForce(rightUpperLeg->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(rightUpperLeg->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(rightUpperLeg->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(rightUpperLeg->GetBodyID(), initialQuaternion);

	//position lower legs
	dReal lowerLegOffsetX = torso->GetXDimension()/2 - leftLowerLeg->GetXDimension()/2/* - leftLowerLeg->GetXDimension()*/;
	dReal lowerLegOffsetY = -torso->GetYDimension()/2 - leftUpperLeg->GetYDimension() - leftLowerLeg->GetYDimension()/2 - leftLowerLeg->GetYDimension()/KNEES_DIV;
	dBodySetPosition(leftLowerLeg->GetBodyID(), position.X - lowerLegOffsetX -LEGS_ADJUST, position.Y + lowerLegOffsetY, position.Z);
	dBodySetPosition(rightLowerLeg->GetBodyID(), position.X + lowerLegOffsetX +LEGS_ADJUST, position.Y + lowerLegOffsetY, position.Z);
	dBodySetForce(leftLowerLeg->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(leftLowerLeg->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(leftLowerLeg->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(leftLowerLeg->GetBodyID(), initialQuaternion);
	dBodySetForce(rightLowerLeg->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(rightLowerLeg->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(rightLowerLeg->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(rightLowerLeg->GetBodyID(), initialQuaternion);

	//position feet
#ifdef FEET
	dReal feetOffsetX = torso->GetXDimension()/2 - leftFoot->GetXDimension()/2 + leftFoot->GetXDimension()/2;
	dReal feetOffsetY = -torso->GetYDimension()/2 - leftUpperLeg->GetYDimension() - leftLowerLeg->GetYDimension() - leftFoot->GetYDimension()*3;
	dReal feetOffsetZ = leftLowerLeg->GetZDimension()/1;
	dBodySetPosition(leftFoot->GetBodyID(), position.X - feetOffsetX -LEGS_ADJUST, position.Y + feetOffsetY, position.Z + feetOffsetZ);
	dBodySetPosition(rightFoot->GetBodyID(), position.X + feetOffsetX +LEGS_ADJUST, position.Y + feetOffsetY, position.Z + feetOffsetZ);
	dBodySetForce(leftFoot->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(leftFoot->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(leftFoot->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(leftFoot->GetBodyID(), initialQuaternion);
	dBodySetForce(rightFoot->GetBodyID(), 0, 0, 0);
	dBodySetLinearVel(rightFoot->GetBodyID(), 0, 0, 0);
	dBodySetAngularVel(rightFoot->GetBodyID(), 0, 0, 0);
	dBodySetQuaternion(rightFoot->GetBodyID(), initialQuaternion); 
#endif
}

// Size it the whole size of the human in the Y dimension
// The sizes of the individual parts are just fractions from it
Human::Human(dWorldID world, dSpaceID space, dReal posx, dReal posy, dReal posz, dReal size, NEAT::Network* br)
{
	vector3df jointPoint;

	hip1_cycles=0;
	previous_hip1_state=0; // 0 - (<0), 1 - (>0)
	hip2_cycles=0;
	previous_hip2_state=0; // 0 - (<0), 1 - (>0)
	knee1_cycles=0;
	previous_knee1_state=0; // 0 - (<0), 1 - (>0)
	knee2_cycles=0;
	previous_knee2_state=0; // 0 - (<0), 1 - (>0)


	brain = br;
    LEGS_ADJUST = size / 32.0;

	double PI = ::PI;

	//All dimensions are x,y,z
/*//	dReal torsoDimensions[3] = {1*size, 2*size, 0.5*size};
	dReal torsoDimensions[3] = {1*size, 1.0*size, 0.5*size};
	dReal upperArmDimensions[3] = {0.3*size, 1.5*size, 0.25*size};
	dReal lowerArmDimensions[3] = {0.25*size, 1.5*size, 0.25*size};

	dReal upperLegDimensions[3] = {0.4*size, 1.7*size, 0.4*size};
	dReal lowerLegDimensions[3] = {0.4*size, 1.7*size, 0.4*size};

//	dReal footDimensions[3] = {0.4*size, 0.3*size, 0.8*size};
	dReal footDimensions[3] = {0.4*size, 0.3*size, 0.8*size};
	dReal headRadius = 0.4*size;
*/
	dReal torsoDimensions[3] = {0.2*size, 0.35*size, 0.1*size};
	dReal upperArmDimensions[3] = {0.06*size, 0.23*size, 0.06*size};
	dReal lowerArmDimensions[3] = {0.05*size, 0.25*size, 0.05*size};

	dReal upperLegDimensions[3] = {0.08*size, 0.3*size, 0.08*size};
	dReal lowerLegDimensions[3] = {0.05*size, 0.35*size, 0.05*size};

	dReal footDimensions[3] = {0.06*size, 0.032*size, 0.18*size};
	dReal headRadius = 0.085*size;

	torso = new Box(world, space, MASS*TORSO_MASS_SCALAR, torsoDimensions[0], torsoDimensions[1], torsoDimensions[2]);

#ifdef COMPLEX_MODEL
	head = new Sphere(world, space, MASS*HEAD_MASS_SCALAR, headRadius);

	leftUpperArm = new Box(world, space, MASS*ARMS_MASS_SCALAR, upperArmDimensions[0], upperArmDimensions[1], upperArmDimensions[2]);
	rightUpperArm = new Box(world, space, MASS*ARMS_MASS_SCALAR, upperArmDimensions[0], upperArmDimensions[1], upperArmDimensions[2]);
	leftLowerArm = new Box(world, space, MASS*ARMS_MASS_SCALAR, lowerArmDimensions[0], lowerArmDimensions[1], lowerArmDimensions[2]);
	rightLowerArm = new Box(world, space, MASS*ARMS_MASS_SCALAR, lowerArmDimensions[0], lowerArmDimensions[1], lowerArmDimensions[2]);
#endif

	leftUpperLeg = new Box(world, space, MASS*LEGS_MASS_SCALAR, upperLegDimensions[0], upperLegDimensions[1], upperLegDimensions[2]);
	rightUpperLeg = new Box(world, space, MASS*LEGS_MASS_SCALAR, upperLegDimensions[0], upperLegDimensions[1], upperLegDimensions[2]);
	leftLowerLeg = new Box(world, space, MASS*LEGS_MASS_SCALAR, lowerLegDimensions[0], lowerLegDimensions[1], lowerLegDimensions[2]);
	rightLowerLeg = new Box(world, space, MASS*LEGS_MASS_SCALAR, lowerLegDimensions[0], lowerLegDimensions[1], lowerLegDimensions[2]);
#ifdef FEET
	leftFoot = new Box(world, space, MASS*FEET_MASS_SCALAR, footDimensions[0], footDimensions[1], footDimensions[2]);
	rightFoot = new Box(world, space, MASS*FEET_MASS_SCALAR, footDimensions[0], footDimensions[1], footDimensions[2]);
#endif
	thisBodyID = torso->GetBodyID();

	const dReal* initialQ = dBodyGetQuaternion(torso->GetBodyID());
	initialQuaternion[0] = initialQ[0];
	initialQuaternion[1] = initialQ[1];
	initialQuaternion[2] = initialQ[2];
	initialQuaternion[3] = initialQ[3];

	//Now setting the positions of all body parts.
	//startPoint is starting point for the center of the torso (in world coordinates).
	dReal initialTorsoHeightAboveFeet = footDimensions[1] + lowerLegDimensions[1] + upperLegDimensions[1] + torsoDimensions[1]/2;
	vector3df startPoint;
	position.X = posx;
	position.Y = posy;
	position.Z = posz;
	startPoint = position;

	SetInitialPosition();

	//Now create joints between objects

#ifdef COMPLEX_MODEL
	//Create neck joint
	neck = dJointCreateHinge(world, 0);
	dJointAttach(neck, torso->GetBodyID(), head->GetBodyID());
	jointPoint = torso->GetPosition();
	jointPoint.Y += torso->GetYDimension()/2;
	dJointSetHingeAnchor(neck, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetHingeAxis(neck, -1, 0, 0);
	dJointSetHingeParam(neck, dParamLoStop, JOINT_LIMIT_HEAD_FORW_BACK_MIN);
	dJointSetHingeParam(neck, dParamHiStop, JOINT_LIMIT_HEAD_FORW_BACK_MAX);

	//Create left shoulder joint
	leftShoulder = dJointCreateUniversal(world, 0);
	dJointAttach(leftShoulder, torso->GetBodyID(), leftUpperArm->GetBodyID());
	jointPoint = torso->GetPosition();
	jointPoint.Y += torso->GetYDimension()/2;
	jointPoint.X -= torso->GetXDimension()/2;
	dJointSetUniversalAnchor(leftShoulder, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetUniversalAxis1(leftShoulder, 1, 0, 0);
	dJointSetUniversalAxis2(leftShoulder, 0, 0, -1); // must be switched due to symmetry !
	dJointSetUniversalParam(leftShoulder, dParamLoStop, JOINT_LIMIT_ARMS_FORW_BACK_MIN);
	dJointSetUniversalParam(leftShoulder, dParamHiStop, JOINT_LIMIT_ARMS_FORW_BACK_MAX);
	dJointSetUniversalParam(leftShoulder, dParamLoStop2, JOINT_LIMIT_ARMS_SIDES_MIN);
	dJointSetUniversalParam(leftShoulder, dParamHiStop2, JOINT_LIMIT_ARMS_SIDES_MAX);

	//Create right shoulder joint
	rightShoulder = dJointCreateUniversal(world, 0);
	dJointAttach(rightShoulder, torso->GetBodyID(), rightUpperArm->GetBodyID());
	jointPoint = torso->GetPosition();
	jointPoint.Y += torso->GetYDimension()/2;
	jointPoint.X += torso->GetXDimension()/2;
	dJointSetUniversalAnchor(rightShoulder, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetUniversalAxis1(rightShoulder, 1, 0, 0);
	dJointSetUniversalAxis2(rightShoulder, 0, 0, 1);
	dJointSetUniversalParam(rightShoulder, dParamLoStop, JOINT_LIMIT_ARMS_FORW_BACK_MIN);
	dJointSetUniversalParam(rightShoulder, dParamHiStop, JOINT_LIMIT_ARMS_FORW_BACK_MAX);
	dJointSetUniversalParam(rightShoulder, dParamLoStop2, JOINT_LIMIT_ARMS_SIDES_MIN); 
	dJointSetUniversalParam(rightShoulder, dParamHiStop2, JOINT_LIMIT_ARMS_SIDES_MAX);

	//Create left elbow joint
	leftElbow = dJointCreateHinge(world, 0);
	dJointAttach(leftElbow, leftUpperArm->GetBodyID(), leftLowerArm->GetBodyID());
	jointPoint = leftUpperArm->GetPosition();
	jointPoint.Y -= leftUpperArm->GetYDimension()/2;
	dJointSetHingeAnchor(leftElbow, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetHingeAxis(leftElbow, 1, 0, 0);
	dJointSetHingeParam(leftElbow, dParamLoStop, JOINT_LIMIT_ELBOWS_FORW_BACK_MIN);
	dJointSetHingeParam(leftElbow, dParamHiStop, JOINT_LIMIT_ELBOWS_FORW_BACK_MAX);

	//Create right elbow joint
	rightElbow = dJointCreateHinge(world, 0);
	dJointAttach(rightElbow, rightUpperArm->GetBodyID(), rightLowerArm->GetBodyID());
	jointPoint = rightUpperArm->GetPosition();
	jointPoint.Y -= rightUpperArm->GetYDimension()/2;
	dJointSetHingeAnchor(rightElbow, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetHingeAxis(rightElbow, 1, 0, 0);
	dJointSetHingeParam(rightElbow, dParamLoStop, JOINT_LIMIT_ELBOWS_FORW_BACK_MIN);
	dJointSetHingeParam(rightElbow, dParamHiStop, JOINT_LIMIT_ELBOWS_FORW_BACK_MAX);
#endif

	//Create left hip joint
	leftHip = dJointCreateUniversal(world, 0);
	dJointAttach(leftHip, torso->GetBodyID(), leftUpperLeg->GetBodyID());
	jointPoint = leftUpperLeg->GetPosition();
	jointPoint.Y += leftUpperLeg->GetYDimension()/2;
	dJointSetUniversalAnchor(leftHip, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetUniversalAxis1(leftHip, 1, 0, 0);
	dJointSetUniversalAxis2(leftHip, 0, 0, 1); // must be switched due to symmetry !
	dJointSetUniversalParam(leftHip, dParamLoStop, JOINT_LIMIT_HIPS_FORW_BACK_MIN);
	dJointSetUniversalParam(leftHip, dParamHiStop, JOINT_LIMIT_HIPS_FORW_BACK_MAX);
	dJointSetUniversalParam(leftHip, dParamLoStop2, JOINT_LIMIT_HIPS_SIDES_MIN);
	dJointSetUniversalParam(leftHip, dParamHiStop2, JOINT_LIMIT_HIPS_SIDES_MAX);

	//Create right hip joint
	rightHip = dJointCreateUniversal(world, 0);
	dJointAttach(rightHip, torso->GetBodyID(), rightUpperLeg->GetBodyID());
	jointPoint = rightUpperLeg->GetPosition();
	jointPoint.Y += rightUpperLeg->GetYDimension()/2;
	dJointSetUniversalAnchor(rightHip, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetUniversalAxis1(rightHip, 1, 0, 0);
	dJointSetUniversalAxis2(rightHip, 0, 0, -1);
	dJointSetUniversalParam(rightHip, dParamLoStop, JOINT_LIMIT_HIPS_FORW_BACK_MIN);
	dJointSetUniversalParam(rightHip, dParamHiStop, JOINT_LIMIT_HIPS_FORW_BACK_MAX);
	dJointSetUniversalParam(rightHip, dParamLoStop2, JOINT_LIMIT_HIPS_SIDES_MIN);
	dJointSetUniversalParam(rightHip, dParamHiStop2, JOINT_LIMIT_HIPS_SIDES_MAX);

	//Create left knee joint
	leftKnee = dJointCreateHinge(world, 0);
	dJointAttach(leftKnee, leftUpperLeg->GetBodyID(), leftLowerLeg->GetBodyID());
	jointPoint = leftUpperLeg->GetPosition();
	jointPoint.Y -= leftUpperLeg->GetYDimension()/2;
	jointPoint.Z += leftUpperLeg->GetZDimension()/2;
	dJointSetHingeAnchor(leftKnee, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetHingeAxis(leftKnee, 1, 0, 0);
	dJointSetHingeParam(leftKnee, dParamLoStop, JOINT_LIMIT_KNEES_FORW_BACK_MIN);
	dJointSetHingeParam(leftKnee, dParamHiStop, JOINT_LIMIT_KNEES_FORW_BACK_MAX);

	//Create right knee joint
	rightKnee = dJointCreateHinge(world, 0);
	dJointAttach(rightKnee, rightUpperLeg->GetBodyID(), rightLowerLeg->GetBodyID());
	jointPoint = rightUpperLeg->GetPosition();
	jointPoint.Y -= rightUpperLeg->GetYDimension()/2;
	jointPoint.Z += rightUpperLeg->GetZDimension()/2;
	dJointSetHingeAnchor(rightKnee, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetHingeAxis(rightKnee, 1, 0, 0);
	dJointSetHingeParam(rightKnee, dParamLoStop, JOINT_LIMIT_KNEES_FORW_BACK_MIN);
	dJointSetHingeParam(rightKnee, dParamHiStop, JOINT_LIMIT_KNEES_FORW_BACK_MAX);

#ifdef FEET
	//Create left ankle joint
	leftAnkle = dJointCreateHinge(world, 0);
	dJointAttach(leftAnkle, leftLowerLeg->GetBodyID(), leftFoot->GetBodyID());
	jointPoint = leftLowerLeg->GetPosition();
	jointPoint.Y -= leftLowerLeg->GetYDimension()/2;
	dJointSetHingeAnchor(leftAnkle, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetHingeAxis(leftAnkle, -1, 0, 0);
	dJointSetHingeParam(leftAnkle, dParamLoStop, JOINT_LIMIT_ANKLES_FORW_BACK_MIN);
	dJointSetHingeParam(leftAnkle, dParamHiStop, JOINT_LIMIT_ANKLES_FORW_BACK_MAX);

	//Create right ankle joint
	rightAnkle = dJointCreateHinge(world, 0);
	dJointAttach(rightAnkle, rightLowerLeg->GetBodyID(), rightFoot->GetBodyID());
	jointPoint = rightLowerLeg->GetPosition();
	jointPoint.Y -= rightLowerLeg->GetYDimension()/2;
	dJointSetHingeAnchor(rightAnkle, jointPoint.X, jointPoint.Y, jointPoint.Z);
	dJointSetHingeAxis(rightAnkle, -1, 0, 0);
	dJointSetHingeParam(rightAnkle, dParamLoStop, JOINT_LIMIT_ANKLES_FORW_BACK_MIN);
	dJointSetHingeParam(rightAnkle, dParamHiStop, JOINT_LIMIT_ANKLES_FORW_BACK_MAX);
#endif
	
#ifdef COMPLEX_MODEL
	dJointSetUniversalParam(leftShoulder, dParamFMax, FMAX * SHOULDER_FORCE_SCALAR);
	dJointSetUniversalParam(rightShoulder, dParamFMax, FMAX * SHOULDER_FORCE_SCALAR);
	dJointSetUniversalParam(leftShoulder, dParamFMax2, FMAX * SHOULDER_FORCE_SCALAR);
	dJointSetUniversalParam(rightShoulder, dParamFMax2, FMAX * SHOULDER_FORCE_SCALAR);

	dJointSetHingeParam(leftElbow, dParamFMax, FMAX * ELBOW_FORCE_SCALAR);
	dJointSetHingeParam(rightElbow, dParamFMax, FMAX * ELBOW_FORCE_SCALAR);

	dJointSetHingeParam(neck, dParamFMax, FMAX * NECK_FORCE_SCALAR);
#endif

	dJointSetUniversalParam(leftHip, dParamFMax, FMAX * HIP_FORCE_SCALAR);
	dJointSetUniversalParam(rightHip, dParamFMax, FMAX * HIP_FORCE_SCALAR);
	dJointSetUniversalParam(leftHip, dParamFMax2, FMAX * HIP_FORCE_SCALAR);
	dJointSetUniversalParam(rightHip, dParamFMax2, FMAX * HIP_FORCE_SCALAR);

	dJointSetHingeParam(leftKnee, dParamFMax, FMAX * KNEE_FORCE_SCALAR);
	dJointSetHingeParam(rightKnee, dParamFMax, FMAX * KNEE_FORCE_SCALAR);

#ifdef FEET
	dJointSetHingeParam(leftAnkle, dParamFMax, FMAX * ANKLE_FORCE_SCALAR);
	dJointSetHingeParam(rightAnkle, dParamFMax, FMAX * ANKLE_FORCE_SCALAR);
#endif

#ifdef COMPLEX_MODEL
	dJointSetUniversalParam(leftShoulder, dParamVel, 0);
	dJointSetUniversalParam(rightShoulder, dParamVel, 0);
	dJointSetUniversalParam(leftShoulder, dParamVel2, 0);
	dJointSetUniversalParam(rightShoulder, dParamVel2, 0);

	dJointSetHingeParam(leftElbow, dParamVel, 0);
	dJointSetHingeParam(rightElbow, dParamVel, 0);

	dJointSetHingeParam(neck, dParamVel, 0);
#endif

	dJointSetUniversalParam(leftHip, dParamVel, 0);
	dJointSetUniversalParam(rightHip, dParamVel, 0);
	dJointSetUniversalParam(leftHip, dParamVel2, 0);
	dJointSetUniversalParam(rightHip, dParamVel2, 0);

	dJointSetHingeParam(leftKnee, dParamVel, 0);
	dJointSetHingeParam(rightKnee, dParamVel, 0);

#ifdef FEET
	dJointSetHingeParam(leftAnkle, dParamVel, 0);
	dJointSetHingeParam(rightAnkle, dParamVel, 0);
#endif
}



//The following functions are to help the evolution system.
vector3df Human::GetHeadPosition()
{   return (head->GetPosition());  }

dReal Human::HeadHeightAboveFeet()
{   dReal headHeightAboveFeet = head->GetPosition().Y - leftFoot->GetPosition().Y; return headHeightAboveFeet; }

dReal Human::ForwardDistanceOfFeet()
{   dReal distance = leftFoot->GetPosition().Z + rightFoot->GetPosition().Z; return distance; }

dReal Human::AverageForwardDistanceOfFeet()
{   dReal distance = (leftFoot->GetPosition().Z + rightFoot->GetPosition().Z)/2; return distance; }


dReal Human::AverageForwardDistance()
{
	dReal distance = 0;

#ifdef COMPLEX_MODEL
	distance += head->GetPosition().Z;
	distance += leftUpperArm->GetPosition().Z;
	distance += rightUpperArm->GetPosition().Z;
	distance += leftLowerArm->GetPosition().Z;
	distance += rightLowerArm->GetPosition().Z;
#endif
	distance += torso->GetPosition().Z;
	distance += leftUpperLeg->GetPosition().Z;
	distance += rightUpperLeg->GetPosition().Z;
	distance += leftLowerLeg->GetPosition().Z;
	distance += rightLowerLeg->GetPosition().Z;
#ifdef FEET
	distance += leftFoot->GetPosition().Z;
	distance += rightFoot->GetPosition().Z;
#endif

#ifdef COMPLEX_MODEL
	distance /= 12.0;
#else

#ifdef FEET
	distance /= 7.0;
#else
	distance /= 5.0;
#endif
#endif

	return distance;
}

dReal Human::ZDistanceBetweenFeet()
{ 	dReal distance = abs(leftFoot->GetPosition().Z - rightFoot->GetPosition().Z); return distance; }

dReal Human::CombinedFeetHeight()
{   dReal height = leftFoot->GetPosition().Y + rightFoot->GetPosition().Y; return height; }

dReal Human::LeftFootHeight() 
{  dReal height = leftFoot->GetPosition().Y; return height; }

dReal Human::RightFootHeight()
{  dReal height = rightFoot->GetPosition().Y; return height; }

bool Human::LeftFootMovingDownward()
{   if (dBodyGetLinearVel(leftFoot->GetBodyID())[1] < 0) return true; else return false; }

bool Human::RightFootMovingDownward() 
{ if (dBodyGetLinearVel(rightFoot->GetBodyID())[1] < 0) return true; else return false; }


double lgt = 0;

void Human::UseBrain(double stepsize)
{
	int i;

	vector<double> inputs;
    vector<double> outputs;
	vector<double> angles;

	inputs.clear();
	outputs.clear();
	angles.clear();

	if (brain == NULL)	return;

	// Joint angles - 15 angles
#ifdef COMPLEX_MODEL
	angles.push_back(dJointGetHingeAngle(neck));

	angles.push_back(dJointGetUniversalAngle1(leftShoulder));
	angles.push_back(dJointGetUniversalAngle2(leftShoulder));
	angles.push_back(dJointGetUniversalAngle1(rightShoulder));
	angles.push_back(dJointGetUniversalAngle2(rightShoulder));

	angles.push_back(dJointGetHingeAngle(leftElbow));
	angles.push_back(dJointGetHingeAngle(rightElbow));
#endif

	angles.push_back(dJointGetUniversalAngle1(leftHip));
	angles.push_back(dJointGetUniversalAngle2(leftHip));
	angles.push_back(dJointGetUniversalAngle1(rightHip));
	angles.push_back(dJointGetUniversalAngle2(rightHip));

	angles.push_back(dJointGetHingeAngle(leftKnee));
	angles.push_back(dJointGetHingeAngle(rightKnee));

#ifdef FEET
	angles.push_back(dJointGetHingeAngle(leftAnkle));
	angles.push_back(dJointGetHingeAngle(rightAnkle));
#endif

/*	for(i=0; i<brain->inputs.size(); i++) 
	{
		switch(i)
		{
		case 0: // head
    		inputs.push_back(angles[i]);
			Scale(inputs[i], JOINT_LIMIT_HEAD_FORW_BACK_MIN, JOINT_LIMIT_HEAD_FORW_BACK_MAX, ACTIVATION_LOW_LIMIT, 1);
			break;

		case 1: // upper arms forw/back
		case 2:
    		inputs.push_back(angles[i]);
			Scale(inputs[i], JOINT_LIMIT_ARMS_FORW_BACK_MIN, JOINT_LIMIT_ARMS_FORW_BACK_MAX, ACTIVATION_LOW_LIMIT, 1);
			break;
		case 3: // upper arms sides
		case 4:
    		inputs.push_back(angles[i]);
			Scale(inputs[i], JOINT_LIMIT_ARMS_SIDES_MIN, JOINT_LIMIT_ARMS_SIDES_MAX, ACTIVATION_LOW_LIMIT, 1);
			break;
		case 5: // elbows
		case 6:
    		inputs.push_back(angles[i]);
			Scale(inputs[i], JOINT_LIMIT_ELBOWS_FORW_BACK_MIN, JOINT_LIMIT_ELBOWS_FORW_BACK_MAX, ACTIVATION_LOW_LIMIT, 1);
			break;
		case 7: // hips forw/back
		case 8:
    		inputs.push_back(angles[i]);
			Scale(inputs[i], JOINT_LIMIT_HIPS_FORW_BACK_MIN, JOINT_LIMIT_HIPS_FORW_BACK_MAX, ACTIVATION_LOW_LIMIT, 1);
			break;
//opencomment		case 9: // hips sides
		case 10:
    		inputs.push_back(angles[i]);
			Scale(a, ACTIVATION_LOW_LIMIT, 1, JOINT_LIMIT_HIPS_SIDES_MIN, JOINT_LIMIT_HIPS_SIDES_MAX);
			break;
//closecomment		case 9: // knees
		case 10:
    		inputs.push_back(angles[i]);
			Scale(inputs[i], JOINT_LIMIT_KNEES_FORW_BACK_MIN, JOINT_LIMIT_KNEES_FORW_BACK_MAX, ACTIVATION_LOW_LIMIT, 1);
			break;
#ifdef FEET
		case 11: // ankles
		case 12:
    		inputs.push_back(angles[i]);
			Scale(inputs[i], JOINT_LIMIT_ANKLES_FORW_BACK_MIN, JOINT_LIMIT_ANKLES_FORW_BACK_MAX, ACTIVATION_LOW_LIMIT, 1);
			break;
#endif
		}

	}
*/

	// Head Velocity - 6 inputs - 2 each
	// 0: X-
	// 1: X+
	// 2: Y-
	// 3: Y+
	// 4: Z-
	// 5: Z+

	const dReal* headVelocity = dBodyGetLinearVel(head->GetBodyID());

	if (headVelocity[0] < 0) // negative?
	{
		inputs.push_back( (-headVelocity[0]) / HEAD_VELOCITY_NORMALIZE); // 0
		inputs.push_back( 0 );                                           // 1
	}
	else
	{
		inputs.push_back( 0 );                                           // 0
		inputs.push_back( headVelocity[0] / HEAD_VELOCITY_NORMALIZE);    // 1
	}

	if (headVelocity[1] < 0) // negative?
	{
		inputs.push_back( (-headVelocity[1]) / HEAD_VELOCITY_NORMALIZE); // 2
		inputs.push_back( 0 );                                           // 3
	}
	else
	{
		inputs.push_back( 0 );                                           // 2
		inputs.push_back( headVelocity[1] / HEAD_VELOCITY_NORMALIZE);    // 3
	}

	if (headVelocity[2] < 0) // negative?
	{
		inputs.push_back( (-headVelocity[2]) / HEAD_VELOCITY_NORMALIZE); // 4
		inputs.push_back( 0 );                                           // 5
	}
	else
	{
		inputs.push_back( 0 );                                           // 4
		inputs.push_back( headVelocity[2] / HEAD_VELOCITY_NORMALIZE);    // 5
	}


	// Body Z Velocity - 0 inputs
/*	const dReal* vel = dBodyGetLinearVel(torso->GetBodyID());
	inputs.push_back(vel[0] / TORSO_VELOCITY_NORMALIZE);
	inputs.push_back(vel[1] / TORSO_VELOCITY_NORMALIZE);
	inputs.push_back(vel[2] / TORSO_VELOCITY_NORMALIZE);
*/
	double d;
	
	// Head Height - 1 inputs
//	d = head->GetPosition().Y;
//	if (d<0) d=0;
//	inputs.push_back(d / HEAD_HEIGHT_NORMALIZE);

	// Torso Height - 0 inputs
//	d = torso->GetPosition().Y;
//	if (d<0) d=0;
//	inputs.push_back(d / TORSO_HEIGHT_NORMALIZE);

    // bias input
	//inputs.push_back(1);


	//clamp the inputs to the range of [-1..1]
	/*for(int i=0; i<inputs.size(); i++) { Clamp(inputs[i], -1, 1); }*/
	time+=stepsize;

	//pass inputs to brain and get outputs
	brain->load_sensors(inputs);
	brain->activate_CTRNN(CTRNN_STEP_SIZE, true);
//	brain->activate_normal_simple_fast(true);

	int p=7;

	// here we check for cyclic activity of hip1
	if ((brain->outputs[p]->activation > HIGH_TRESHOLD) && (previous_hip1_state == 0)) hip1_cycles++;
    if ((brain->outputs[p]->activation < LOW_TRESHOLD) 	&& (previous_hip1_state == 1)) hip1_cycles++;
	if (brain->outputs[p]->activation > HIGH_TRESHOLD)	previous_hip1_state = 1;
	if (brain->outputs[p]->activation < LOW_TRESHOLD) previous_hip1_state = 0;
	// here we check for cyclic activity of hip2
	if ((brain->outputs[p+1]->activation > HIGH_TRESHOLD) && (previous_hip2_state == 0)) hip2_cycles++;
    if ((brain->outputs[p+1]->activation < LOW_TRESHOLD) 	&& (previous_hip2_state == 1)) hip2_cycles++;
	if (brain->outputs[p+1]->activation > HIGH_TRESHOLD)	previous_hip2_state = 1;
	if (brain->outputs[p+1]->activation < LOW_TRESHOLD) previous_hip2_state = 0;
	// here we check for cyclic activity of knee1
	if ((brain->outputs[p+2+2]->activation > HIGH_TRESHOLD) && (previous_knee1_state == 0)) knee1_cycles++;
    if ((brain->outputs[p+2+2]->activation < LOW_TRESHOLD) 	&& (previous_knee1_state == 1)) knee1_cycles++;
	if (brain->outputs[p+2+2]->activation > HIGH_TRESHOLD)	previous_knee1_state = 1;
	if (brain->outputs[p+2+2]->activation < LOW_TRESHOLD) previous_knee1_state = 0;
	// here we check for cyclic activity of knee2
	if ((brain->outputs[p+3+2]->activation > HIGH_TRESHOLD) && (previous_knee2_state == 0)) knee2_cycles++;
    if ((brain->outputs[p+3+2]->activation < LOW_TRESHOLD) 	&& (previous_knee2_state == 1)) knee2_cycles++;
	if (brain->outputs[p+3+2]->activation > HIGH_TRESHOLD)	previous_knee2_state = 1;
	if (brain->outputs[p+3+2]->activation < LOW_TRESHOLD) previous_knee2_state = 0;
	


	for(i=0; i<brain->outputs.size(); i++) 
	{
		double a=0;

		/////////////////////////////////////////
		// DEBUG
		/*if (brain->outputs[i]->substrate_x < 0)
			brain->outputs[i]->activation = 1;
		else
			brain->outputs[i]->activation = 0;*/
		/////////////////////////////////////////


		// output is in -1 .. 1
		a = brain->outputs[i]->activation;

		// Now scale it relative to the corresponding joint's angle range, to extract the original angle
		switch(i)
		{
		case 0: // head
			Scale(a, ACTIVATION_LOW_LIMIT, 1, JOINT_LIMIT_HEAD_FORW_BACK_MIN, JOINT_LIMIT_HEAD_FORW_BACK_MAX);
			break;

		case 1: // upper arms forw/back
		case 3:
			Scale(a, ACTIVATION_LOW_LIMIT, 1, JOINT_LIMIT_ARMS_FORW_BACK_MIN, JOINT_LIMIT_ARMS_FORW_BACK_MAX);
			break;
		case 2: // upper arms sides
		case 4:
			Scale(a, ACTIVATION_LOW_LIMIT, 1, JOINT_LIMIT_ARMS_SIDES_MIN, JOINT_LIMIT_ARMS_SIDES_MAX);
			break;

		case 5: // elbows
		case 6:
			Scale(a, ACTIVATION_LOW_LIMIT, 1, JOINT_LIMIT_ELBOWS_FORW_BACK_MIN, JOINT_LIMIT_ELBOWS_FORW_BACK_MAX);
			break;

		case 7: // hips forw/back
		case 9:
			Scale(a, ACTIVATION_LOW_LIMIT, 1, JOINT_LIMIT_HIPS_FORW_BACK_MIN, JOINT_LIMIT_HIPS_FORW_BACK_MAX);
			break;
		case 8: // hips sides
		case 10:
			Scale(a, ACTIVATION_LOW_LIMIT, 1, JOINT_LIMIT_HIPS_SIDES_MIN, JOINT_LIMIT_HIPS_SIDES_MAX);
			break;

		case 11: // knees
		case 12:
			Scale(a, ACTIVATION_LOW_LIMIT, 1, JOINT_LIMIT_KNEES_FORW_BACK_MIN, JOINT_LIMIT_KNEES_FORW_BACK_MAX);
			break;
#ifdef FEET
		case 13: // ankles
		case 14:
			Scale(a, ACTIVATION_LOW_LIMIT, 1, JOINT_LIMIT_ANKLES_FORW_BACK_MIN, JOINT_LIMIT_ANKLES_FORW_BACK_MAX);
			break;
#endif
		}

		outputs.push_back( (a - angles[i]) * PD_RATE ); // (desired - actual) * rate
	}

	int op=0;

#ifdef COMPLEX_MODEL
	dJointSetHingeParam(neck, dParamVel, outputs[op++]);

	dJointSetUniversalParam(leftShoulder, dParamVel, outputs[op++]);
	dJointSetUniversalParam(leftShoulder, dParamVel2, outputs[op++]);
	dJointSetUniversalParam(rightShoulder, dParamVel, outputs[op++]);
	dJointSetUniversalParam(rightShoulder, dParamVel2, outputs[op++]);

	dJointSetHingeParam(leftElbow, dParamVel, -outputs[op++]);
	dJointSetHingeParam(rightElbow, dParamVel, -outputs[op++]);
#endif 

	dJointSetUniversalParam(leftHip, dParamVel, outputs[op++]);
	dJointSetUniversalParam(leftHip, dParamVel2, outputs[op++]);
	dJointSetUniversalParam(rightHip, dParamVel, outputs[op++]);
	dJointSetUniversalParam(rightHip, dParamVel2, outputs[op++]);

	dJointSetHingeParam(leftKnee, dParamVel, outputs[op++]);
	dJointSetHingeParam(rightKnee, dParamVel, outputs[op++]);

#ifdef FEET
	dJointSetHingeParam(leftAnkle, dParamVel, outputs[op++]);
	dJointSetHingeParam(rightAnkle, dParamVel, outputs[op++]);
#endif



//	dJointAddUniversalTorques(leftHip, outputs[op+1], outputs[op]); op += 2;
//	dJointAddUniversalTorques(rightHip, outputs[op+1], outputs[op]); op += 2;

//	dJointAddHingeTorque(leftKnee, outputs[op++]);
//	dJointAddHingeTorque(rightKnee, outputs[op++]);

//	dJointAddHingeTorque(leftAnkle, outputs[op++]);
//	dJointAddHingeTorque(rightAnkle, outputs[op++]);
}



void Human::Update()
{
#ifdef COMPLEX_MODEL
	head->UpdateNode();
	leftUpperArm->UpdateNode();
	rightUpperArm->UpdateNode();
	leftLowerArm->UpdateNode();
	rightLowerArm->UpdateNode();
#endif
	leftUpperLeg->UpdateNode();
	rightUpperLeg->UpdateNode();
	leftLowerLeg->UpdateNode();
	rightLowerLeg->UpdateNode();
#ifdef FEET
	leftFoot->UpdateNode();
	rightFoot->UpdateNode();
#endif
	torso->UpdateNode();

}



Human::~Human()
{
#ifdef COMPLEX_MODEL
	dJointDestroy(leftElbow);
	dJointDestroy(rightElbow);
	dJointDestroy(leftShoulder);
	dJointDestroy(rightShoulder);
	dJointDestroy(neck);
#endif
	dJointDestroy(leftHip);
	dJointDestroy(rightHip);
	dJointDestroy(leftKnee);
	dJointDestroy(rightKnee);
#ifdef FEET
	dJointDestroy(leftAnkle);
	dJointDestroy(rightAnkle);
#endif

	//don't delete brain; it will get deleted externally
#ifdef COMPLEX_MODEL
	delete head;
	delete leftUpperArm;
	delete rightUpperArm;
	delete leftLowerArm;
	delete rightLowerArm;
#endif
	delete leftUpperLeg;
	delete rightUpperLeg;
	delete leftLowerLeg;
	delete rightLowerLeg;
#ifdef FEET
	delete leftFoot;
	delete rightFoot;
#endif
	delete torso;
}
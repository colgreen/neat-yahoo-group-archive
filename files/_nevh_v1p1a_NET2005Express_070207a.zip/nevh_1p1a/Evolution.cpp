#include <iostream>
#include "headers.h"
#include "ode\ode.h"
#include "human.h"
#include "physics.h"
#include "neat\utils.h"
#include "neat\neat.h"
#include "neat\gene.h"
#include "neat\population.h"
#include "neat\network.h"
#include "neat\organism.h"
#include "neat\math_vectors.h"
#include "neat\math_matrix.h"
#include "neat\visual.h"
#include "neat\substrate.h"

using namespace NEAT;

NEAT::Population* pop;
NEAT::Substrate* subst;

//#define FS_NEAT


// Initialize the population of genotypes for neural networks (and the NNs too)...
void init_population(char* genomefile)
{
	NEAT::load_neat_params("params.ini", false);
	vector<Genome*> genomes;
	Genome* genome = NULL;

	// The user wants to load it from file?
    if (genomefile!=NULL)
	{
		std::ifstream iFile(genomefile);
		genome=new Genome(0,iFile);
		pop = new Population(genome, NEAT::pop_size, 1);//0);
	}
	else
	{
		// A random one... With very minimal structure, of course
again:
		// CTRNN
		//genome = new Genome(0, 0, 11, 4, 0, false, 0.1);
		//genome = new Genome(4, 4, 1, 2);
		//genome = new Genome(0, 4, 11, false, true); 
		
		// CPPN    
#ifndef FS_NEAT
		genome = new Genome(6, 3, 0, 0);
#else
		genome = new Genome(0, 6, 3, 0, 0, false, 0.001); // FS-NEAT
#endif

		// ensure that there is a network with at least one connection
		while (genome->genes.size() == 0)
		{
			// oh, a genome with no links? delete it and ask for the next... 
			delete genome;
 			genome = new Genome(0, 6, 3, 0, 0, false, 0.001);
		}

		////////////////////////////////////////////////////////////////////
		// CPPN setup                                                     //
		////////////////////////////////////////////////////////////////////

#ifdef FS_NEAT
		// * the first link must have the first output node as outgoing
		// * and the first input node as incoming
		if 
			(
			(genome->genes[0]->lnk->out_node->node_id != (6 +1))
			||
			(genome->genes[0]->lnk->in_node->node_id != 5) 
			)
		{
			delete genome;
			goto again;
		}
#endif

		// Make the outputs as I want to (experimental)
		genome->nodes[5 + 1]->ftype = (NEAT::functype)NEAT::GAUSS;   // Link - Weight
		genome->nodes[5 + 2]->ftype = (NEAT::functype)NEAT::SIGMOID;   // Node - Time Constant
		genome->nodes[5 + 3]->ftype = (NEAT::functype)NEAT::SIGMOID;   // Node - Bias
		
		genome->nodes[5 + 1]->sftype = (NEAT::sfunctype)NEAT::ADD;   // Link - Weight
		genome->nodes[5 + 2]->sftype = (NEAT::sfunctype)NEAT::ADD;   // Node - Time Constant
		genome->nodes[5 + 3]->sftype = (NEAT::sfunctype)NEAT::ADD;   // Node - Bias

		// some debug info
		printf("Genome #%d - Genes: %d\n\n", 0, genome->genes.size());

	    // create the population from the genome
	    pop = new Population(genome, NEAT::pop_size);
	}

	////////////////////////////////////////////////////////////////////
	// Substrate setup                                                //
	////////////////////////////////////////////////////////////////////

	subst = new Substrate(NEAT::CIRCULAR, 4, 15, 15); 

	// ***************************************************************************
	// At this point, we can set the substrate to fit the geometry of the problem
	// We can set the node positions to form a human-like shape
	// Important nodes will be close to each other
	// The coords should be in the range ot [-1..1]
	// ***************************************************************************
	// The numbers of inputs/outputs are:
	// 0 - neck
	// 1 - left shoulder axis 1
	// 2 - left shoulder axis 2
	// 3 - right shoulder axis 1
	// 4 - right shoulder axis 2
	// 5 - left elbow
	// 6 - right elbow
	// 7 - left hip axis 1
	// 8 - left hip axis 2
	// 9 - right hip axis 1
	// 10 - right hip axis 2
	// 11 - left knee 
	// 12 - right knee
	// 13 - left foot
	// 14 - right foot
	// ***************************************************************************


    // Head velocity inputs
	subst->inputs[0].x = 1;   // X-
	subst->inputs[0].y = 0;   // X- 
	subst->inputs[1].x = -1;   // X+
	subst->inputs[1].y = 0;  // X+ 

	subst->inputs[2].x = 0;   // Y-
	subst->inputs[2].y = -1;   // Y- 
	subst->inputs[3].x = 0;   // Y+
	subst->inputs[3].y = 1;  // Y+ 
	

	
	// Joint angle outputs
	// neck
	subst->outputs[0].x = 0;
	subst->outputs[0].y = 6;

	// lsh1
	subst->outputs[1].x = -6;
	subst->outputs[1].y = 4;

	// lsh2
	subst->outputs[2].x = -4;
	subst->outputs[2].y = 4;

	// rsh1
	subst->outputs[3].x = 6;
	subst->outputs[3].y = 4;

	// rsh2
	subst->outputs[4].x = 4;
	subst->outputs[4].y = 4;

	// le
	subst->outputs[5].x = -5;
	subst->outputs[5].y = 2;

	// re
	subst->outputs[6].x = 5;
	subst->outputs[6].y = 2;

	// lh1
	subst->outputs[7].x = -3;
	subst->outputs[7].y = -4;

	// lh2
	subst->outputs[8].x = -6;
	subst->outputs[8].y = -4;

	// rh1
	subst->outputs[9].x = 3;
	subst->outputs[9].y = -4;

	// rh2
	subst->outputs[10].x = 6;
	subst->outputs[10].y = -4;

	// lk
	subst->outputs[11].x = -4.5;
	subst->outputs[11].y = -5;

	// rk 
	subst->outputs[12].x = 4.5;
	subst->outputs[12].y = -5;

	// la
	subst->outputs[13].x = -4.5;
	subst->outputs[13].y = -6;

	// ra 
	subst->outputs[14].x = 4.5;
	subst->outputs[14].y = -6;

	// normalize coords
	for(int i=0; i<15; i++)
	{
		subst->outputs[i].x /= 6;
		subst->outputs[i].y /= 6;
		subst->outputs[i].z  = 0;
	}
	for(int i=0; i<4; i++)
	{
		subst->inputs[i].x /= 6;
		subst->inputs[i].y /= 6;
		subst->inputs[i].z  = 0;
	}

}





////////////////////////////////////////////////
// some shitty globals and defines
int gen = 0;
char* genome_file_name = "genomes\\best_at";
////////////////////////////////////////////////

void evolve()
{
	// variables used in the function
	char filename[128];
	double best;
	int best_index;
	int i;

	// save the best genome every generation
	best = 0;
	best_index = 0;
	for(i=0; i<NEAT::pop_size; i++)
	{
		if (pop->organisms[i]->fitness > best)
		{
			best = pop->organisms[i]->fitness;
			best_index = i;
		}
	}

	// the format of the file name is "filename_generation_fitness.txt"
	sprintf(filename, "%s_%d_fitness_is_%3.5f.txt", genome_file_name, gen, best);

	//so save it
	pop->organisms[best_index]->gnome->print_to_filename(filename);

    // Perform a NEAT epoch (reproduce the next brains)
	pop->epoch(++gen);
}

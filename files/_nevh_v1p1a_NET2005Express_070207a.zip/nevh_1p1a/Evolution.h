#include "headers.h"

extern NEAT::Population* pop;
void init_population(char* file);
void evaluate(NEAT::Organism* org);
void evolve();
//////////////////////
// Physics engine data

#define MAX_CONTACTS 2048

extern dWorldID physics_world;
extern dSpaceID physics_space;
extern dGeomID plane;
extern dJointGroupID conts;

void nearCollisionCallback(void* data, dGeomID o1, dGeomID o2);
void init_physics();
double ElapsedTime();


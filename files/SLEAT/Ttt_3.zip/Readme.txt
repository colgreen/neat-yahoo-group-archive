TTTST.exe is the stand-alone system tray program.

TTTSS.scr is the screen-saver if anybody is interested.

---

For TTTST:

Arrange for this exe to be launched when the machine starts, say by
putting a short-cut to it in the program menu startup folder.

Run the program.

Now right click on the system tray icon, and a configuration menu
should appear.  In the text box enter the path to a folder that
the program can use for working space - such as c:\temp\TTT or
something similar...

When you click OK, three folders will be created in that folder:

"todo"
"current_st"
"done"

Then copy the folder _testjob1 into "todo".

If you now right click on the icon again and just click OK (which
makes it check for new jobs as it will have just decided there is
nothing to do and gone to sleep) then you should see _testjob1
dissappear from "todo" and appear in "current_st".

If you can make that work, drop me a note and I will send you
some real jobs...

--

For the screen saver, copy it into your windows system32 folder
(that's where screen savers go, yes it seems a bit insecure to me
too).  Then right click on the desktop, get "properties" and
configure as a standard screen saver.  The "settings..." button
will give you a configuration dialog very like the one I described
above, just set it up the same way...

Thanks,

	Ian

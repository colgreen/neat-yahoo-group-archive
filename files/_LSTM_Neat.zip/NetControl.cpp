#include "StdAfx.h"
#include ".\netcontrol.h"


CParams   g_Params;

static int LARGE=800;
static int WIDE=600;

CNetControl::CNetControl(void)
{
	active = false;
	// Load Parameters
	g_Params.Initialize();
   // Initialize Population
	dat = new CData;
	dat->LoadData("xor_serie.nat");
	m_pPop = new Cga(CParams::iPopSize,
                   dat->GetInputs(),
                   dat->GetOutputs());
	m_nGeneration =0; // Reset epoch counter.
 //create the phenotypes
   pBrains = m_pPop->CreatePhenotypes();
//Ejemplo de red.
     
	 vector<SData> d; 
	 vector<double> in;vector<double> out;
	//Cargamos los datos 
	 
//---Datos del Thread------------------------------------------------
		
	m_recalcThreadInfo.voidParam  = (void*)this;
	m_hEventStartRecalc = CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially reset
	m_hEventRecalcDone = CreateEvent(NULL, TRUE, TRUE, NULL); // manual reset, initially set
	m_hEventKillRecalcThread = CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially reset
	m_hEventRecalcThreadKilled = CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially reset
	Sincro = CreateEvent(NULL, TRUE, TRUE, NULL); // manual reset, initially set
	m_recalcThreadInfo.m_hEventStartRecalc = m_hEventStartRecalc;
	m_recalcThreadInfo.m_hEventRecalcDone = m_hEventRecalcDone;
	m_recalcThreadInfo.m_hEventKillRecalcThread = m_hEventKillRecalcThread;
	m_recalcThreadInfo.m_hEventRecalcThreadKilled = m_hEventRecalcThreadKilled;
	m_recalcThreadInfo.Sincro=Sincro;
	m_pRecalcWorkerThread = NULL;
//------------------------------------------------------------------------

	
}

CNetControl::~CNetControl(void)
{
	KillThread();
	/*if(m_recalcThreadInfo.ESTADO_THREAD)
	{ SetEvent(m_recalcThreadInfo.m_hEventKillRecalcThread);
		WaitForSingleObject(m_recalcThreadInfo.m_hEventRecalcThreadKilled, INFINITE);
	}*/
	ControlBitmap.DeleteObject(); //Borramos el objeto.
	ControlBitmap2.DeleteObject(); //Borramos el objeto.

	if (m_pPop)
  {
    delete m_pPop;
  }

  	if (dat)
  {
    delete dat;
  }
}

// // Render a group of networks
void CNetControl::RenderBest(HDC &surface)
{
	vector<CNeuralNet*> m_best;
	m_best = m_pPop->GetBestPhenotypesFromLastGeneration();
	if(m_nGeneration)
	{
		for(int i=0;i<CParams::iNumBestSweepers;i++)
		{
			m_best[i]->DrawNet(dat,surface,i*75+20,i*75+150,200,10);
			m_best[i]->PrintStats(dat,surface,75,220+20*i);
			
		}
	}
}

void CNetControl::RenderNeuron(HDC & surface, int n)
{
	pBrains[n]->DrawNet(dat,surface,50,210,400,200);
}

vector<double> CNetControl::CalculateFitness(void)
{


	vector<double> fitness;

	vector<double> inputs,outputs;
	vector<SData> data;
	double fit=0,temp,temp1,temp2,error;
	int i,j,t,neur;
    //Calculate individual fitness
for (neur=0;neur<pBrains.size();neur++)
{
	for (j=0;j<dat->Sequences.size();j++)
	{
		data=dat->Sequences[j].vecSequence;
		// go though overall data.
			for(t=0;t<data.size();t++)
			{
		//We run the net in active mode at the beginning, at the end data we run
		//it in snapshot mode.
		if(t==data.size()-1)
			outputs = pBrains[neur]->Update(data[t].vecInData,CNeuralNet::run_type::snapshot); 
		else
			outputs = pBrains[neur]->Update(data[t].vecInData,CNeuralNet::run_type::active); 
			
		//**Borrar** 
		temp=data[t].vecInData[0];
		temp1=data[t].vecOutData[0];
		temp2=outputs[0];
			
			for (i=0;i<dat->GetOutputs();i++)
				fit += (error=fabs(outputs[i]-data[t].vecOutData[i])); //We get it negative because it's an error.

			}
	
	}
//	fitness.push_back(3-fit-pBrains[neur]->GetSize()/10);//+0.0005+pBrains[neur]->GetSize()/50));
	fitness.push_back(1/(fit+pBrains[neur]->GetSize()/10));//+0.0005+pBrains[neur]->GetSize()/50));
	fit=0;
}
 
	return fitness;

}

void CNetControl::Epoch(void)
{
	double val;
	//***
	/*if(m_nGeneration>1939)
	{
	for(int i=0;i<pBrains.size();i++);



	}*/
	pBrains = m_pPop->Epoch(CalculateFitness());
	
/*	vector<double> in,out;
	in.push_back(1);/////////////
	//in.push_back(0);
	double output;
	pBrains[1]->Reset();
	out= pBrains[1]->Update(in,CNeuralNet::run_type::active);
	val=out[0];
//	if(ControlDC2.m_hDC)
//		RenderNeuron(dc->m_hDC,0);
	//pBrains[0]->PrintStats(dat,ControlDC.m_hDC,150+20,220+20*5);
	in.pop_back();
	output= out[0];
	in.push_back(0);/////////////
	out=pBrains[0]->Update(in,CNeuralNet::run_type::snapshot );
	output= out[0];
*/	
	val = m_pPop->BestEverFitness();
	m_nGeneration++;

}

// // Thread fo the Control Process
void CNetControl::StartThread(void)
{

	//Iniciamos el HWND del Thread para poder recibir Mensajes
	/*POSITION pos = GetFirstViewPosition();
	ASSERT(pos != NULL);
	CView* pView = GetNextView(pos);
	ASSERT(pView != NULL);
	m_recalcThreadInfo.m_hwndNotifyRecalcDone = pView->m_hWnd;*/
	//Data.THREAD_INFO = &m_recalcThreadInfo;

	m_pRecalcWorkerThread =
			AfxBeginThread(RecalcThreadProc, &m_recalcThreadInfo);
	SetEvent(m_recalcThreadInfo.m_hEventStartRecalc); 
	SetEvent(m_recalcThreadInfo.Sincro); 
}

void CNetControl::KillThread(void)
{
	// Eliminamos el Thread
	SetEvent(m_hEventKillRecalcThread);
	SetEvent(m_hEventStartRecalc); //Activamos el thread
		
	// Esperamos a que termine el proceso
if (m_recalcThreadInfo.ESTADO_THREAD==1 )
	while(WaitForSingleObject(m_hEventRecalcThreadKilled, 0)
								!= WAIT_OBJECT_0);
}





UINT RecalcThreadProc(LPVOID pParam /* CRecalcThreadInfo ptr */)
{
	CRecalcThreadInfo* pRecalcInfo = (CRecalcThreadInfo*)pParam;

	// This recalc thread runs in an infinite loop, waiting to recalculate the
	// result whenever the main application thread sets the "start recalc" event.
	// The recalc thread exits the loop only when the main application sets the
	// "kill recalc" event.
	CNetControl* net = (CNetControl*) pRecalcInfo->voidParam;
	BOOL bRecalcCompleted;
	int MADE=1;
	ResetEvent(pRecalcInfo->m_hEventKillRecalcThread);
	ResetEvent(pRecalcInfo->m_hEventRecalcThreadKilled);
	pRecalcInfo->ESTADO_THREAD=1;
	while (WaitForSingleObject(pRecalcInfo->m_hEventKillRecalcThread, 0) != WAIT_OBJECT_0 
	 	) //Calculamos soluciones del problema
	{
		bRecalcCompleted = FALSE;

		// Esperamos hasta que tengamos mensajes que procesar.
		/* -- Lo eliminamos para s�lo salir desde fuera del thread --
			if (WaitForSingleObject(pRecalcInfo->m_hEventStartRecalc, INFINITE)
				!= WAIT_OBJECT_0)	break;
		*/
			
	//	ResetEvent(pRecalcInfo->m_hEventStartRecalc); //Ponemos el evento a 0.



		// Exit the thread if the main application sets the "kill recalc"
		// event. The main application will set the "start recalc" event
		// before setting the "kill recalc" event.
		
		if (WaitForSingleObject(pRecalcInfo->m_hEventKillRecalcThread, 0)
			== WAIT_OBJECT_0)
			break; // Terminate this thread by existing the proc.

		// Reset event to indicate "not done", that is, recalculation is in progress.
		ResetEvent(pRecalcInfo->m_hEventRecalcDone);
        
		// Hacemos cualquier c�lculo aqu�.*************** ********** *******


	//	 ResetEvent(pRecalcInfo->Sincro);
		 net->Epoch();
		 net->active=true;
		 net->Paint();
		 net->active=false;
		 		 


		// ************** ********** ********************* ********** *******

          // Podemos llamar a un evento creado por el usuario.
          //::SendMessage(pRecalcInfo->m_hwndNotifyRecalcDone,
		//	WM_USER_DIBUJA, 0, 0);



		//****************** ***************** ************** ***********
		
		// Set event to indicate that recalculation is done (i.e., no longer in progres),
		// even if perhaps interrupted by "kill recalc" event detected in the SlowAdd function.
		SetEvent(pRecalcInfo->m_hEventRecalcDone);

	/*	if (!bRecalcCompleted)  // If interrupted by kill then...
			break; // terminate this thread by exiting the proc.

		::PostMessage(pRecalcInfo->m_hwndNotifyRecalcDone,
			WM_USER_RECALC_DONE, 0, 0); */
	}

		
		pRecalcInfo->ESTADO_THREAD=0;
		//pRecalcInfo->problema->SaveSolutionInDB(); //Almacenamos la soluci�n
		SetEvent(pRecalcInfo->m_hEventRecalcThreadKilled);
	return 0;

}
void CNetControl::Paint()
{
	RECT rect = {10,230,200,400};
	ControlDC.BitBlt(0,0,LARGE,WIDE,0,0,0,WHITENESS); //Borramos la pantalla.
	int a = m_nGeneration;
	TextOut(ControlDC.m_hDC ,20,20,ftos(a).c_str(),ftos(a).size());
	RenderBest(ControlDC.m_hDC);
	//______________________
/*	double val=0;
	vector<double> in,out;
	in.push_back(1);
	//in.push_back(0);
	double output;
	pBrains[1]->Reset();
	out= pBrains[0]->Update(in,CNeuralNet::run_type::active);
	val=out[0];
	out= pBrains[0]->Update(in,CNeuralNet::run_type::active);
	out= pBrains[0]->Update(in,CNeuralNet::run_type::active);
	RenderNeuron(ControlDC.m_hDC,0);*/
	//______________________
	//RenderNeuron(ControlDC.m_hDC,0);
	//pDoc->net->pBrains[0]->DrawNet(surface,10,200,200,100);
	m_pPop->RenderSpeciesInfo(ControlDC.m_hDC,rect);
	ControlDC2.BitBlt(0,0,LARGE,WIDE,&ControlDC,0,0,SRCCOPY);
}

int CNetControl::CreateDC(CDC* pDC)
{
	dc=pDC;
	ControlDC.CreateCompatibleDC(pDC);
	ControlBitmap.CreateCompatibleBitmap(pDC,LARGE,WIDE);
	ControlDC.SelectObject(&ControlBitmap);
	ControlDC.BitBlt(0,0,LARGE,WIDE,0,0,0,WHITENESS);
	ControlDC2.CreateCompatibleDC(pDC);
	ControlBitmap2.CreateCompatibleBitmap(pDC,LARGE,WIDE);
	ControlDC2.SelectObject(&ControlBitmap2);
	ControlDC2.BitBlt(0,0,LARGE,WIDE,0,0,0,WHITENESS);
	return 0;
}

void CNetControl::GetPaint(CDC* pDC)
{
	int a = m_nGeneration;
	
    

	pDC->BitBlt(0,0,LARGE,WIDE,&ControlDC2,0,0,SRCCOPY);
	
}

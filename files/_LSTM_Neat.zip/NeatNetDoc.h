// NeatNetDoc.h: interfaz de la clase CNeatNetDoc
//


#pragma once
#include "NetControl.h"

class CNeatNetDoc : public CDocument
{
protected: // Crear s�lo a partir de serializaci�n
	CNeatNetDoc();
    DECLARE_DYNCREATE(CNeatNetDoc)
	~CNeatNetDoc();


// Atributos
public:
	
// Operaciones
public:

// Reemplazos
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementaci�n
public:
	bool m_RUN;
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	
	CNetControl *net; //Net control implementation.
protected:
	
// Funciones de asignaci�n de mensajes generadas
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnNetRun();
	afx_msg void OnNetStop();
	
};



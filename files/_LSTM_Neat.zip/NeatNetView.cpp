// NeatNetView.cpp: implementaci�n de la clase CNeatNetView
//

#include "stdafx.h"
#include "NeatNet.h"

#include "NeatNetDoc.h"
#include "NeatNetView.h"
#include ".\neatnetview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CNeatNetView

IMPLEMENT_DYNCREATE(CNeatNetView, CView)

BEGIN_MESSAGE_MAP(CNeatNetView, CView)
	ON_COMMAND(ID_NET_RUN, OnNetRun)
	ON_COMMAND(ID_NET_STOP, OnNetStop)
	ON_WM_TIMER()
END_MESSAGE_MAP()

// Construcci�n o destrucci�n de CNeatNetView

CNeatNetView::CNeatNetView()
{
	// TODO: agregar aqu� el c�digo de construcci�n

}

CNeatNetView::~CNeatNetView()
{
}

BOOL CNeatNetView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: modificar aqu� la clase Window o los estilos cambiando
	//  CREATESTRUCT cs
	
	return CView::PreCreateWindow(cs);
}

// Dibujo de CNeatNetView

void CNeatNetView::OnDraw(CDC* pDC)
{
	CNeatNetDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	
	RECT rect = {10,230,200,400};
	
	HDC surface = HDC(*pDC);
	if(1)
	{	
		//if(!pDoc->net->active)
		//{
		//	pDoc->net->active = true;
			
	//		pDoc->net->Epoch();
		//	pDoc->net->RenderBest(surface);
			//pDoc->net->pBrains[0]->DrawNet(surface,10,200,200,100);
		//	pDoc->net->m_pPop->RenderSpeciesInfo(surface,rect);
		pDoc->net->GetPaint(pDC);
		//pDoc->net->RenderNeuron(pDC->m_hDC,0);
			//this->Invalidate(1);
		//}
		
		

	}
	
	// TODO: agregar aqu� el c�digo de dibujo para datos nativos
}


// Diagn�sticos de CNeatNetView

#ifdef _DEBUG
void CNeatNetView::AssertValid() const
{
	CView::AssertValid();
}

void CNeatNetView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CNeatNetDoc* CNeatNetView::GetDocument() const // La versi�n de no depuraci�n es en l�nea
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CNeatNetDoc)));
	return (CNeatNetDoc*)m_pDocument;
}
#endif //_DEBUG


// Controladores de mensaje de CNeatNetView

void CNeatNetView::OnNetRun()
{
	CNeatNetDoc* pDoc = GetDocument();
	pDoc->m_RUN=true;
	pDoc->net->StartThread();
	//while(0) pDoc->net->Epoch();
	//OnDraw(this->GetDC());
}

void CNeatNetView::OnNetStop()
{
	CNeatNetDoc* pDoc = GetDocument();
	pDoc->m_RUN=false;
	pDoc->net->KillThread();
}

void CNeatNetView::OnInitialUpdate()
{
		CNeatNetDoc* pDoc = GetDocument();
		CDC* unDC = this->GetDC();
		pDoc->net->CreateDC(this->GetDC());
		ReleaseDC(unDC);
		SetTimer(1,200,0);

}

void CNeatNetView::OnTimer(UINT nIDEvent)
{
	CNeatNetDoc* pDoc = GetDocument();
	CDC* dc_mio = this->GetDC();
	if(dc_mio==NULL)
		dc_mio=dc_mio;
	OnDraw(dc_mio);
	ReleaseDC(dc_mio);
    CView::OnTimer(nIDEvent);
}

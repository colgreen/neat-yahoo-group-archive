// NeatNet.h: archivo de encabezado principal para la aplicaci�n NeatNet
//
#pragma once

#ifndef __AFXWIN_H__
	#error incluye 'stdafx.h' antes de incluir este archivo para PCH
#endif

#include "resource.h"       // S�mbolos principales


// CNeatNetApp:
// Consulte la secci�n NeatNet.cpp para obtener informaci�n sobre la implementaci�n de esta clase
//

class CNeatNetApp : public CWinApp
{
public:
	CNeatNetApp();


// Reemplazos
public:
	virtual BOOL InitInstance();

// Implementaci�n
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CNeatNetApp theApp;

// NeatNetDoc.cpp: implementaci�n de la clase CNeatNetDoc
//

#include "stdafx.h"
#include "NeatNet.h"


#include "NeatNetDoc.h"
#include ".\neatnetdoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CNeatNetDoc

IMPLEMENT_DYNCREATE(CNeatNetDoc, CDocument)

BEGIN_MESSAGE_MAP(CNeatNetDoc, CDocument)
	ON_COMMAND(ID_NET_RUN, OnNetRun)
	ON_COMMAND(ID_NET_STOP, OnNetStop)
END_MESSAGE_MAP()


// Construcci�n o destrucci�n de CNeatNetDoc

CNeatNetDoc::CNeatNetDoc()
{
	// TODO: agregar aqu� el c�digo de construcci�n �nico
	net = new CNetControl;
	m_RUN = false;
}

CNeatNetDoc::~CNeatNetDoc()
{
	// TODO: agregar aqu� el c�digo de construcci�n �nico
	if(net) delete net;
}
BOOL CNeatNetDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: agregar aqu� c�digo de reinicio
	// (los documentos SDI volver�n a utilizar este documento)

	return TRUE;
}




// Serializaci�n de CNeatNetDoc

void CNeatNetDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: agregar aqu� el c�digo de almacenamiento
	}
	else
	{
		// TODO: agregar aqu� el c�digo de carga
	}
}


// Diagn�sticos de CNeatNetDoc

#ifdef _DEBUG
void CNeatNetDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CNeatNetDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// Comandos de CNeatNetDoc

void CNeatNetDoc::OnNetRun()
{
	//Ejecutamos la simulaci�n.
	m_RUN=true;
	
}

void CNeatNetDoc::OnNetStop()
{
	m_RUN=false;
}


// NeatNetView.h: interfaz de la clase CNeatNetView
//


#pragma once


class CNeatNetView : public CView
{
protected: // Crear s�lo a partir de serializaci�n
	CNeatNetView();
	DECLARE_DYNCREATE(CNeatNetView)

// Atributos
public:
	CNeatNetDoc* GetDocument() const;

// Operaciones
public:

// Reemplazos
	public:
	virtual void OnDraw(CDC* pDC);  // Reemplazado para dibujar esta vista
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// Implementaci�n
public:
	virtual ~CNeatNetView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Funciones de asignaci�n de mensajes generadas
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnNetRun();
	afx_msg void OnNetStop();
	virtual void OnInitialUpdate();
	afx_msg void OnTimer(UINT nIDEvent);
};

#ifndef _DEBUG  // Versi�n de depuraci�n en NeatNetView.cpp
inline CNeatNetDoc* CNeatNetView::GetDocument() const
   { return reinterpret_cast<CNeatNetDoc*>(m_pDocument); }
#endif




#include <stdafx.h>
#include <vector>
#include <fstream>

#include "data.h"
#include ".\data.h"



void CData::AddSequence(int seq,SData dat) 
		{ 
			vector<SData> data_in;
			
			if(Sequences.size()<=seq) 
			{
				data_in.push_back(dat);
				Sequences.push_back(SSequence(data_in));
			}
			else
			{
			
				Sequences[seq].vecSequence.push_back(dat); 
			}
		}

void CData::AddSequence(int seq,vector<SData> dat) 
{ 
	
	
	if(Sequences.size()<=seq) 
	{
	
		Sequences.push_back(SSequence(dat));
	}
	else
	{
		 Sequences[seq].vecSequence.clear();
	     Sequences[seq] = SSequence(dat); 
	}
}

bool CData::LoadData(char* szFileName)
{
	ifstream grab(szFileName);
	if (!grab)
  {
    MessageBox(NULL, "Cannot find NAT file!", "error", MB_OK);

    return false;
  }
	char parameter[100];
	long NData;
	int nT;
	int i,j,k,m;
	SData temp;
	vector<SData> VD;
	double d;

	grab >> parameter;
	grab >> NData;
	grab >> parameter;
	grab >> NInputs;
	grab >> parameter;
	grab >> NOutputs;
	for(k=0;k<NData;k++)
	{
		grab >> parameter;
		grab >> nT;
			for(m=0;m<nT;m++)
			{
				for(i=0;i<NInputs;i++)
				{
					grab >> d;
					temp.vecInData.push_back(d);
				}
				for(i=0;i<NOutputs;i++)
				{
					grab >> d;
					temp.vecOutData.push_back(d);
				}
				VD.push_back(temp);
				temp.vecInData.clear();
				temp.vecOutData.clear();
			}
			Sequences.push_back(SSequence(VD));
			VD.clear();
	}			
/*	--------Prueba para la entrada de datos------*/					
		double temp2= Sequences.size();
		for(i=0;i<Sequences.size();i++)
		{
            temp2=Sequences[i].vecSequence.size();
			for(k=0;k<Sequences[i].vecSequence.size();k++)
			{
				temp2=Sequences[i].vecSequence[k].vecInData.size();
				temp2=Sequences[i].vecSequence[k].vecOutData.size();
				temp2=Sequences[i].vecSequence[k].vecInData[0];
				temp2=Sequences[i].vecSequence[k].vecInData[1];
				temp2=Sequences[i].vecSequence[k].vecOutData[0];


			}
		}
           					
return true;

}
int CData::GetInputs(void)
{
	return NInputs;
}

int CData::GetOutputs(void)
{
	return NOutputs;
}

#pragma once

//-------------------------------------------------------------------------
//
//  Name: data.h
//
//  Author: Germ�n Bravo 2004 (gbravoescobar@hotmail.com)
//
//	Desc: definitions required for input/output data vector (time x input+Outputs)
//        
//        
//-------------------------------------------------------------------------

#include <vector>
#include <math.h>
#include <windows.h>
#include <algorithm>

#include "utils.h"
#include "CParams.h"
#include "genes.h"


using namespace std;
//Data class


struct SData
{
	vector<double> vecInData;
	vector<double> vecOutData;
	SData(){}
	SData(vector<double> In, vector<double> Out):vecInData(In),vecOutData(Out)
	{}
};
struct SSequence
{
	 vector<SData> vecSequence;
	 SSequence(){}
	 SSequence(vector<SData> datos):vecSequence(datos)
	 {
		
	 }
};	

class CData
{

   //all the Data Sequences patterns

public:
 vector<SSequence> Sequences;
private: 
 int NInputs;
 int NOutputs;

public:	
	void AddSequence(const int seq,SData dat); 
	void AddSequence(const int seq,vector<SData> dat); 
		

	bool LoadData(char* szfileName);
	int GetInputs(void);
	int GetOutputs(void);
};


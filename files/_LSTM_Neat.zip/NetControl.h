#pragma once

#include <vector>
#include <sstream>
#include <string>

#include "utils.h"
#include "CParams.h"
#include "Cga.h"
#include "data.h"
#include "threads.h"
//-----------------------------------------------------------------
//----------------- NetControl.h Master Control of all Process-----
//-----------------------------------------------------------------

class CNetControl
{
public:
	CNetControl(void);
	~CNetControl(void);
	//storage for the entire population of chromosomes
	Cga*  m_pPop;
	CDC *dc;
	CDC ControlDC;
	CDC ControlDC2;
	CBitmap ControlBitmap;
	CBitmap ControlBitmap2;
	//------DATOS PARA EL THREAD -----
	CWinThread* m_pRecalcWorkerThread;
	CRecalcThreadInfo m_recalcThreadInfo;
	HANDLE m_hEventStartRecalc;
	HANDLE m_hEventRecalcDone;
	HANDLE m_hEventKillRecalcThread;
	HANDLE m_hEventRecalcThreadKilled;
	HANDLE Sincro;
	//--------------------------------
	bool active;
	long m_nGeneration ; // epoch counter.
	vector<CNeuralNet*> pBrains; //Neuron Buffer
	CData *dat; // Pattern Data.
    
	// // Render a group of networks
	void RenderBest(HDC &surface);
	void RenderNeuron(HDC & surface, int n);
	vector<double> CalculateFitness(void);
	void Epoch(void);
	// // Thread fo the Control Process
	void StartThread(void);
	void KillThread(void);


	void Paint();
	int CreateDC(CDC* pDC);
	void GetPaint(CDC* pDC);
};

#ifndef GENES_H
#define GENES_H
//-----------------------------------------------------------------------
//
//  Name: GeneGenes.h
//
//  Author: Mat Buckland 2002 (fup@btinternet.com)
//
//	Desc: neuron and link gene definitions used in the 
//        implementation of Kenneth Owen Stanley's and Risto 
//        Miikkulainen's NEAT idea.These structures are used to define
//        a genome.
//
//-----------------------------------------------------------------------

class CNeuron;

//------------------------------------------------------------------------
//
//  enumeration for all the available neuron types
//------------------------------------------------------------------------
enum neuron_type	//---- From---|------To----|--------------------------|
{					//  NL  |  L  |  NL  |  L  | Sigmoid | Linear | Mult  |
  input,			//		|  X  |  X   |     |         |   X    |       |
  hidden,			//		|  X  |      |  X  |    X    |        |       |
  output,			//	X	|     |      |  X  |    X    |        |       |
  bias,				//		|  X  |  X   |     |         |   X    |       |
  hidden_NL, // Out: Sigmoid,From: No Link To: Link.
  memory_cell, // Long short memory Out: Linear,From: No Link To: No Link.
  mul,		// Product. Out: product ,From: No Link To: No Link.
  mul_out,  // Product OutPut. Out: product ,From: Link To: No Link.
  none
};

enum link_type
{
	normal, //Mutable, divisible.
	peenhole, // Mutable, No divisible.
	fix, //No mutable, No divisible.
};

//------------------------------------------------------------------------
//
//  this structure defines a neuron gene
//------------------------------------------------------------------------
struct SNeuronGene
{  
  //its identification
  int         iID;

  //its type
  neuron_type NeuronType;

  //is it recurrent
  bool        bRecurrent;

  //sets the curvature of the sigmoid function
  double    dActivationResponse;

  //position in network grid
  double    dSplitY, dSplitX;

  SNeuronGene(neuron_type type,
              int         id,
              double      splitY,
              double      splitX,
              bool        r = false,
              double      act = 1):iID(id),
                                   NeuronType(type),
                                   bRecurrent(r),
                                   dSplitY(splitY),
                                   dSplitX(splitX),
                                   dActivationResponse(act)
  {}

  //overload << for streaming
  friend ostream& operator <<(ostream &os, const SNeuronGene &rhs)
  {
    os << "\nNeuron: " << rhs.iID << "  Type: " << rhs.NeuronType
       << "  Recurrent: " << rhs.bRecurrent << "  Activation: " << rhs.dActivationResponse
       << "  SplitX: " << rhs.dSplitX << "  SplitY: " << rhs.dSplitY;
    
    return os;
  }

    //overload '<' used for sorting(we use the innovation ID as the criteria)
	friend bool operator<(const SNeuronGene& lhs, const SNeuronGene& rhs)
	{
		return (lhs.dSplitY  < rhs.dSplitY );
	}
};

//------------------------------------------------------------------------
//
//  this structure defines a link gene
//------------------------------------------------------------------------
struct SLinkGene
{
	//the IDs of the two neurons this link connects		
	int     FromNeuron,
	        ToNeuron;
	
	double	dWeight;

  //flag to indicate if this link is currently enabled or not
  bool    bEnabled;

  //flag to indicate if this link is recurrent or not
  bool    bRecurrent;
	
  int     InnovationID;
  int link_type;

  SLinkGene(){}
  
  SLinkGene(int    in,
            int    out,
            bool   enable,
            int    tag,
            double weight,
            bool   rec = false):bEnabled(enable),
								                InnovationID(tag),
                                FromNeuron(in),
                                ToNeuron(out),
                                dWeight(weight),
                                bRecurrent(rec)
	{ link_type= normal;}

	SLinkGene(int    in,
            int    out,
            bool   enable,
            int    tag,
            double weight, int lnk_type,
            bool   rec = false):bEnabled(enable),
							 	                InnovationID(tag),
                                FromNeuron(in),
                                ToNeuron(out),
                                dWeight(weight),
                                bRecurrent(rec),
								link_type(lnk_type)
	{}

  //overload '<' used for sorting(we use the innovation ID as the criteria)
	friend bool operator<(const SLinkGene& lhs, const SLinkGene& rhs)
	{
		return (lhs.InnovationID < rhs.InnovationID);
	}

  //overload << for streaming
  friend ostream& operator <<(ostream &os, const SLinkGene &rhs)
  {
    os << "\nInnovID: " << rhs.InnovationID << "  From: " << rhs.FromNeuron
       << "  To: " << rhs.ToNeuron << "  Enabled: " << rhs.bEnabled 
       << "  Recurrent: " << rhs.bRecurrent << "  Weight: " << rhs.dWeight;

    return os;
  }
};


                                         
#endif 
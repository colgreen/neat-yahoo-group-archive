



struct CRecalcThreadInfo
{



	// Datos internos del Thread
	HWND m_hwndNotifyRecalcDone; // el HWND del programa padre (No lo utilizamos)
				//La utilizamos para pasar el mensaje de repintar
	HANDLE m_hEventStartRecalc;
	HANDLE m_hEventRecalcDone;
	HANDLE m_hEventKillRecalcThread;
	HANDLE m_hEventRecalcThreadKilled;
	HANDLE Sincro;
	int m_nRecalcSpeedSeconds;
	HWND m_hwndNotifyProgress;
	int ESTADO_THREAD; //1 ACTIVO
	void* voidParam;
};

// Controlling function for the worker thread.
UINT RecalcThreadProc(LPVOID pParam /* CRecalcThreadInfo ptr */);

